//----------------------------------------------------------------------------------------------------------
// 	0	   	1  		2	  	3			4			5			6			7			8	 	 		9				10		11  	  12   		13    14  	 15			
//portMsk, 	0	, 	0	,	dvpx	,	maddr	, 	saddr	, meta_rows	, meta_cols	, edge_rows 	, edge_cols   	,   0	, 	0	 	, 0	 	, 0		, 0		, OP)//OMTX
//portMsk, 	0	, 	0	,	NNEX	,	  0		, 	  0  	, 	0	  	, 	0	 	, 		0	  	, 	0			,   0	, 	0	 	, LS 	, LC	, LOOP	, OP)//NNEX
//portMsk, 	0	, 	0	,	gsml	,	maddr	, 	saddr	, port_rows	, port_cols	, edge_rows  	, edge_cols		,   0 	, meta_cols	, 0	 	, 0  	, 0		, OP)//RIMT_R1
//portMsk, 	0	, 	0	,	gsml	,	maddr	, 	saddr	, port_rows	, port_cols	, edge_rows*2	, edge_cols//2	,   1 	, meta_cols	, 0	 	, 0  	, 0		, OP)//RIMT_R2
//portMsk, 	5	, 	0	,	0   	,	maddr	,	hbias	, meta_rows	, meta_cols	, hubs_cols		, hubs_dmmy		, port	, 	0		, 0	 	, 0		, 0		, 0)//RISM
//**********************************************************************************************************
//OMTX_DOWN -> NNEX_ATTN -> RIMT_ATTN -> RISM_ATTN
//OMTX_ATTN -> NNEX_OUTP -> RIMT_OUTP -> RISM_OUTP
//OMTX_OUTP -> NNEX_UGAT -> RIMT_UGAT -> RISM_UGAT
//OMTX_UGAT -> NNEX_DOWN -> RIMT_DOWN -> RISM_DOWN
//OMTX_DOWN -> NNEX_VCBR -> RIMT_VCBR -> RISM_VCBR
//**********************************************************************************************************
module	supv_cmnd_nnex_gens(
	output		[0:15][31:0]			cmnd_nnex_argu	,	
	
	input		[31:0]					nnex_task_posi 	,
	input		[31:0]					nnex_task_leng 	,
	input		[31:0]					nnex_task_loop 	,
	
	input								nnex_attn_csen	,
	input								nnex_outp_csen	,
	input								nnex_ugat_csen	,
	input								nnex_down_csen	,
	input								nnex_vcbr_csen	);
/**********************************************************************************************************************/	
	wire		[31: 0]					cmnd_nnex_oper	;

	assign	cmnd_nnex_oper	=			nnex_attn_csen	?	32'H18010000	:
										nnex_outp_csen	?	32'H18020000	:
										nnex_ugat_csen	?	32'H18030000	:
										nnex_down_csen	?	32'H18040000	:
										nnex_vcbr_csen	?	32'H18050000	:	32'H00000000	;

	assign	cmnd_nnex_argu	=		{	32'H000F00FF	,	32'H0			,	32'H0			,	32'H8			,	
										32'H0			,	32'H0			,	32'H0			,	32'H0			,
										32'H0			,	32'H0			,	32'H0			,	32'H0			,
										nnex_task_posi	,	nnex_task_leng	,	nnex_task_loop	,	cmnd_nnex_oper	};	

endmodule
