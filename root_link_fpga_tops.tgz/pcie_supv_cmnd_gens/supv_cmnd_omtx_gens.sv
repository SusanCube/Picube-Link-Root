//----------------------------------------------------------------------------------------------------------
// 	0	   	1  		2	  	3			4			5			6			7			8	 	 		9				10		11  	  12   		13    14  	 15			
//portMsk, 	0	, 	0	,	dvpx	,	maddr	, 	saddr	, meta_rows	, meta_cols	, edge_rows 	, edge_cols   	,   0	, 	0	 	, 0	 	, 0		, 0		, OP)//OMTX
//portMsk, 	0	, 	0	,	NNEX	,	  0		, 	  0  	, 	0	  	, 	0	 	, 		0	  	, 	0			,   0	, 	0	 	, LS 	, LC	, LOOP	, OP)//NNEX
//portMsk, 	0	, 	0	,	gsml	,	maddr	, 	saddr	, port_rows	, port_cols	, edge_rows  	, edge_cols		,   0 	, meta_cols	, 0	 	, 0  	, 0		, OP)//RIMT_R1
//portMsk, 	0	, 	0	,	gsml	,	maddr	, 	saddr	, port_rows	, port_cols	, edge_rows*2	, edge_cols//2	,   1 	, meta_cols	, 0	 	, 0  	, 0		, OP)//RIMT_R2
//portMsk, 	5	, 	0	,	0   	,	maddr	,	hbias	, meta_rows	, meta_cols	, hubs_cols		, hubs_dmmy		, port	, 	0		, 0	 	, 0		, 0		, 0)//RISM
//**********************************************************************************************************
module	supv_cmnd_omtx_gens(
	output		[0:15][31:0]			cmnd_omtx_argu	,	
	
	input		[31:0]					meta_omtx_rows	,
	input		[31:0]					meta_omtx_madd	,
	input		[31:0]					meta_omtx_sadd	,

	input								omtx_down_csen	,//2560
	input								omtx_attn_csen	,//4096
	input								omtx_outp_csen	,//2560
	input								omtx_ugat_csen	,//9728
	input								omtx_vcbr_csen	,//151936

	input		[31: 0]					meta_down_dims	,
	input		[31: 0]					meta_attn_dims	,
	input		[31: 0]					meta_outp_dims	,
	input		[31: 0]					meta_ugat_dims	,
	input		[31: 0]					meta_vcbr_dims	);
/**********************************************************************************************************************/	
	wire		[31: 0]					meta_omtx_cols	;
	wire		[31: 0]					edge_omtx_cols	;
	wire		[31: 0]					edge_omtx_rows	;

	assign	meta_omtx_cols	=			omtx_down_csen	?	meta_down_dims	:
										omtx_attn_csen	?	meta_attn_dims	:
										omtx_outp_csen	?	meta_outp_dims	:
										omtx_ugat_csen	?	meta_ugat_dims	:
										omtx_vcbr_csen	?	meta_vcbr_dims	:	32'H0 	;	

	assign	edge_omtx_rows	= 		{	7'H0	,	meta_omtx_cols[31:7]	};
	assign	edge_omtx_cols	= 		{	meta_omtx_rows[24:0],	7'H0		};//128 * rows

	assign	cmnd_omtx_argu	=		{	32'H000F00FF	,	32'H0			,	32'H0			,	32'H00000005	,	
										meta_omtx_madd	,	meta_omtx_sadd	, 	meta_omtx_rows	,	meta_omtx_cols	,
										edge_omtx_rows	,	edge_omtx_cols	,	32'h0			,	32'h0			, 	
										32'h0			,	32'h0			,	32'h0			,	32'H00000024	};	

endmodule


