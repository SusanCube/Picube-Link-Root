//**********************************************************************************************************************
//	0--	meta_down_dims	31:16 	meta 	15:0	cube
//	1--	meta_attn_dims	31:16 	meta 	15:0	cube
//	2--	meta_ugat_dims	31:16 	meta 	15:0	cube
//	3--	meta_vcbr_dims	31:16 	meta 	15:0	cube
//	4--	ecos_task_madd
//	5--	ecos_task_sadd
//	6--	ecos_task_feat	31:16 	posi	15:0	leng
//	7--	ecos_task_cfig	31:16 	loop	15:0	step
//	8--	ecos_task_cmnd	0: OMTX
//						1: NNEX
//						2: RIMT_1
//						3: RIMT_2
//						4: RISM_1
//						5: RISM_2
//						6: RISM_3
//**********************************************************************************************************************
module	pcie_supv_cmnd_gens(
	input								pcie_supv_cmnd_csen	,
	input		[ 3: 0]					pcie_supv_cmnd_addr	,
	input								pcie_supv_cmnd_wrcs	,
	input		[31: 0]					pcie_supv_cmnd_wdin	,
	output		[31: 0]					pcie_supv_cmnd_rout	,

	output		[ 3: 0]					supv_link_port_enab	,
	output		[31: 0]					supv_cmnd_argu_data	,
	input		[ 3: 0]					supv_cmnd_argu_indx	,

	output		[24: 0]					supv_xdma_ddrs_base	,
	output		[19: 0]					supv_xdma_meta_rows	,
	output		[19: 0]					supv_xdma_meta_cols	,
	output		[19: 0]					supv_xdma_edge_rows	,
	output		[19: 0]					supv_xdma_edge_cols	,
	
	input								pcie_bclk		,
	input								pcie_rstn		,
	input								tpgm_sclk		,
	input								tpgm_rstn		);
//**PCIE****************************************************************************************************************
	reg			[ 0:10][31: 0]			pcie_supv_cmnd_memo	;
	reg			[ 0:10][31: 0]			tpgm_supv_cmnd_memo	;
	wire		[ 0:10]					pcie_supv_cmnd_csid	;
	wire		[ 0:10]					pcie_supv_cmnd_wrid	;
	wire		[ 0:10]					tpgm_supv_cmnd_wrid	;
	wire								pcie_supv_cmnd_wren	;

	assign	pcie_supv_cmnd_wren	=	&{	pcie_supv_cmnd_csen	,	pcie_supv_cmnd_wrcs	};
	assign	pcie_supv_cmnd_rout	=		pcie_supv_cmnd_csid[ 0]	?	pcie_supv_cmnd_memo[ 0]	:
										pcie_supv_cmnd_csid[ 1]	?	pcie_supv_cmnd_memo[ 1]	:
										pcie_supv_cmnd_csid[ 2]	?	pcie_supv_cmnd_memo[ 2]	:
										pcie_supv_cmnd_csid[ 3]	?	pcie_supv_cmnd_memo[ 3]	:
										pcie_supv_cmnd_csid[ 4]	?	pcie_supv_cmnd_memo[ 4]	:
										pcie_supv_cmnd_csid[ 5]	?	pcie_supv_cmnd_memo[ 5]	:
										pcie_supv_cmnd_csid[ 6]	?	pcie_supv_cmnd_memo[ 6]	:
										pcie_supv_cmnd_csid[ 7]	?	pcie_supv_cmnd_memo[ 7]	:
										pcie_supv_cmnd_csid[ 8]	?	pcie_supv_cmnd_memo[ 8]	:
										pcie_supv_cmnd_csid[ 9]	?	pcie_supv_cmnd_memo[ 9]	:
										pcie_supv_cmnd_csid[10]	?	pcie_supv_cmnd_memo[10]	:	32'H0	;

	for(genvar i = 0 ; i <11 ; i++) begin	:	pcie_supv_cmnd_rwcs
	
		assign	pcie_supv_cmnd_csid[i]	=	pcie_supv_cmnd_addr	==	i	;
		assign	pcie_supv_cmnd_wrid[i]	= &{pcie_supv_cmnd_wren	,	pcie_supv_cmnd_csid[i]	};
		
		always@(posedge pcie_bclk or negedge pcie_rstn)
		if(~pcie_rstn)					pcie_supv_cmnd_memo[i]	<=	0	;
		else if(pcie_supv_cmnd_wrid[i])	pcie_supv_cmnd_memo[i]	<=	pcie_supv_cmnd_wdin	;

		always@(posedge tpgm_sclk or negedge tpgm_rstn)
		if(~tpgm_rstn)					tpgm_supv_cmnd_memo[i]	<=	0	;
		else if(tpgm_supv_cmnd_wrid[i])	tpgm_supv_cmnd_memo[i]	<=	pcie_supv_cmnd_memo[i]	;

		gens_edge_fast_slow #(	.EXTN( 5)	)
									u_gens_supv_mode_reqs(	
			.slow_edge					(tpgm_supv_cmnd_wrid[i]	),
			.slow_clki					(tpgm_sclk				),
			.slow_rstn					(tpgm_rstn				),
			.fast_sign					(pcie_supv_cmnd_wrid[i]	),
			.fast_clki					(pcie_bclk				),
			.fast_rstn					(pcie_rstn				));	
	end 
//**********************************************************************************************************************
	wire		[31: 0]					meta_down_cfig	;
	wire		[31: 0]					meta_attn_cfig	;
	wire		[31: 0]					meta_outp_cfig	;
	wire		[31: 0]					meta_ugat_cfig	;
	wire		[31: 0]					meta_vcbr_cfig	;
	wire		[31: 0]					ecos_xdma_madd	;
	wire		[31: 0]					ecos_wdma_sadd	;
	wire		[31: 0]					ecos_rdma_sadd	;
	wire		[31: 0]					ecos_task_feat	;
	wire		[31: 0]					ecos_task_cfig	;
	wire		[31: 0]					ecos_task_cmnd	;
 
	assign	meta_down_cfig	=			tpgm_supv_cmnd_memo[ 0];
	assign	meta_attn_cfig	=			tpgm_supv_cmnd_memo[ 1];
	assign	meta_outp_cfig	=			tpgm_supv_cmnd_memo[ 2];
	assign	meta_ugat_cfig	=			tpgm_supv_cmnd_memo[ 3];
	assign	meta_vcbr_cfig	=			tpgm_supv_cmnd_memo[ 4];
	assign	ecos_xdma_madd	=			tpgm_supv_cmnd_memo[ 5];
	assign	ecos_wdma_sadd	=			tpgm_supv_cmnd_memo[ 6];
	assign	ecos_rdma_sadd	=			tpgm_supv_cmnd_memo[ 7];
	assign	ecos_task_feat	=			tpgm_supv_cmnd_memo[ 8];
	assign	ecos_task_cfig	=			tpgm_supv_cmnd_memo[ 9];
	assign	ecos_task_cmnd	=			tpgm_supv_cmnd_memo[10];
//**********************************************************************************************************************
	wire		[31: 0]					meta_down_dims	;
	wire		[31: 0]					meta_attn_dims	;
	wire		[31: 0]					meta_outp_dims	;
	wire		[31: 0]					meta_ugat_dims	;
	wire		[31: 0]					meta_vcbr_dims	;
	
	wire		[31: 0]					cube_down_dims	;
	wire		[31: 0]					cube_attn_dims	;
	wire		[31: 0]					cube_outp_dims	;
	wire		[31: 0]					cube_ugat_dims	;
	wire		[31: 0]					cube_vcbr_dims	;

	wire		[31: 0]					ecos_task_posi	;
	wire		[31: 0]					ecos_task_leng	;
	wire		[31: 0]					ecos_task_loop	;
	wire		[31: 0]					ecos_task_step	;

	assign	meta_down_dims	=	{16'H0	,	meta_down_cfig[31:16]	};
	assign	cube_down_dims	=	{16'H0	,	meta_down_cfig[15: 0]	};

	assign	meta_attn_dims	=	{16'H0	,	meta_attn_cfig[31:16]	};
	assign	cube_attn_dims	=	{16'H0	,	meta_attn_cfig[15: 0]	};

	assign	meta_outp_dims	=	{16'H0	,	meta_outp_cfig[31:16]	};
	assign	cube_outp_dims	=	{16'H0	,	meta_outp_cfig[15: 0]	};

	assign	meta_ugat_dims	=	{16'H0	,	meta_ugat_cfig[31:16]	};
	assign	cube_ugat_dims	=	{16'H0	,	meta_ugat_cfig[15: 0]	};

	assign	meta_vcbr_dims	=	{16'H0	,	meta_vcbr_cfig[31:16]	};
	assign	cube_vcbr_dims	=	{16'H0	,	meta_vcbr_cfig[15: 0]	};

	assign	ecos_task_posi	=	{16'H0	,	ecos_task_feat[31:16]	};
	assign	ecos_task_leng	=	{16'H0	,	ecos_task_feat[15:0 ]	};
	assign	ecos_task_loop	=	{16'H0	,	ecos_task_cfig[31:16]	};
	assign	ecos_task_step	=	{16'H0	,	ecos_task_cfig[15:0 ]	};
//----------------------------------------------------------------------------------------------------------
	reg									tpgm_supv_cmnd_wrok	;
	reg									tpgm_supv_cmnd_issu	;
	
	always@(posedge tpgm_sclk or negedge tpgm_rstn)
	if(~tpgm_rstn)					tpgm_supv_cmnd_wrok	<=	0	;
	else 							tpgm_supv_cmnd_wrok	<=	tpgm_supv_cmnd_wrid[10]	;

	always@(posedge tpgm_sclk or negedge tpgm_rstn)
	if(~tpgm_rstn)					tpgm_supv_cmnd_issu	<=	0	;
	else 							tpgm_supv_cmnd_issu	<=	tpgm_supv_cmnd_wrok	;
//----------------------------------------------------------------------------------------------------------
//	STAGE_0	(ATTN)	OMTX_DOWN -> NNEX_ATTN -> RIMT_ATTN -> RISM_ATTN
//	STAGE_1	(OUTP)	OMTX_ATTN -> NNEX_OUTP -> RIMT_OUTP -> RISM_OUTP
//	STAGE_2	(UGAT)	OMTX_OUTP -> NNEX_UGAT -> RIMT_UGAT -> RISM_UGAT
//	STAGE_3	(DOWN)	OMTX_UGAT -> NNEX_DOWN -> RIMT_DOWN -> RISM_DOWN
//	STAGE_4	(VCBR)	OMTX_DOWN -> NNEX_VCBR -> RIMT_VCBR -> RISM_VCBR
	parameter	ECOS_NNEX_TASK_ATTN	=	32'H0 	;
	parameter	ECOS_NNEX_TASK_OUTP	=	32'H1 	;
	parameter	ECOS_NNEX_TASK_UGAT	=	32'H2 	;
	parameter	ECOS_NNEX_TASK_DOWN	=	32'H3 	;
	parameter	ECOS_NNEX_TASK_VCBR	=	32'H4 	;

	wire								omtx_attn_csen	;
	wire								omtx_outp_csen	;
	wire								omtx_ugat_csen	;
	wire								omtx_down_csen	;
	wire								omtx_vcbr_csen	;

	wire								nnex_attn_csen	;
	wire								nnex_outp_csen	;
	wire								nnex_ugat_csen	;
	wire								nnex_down_csen	;
	wire								nnex_vcbr_csen	;

	assign	omtx_down_csen	=	ecos_task_step	==	ECOS_NNEX_TASK_ATTN	;
	assign	omtx_attn_csen	=	ecos_task_step	==	ECOS_NNEX_TASK_OUTP	;
	assign	omtx_outp_csen	=	ecos_task_step	==	ECOS_NNEX_TASK_UGAT	;
	assign	omtx_ugat_csen	=	ecos_task_step	==	ECOS_NNEX_TASK_DOWN	;
	assign	omtx_vcbr_csen	=	ecos_task_step	==	ECOS_NNEX_TASK_VCBR	;

	assign	nnex_attn_csen	=	ecos_task_step	==	ECOS_NNEX_TASK_ATTN	;
	assign	nnex_outp_csen	=	ecos_task_step	==	ECOS_NNEX_TASK_OUTP	;
	assign	nnex_ugat_csen	=	ecos_task_step	==	ECOS_NNEX_TASK_UGAT	;
	assign	nnex_down_csen	=	ecos_task_step	==	ECOS_NNEX_TASK_DOWN	;
	assign	nnex_vcbr_csen	=	ecos_task_step	==	ECOS_NNEX_TASK_VCBR	;
//----------------------------------------------------------------------------------------------------------
	wire		[0:15][31:0]			cmnd_omtx_argu_gens	;
	wire		[0:15][31:0]			cmnd_nnex_argu_gens	;
	wire		[0:15][31:0]			cmnd_rimt_argu_gens	;
	wire		[0:15][31:0]			cmnd_rism_argu_gens	;

	wire								cmnd_omtx_argu_case	;
	wire								cmnd_nnex_argu_case	;
	wire								cmnd_rimt_arg1_case	;
	wire								cmnd_rimt_arg2_case	;
	wire								cmnd_rism_arg1_case	;
	wire								cmnd_rism_arg2_case	;
	wire								cmnd_rism_arg3_case	;
	wire								cmnd_rimt_argu_case	;
	wire								cmnd_rism_argu_case	;

	wire								cmnd_omtx_argu_load	;
	wire								cmnd_nnex_argu_load	;
	wire								cmnd_rimt_argu_load	;
	wire								cmnd_rism_argu_load	;

	wire								meta_rimt_port 		;
	wire		[1:0]					meta_rism_port 		;

	assign	cmnd_omtx_argu_case	=		ecos_task_cmnd == 32'H0	;
	assign	cmnd_nnex_argu_case	=		ecos_task_cmnd == 32'H1	;
	assign	cmnd_rimt_arg1_case	=		ecos_task_cmnd == 32'H2	;
	assign	cmnd_rimt_arg2_case	=		ecos_task_cmnd == 32'H3	;
	assign	cmnd_rism_arg1_case	=		ecos_task_cmnd == 32'H4	;
	assign	cmnd_rism_arg2_case	=		ecos_task_cmnd == 32'H5	;
	assign	cmnd_rism_arg3_case	=		ecos_task_cmnd == 32'H6	;

	assign	cmnd_rimt_argu_case	=	|{	cmnd_rimt_arg1_case	,	cmnd_rimt_arg2_case	};
	assign	cmnd_rism_argu_case	=	|{	cmnd_rism_arg1_case	,	cmnd_rism_arg2_case	,	cmnd_rism_arg3_case	};
													
	assign	cmnd_omtx_argu_load	=	&{	cmnd_omtx_argu_case	,	tpgm_supv_cmnd_issu	};
	assign	cmnd_nnex_argu_load	=	&{	cmnd_nnex_argu_case	,	tpgm_supv_cmnd_issu	};
	assign	cmnd_rimt_argu_load	=	&{	cmnd_rimt_argu_case	,	tpgm_supv_cmnd_issu	};
	assign	cmnd_rism_argu_load	=	&{	cmnd_rism_argu_case	,	tpgm_supv_cmnd_issu	};

	assign	meta_rimt_port 		=		cmnd_rimt_arg2_case		;
	assign	meta_rism_port 		=		cmnd_rism_arg1_case	?	2'H1	:
										cmnd_rism_arg2_case	?	2'H2	:	2'H3	;
											
	reg		[ 0:15][31: 0]				supv_cmnd_argu_memo		;
	wire	[ 0:15]						supv_cmnd_argu_csid		;

	for(genvar m = 0 ; m < 16 ; m = m +1	) begin	:latch_cmnd_argu

		assign	supv_cmnd_argu_csid[m]=	supv_cmnd_argu_indx	==	m	;

		always@(posedge tpgm_sclk or negedge tpgm_rstn)
		if(~tpgm_rstn)					supv_cmnd_argu_memo[m]	<= 	0	;
		else if(cmnd_omtx_argu_load)	supv_cmnd_argu_memo[m]	<= 	cmnd_omtx_argu_gens[m]	;
		else if(cmnd_nnex_argu_load)	supv_cmnd_argu_memo[m]	<= 	cmnd_nnex_argu_gens[m]	;
		else if(cmnd_rimt_argu_load)	supv_cmnd_argu_memo[m]	<= 	cmnd_rimt_argu_gens[m]	;
		else if(cmnd_rism_argu_load)	supv_cmnd_argu_memo[m]	<= 	cmnd_rism_argu_gens[m]	;

	end
//**********************************************************************************************************************
	wire	[31: 0]						supv_link_dest_cube	;

	assign	supv_link_port_enab	=		supv_cmnd_argu_memo[0][19:16]	;

	assign	supv_link_dest_cube	={16'H0,supv_cmnd_argu_memo[0][15:0]};
	assign	supv_xdma_ddrs_base	=		supv_cmnd_argu_memo[4][24:0];
	assign	supv_xdma_meta_rows	=		supv_cmnd_argu_memo[6][19:0];
	assign	supv_xdma_meta_cols	=		supv_cmnd_argu_memo[7][19:0];
	assign	supv_xdma_edge_rows	=		supv_cmnd_argu_memo[8][19:0];
	assign	supv_xdma_edge_cols	=		supv_cmnd_argu_memo[9][19:0];

	assign	supv_cmnd_argu_data	=		supv_cmnd_argu_csid[ 0]	?	supv_link_dest_cube		:
										supv_cmnd_argu_csid[ 1]	?	supv_cmnd_argu_memo[ 1]	:
										supv_cmnd_argu_csid[ 2]	?	supv_cmnd_argu_memo[ 2]	:
										supv_cmnd_argu_csid[ 3]	?	supv_cmnd_argu_memo[ 3]	:
										supv_cmnd_argu_csid[ 4]	?	supv_cmnd_argu_memo[ 4]	:
										supv_cmnd_argu_csid[ 5]	?	supv_cmnd_argu_memo[ 5]	:
										supv_cmnd_argu_csid[ 6]	?	supv_cmnd_argu_memo[ 6]	:
										supv_cmnd_argu_csid[ 7]	?	supv_cmnd_argu_memo[ 7]	:
										supv_cmnd_argu_csid[ 8]	?	supv_cmnd_argu_memo[ 8]	:
										supv_cmnd_argu_csid[ 9]	?	supv_cmnd_argu_memo[ 9]	:
										supv_cmnd_argu_csid[10]	?	supv_cmnd_argu_memo[10]	:
										supv_cmnd_argu_csid[11]	?	supv_cmnd_argu_memo[11]	:
										supv_cmnd_argu_csid[12]	?	supv_cmnd_argu_memo[12]	:
										supv_cmnd_argu_csid[13]	?	supv_cmnd_argu_memo[13]	:
										supv_cmnd_argu_csid[14]	?	supv_cmnd_argu_memo[14]	:	supv_cmnd_argu_memo[15]	;	
//**********************************************************************************************************************
	supv_cmnd_omtx_gens				u_cmnd_omtx_gens(
		.cmnd_omtx_argu					(cmnd_omtx_argu_gens),//output		[0:15][31:0]	
		
		.meta_omtx_rows					(ecos_task_leng		),//input		[31:0]			
		.meta_omtx_madd					(ecos_xdma_madd		),//input		[31:0]			
		.meta_omtx_sadd					(ecos_wdma_sadd		),//input		[31:0]			
		
		.omtx_down_csen					(omtx_down_csen		),//input						
		.omtx_attn_csen					(omtx_attn_csen		),//input						
		.omtx_outp_csen					(omtx_outp_csen		),//input						
		.omtx_ugat_csen					(omtx_ugat_csen		),//input						
		.omtx_vcbr_csen					(omtx_vcbr_csen		),//input						
		
		.meta_down_dims					(meta_down_dims		),//input		[31: 0]			
		.meta_attn_dims					(meta_attn_dims		),//input		[31: 0]			
		.meta_outp_dims					(meta_outp_dims		),//input		[31: 0]			
		.meta_ugat_dims					(meta_ugat_dims		),//input		[31: 0]			
		.meta_vcbr_dims					(meta_vcbr_dims		));//input		[31: 0]			

	supv_cmnd_nnex_gens				u_cmnd_nnex_gens(
		.cmnd_nnex_argu					(cmnd_nnex_argu_gens),	//output		[0:15][31:0]

		.nnex_task_posi 				(ecos_task_posi		),//input		[31:0]		
		.nnex_task_leng 				(ecos_task_leng		),//input		[31:0]		
		.nnex_task_loop 				(ecos_task_loop		),//input		[31:0]		
		
		.nnex_attn_csen					(nnex_attn_csen		),//input					
		.nnex_outp_csen					(nnex_outp_csen		),//input					
		.nnex_ugat_csen					(nnex_ugat_csen		),//input					
		.nnex_down_csen					(nnex_down_csen		),//input					
		.nnex_vcbr_csen					(nnex_vcbr_csen		));//input					

	supv_cmnd_rimt_gens				u_cmnd_rimt_gens(
		.cmnd_rimt_argu					(cmnd_rimt_argu_gens),//output		[0:15][31:0]

		.meta_rimt_rows					(ecos_task_leng		),//input		[31:0]		
		.meta_rimt_port					(meta_rimt_port		),//input		[1: 0]		
		.meta_rimt_madd					(ecos_xdma_madd		),//input		[31:0]		
		.meta_rimt_sadd					(ecos_rdma_sadd		),//input		[31:0]		
		
		.rimt_attn_csen					(nnex_attn_csen		),//input					
		.rimt_outp_csen					(nnex_outp_csen		),//input					
		.rimt_ugat_csen					(nnex_ugat_csen		),//input					
		.rimt_down_csen					(nnex_down_csen		),//input					
		.rimt_vcbr_csen					(nnex_vcbr_csen		),//input					
		
		.meta_down_dims					(meta_down_dims		),//input		[31: 0]		
		.meta_attn_dims					(meta_attn_dims		),//input		[31: 0]		
		.meta_outp_dims					(meta_outp_dims		),//input		[31: 0]		
		.meta_ugat_dims					(meta_ugat_dims		),//input		[31: 0]		
		.meta_vcbr_dims					(meta_vcbr_dims		),//input		[31: 0]		
		
		.cube_down_dims					(cube_down_dims		),//input		[31: 0]		
		.cube_attn_dims					(cube_attn_dims		),//input		[31: 0]		
		.cube_outp_dims					(cube_outp_dims		),//input		[31: 0]		
		.cube_ugat_dims					(cube_ugat_dims		),//input		[31: 0]		
		.cube_vcbr_dims					(cube_vcbr_dims		));//input		[31: 0]		

	supv_cmnd_rism_gens				u_cmnd_rism_gens(
		.cmnd_rism_argu					(cmnd_rism_argu_gens),//output		[0:15][31:0]

		.meta_rism_rows					(ecos_task_leng		),//input		[31:0]		
		.meta_rism_port					(meta_rism_port		),//input		[ 1:0]		
		.meta_rism_madd					(ecos_xdma_madd		),//input		[31:0]		
		
		.rism_attn_csen					(nnex_attn_csen		),//input					
		.rism_outp_csen					(nnex_outp_csen		),//input					
		.rism_ugat_csen					(nnex_ugat_csen		),//input					
		.rism_down_csen					(nnex_down_csen		),//input					
		.rism_vcbr_csen					(nnex_vcbr_csen		),//input					
		
		.meta_down_dims					(meta_down_dims		),//input		[31: 0]		
		.meta_attn_dims					(meta_attn_dims		),//input		[31: 0]		
		.meta_outp_dims					(meta_outp_dims		),//input		[31: 0]		
		.meta_ugat_dims					(meta_ugat_dims		),//input		[31: 0]		
		.meta_vcbr_dims					(meta_vcbr_dims		),//input		[31: 0]		
		
		.cube_down_dims					(cube_down_dims		),//input		[31: 0]		
		.cube_attn_dims					(cube_attn_dims		),//input		[31: 0]		
		.cube_outp_dims					(cube_outp_dims		),//input		[31: 0]		
		.cube_ugat_dims					(cube_ugat_dims		),//input		[31: 0]		
		.cube_vcbr_dims					(cube_vcbr_dims		));//input		[31: 0]		
//**********************************************************************************************************************

endmodule


