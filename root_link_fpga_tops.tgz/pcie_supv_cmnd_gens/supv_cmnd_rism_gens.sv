//----------------------------------------------------------------------------------------------------------
// 	0	   	1  		2	  	3			4			5			6			7			8	 	 		9				10		11  	  12   		13    14  	 15			
//portMsk, 	0	, 	0	,	dvpx	,	maddr	, 	saddr	, meta_rows	, meta_cols	, edge_rows 	, edge_cols   	,   0	, 	0	 	, 0	 	, 0		, 0		, OP)//OMTX
//portMsk, 	0	, 	0	,	NNEX	,	  0		, 	  0  	, 	0	  	, 	0	 	, 		0	  	, 	0			,   0	, 	0	 	, LS 	, LC	, LOOP	, OP)//NNEX
//portMsk, 	0	, 	0	,	gsml	,	maddr	, 	saddr	, port_rows	, port_cols	, edge_rows  	, edge_cols		,   0 	, meta_cols	, 0	 	, 0  	, 0		, OP)//RIMT_R1
//portMsk, 	0	, 	0	,	gsml	,	maddr	, 	saddr	, port_rows	, port_cols	, edge_rows*2	, edge_cols//2	,   1 	, meta_cols	, 0	 	, 0  	, 0		, OP)//RIMT_R2
//portMsk, 	5	, 	0	,	0   	,	maddr	,	hbias	, meta_rows	, meta_cols	, hubs_cols		, hubs_dmmy		, port	, 	0		, 0	 	, 0		, 0		, 0)//RISM
//**********************************************************************************************************
//OMTX_DOWN -> NNEX_ATTN -> RIMT_ATTN -> RISM_ATTN
//OMTX_ATTN -> NNEX_OUTP -> RIMT_OUTP -> RISM_OUTP
//OMTX_OUTP -> NNEX_UGAT -> RIMT_UGAT -> RISM_UGAT
//OMTX_UGAT -> NNEX_DOWN -> RIMT_DOWN -> RISM_DOWN
//OMTX_DOWN -> NNEX_VCBR -> RIMT_VCBR -> RISM_VCBR
//**********************************************************************************************************
module	supv_cmnd_rism_gens(
	output		[0:15][31:0]			cmnd_rism_argu	,	
	
	input		[31:0]					meta_rism_rows	,
	input		[ 1:0]					meta_rism_port	,
	input		[31:0]					meta_rism_madd	,
	
	input								rism_down_csen	,//2560
	input								rism_attn_csen	,//4096
	input								rism_outp_csen	,//2560
	input								rism_ugat_csen	,//9728
	input								rism_vcbr_csen	,//151936

	input		[31: 0]					meta_down_dims	,
	input		[31: 0]					meta_attn_dims	,
	input		[31: 0]					meta_outp_dims	,
	input		[31: 0]					meta_ugat_dims	,
	input		[31: 0]					meta_vcbr_dims	,

	input		[31: 0]					cube_down_dims	,
	input		[31: 0]					cube_attn_dims	,
	input		[31: 0]					cube_outp_dims	,
	input		[31: 0]					cube_ugat_dims	,
	input		[31: 0]					cube_vcbr_dims	);
/**********************************************************************************************************************/	
	wire		[31: 0]					meta_rism_cols	;
	wire		[31: 0]					hubs_rism_cols	;
	wire		[31: 0]					cube_rism_cols	;

	wire		[31: 0]					meta_rism_page	;
	wire		[31: 0]					cube_rism_page	;
	wire		[31: 0]					hubs_rism_page	;

	wire		[31: 0]					hub1_rism_size	;	
	wire		[31: 0]					hub2_rism_size	;	
	wire		[31: 0]					hub3_rism_size	;	

	wire								hub1_rism_ovfl	;
	wire								hub2_rism_ovfl	;
	wire								hub3_rism_ovfl	;

	wire								hub1_rism_last	;
	wire								hub2_rism_last	;
	wire								hub3_rism_last	;

	wire	[31: 0]						hub1_rism_page	;	
	wire	[31: 0]						hub2_rism_page	;	
	wire	[31: 0]						hub3_rism_page	;	

	wire	[31: 0]						hub1_rism_dmmy	;	
	wire	[31: 0]						hub2_rism_dmmy	;	
	wire	[31: 0]						hub3_rism_dmmy	;

	assign	meta_rism_cols		=		rism_down_csen	?	meta_down_dims	:
										rism_attn_csen	?	meta_attn_dims	:
										rism_outp_csen	?	meta_outp_dims	:
										rism_ugat_csen	?	meta_ugat_dims	:
										rism_vcbr_csen	?	meta_vcbr_dims	:	32'H0	;

	assign	cube_rism_cols		=		rism_down_csen	?	cube_down_dims	:
										rism_attn_csen	?	cube_attn_dims	:
										rism_outp_csen	?	cube_outp_dims	:
										rism_ugat_csen	?	cube_ugat_dims	:
										rism_vcbr_csen	?	cube_vcbr_dims	:	32'H0	;
	
	assign	hubs_rism_cols 		=	{	cube_rism_cols[27:0],4'H0	};


	assign	meta_rism_page		=	{	4'H0	,	meta_rism_cols[31:4]   };
	assign	cube_rism_page		=	{	4'H0	,	cube_rism_cols[31:4]   };
	assign	hubs_rism_page		=	{	4'H0	,	hubs_rism_cols[31:4]   };
	assign	hub1_rism_size		=	{	hubs_rism_page[30:0] , 1'H0}		;// COLS *	16 * 2 /	16
	assign	hub3_rism_size		=	{	hubs_rism_page[29:0] , 2'H0}		;// COLS *	16 * 2 /	16
	assign	hub2_rism_size		=		hubs_rism_page	*	3				;// COLS *	16 * 3 /	16

	assign	hub1_rism_ovfl		=		hub1_rism_size	>=	meta_rism_page	;
	assign	hub2_rism_ovfl		=		hub2_rism_size	>=	meta_rism_page	;
	assign	hub3_rism_ovfl		=		hub3_rism_size	>=	meta_rism_page	;

	assign	hub1_rism_last		=		hub1_rism_ovfl	;
	assign	hub2_rism_last		=	&{ ~hub1_rism_ovfl	,	hub2_rism_ovfl	};
	assign	hub3_rism_last		=	&{ ~hub1_rism_ovfl	, ~	hub2_rism_ovfl	,	hub3_rism_ovfl };

	assign	hub1_rism_page		=		hub1_rism_last	?	meta_rism_page - hubs_rism_page	:	hubs_rism_page	;
	assign	hub1_rism_dmmy		=		hubs_rism_page	-	hub1_rism_page	;
	
	assign	hub2_rism_page		=		hub2_rism_last	?	meta_rism_page - hub1_rism_size	:	hubs_rism_page	;
	assign	hub2_rism_dmmy		=		hubs_rism_page	-	hub2_rism_page	;

	assign	hub3_rism_page		=		hub3_rism_last	?	meta_rism_page - hub2_rism_size	:	hubs_rism_page	;
	assign	hub3_rism_dmmy		=		hubs_rism_page	-	hub3_rism_page	;
/**********************************************************************************************************************/	
	wire		[31: 0]					rism_cmnd_pmsk	;
	wire		[31: 0]					rism_cmnd_hubs	;

	wire		[31: 0]					rism_hubx_bias	;
	wire		[31: 0]					rism_hubx_page	;
	wire		[31: 0]					rism_hubx_dmmy	;

	assign	rism_cmnd_pmsk		=	 (	meta_rism_port == 2'H1)	?	32'H00030000	:
									 (	meta_rism_port == 2'H2)	?	32'H00050000	:
									 (	meta_rism_port == 2'H3)	?	32'H00090000	:	32'H00000000	;

	assign	rism_cmnd_hubs		=	 (	meta_rism_port == 2'H1)	?	32'H00000001	:
									 (	meta_rism_port == 2'H2)	?	32'H00000002	:
									 (	meta_rism_port == 2'H3)	?	32'H00000003	:	32'H00000000	;

	assign	rism_hubx_bias		=	 (	meta_rism_port == 2'H1)	?	hubs_rism_page	:
									 (	meta_rism_port == 2'H2)	?	hub1_rism_size	:
									 (	meta_rism_port == 2'H3)	?	hub2_rism_size	:	32'H00000000	;

	assign	rism_hubx_page		=	 (	meta_rism_port == 2'H1)	?	hub1_rism_page	:
									 (	meta_rism_port == 2'H2)	?	hub2_rism_page	:
									 (	meta_rism_port == 2'H3)	?	hub3_rism_page	:	32'H00000000	;

	assign	rism_hubx_dmmy		=	 (	meta_rism_port == 2'H1)	?	hub1_rism_dmmy	:
									 (	meta_rism_port == 2'H2)	?	hub2_rism_dmmy	:
									 (	meta_rism_port == 2'H3)	?	hub3_rism_dmmy	:	32'H00000000	;
	
//    self.pcie_cfig_cmnd(portMsk, 5, 0, 0,  ROOT_ADDR, HUBS_BIAS, IMAGE_ROWS, ROOT_COLS, HUBS_COLS, HUBS_DUMY, P, 0,0,0,0,0)
//												4			5			6			7			8		9			
	assign	cmnd_rism_argu		=	{	rism_cmnd_pmsk	,	32'H5			,	32'H0			,	32'H0			,
										meta_rism_madd	, 	rism_hubx_bias	, 	meta_rism_rows	,	meta_rism_page	,
										rism_hubx_page	,	rism_hubx_dmmy	,	rism_cmnd_hubs	,	32'H0			,
										32'H0			,	32'H0			,	32'H0			,	32'H00000043	};	

endmodule


