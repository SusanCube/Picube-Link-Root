//----------------------------------------------------------------------------------------------------------
// 	0	   	1  		2	  	3			4			5			6			7			8	 	 		9				10		11  	  12   		13    14  	 15			
//portMsk, 	0	, 	0	,	dvpx	,	maddr	, 	saddr	, meta_rows	, meta_cols	, edge_rows 	, edge_cols   	,   0	, 	0	 	, 0	 	, 0		, 0		, OP)//OMTX
//portMsk, 	0	, 	0	,	NNEX	,	  0		, 	  0  	, 	0	  	, 	0	 	, 		0	  	, 	0			,   0	, 	0	 	, LS 	, LC	, LOOP	, OP)//NNEX
//portMsk, 	0	, 	0	,	gsml	,	maddr	, 	saddr	, port_rows	, port_cols	, edge_rows  	, edge_cols		,   0 	, meta_cols	, 0	 	, 0  	, 0		, OP)//RIMT_R1
//portMsk, 	0	, 	0	,	gsml	,	maddr	, 	saddr	, port_rows	, port_cols	, edge_rows*2	, edge_cols//2	,   1 	, meta_cols	, 0	 	, 0  	, 0		, OP)//RIMT_R2
//portMsk, 	5	, 	0	,	0   	,	maddr	,	hbias	, meta_rows	, meta_cols	, hubs_cols		, hubs_dmmy		, port	, 	0		, 0	 	, 0		, 0		, 0)//RISM
//**********************************************************************************************************
//OMTX_DOWN -> NNEX_ATTN -> RIMT_ATTN -> RISM_ATTN
//OMTX_ATTN -> NNEX_OUTP -> RIMT_OUTP -> RISM_OUTP
//OMTX_OUTP -> NNEX_UGAT -> RIMT_UGAT -> RISM_UGAT
//OMTX_UGAT -> NNEX_DOWN -> RIMT_DOWN -> RISM_DOWN
//OMTX_DOWN -> NNEX_VCBR -> RIMT_VCBR -> RISM_VCBR
//**********************************************************************************************************
module	supv_cmnd_rimt_gens(
	output		[0:15][31:0]			cmnd_rimt_argu	,	
	
	input		[31:0]					meta_rimt_rows	,
	input								meta_rimt_port	,
	input		[31:0]					meta_rimt_madd	,
	input		[31:0]					meta_rimt_sadd	,

	input								rimt_attn_csen	,//4096
	input								rimt_outp_csen	,//2560
	input								rimt_ugat_csen	,//9728
	input								rimt_down_csen	,//2560
	input								rimt_vcbr_csen	,//151936

	input		[31: 0]					meta_down_dims	,
	input		[31: 0]					meta_attn_dims	,
	input		[31: 0]					meta_outp_dims	,
	input		[31: 0]					meta_ugat_dims	,
	input		[31: 0]					meta_vcbr_dims	,

	input		[31: 0]					cube_down_dims	,
	input		[31: 0]					cube_attn_dims	,
	input		[31: 0]					cube_outp_dims	,
	input		[31: 0]					cube_ugat_dims	,
	input		[31: 0]					cube_vcbr_dims	);
/**********************************************************************************************************************/	
//------RIMT----------------------------
	wire		[31: 0]					cmnd_rimt_gmsl	;
	wire		[31: 0]					meta_rimt_cols	;
	wire		[31: 0]					cube_rimt_cols	;
	wire		[31: 0]					hubs_rimt_cols	;
	
	assign	cmnd_rimt_gmsl		=		meta_rimt_port	?	32'H00000007	:	32'H00000006	;

	assign	meta_rimt_cols		=		rimt_down_csen	?	meta_down_dims	:
										rimt_attn_csen	?	meta_attn_dims	:
										rimt_outp_csen	?	meta_outp_dims	:
										rimt_ugat_csen	?	meta_ugat_dims	:
										rimt_vcbr_csen	?	meta_vcbr_dims	:	32'H0	;

	assign	cube_rimt_cols		=		rimt_down_csen	?	cube_down_dims	:
										rimt_attn_csen	?	cube_attn_dims	:
										rimt_outp_csen	?	cube_outp_dims	:
										rimt_ugat_csen	?	cube_ugat_dims	:
										rimt_vcbr_csen	?	cube_vcbr_dims	:	32'H0	;
	
	assign	hubs_rimt_cols 		=	{	cube_rimt_cols[27:0],4'H0	};


	assign	cmnd_rimt_argu		=	{	32'H000F00FF	,	32'H0			,	32'H0			,	cmnd_rimt_gmsl	,
										meta_rimt_madd	, 	meta_rimt_sadd	, 	meta_rimt_rows	,	hubs_rimt_cols	,
										meta_rimt_rows	,	cube_rimt_cols	,	32'h0			,	meta_rimt_cols	,
										32'h0			,	32'h0			,	32'h0			,	32'H00000033	};	



endmodule


