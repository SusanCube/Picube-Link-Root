
module	gens_sync_gray #(	parameter MSB =	24 )	(
	input	[MSB: 0]				data_asyn	,
	input							scki		,

	output	reg [MSB: 0]			data_sync	,
	input							clki		,
	input							rstn		);

	reg		[MSB: 0]				data_asyn_gray_code		;
	wire	[MSB: 0]				gray_sync		;

	assign	gray_sync	= {	data_asyn[MSB] , data_asyn[MSB: 1] ^ data_asyn[MSB-1: 0]}	;

	always@(posedge scki)
		data_asyn_gray_code	<=	gray_sync	;
//----------------------------------------------------------------------

	reg		[MSB: 0]					data_syn0	;
	reg		[MSB: 0]					data_syn1	;
	
	wire	[MSB: 0]					data_sync_gray_decd	;
	
	
	always@(posedge clki or negedge rstn)
	if(~rstn)	begin				data_syn0	<=	0	;
									data_syn1	<=	0	;
	end else	begin				data_syn0	<=	data_asyn_gray_code	;
									data_syn1	<=	data_syn0			;								
	end

	assign	data_sync_gray_decd[MSB]=data_syn1[MSB]	;

for(genvar i=MSB-1 ; i>=0 ; i =i-1) begin
	assign	data_sync_gray_decd[i] = data_sync_gray_decd[i+1] ^ data_syn1[i];
end

	always@(posedge clki or negedge rstn)
	if(~rstn)						data_sync	<=	0	;
	else							data_sync	<=	data_sync_gray_decd	;
									


//	assign	data_sync	=	data_sync_gray_decd	;

endmodule
  