module	xcku_sysclk(
	output								link_fclk	,
	output								link_sclk	,
	output								link_cclk	,
	
	output								link_rstn	,
	output								chip_rstn	,
	output								dlys_rstn	,

	input								auxi_rstn	,
	input								cold_rstn	,
	input								chip_clki	);
/**********************************************************************************************************************/
	wire								mmcm_lock	;

	wire	mixs_rstn		=   &{		cold_rstn ,	mmcm_lock ,	auxi_rstn	};
	assign	dlys_rstn 		=	&{		cold_rstn , mmcm_lock 				};
//------------------------------------------------------------------------------
	reg		[ 7: 0]						chip_rstn_time 	= 	0 	;
	wire	[ 7: 0]						chip_rstn_tnxt	=	1 +	chip_rstn_time	;

	assign	chip_rstn		=   		chip_rstn_time	==	8'H7F	;
	
	always@(posedge chip_clki)			
	if(~chip_rstn)						chip_rstn_time	<=	chip_rstn_tnxt	;
//------------------------------------------------------------------------------
	reg		[ 7: 0]						link_rstn_time 	= 	0	;
	wire	[ 7: 0]						link_rstn_tnxt	=	1 +	link_rstn_time	;

	assign	link_rstn		=   		link_rstn_time	==	8'H7F	;

	always@(posedge link_sclk  or negedge mixs_rstn )
	if(~mixs_rstn)						link_rstn_time	<=	0	;
	else if(~link_rstn)					link_rstn_time	<=	link_rstn_tnxt	;
/**********************************************************************************************************************/
//    wire                                mmcm_200m;
    wire                              link_fclk;
      
    MMCM_200M                      u_MMCM_200M   (
        .resetn                         (chip_rstn      ),      // input reset
        .locked                         (mmcm_lock      ),       // output locked
        
        .clko_200m                      (link_fclk      ),     // output link_fclk
        .clki_100m                      (chip_clki      ));      // input chip_clki
/**********************************************************************************************************************/
	reg		[3: 0]						mmcm_clrs_shft	= 4'HF	;
	reg		[7: 0]						mmcm_cken_shft	= 8'H0	;

	wire								mmcm_clrs	=	mmcm_clrs_shft[0]	;
	wire								mmcm_cken	=	mmcm_cken_shft[0]	;

	always@(posedge link_fclk)
	if(~mmcm_lock)						mmcm_clrs_shft	<=	4'HF	;
	else 								mmcm_clrs_shft	<= {1'B0	,	mmcm_clrs_shft[3:1]	};

	always@(posedge link_fclk)
	if(~mmcm_lock)						mmcm_cken_shft	<=	8'H0	;
	else 								mmcm_cken_shft	<= {1'B1	,	mmcm_cken_shft[7:1]	};
//----------------------------------------------------------------------
//  	(* KEEP = "TRUE" *)
//  	BUFGCE_DIV #(		
//		.BUFGCE_DIVIDE					(1.0 			),      // 1-8
//		.IS_CE_INVERTED					(1'b0			),  // Optional inversion for CE
//		.IS_CLR_INVERTED				(1'b0			), // Optional inversion for CLR
//		.IS_I_INVERTED					(1'b0			))    // Optional inversion for I
		
//	                               BUFG_FCLK(	
//		.O								(link_fclk		), 	// 1-bit output: Buffer
//		.CLR							(mmcm_clrs		), 	// 1-bit input: Asynchronous clear
//		.CE								(mmcm_cken		), 	// 1-bit input: Buffer enable
//		.I								(mmcm_200m		));	// 1-bit input: Buffer
//----------------------------------------------------------------------
  	(* KEEP = "TRUE" *)
  	BUFGCE_DIV #(		
		.BUFGCE_DIVIDE					(4.0 			),      // 1-8
		.IS_CE_INVERTED					(1'b0			),  // Optional inversion for CE
		.IS_CLR_INVERTED				(1'b0			), // Optional inversion for CLR
		.IS_I_INVERTED					(1'b0			))    // Optional inversion for I
		
	                               BUFG_SCLK(	
		.O								(link_sclk		), 	// 1-bit output: Buffer
		.CLR							(mmcm_clrs		), 	// 1-bit input: Asynchronous clear
		.CE								(mmcm_cken		), 	// 1-bit input: Buffer enable
		.I								(link_fclk		));	// 1-bit input: Buffer
//----------------------------------------------------------------------
  	(* KEEP = "TRUE" *)
  	BUFGCE_DIV #(		
		.BUFGCE_DIVIDE					(5.0 			),      // 1-8
		.IS_CE_INVERTED					(1'b0			),  // Optional inversion for CE
		.IS_CLR_INVERTED				(1'b0			), // Optional inversion for CLR
		.IS_I_INVERTED					(1'b0			))    // Optional inversion for I
		
	                               BUFG_CCLK(	
		.O								(link_cclk		), 	// 1-bit output: Buffer
		.CLR							(mmcm_clrs		), 	// 1-bit input: Asynchronous clear
		.CE								(mmcm_cken		), 	// 1-bit input: Buffer enable
		.I								(link_fclk		));	// 1-bit input: Buffer


endmodule




module MMCM_200M

 (// Clock in ports
  // Clock out ports
  output        clko_200m,
  // Status and control signals
  input         resetn,
  output        locked,
  input         clki_100m
 );
  // Input buffering
  //------------------------------------
wire clki_100m_MMCM_200M;
wire clki_100m_MMCM_200M_buf;
wire clk_in2_MMCM_200M;
  IBUF clkin1_ibuf
   (.O (clki_100m_MMCM_200M),
    .I (clki_100m));




  // Clocking PRIMITIVE
  //------------------------------------

  // Instantiation of the MMCM PRIMITIVE
  //    * Unused inputs are tied off
  //    * Unused outputs are labeled unused

  wire        clko_200m_MMCM_200M;
  wire        clk_out2_MMCM_200M;
  wire        clk_out3_MMCM_200M;
  wire        clk_out4_MMCM_200M;
  wire        clk_out5_MMCM_200M;
  wire        clk_out6_MMCM_200M;
  wire        clk_out7_MMCM_200M;

  wire [15:0] do_unused;
  wire        drdy_unused;
  wire        psdone_unused;
  wire        locked_int;
  wire        clkfbout_MMCM_200M;
  wire        clkfbout_buf_MMCM_200M;
  wire        clkfboutb_unused;
    wire clkout0b_unused;
   wire clkout1_unused;
   wire clkout1b_unused;
   wire clkout2_unused;
   wire clkout2b_unused;
   wire clkout3_unused;
   wire clkout3b_unused;
   wire clkout4_unused;
  wire        clkout5_unused;
  wire        clkout6_unused;
  wire        clkfbstopped_unused;
  wire        clkinstopped_unused;
  wire        reset_high;
  (* KEEP = "TRUE" *) 
  (* ASYNC_REG = "TRUE" *)
  reg  [7 :0] seq_reg1 = 0;


  
    MMCME3_ADV

  #(.BANDWIDTH            ("OPTIMIZED"),
    .CLKOUT4_CASCADE      ("FALSE"),
    .COMPENSATION         ("AUTO"),
    .STARTUP_WAIT         ("FALSE"),
    .DIVCLK_DIVIDE        (1),
    .CLKFBOUT_MULT_F      (10.000),
    .CLKFBOUT_PHASE       (0.000),
    .CLKFBOUT_USE_FINE_PS ("FALSE"),
    .CLKOUT0_DIVIDE_F     (5.000),
    .CLKOUT0_PHASE        (0.000),
    .CLKOUT0_DUTY_CYCLE   (0.500),
    .CLKOUT0_USE_FINE_PS  ("FALSE"),
    .CLKIN1_PERIOD        (10.000))
  
  INST   (
    .CLKFBOUT            (clkfbout_MMCM_200M),
    .CLKFBOUTB           (clkfboutb_unused),
    .CLKOUT0             (clko_200m_MMCM_200M),
    .CLKOUT0B            (clkout0b_unused),
    .CLKOUT1             (clkout1_unused),
    .CLKOUT1B            (clkout1b_unused),
    .CLKOUT2             (clkout2_unused),
    .CLKOUT2B            (clkout2b_unused),
    .CLKOUT3             (clkout3_unused),
    .CLKOUT3B            (clkout3b_unused),
    .CLKOUT4             (clkout4_unused),
    .CLKOUT5             (clkout5_unused),
    .CLKOUT6             (clkout6_unused),
     // Input clock control
    .CLKFBIN             (clkfbout_MMCM_200M),
    .CLKIN1              (clki_100m_MMCM_200M),
    .CLKIN2              (1'b0),
     // Tied to always select the primary input clock
    .CLKINSEL            (1'b1),
    // Ports for dynamic reconfiguration
    .DADDR               (7'h0),
    .DCLK                (1'b0),
    .DEN                 (1'b0),
    .DI                  (16'h0),
    .DO                  (do_unused),
    .DRDY                (drdy_unused),
    .DWE                 (1'b0),
    .CDDCDONE            (),
    .CDDCREQ             (1'b0),
    // Ports for dynamic phase shift
    .PSCLK               (1'b0),
    .PSEN                (1'b0),
    .PSINCDEC            (1'b0),
    .PSDONE              (psdone_unused),
    // Other control and status signals
    .LOCKED              (locked_int),
    .CLKINSTOPPED        (clkinstopped_unused),
    .CLKFBSTOPPED        (clkfbstopped_unused),
    .PWRDWN              (1'b0),
    .RST                 (reset_high));
  assign reset_high = ~resetn; 

  assign locked = locked_int;
// Clock Monitor clock assigning
//--------------------------------------
 // Output buffering
  //-----------------------------------

  BUFG clkf_buf
   (.O (clkfbout_buf_MMCM_200M),
    .I (clkfbout_MMCM_200M));






  BUFGCE clkout1_buf
   (.O   (clko_200m),
    .CE  (seq_reg1[7]),
    .I   (clko_200m_MMCM_200M));

  BUFGCE clkout1_buf_en
   (.O   (clko_200m_MMCM_200M_en_clk),
    .CE  (1'b1),
    .I   (clko_200m_MMCM_200M));
  always @(posedge clko_200m_MMCM_200M_en_clk or posedge reset_high) begin
    if(reset_high == 1'b1) begin
	    seq_reg1 <= 8'h00;
    end
    else begin
        seq_reg1 <= {seq_reg1[6:0],locked_int};
  
    end
  end





endmodule
