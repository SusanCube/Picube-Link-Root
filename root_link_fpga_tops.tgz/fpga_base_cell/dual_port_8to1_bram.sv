module	dual_port_8to1_bram	(
	input  				 				wport_csen	,
	input		[ 8:0]					wport_addr	,
	input		[255:0]					wport_data	,
	input								wport_clki	,

	input		[12 :0]			 		rport_addr	,
	output	reg	[31 :0]			 		rport_data	,
	input								rport_clki	);

(* ram_style="block" *) reg [255: 0] 	memo[0:511];

	always@(posedge wport_clki)
	if(wport_csen)
		memo[wport_addr]	<=	wport_data		;
//------------------------------------------------------------------------------
//	always@(posedge rport_clki)
	wire		[255:0]					rport_buff	;

	wire		[  8:0]					rport_hadd	= rport_addr[11: 3]	;
	wire		[  2:0]					rport_ladd	= rport_addr[ 2: 0]	;
	

	assign	rport_buff		=	memo[rport_hadd];
	assign	rport_data		=	rport_ladd == 7	?	rport_buff[255:224]	:
								rport_ladd == 6	?	rport_buff[223:192]	:
								rport_ladd == 5	?	rport_buff[191:160]	:
								rport_ladd == 4	?	rport_buff[159:128]	:
								rport_ladd == 3	?	rport_buff[127: 96]	:
								rport_ladd == 2	?	rport_buff[ 95: 64]	:
								rport_ladd == 1	?	rport_buff[ 63: 32]	:	rport_buff[ 31:  0]	;

endmodule