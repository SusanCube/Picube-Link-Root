module	dual_port_bram	#(
  parameter ADDR_BITS = 4	,
  parameter DATA_BITS = 256	
)  (
	input  				 			wport_csen	,
	input		[ADDR_BITS-1:0]		wport_addr	,
	input		[DATA_BITS-1:0]		wport_data	,
	input							wport_clki	,

//	input  				 			rport_csen	,
	input		[ADDR_BITS-1:0] 	rport_addr	,
	output	reg	[DATA_BITS-1:0] 	rport_data	,
	input							rport_clki	);

  //(* ram_style="register" *) reg [DATA_BITS-1:0] mem [(1<<ADDR_BITS)-1:0];
(* ram_style="block" *) reg [DATA_BITS-1:0] memo[(1<<ADDR_BITS)-1:0];

//initial for (integer i = 0; i < (1<<ADDR_BITS); i = i + 1) mem[i] = {DATA_BITS{1'b0}};
//  for (genvar i = 0; i < DATA_BITS/COL_WIDTH; i = i+1) begin
//    always @(posedge CLKA)
//      if (~CENA)
//        QA[(i+1)*COL_WIDTH-1:i*COL_WIDTH] <= mem[AA][(i+1)*COL_WIDTH-1:i*COL_WIDTH];
//
//    always @(posedge CLKB)
//      if (~CENB)
//        if (~WENB && ~BWENB[i]) begin
//          mem[AB][(i+1)*COL_WIDTH-1:i*COL_WIDTH] <= DB[(i+1)*COL_WIDTH-1:i*COL_WIDTH];
//        end
//  end
//	if(rport_csen)

	always@(posedge wport_clki)
	if(wport_csen)
		memo[wport_addr]	<=	wport_data		;

	always@(posedge rport_clki)
		rport_data			<=	memo[rport_addr];
		


endmodule