module	ping_pang_rimt_bram	(
	input								wport_rank	,
	input  				 				wport_csen	,
	input		[ 5: 0]					wport_addr	,
	input		[255:0]					wport_data	,
	input								wport_clki	,

	input								rport_rank	,
	input		[ 5 :0]			 		rport_addr	,
	output	reg	[255:0]			 		rport_data	,
	input								rport_clki	);
/**********************************************************************************************************************/
(*ram_style="block"*) 	reg [255: 0] 	memo[0:127]	;

	wire		[ 7: 0]					page_wadd	= {	wport_rank,	wport_addr	};
	
	always@(posedge wport_clki)
	if(wport_csen)		
		memo[page_wadd]	<= 		wport_data	;
/**********************************************************************************************************************/
	wire		[ 7: 0]					page_radd	;

	assign		page_radd 	= {	rport_rank,	rport_addr	};

	always@(posedge rport_clki)		
		rport_data		<=	memo[page_radd]	;
/**********************************************************************************************************************/

endmodule