
module	dlys_inst(
	output								dlys_sout	,
	input								dlys_sdin	);
//----------------------------------------------------------------------------------------------------------
wire									dlys_smid	;

buf #1000ps	buf_00		(	dlys_smid	,	dlys_sdin	);
buf #600ps	buf_01		(	dlys_sout	,	dlys_smid	);
			



endmodule

