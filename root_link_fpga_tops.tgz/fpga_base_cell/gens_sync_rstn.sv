module  gens_sync_rstn(
    output								rstn_gens		,
	input								rstn_reqs		,
	input								main_clki		);

	reg	[3:0]						rstn_gens_shft	= 0	;

	always@(posedge main_clki or negedge rstn_reqs)
	if(~rstn_reqs)					rstn_gens_shft	<=	4'B0000	;
	else							rstn_gens_shft	<= {1'B1,	rstn_gens_shft[3:1]}	;

	assign	rstn_gens	=	rstn_gens_shft[0]	;
	


endmodule


 