
module	gens_sign_slow_fast  #(	parameter EXTN = 1	) (	
	input								slow_sign	,
	input								slow_clki	,
	input								slow_rstn	,

	output								fast_sign   ,
	input								fast_clki	,
	input								fast_rstn	);
//------------------------------------------------------------------------------
	reg									slow_extn_samp	;
	reg									slow_extn_mark	;

	always@(posedge slow_clki or negedge slow_rstn)
    if(~slow_rstn)      				slow_extn_samp	<= 	0	;
	else								slow_extn_samp	<=	slow_sign	;

	always@(posedge slow_clki or negedge slow_rstn)
    if(~slow_rstn)      				slow_extn_mark	<= 	1'B0     ;
	else								slow_extn_mark	<=	slow_extn_samp | slow_sign	;
//----------------------------------------------------------------------
	reg		[ EXTN: 0]					fast_extn_mark	;
		
	always@(posedge fast_clki or negedge fast_rstn)
    if(~fast_rstn)						fast_extn_mark	<=	0     ;
	else 								fast_extn_mark	<= {slow_extn_mark	, fast_extn_mark[ EXTN :1]	};

	assign	fast_sign	=	fast_extn_mark[0]	;
	
endmodule