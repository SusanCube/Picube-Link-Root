module	xcku_sysclk(
	output								link_fclk	,
//	output								link_strb	,
	output								link_sclk	,
	output								init_bclk	,
	
	output								link_rstn	,
	output								chip_rstn	,
	output								dlys_rstn	,

	input								auxi_rstn	,
	input								cold_rstn	,
	input								chip_clki	);
/**********************************************************************************************************************/
	wire								mmcm_lock	;

	wire	mixs_rstn		=   &{		cold_rstn ,	mmcm_lock ,	auxi_rstn	};
	assign	dlys_rstn 		=	&{		cold_rstn , mmcm_lock 				};
//------------------------------------------------------------------------------
	reg		[ 7: 0]						chip_rstn_time 	= 	0 	;
	wire	[ 7: 0]						chip_rstn_tnxt	=	1 +	chip_rstn_time	;

	assign	chip_rstn		=   		chip_rstn_time	==	8'H7F	;
	
	always@(posedge chip_clki)			
	if(~chip_rstn)						chip_rstn_time	<=	chip_rstn_tnxt	;
//------------------------------------------------------------------------------
	reg		[ 7: 0]						link_rstn_time 	= 	0	;
	wire	[ 7: 0]						link_rstn_tnxt	=	1 +	link_rstn_time	;

	assign	link_rstn		=   		link_rstn_time	==	8'H7F	;

	always@(posedge link_sclk  or negedge mixs_rstn )
	if(~mixs_rstn)						link_rstn_time	<=	0	;
	else if(~link_rstn)					link_rstn_time	<=	link_rstn_tnxt	;
/**********************************************************************************************************************/
	wire        						clkfb_cko	;
  	wire        						clkfb_cki	;
	wire								mmcmo_320	;
//----------------------------------------------------------------------	
   	(* KEEP = "TRUE" *)
	BUFG 							clkfb_buf(
		.O								(clkfb_cki	),
    	.I								(clkfb_cko	));
//----------------------------------------------------------------------
   	(* KEEP = "TRUE" *)
	BUFG 							BUFG_320M(
		.O  						 	(link_fclk		),
    	.I  						 	(mmcmo_320		));		
//----------------------------------------------------------------------
	(* KEEP = "TRUE" *)
  	BUFGCE_DIV #(
		.BUFGCE_DIVIDE					(4.0 	),// 1-8
		.IS_CE_INVERTED					(1'b0	),// Optional inversion for CE
		.IS_CLR_INVERTED				(1'b0	),// Optional inversion for CLR
		.IS_I_INVERTED					(1'b0	))// Optional inversion for I
   	BUFG_080M (	
		.CE								(1'b1		), 	// 1-bit input: Buffer enable
		.CLR							(1'b0		), 	// 1-bit input: Asynchronous clear
		.O								(link_sclk	), 	// 1-bit output: Buffer
		.I								(mmcmo_320	));	// 1-bit input: Buffer
//----------------------------------------------------------------------
   	(* KEEP = "TRUE" *)
  	BUFGCE_DIV #(
		.BUFGCE_DIVIDE					(8.0 	),      // 1-8
		.IS_CE_INVERTED					(1'b0	),  // Optional inversion for CE
		.IS_CLR_INVERTED				(1'b0	), // Optional inversion for CLR
		.IS_I_INVERTED					(1'b0	))    // Optional inversion for I
	BUFG_040M (	
		.CE								(1'b1		),	// 1-bit input: Buffer enable
		.CLR							(1'b0		), 	// 1-bit input: Asynchronous clear
		.O								(init_bclk	), 	// 1-bit output: Buffer
		.I								(mmcmo_320	));	// 1-bit input: Buffer
/**********************************************************************************************************************/
	MMCME3_ADV  #(	
		.BANDWIDTH            			("HIGH"		),
    	.CLKOUT4_CASCADE      			("FALSE"	),
    	.COMPENSATION         			("AUTO"		),
    	.STARTUP_WAIT         			("FALSE"	),
    	.DIVCLK_DIVIDE        			(1			),
    	.CLKFBOUT_MULT_F      			(12.000		),
    	.CLKFBOUT_PHASE       			(0.000		),
    	.CLKFBOUT_USE_FINE_PS 			("FALSE"	),
	
		.CLKOUT0_DIVIDE_F     			(3.750		),
    	.CLKOUT0_PHASE        			(0.000		),
    	.CLKOUT0_DUTY_CYCLE   			(0.500		),
    	.CLKOUT0_USE_FINE_PS  			("FALSE"	),
	
		.CLKOUT1_DIVIDE       			(4.00		),
    	.CLKOUT1_PHASE        			(0.000		),
    	.CLKOUT1_DUTY_CYCLE   			(0.500		),
    	.CLKOUT1_USE_FINE_PS  			("FALSE"	),
	
		.CLKOUT2_DIVIDE       			(30			),
    	.CLKOUT2_PHASE        			(0.000		),
    	.CLKOUT2_DUTY_CYCLE   			(0.500		),
    	.CLKOUT2_USE_FINE_PS  			("FALSE"	),
    	.CLKIN1_PERIOD        			(10.000		))
    
	CHIP_MMCM(
		.CLKFBIN             			(clkfb_cki		),
		.CLKFBOUT            			(clkfb_cko		),
		.CLKFBOUTB           			(				),			//clkfboutb_unused			),
		
		.CLKIN1              			(chip_clki		),
		.CLKIN2              			(1'b0			),
		.CLKINSEL            			(1'b1			),


		.CLKOUT0             			(mmcmo_320		),
		.CLKOUT0B            			(),							//clkout0b_unused			),
		.CLKOUT1             			(),							//clkout1_unused			),
		.CLKOUT1B            			(),							//clkout1b_unused			),
		.CLKOUT2             			(),							//clkout2_unused			),
		.CLKOUT2B            			(),							//clkout2b_unused			),
		.CLKOUT3             			(),							//clkout3_unused			),
		.CLKOUT3B            			(),							//clkout3b_unused			),
		.CLKOUT4             			(),							//clkout4_unused			),
		.CLKOUT5             			(),							//clkout5_unused			),
		.CLKOUT6             			(),							//clkout6_unused			),
		
		// Ports for dynamic reconfiguration
		.DADDR               			(7'h0),
		.DCLK                			(1'b0),
		.DEN                 			(1'b0),
		.DI                  			(16'h0),
		.DO                  			(),							//do_unused),
		.DRDY                			(),							//drdy_unused),
		.DWE                 			(1'b0),
		.CDDCDONE            			(),
		.CDDCREQ             			(1'b0),
		// Ports for dynamic phase shift
		.PSCLK               			(1'b0),
		.PSEN                			(1'b0),
		.PSINCDEC            			(1'b0),

		.PSDONE              			(),							//psdone_unused),
		.CLKINSTOPPED        			(),							//clkinstopped_unused),
		.CLKFBSTOPPED        			(),							//clkfbstopped_unused),
		.PWRDWN              			(1'b0			),
		.LOCKED              			( mmcm_lock		),
		.RST                 			(~chip_rstn		));
/**********************************************************************************************************************/
endmodule
//------------------------------------------------------------------------------
//	reg		[ 3: 0]						link_strb_posi	=	4'H1	;
//	
//	wire								mmcm_lock		;
//	assign	link_strb		=			link_strb_posi[3]	;
//
//	always@(posedge link_fclk )
//	if(!mmcm_lock) 						link_strb_posi	<=	4'H1	;
//	else								link_strb_posi	<= {link_strb_posi[2:0],link_strb_posi[3]};	
//	reg									dlys_ctrl_disa	=	1'B1	;
//	reg		[ 15: 0]					dlys_ctrl_time	=	16'H0000;
//
//	assign	dlys_prst		=			dlys_ctrl_disa	;
//
//	wire	dlys_ctrl_init	=			dlys_ctrl_time	<= 	16'HFFF0;
//	
//
//	always@(posedge link_sclk)
//	if(~cold_rstn)						dlys_ctrl_time	<=	16'H0	;
//	else if(~mmcm_lock) 				dlys_ctrl_time	<=	16'H0	;
//	else if( dlys_ctrl_init)			dlys_ctrl_time	<=	16'H1	+	dlys_ctrl_time	;
//
//	always@(posedge link_sclk)			dlys_ctrl_disa	<=	dlys_ctrl_init	;
/**********************************************************************************************************************/
//	reg									dlys_cell_disa	=	1'B0	;
//	reg		[  2: 0]					dlys_drdy_samp	=	3'H0	;
//	
//	assign	dlys_brst		=			dlys_cell_disa	;
//	
//	always@(posedge link_sclk)			dlys_drdy_samp	<= {dlys_drdy	,	dlys_drdy_samp[2:1]};
//	always@(posedge link_sclk)			dlys_cell_disa	<= 	dlys_drdy_samp[1:0]	==	2'B10		;

 