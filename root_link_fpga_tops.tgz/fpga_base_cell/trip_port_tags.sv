module	trip_port_tags	 (
	input  				 				wport_csen	,
	input		[ 2: 0]					wport_addr	,
	input		[ 1: 0]					wport_tags	,
	input		[31: 0]					wport_data	,
	input								wport_clki	,
	input								wport_rstn	,
	
	input		[ 2: 0] 				rport_addr	,
	output	reg	[ 1: 0] 				rport_tags	,
	output	reg	[31: 0] 				rport_data	,
	input								rport_clki	);

	reg 		[31:0] 					data_memo[ 0: 7]	;
	reg 		[ 1:0] 					tags_memo[ 0: 7]	;

	wire		[ 0: 7]					wport_csid	;
	wire		[ 0: 7]					wport_wrid	;

for(genvar i = 0 ; i < 8 ; i++) begin	:	tags_memo_wrcs_ctrl

	assign	wport_csid[i]	=	wport_addr	==	i				;
	assign	wport_wrid[i]	= &{wport_csen 	, 	wport_csid[i]	};

	always@(posedge wport_clki )
	if(wport_rstn)				tags_memo[i]	<=	2'H0		;
	else if(wport_wrid[i])		tags_memo[i]	<=	wport_tags	;

	always@(posedge wport_clki )
	if(wport_rstn)				data_memo[i]	<=	32'H0		;
	else if(wport_wrid[i])		data_memo[i]	<=	wport_data	;
end	


//	always@(posedge rport_clki)
	assign	rport_tags			=	tags_memo[rport_addr];

//	always@(posedge rport_clki)
	assign	rport_data			=	data_memo[rport_addr];
		


endmodule