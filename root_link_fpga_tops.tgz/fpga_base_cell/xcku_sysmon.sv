///////////////////////////////////////////////////////////////////////////////
//    
//    Company:          Xilinx
//    Engineer:         Jim Tatsukawa
//    Date:             3/30/2014
//    Design Name:      ug580
//    Module Name:      ug580.v
//    Version:          1.1
//    Target Devices:   UltraScale
//    Tool versions:    2014.1
//    Description:      This is a basic demonstration of SYSMON 
// 
//    Disclaimer:  XILINX IS PROVIDING THIS DESIGN, CODE, OR
//                 INFORMATION "AS IS" SOLELY FOR USE IN DEVELOPING
//                 PROGRAMS AND SOLUTIONS FOR XILINX DEVICES.  BY
//                 PROVIDING THIS DESIGN, CODE, OR INFORMATION AS
//                 ONE POSSIBLE IMPLEMENTATION OF THIS FEATURE,
//                 APPLICATION OR STANDARD, XILINX IS MAKING NO
//                 REPRESENTATION THAT THIS IMPLEMENTATION IS FREE
//                 FROM ANY CLAIMS OF INFRINGEMENT, AND YOU ARE
//                 RESPONSIBLE FOR OBTAINING ANY RIGHTS YOU MAY
//                 REQUIRE FOR YOUR IMPLEMENTATION.  XILINX
//                 EXPRESSLY DISCLAIMS ANY WARRANTY WHATSOEVER WITH
//                 RESPECT TO THE ADEQUACY OF THE IMPLEMENTATION,
//                 INCLUDING BUT NOT LIMITED TO ANY WARRANTIES OR
//                 REPRESENTATIONS THAT THIS IMPLEMENTATION IS FREE
//                 FROM CLAIMS OF INFRINGEMENT, IMPLIED WARRANTIES
//                 OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
//                 PURPOSE.
// 
//                 (c) Copyright 2013-2014 Xilinx, Inc.
//                 All rights reserved.
// 
///////////////////////////////////////////////////////////////////////////////
module xcku_sysmon (
	output reg	[15:0] 				MEASURED_TEMP		, 
	output reg	[15:0] 				MEASURED_VCCINT		, 
	output reg	[15:0] 				MEASURED_VCCAUX		, 
	output reg	[15:0] 				MEASURED_VCCBRAM	,
	input 							DCLK				,  // Clock input for DRP
	input 							RESET				);	
//	input [3:0] VAUXP, VAUXN,  // Auxiliary analog channel inputs
//	input VP, VN,// Dedicated and Hardwired Analog Input Pair
//	inout I2C_SCLK,
//	inout I2C_SDA,

//	output reg [15:0] MEASURED_AUX0, MEASURED_AUX1, 
//	output reg [15:0] MEASURED_AUX2, MEASURED_AUX3,

//	output wire [15:0] ALM,
//	output wire [5:0]  CHANNEL,       
//	output wire        OT,
//	output wire        EOC,
//	output wire        EOS    );     

//	wire		[15:0] 				ALM		;
//	wire		[5:0]  				CHANNEL	;       
//	wire		       				OT		;
	wire		       				EOC		;
	wire		       				EOS   	;     


	reg 		[15:0] 				MEASURED_AUX0	;
	reg 		[15:0] 				MEASURED_AUX1	;
	reg 		[15:0] 				MEASURED_AUX2	;
	reg 		[15:0] 				MEASURED_AUX3	;
	
    wire busy;
    wire [5:0] channel;
    wire drdy;
    wire i2c_sclk_in;
    wire i2c_sclk_ts;
    wire i2c_sda_in;
    wire i2c_sda_ts;
    
    
    reg [7:0] daddr;
    reg [15:0] di_drp;
    wire [15:0] do_drp;

    wire dclk_bufg, dclk_ibuf;
    reg [1:0]  den_reg;
    reg [1:0]  dwe_reg;
    
    parameter       init_read       = 8'h00,
                    read_waitdrdy   = 8'h01,
                    write_waitdrdy  = 8'h03,
                    read_reg00      = 8'h04,
                    reg00_waitdrdy  = 8'h05,
                    read_reg01      = 8'h06,
                    reg01_waitdrdy  = 8'h07,
                    read_reg02      = 8'h08,
                    reg02_waitdrdy  = 8'h09,
                    read_reg06      = 8'h0a,
                    reg06_waitdrdy  = 8'h0b,
                    read_reg10      = 8'h0c,
                    reg10_waitdrdy  = 8'h0d,
                    read_reg11      = 8'h0e,
                    reg11_waitdrdy  = 8'h0f,
                    read_reg12      = 8'h10,
                    reg12_waitdrdy  = 8'h11,
                    read_reg13      = 8'h12,
                    reg13_waitdrdy  = 8'h13;
    reg [7:0]   state = read_reg00;

    IBUF i_ibuf (.I(DCLK),  .O(dclk_ibuf));
    BUFG i_bufg (.I(dclk_ibuf), .O(dclk_bufg));
//----------------------------------------------------------------------    

   always @(posedge dclk_bufg)
      if (RESET) begin
         state   <= init_read;
         den_reg <= 2'h0;
         dwe_reg <= 2'h0;
         di_drp  <= 16'h0000;
      end
      else
         case (state)
         init_read : begin
            daddr = 8'h40;
            den_reg = 2'h2; // performing read
            if (EOC == 1 ) state <= read_waitdrdy;
            end
         read_waitdrdy : 
            if ( EOC ==1)  	begin
               di_drp = do_drp  & 16'h03_FF; //Clearing AVG bits for Configreg0
               daddr = 8'h40;
               den_reg = 2'h2;
               dwe_reg = 2'h2; // performing write
               state = write_waitdrdy;
            end
            else begin
               den_reg = { 1'b0, den_reg[1] } ;
               dwe_reg = { 1'b0, dwe_reg[1] } ;
               state = state;                
            end
         write_waitdrdy : 
            if (drdy ==1) begin
               state = read_reg00;
               end
            else begin
               den_reg = { 1'b0, den_reg[1] } ;
               dwe_reg = { 1'b0, dwe_reg[1] } ;      
               state = state;          
            end
         read_reg00 : begin
            daddr   = 8'h00;
            den_reg = 2'h2; // performing read
            if (EOS == 1) state   <=reg00_waitdrdy;
            end
         reg00_waitdrdy : 
            if (drdy ==1)  	begin
               MEASURED_TEMP = do_drp; 
               state <=read_reg01;
               end
            else begin
               den_reg = { 1'b0, den_reg[1] } ;
               dwe_reg = { 1'b0, dwe_reg[1] } ;      
               state = state;          
            end
         read_reg01 : begin
            daddr   = 8'h01;
            den_reg = 2'h2; 
            state   <=reg01_waitdrdy;
            end
            reg01_waitdrdy : 
            if (drdy ==1)  	begin
               MEASURED_VCCINT = do_drp; 
               state <=read_reg02;
               end
            else begin
               den_reg = { 1'b0, den_reg[1] } ;
               dwe_reg = { 1'b0, dwe_reg[1] } ;      
               state = state;          
            end
         read_reg02 : begin
            daddr   = 8'h02;
            den_reg = 2'h2; 
            state   <=reg02_waitdrdy;
            end
         reg02_waitdrdy : 
            if (drdy ==1)  	begin
               MEASURED_VCCAUX = do_drp; 
               state <=read_reg06;
               end
            else begin
               den_reg = { 1'b0, den_reg[1] } ;
               dwe_reg = { 1'b0, dwe_reg[1] } ;      
               state = state;          
            end
         read_reg06 : begin
            daddr   = 8'h06;
            den_reg = 2'h2;
            state   <=reg06_waitdrdy;
            end
         reg06_waitdrdy : 
            if (drdy ==1)  	begin
               MEASURED_VCCBRAM = do_drp; 
               state <= read_reg10;
            end
            else begin
               den_reg = { 1'b0, den_reg[1] } ;
               dwe_reg = { 1'b0, dwe_reg[1] } ;      
               state = state;          
            end
         read_reg10 : begin
               daddr   = 8'h10;
               den_reg = 2'h2; // performing read
               state   <= reg10_waitdrdy;
            end
         reg10_waitdrdy : 
            if (drdy ==1)  	begin
               MEASURED_AUX0 = do_drp; 
               state <= read_reg11;
            end
            else begin
               den_reg = { 1'b0, den_reg[1] } ;
               dwe_reg = { 1'b0, dwe_reg[1] } ;      
               state = state;          
            end
         read_reg11 : begin
            daddr   = 8'h11;
            den_reg = 2'h2; // performing read
            state   <= reg11_waitdrdy;
            end
         reg11_waitdrdy : 
            if (drdy ==1)  	begin
               MEASURED_AUX1 = do_drp; 
               state <= read_reg12;
               end
            else begin
               den_reg = { 1'b0, den_reg[1] } ;
               dwe_reg = { 1'b0, dwe_reg[1] } ;      
               state = state;          
            end
         read_reg12 : begin
            daddr   = 8'h12;
            den_reg = 2'h2; // performing read
            state   <= reg12_waitdrdy;
            end
         reg12_waitdrdy : 
            if (drdy ==1)  	begin
               MEASURED_AUX2= do_drp; 
               state <= read_reg13;
               end
            else begin
               den_reg = { 1'b0, den_reg[1] } ;
               dwe_reg = { 1'b0, dwe_reg[1] } ;      
               state = state;          
            end
         read_reg13 : begin
            daddr   = 8'h13;
            den_reg = 2'h2; // performing read
            state   <= reg13_waitdrdy;
            end
         reg13_waitdrdy :
            if (drdy ==1)  	begin
               MEASURED_AUX3= do_drp; 
               state <=read_reg00;
               daddr   = 8'h00;
            end
            else begin
               den_reg = { 1'b0, den_reg[1] } ;
               dwe_reg = { 1'b0, dwe_reg[1] } ;      
               state = state;          
            end
         default :
                  state <=read_reg00;
         endcase
 
//----------------------------------------------------------------------
    wire 		[15:0]				vauxp_active 	= {16'h000	};
    wire 		[15:0]				vauxn_active 	= {16'h000	};
	wire							vanap_active	=	1'b0	;
	wire							vanan_active	=	1'b0	;

SYSMONE1 #(// Initializing the SYSMON Control Registers
    .INIT_40						(16'h9000			),// averaging of 16 selected for external channels
    .INIT_41						(16'h2EF0			),// Continuous Seq Mode, Disable unused ALMs, Enable calibration
    .INIT_42						(16'h0400			),// Set DCLK divides
    .INIT_43						(16'h2EF0			),// CONFIG3 
    .INIT_46						(16'h0001			),// CHSEL0 - enable USER0
    .INIT_47						(16'h0000			),// SEQAVG0 disabled 
    .INIT_48						(16'h4701			),// CHSEL1 - enable Temp VCCINT, VCCAUX, VCCBRAM, and calibration
    .INIT_49						(16'h000F			),// CHSEL2 - enable aux analog channels 0 - 3
    .INIT_4A						(16'h0000			),// SEQAVG1 disabled
    .INIT_4B						(16'h0000			),// SEQAVG2 disabled
    .INIT_4C						(16'h0000			),// SEQINMODE0 
    .INIT_4D						(16'h0000			),// SEQINMODE1
    .INIT_4E						(16'h0000			),// SEQACQ0
    .INIT_4F						(16'h0000			),// SEQACQ1
    .INIT_50						(16'hB723			),// Temp upper alarm trigger 85�C -For On-Chip Reference
    .INIT_51						(16'h5999			),// Vccint upper alarm limit 1.05V
    .INIT_52						(16'hA147			),// Vccaux upper alarm limit 1.89V
    .INIT_53						(16'hCB93			),// OT upper alarm limit 125�C - For On-Chip Reference
    .INIT_54						(16'hAA5F			),// Temp lower alarm reset 60�C - For On-Chip Reference
    .INIT_55						(16'h5111			),// Vccint lower alarm limit 0.95V
    .INIT_56						(16'h91EB			),// Vccaux lower alarm limit 1.71V
    .INIT_57						(16'hAF7B			),// OT lower alarm reset 70�C - For On-Chip Reference
    .INIT_58						(16'h5999			),// VCCBRAM upper alarm limit 1.05V
    .INIT_5C						(16'h5111			), // VUSER0 upper alarm limit 1.05V 
    .INIT_60						(16'h5999			), // VUSER1 upper alarm limit 1.05V 
    .INIT_61						(16'h5999			), // VUSER2 upper alarm limit 1.05V 
    .INIT_62						(16'h5999			), // VUSER3 upper alarm limit 1.05V 
    .INIT_63						(16'h5999			), // VCCBRAM lower alarm limit 1.05V 
    .INIT_64						(16'h5999			), // VCCSYSMON upper alarm limit 1.05V 
    .INIT_68						(16'h5111			), // VUSER0 lower alarm limit 0.95V 
    .INIT_69						(16'h5111			), // VUSER1 lower alarm limit 0.95V 
    .INIT_6A						(16'h5111			), // VUSER2 lower alarm limit 0.95V 
    .INIT_6B						(16'h5111			), // VUSER3 lower alarm limit 0.95V 
    .INIT_6C						(16'h5111			), // VCCBRAM lower alarm limit 0.95V 
    .INIT_78						(16'h0000			), // SEQINMODE2
    .INIT_79						(16'h0000			), // SEQACQ2
    .SYSMON_VUSER0_BANK				(66					),
    .SYSMON_VUSER0_MONITOR			("VCCO"				),
    .SIM_MONITOR_FILE				("/home/home1/yangxg/X11/agile_p4e08/rsrc/fpga_base_cell/xcku_sysmon.sti"	))// Analog Stimulus file for simulation
	
	SYSMON_XCKU (// Connect up instance IO. See UG580 for port descriptions
	.DADDR  						(daddr			),
	.DCLK   						(dclk_bufg		),
	.DEN    						(den_reg[0]		),
	.DI     						(di_drp			),
	.DWE    						(dwe_reg[0]		),
	.RESET  						(RESET			),
	
	
	.BUSY   						(busy			),
	.DO     						(do_drp			),
	.DRDY   						(drdy			),
	.EOC    						(EOC			),
	.EOS    						(EOS			),

	.ALM    						(				),
	.CHANNEL						(				),
	.OT     						(				),
	

	.MUXADDR    					(				),// not used
	.CONVST 						(1'b0			),// not used
	.CONVSTCLK  					(1'b0			), // not used
	.JTAGBUSY					   	(				),// not used
	.JTAGLOCKED 					(				),// not used
	.JTAGMODIFIED   				(				),// not used
	.I2C_SCLK   					(1'b0			), // not used
	.I2C_SDA    					(1'b1			), // not used
	.I2C_SCLK_TS  	 				(				), // not used
	.I2C_SDA_TS    					(				), // not used
 	.VAUXP  						(vauxp_active	),
	.VAUXN  						(vauxn_active	),
	.VP     						(vanap_active	),
	.VN     						(vanan_active	));
/*
   IOBUF I2C_SCLK_inst (
      .O(i2c_sclk_in),     // Buffer output
      .IO(I2C_SCLK),   // Buffer inout port (connect directly to top-level port)
      .I(1'b0),     // Buffer input
      .T(i2c_sclk_ts)      // 3-state enable input, high=input, low=output
   );

   IOBUF I2C_SDA_inst (
      .O(i2c_sda_in),     // Buffer output
      .IO(I2C_SDA),   // Buffer inout port (connect directly to top-level port)
      .I(1'b0),     // Buffer input
      .T(i2c_sda_ts)      // 3-state enable input, high=input, low=output
   );
*/



endmodule