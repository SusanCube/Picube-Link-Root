
module  gens_sign_fast_slow #(	parameter EXTN = 2	)
(	
	input								fast_sign   ,
	input								fast_clki	,
	input								fast_rstn	,
	
	output								slow_sign	,
	input								slow_clki	,
	input								slow_rstn	);
//----------------------------------------------------------------------
	reg		[EXTN:0]					fast_extn_samp	;
	reg									fast_extn_mark	;

	always@(posedge fast_clki or negedge fast_rstn)
    if(~fast_rstn)      				fast_extn_samp	<=	0     ;
	else								fast_extn_samp	<={	fast_sign ,	fast_extn_samp[EXTN:1]	};

	always@(posedge fast_clki or negedge fast_rstn)
    if(~fast_rstn)      				fast_extn_mark	<=	1'B0     ;
	else								fast_extn_mark	<=|{fast_sign ,	fast_extn_samp	};
//----------------------------------------------------------------------
	reg		[ 1: 0]						slow_mark_samp	;
		
	always@(posedge slow_clki or negedge slow_rstn)
    if(~slow_rstn)      			    slow_mark_samp  <= 2'H0     ;
	else 								slow_mark_samp 	<={fast_extn_mark	, slow_mark_samp[1]	};

	assign	slow_sign	=	slow_mark_samp[0]	;
	
endmodule