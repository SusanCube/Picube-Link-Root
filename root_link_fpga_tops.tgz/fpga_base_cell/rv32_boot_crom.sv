// 
// FPGA version, by template
//
//  run vivado/ku35_0/getrsrc.sh, 
//    to copy rsim/init_file/tpgs_rv32_crom.hex to <ip_root>/rv32_rom.hex
//    copy this file to vivado/ku35_0/rsrc

module  rv32_boot_crom (
  output  reg [31: 0]       douta ,
  input       [11: 0]       addra ,
  input                     ena   ,
  input                     clka  );

  (* rom_style="{block}" *)
  reg    [31: 0]           memo[0:4096]  ;

	initial 
		$readmemh("/home/home1/yangxg/X11/agile_p4e08/firmware/tpuc_bios/code.hex",memo);

  always  @(posedge clka)
    douta <= ena  ? memo[addra] : douta;

endmodule
