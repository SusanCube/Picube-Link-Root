
module	dlys_tune_ctrl(
	output								dlys_tune_done	,
	input								dlys_tune_reqs	,
	input	[ 8: 0]						dlys_tune_vals	,

	output	reg							dlys_tune_envt	,
	output	reg							dlys_tune_load	,
	output	reg [ 8: 0]					dlys_tune_taps	,

	input								link_clki		,
	input								link_rstn		);
//----------------------------------------------------------------------------------------------------------
	reg		[ 2: 0]						dlys_tune_mfsm	;
	reg									dlys_tune_pass = 0	;
	reg									dlys_tune_csen	;
	reg		[ 3: 0]						dlys_tune_time	;

	assign	dlys_tune_done	=	dlys_tune_pass	;	


	parameter	TUNE_CTRL_IDLE	=	3'H0	;
	parameter	TUNE_ENVT_DISA	=	3'H1	;
	parameter	TUNE_UPDT_TAPS	=	3'H2	;
	parameter	TUNE_UPDT_LOAD	=	3'H3	;
	parameter	TUNE_UPDT_VLID	=	3'H4	;
	parameter	TUNE_ENVT_ACTV	=	3'H5	;
	parameter	TUNE_CTRL_DONE	=	3'H6	;

	wire	tune_hits_ctrl_idle	=		dlys_tune_mfsm	==	TUNE_CTRL_IDLE	;
	wire	tune_hits_envt_disa	=		dlys_tune_mfsm	==	TUNE_ENVT_DISA	;
	wire	tune_hits_updt_taps	=		dlys_tune_mfsm	==	TUNE_UPDT_TAPS	;
	wire	tune_hits_updt_load	=		dlys_tune_mfsm	==	TUNE_UPDT_LOAD	;
	wire	tune_hits_updt_vlid	=		dlys_tune_mfsm	==	TUNE_UPDT_VLID	;
	wire	tune_hits_envt_actv	=		dlys_tune_mfsm	==	TUNE_ENVT_ACTV	;
	wire	tune_hits_ctrl_done	=		dlys_tune_mfsm	==	TUNE_CTRL_DONE	;
	
	wire	tune_dlys_time_enab	= |{tune_hits_envt_disa	,	tune_hits_updt_vlid	};

	wire	dlys_tune_tmax		=		dlys_tune_time 	==	4'HF	;
	wire	dlys_tune_tmid		=		dlys_tune_time 	==	4'H7	;
//----------------------------------------------------------------------------------------------------------
	always@(posedge link_clki)// or negedge link_rstn )		//	if(~link_rstn)					dlys_tune_done	<=	0	;
	if(dlys_tune_reqs)					dlys_tune_pass	<=	0	;
	else if(tune_hits_ctrl_done)		dlys_tune_pass	<=	1	;

	always@(posedge link_clki or negedge link_rstn )				
	if(~link_rstn)						dlys_tune_time	<=	0	;
	else if(~tune_dlys_time_enab)		dlys_tune_time	<=	0	;
	else 								dlys_tune_time	<=	dlys_tune_time + 1	;
//----UPDT_TAPS
	always@(posedge link_clki or negedge link_rstn )				
	if(~link_rstn)						dlys_tune_taps	<=	0	;
	else if(tune_hits_updt_taps)		dlys_tune_taps	<=	dlys_tune_vals	;
//----UPDT_LOAD
	always@(posedge link_clki or negedge link_rstn )		
	if(~link_rstn)						dlys_tune_load	<=	0	;
	else								dlys_tune_load	<=	tune_hits_updt_load	;

 	always@(posedge link_clki or negedge link_rstn )		//ACTV/DISA_ENVT
 	if(~link_rstn)						dlys_tune_envt	<=	1	;
 	else if(tune_hits_envt_disa)		dlys_tune_envt	<=	0	;
 	else if(tune_hits_envt_actv)		dlys_tune_envt	<=	1	;
//----------------------------------------------------------------------------------------------------------
	always@(posedge link_clki or negedge link_rstn )				
	if(~link_rstn)						dlys_tune_mfsm	<=	0	;
	else begin
		case(dlys_tune_mfsm)	
			TUNE_CTRL_IDLE		:		dlys_tune_mfsm	<=	dlys_tune_reqs	?	TUNE_ENVT_DISA	:	TUNE_CTRL_IDLE	;
			TUNE_ENVT_DISA		:		dlys_tune_mfsm	<=	dlys_tune_tmax	?	TUNE_UPDT_TAPS	:	TUNE_ENVT_DISA	;
			TUNE_UPDT_TAPS		:		dlys_tune_mfsm	<=						TUNE_UPDT_LOAD	;
			TUNE_UPDT_LOAD		:		dlys_tune_mfsm	<=						TUNE_UPDT_VLID	;
			TUNE_UPDT_VLID		:		dlys_tune_mfsm	<=	dlys_tune_tmax	?	TUNE_ENVT_ACTV	:	TUNE_UPDT_VLID	;
			TUNE_ENVT_ACTV		:		dlys_tune_mfsm	<=						TUNE_CTRL_DONE	;
			TUNE_CTRL_DONE		:		dlys_tune_mfsm	<=						TUNE_CTRL_IDLE	;
			default				:		dlys_tune_mfsm	<=						TUNE_CTRL_IDLE	;
		endcase
	end
	
endmodule

