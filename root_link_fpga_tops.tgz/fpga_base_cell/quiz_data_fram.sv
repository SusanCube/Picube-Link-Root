module	quiz_data_fram(
	output	reg							data_fram_flag	,

	input								link_fram_vlid	,
	input	[31: 0]						link_fram_data	,
	input								link_clki		,
	input								link_rstn		);
//----------------------------------------------------------------------------------------------------------------------
	reg									link_fram_samp	;
	
	wire								link_fram_rise	;
	wire								link_fram_fall	;
	
	assign	link_fram_rise	=		{	link_fram_vlid	,	link_fram_samp}	==	2'H2	;
	assign	link_fram_fall	=		{	link_fram_vlid	,	link_fram_samp}	==	2'H1	;
	wire	link_data_issu	=		&{	link_fram_rise	,	link_fram_data	== "DATA" 	};
	
	always@(posedge link_clki or negedge link_rstn)
	if(~link_rstn)						link_fram_samp	<=	0	;
	else 								link_fram_samp	<=	link_fram_vlid	;

//----------------------------------------------------------------------------------------------------------------------
	reg									data_fram_flag	;

	always@(posedge link_clki or negedge link_rstn)
	if(~link_rstn)						data_fram_flag	<=	0	;
	else if(link_fram_fall)				data_fram_flag	<=	0	;
	else if(link_data_issu)				data_fram_flag	<=	1	;

endmodule
