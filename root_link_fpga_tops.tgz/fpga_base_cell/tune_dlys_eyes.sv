/***********************************************************************************************************
//--reduce the number of filter taps from 5 to 4
***********************************************************************************************************/
module	tune_dlys_eyes(
	input	[ 7: 0]						isde_patn_real	,
	input	[ 7: 0]						tune_patn_code	,
	output								tune_patn_seek	);
//----------------------------------------------------------------------------------------------------------
	wire	[ 0 :7 ][ 7: 0]				tune_patn_shft	;
	
	assign	tune_patn_shft[0]	=		tune_patn_code	;
	assign	tune_patn_shft[1]	=	{	tune_patn_code[ 6: 0]	,	tune_patn_code[ 7: 7]	};
	assign	tune_patn_shft[2]	=	{	tune_patn_code[ 5: 0]	,	tune_patn_code[ 7: 6]	};
	assign	tune_patn_shft[3]	=	{	tune_patn_code[ 4: 0]	,	tune_patn_code[ 7: 5]	};
	assign	tune_patn_shft[4]	=	{	tune_patn_code[ 3: 0]	,	tune_patn_code[ 7: 4]	};
	assign	tune_patn_shft[5]	=	{	tune_patn_code[ 2: 0]	,	tune_patn_code[ 7: 3]	};
	assign	tune_patn_shft[6]	=	{	tune_patn_code[ 1: 0]	,	tune_patn_code[ 7: 2]	};
	assign	tune_patn_shft[7]	=	{	tune_patn_code[ 0: 0]	,	tune_patn_code[ 7: 1]	};
	
	assign	tune_patn_seek		=	(	isde_patn_real ==	tune_patn_shft[0]	)	|	
									(	isde_patn_real ==	tune_patn_shft[1]	)	|	
									(	isde_patn_real ==	tune_patn_shft[2]	)	|	
									(	isde_patn_real ==	tune_patn_shft[3]	)	|	
									(	isde_patn_real ==	tune_patn_shft[4]	)	|	
									(	isde_patn_real ==	tune_patn_shft[5]	)	|	
									(	isde_patn_real ==	tune_patn_shft[6]	)	|	
									(	isde_patn_real ==	tune_patn_shft[7]	)	;
endmodule
 