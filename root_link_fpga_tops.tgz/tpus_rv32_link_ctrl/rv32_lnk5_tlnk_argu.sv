module	rv32_link_tlnk_argu(
	input								rv32_tlnk_argu_csen	,
	input								rv32_tlnk_argu_wrcs	,
	input		[  3: 0]				rv32_tlnk_argu_addr	,
	output		[ 31: 0]				rv32_tlnk_argu_rout	,
	input		[ 31: 0]				rv32_tlnk_argu_wdin	,
//-------------------------------------------------------
	input								tpgs_link_cmnd_updt	,
	input		[ 0:15][31: 0]			tpgs_link_cmnd_memo	,
//-------------------------------------------------------
	input		[ 3: 0]					tpem_link_cmnd_indx	,
	output		[31: 0]					tpem_link_cmnd_data	,

	input		[ 3: 0]					tpem_xdat_cmnd_indx	,
	output		[31: 0]					tpem_xdat_cmnd_data	,

	input		[ 3: 0]					tpem_scfg_cmnd_indx	,
	output		[31: 0]					tpem_scfg_cmnd_data	,
//-------------------------------------------------------
	output	reg	[24: 0]					llmb_meta_imag_size	,
	output		[19: 0]					llmb_meta_imag_rows	,
	output		[19: 0]					llmb_meta_imag_cols	,
	output		[19: 0]					llmb_mtrx_imag_cols	,
	
	output	reg	[24: 0]					llmb_edge_imag_size	,
	output		[19: 0]					llmb_edge_imag_rows	,
	output		[19: 0]					llmb_edge_imag_cols	,
	output								llmb_edge_imag_even	,
	output								llmb_edge_imag_row2	,
	
	output		[24: 0]					llmb_mast_ddrs_base	,
	output		[24: 0]					llmb_devs_ddrs_base	,

	output		[3 : 0]					sdes_link_mgth_csid	,
	output		[24: 0]					sdes_link_ddrs_size	,
	output		[24: 0]					sdes_meta_ddrs_base	,
	output		[15: 0]					sdes_meta_cols_dims	,
	output		[24: 0]					sdes_hubs_ddrs_base	,
	output		[15: 0]					sdes_hubs_cols_dims	,
	output		[15: 0]					sdes_hubs_cols_dumy	,
//-------------------------------------------------------
	input								link_sclk			,
	input								link_rstn			);
/**********************************************************************************************************/
//--	TLNK ARGUMENT MEMORY
	reg			[  0:15][31: 0]		rv32_ecos_tlnk_memo	;

	wire							rv32_tlnk_argu_wren	;
	wire		[  0:15]			rv32_tlnk_argu_csid	;
	wire		[  0:15]			rv32_tlnk_argu_wrid	;
	
	assign	rv32_tlnk_argu_wren	= &{rv32_tlnk_argu_csen	,	rv32_tlnk_argu_wrcs	};

	for(genvar i = 0 ; i <16 ; i++) begin	:	rv32_ecos_rwcs_ctrl
		assign	rv32_tlnk_argu_csid[i]	=	rv32_tlnk_argu_addr	==	i	;
		assign	rv32_tlnk_argu_wrid[i]	= &{rv32_tlnk_argu_wren	,	rv32_tlnk_argu_csid[i]	};
	
		always@(posedge link_sclk or negedge link_rstn)
		if(!link_rstn)					rv32_ecos_tlnk_memo[i]	<=	0	;
		else if(tpgs_link_cmnd_updt   )	rv32_ecos_tlnk_memo[i]	<=	tpgs_link_cmnd_memo[i]	;
		else if(rv32_tlnk_argu_wrid[i])	rv32_ecos_tlnk_memo[i]	<=	rv32_tlnk_argu_wdin		;
	end

	assign	rv32_tlnk_argu_rout=	rv32_tlnk_argu_csid[ 0]	?	rv32_ecos_tlnk_memo[ 0]	:	// TPES_PORT_ENAB
									rv32_tlnk_argu_csid[ 1]	?	rv32_ecos_tlnk_memo[ 1]	:	// TPGS_DEST_MARK
									rv32_tlnk_argu_csid[ 2]	?	rv32_ecos_tlnk_memo[ 2]	:	// TPES_DEST_MARK
									rv32_tlnk_argu_csid[ 3]	?	rv32_ecos_tlnk_memo[ 3]	:	// EDGE_DEST_MARK
									rv32_tlnk_argu_csid[ 4]	?	rv32_ecos_tlnk_memo[ 4]	:	// MAST_DDRS_BASE	//SDES_DDRS_ADDR
									rv32_tlnk_argu_csid[ 5]	?	rv32_ecos_tlnk_memo[ 5]	:	// SLAV_DDRS_BASE	//SDES_DDRS_BIAS
									rv32_tlnk_argu_csid[ 6]	?	rv32_ecos_tlnk_memo[ 6]	:	// META_ROWS_NUMB	//SDES_DDRS_ROWS
									rv32_tlnk_argu_csid[ 7]	?	rv32_ecos_tlnk_memo[ 7]	:	// META_COLS_NUMB	//SDES_META_COLS
									rv32_tlnk_argu_csid[ 8]	?	rv32_ecos_tlnk_memo[ 8]	:	// EDGE_ROWS_NUMB	//SDES_HUBS_COLS_DIMS
									rv32_tlnk_argu_csid[ 9]	?	rv32_ecos_tlnk_memo[ 9]	:	// EDGE_COLS_NUMB	//SDES_HUBS_COLS_DUMY
									rv32_tlnk_argu_csid[10]	?	rv32_ecos_tlnk_memo[10]	:	// CMND_AUXI_WRD0	//	
									rv32_tlnk_argu_csid[11]	?	rv32_ecos_tlnk_memo[11]	:	// CMND_AUXI_WRD1	//
									rv32_tlnk_argu_csid[12]	?	rv32_ecos_tlnk_memo[12]	:	// CMND_AUXI_WRD2	//
									rv32_tlnk_argu_csid[13]	?	rv32_ecos_tlnk_memo[13]	:	// CMND_AUXI_WRD3	//
									rv32_tlnk_argu_csid[14]	?	rv32_ecos_tlnk_memo[14]	:	// CMND_AUXI_WRD4	//
									rv32_tlnk_argu_csid[15]	?	rv32_ecos_tlnk_memo[15]	:	// CMND_AUXI_WRD5	//
																32'H00					;
/**********************************************************************************************************/
	wire		[24: 0]					sdes_link_ddrs_base	;
	wire		[24: 0]					sdes_link_ddrs_bias	;
	wire		[15: 0]					sdes_link_ddrs_rows	;
	

	assign	sdes_link_ddrs_base	=		rv32_ecos_tlnk_memo[ 4][24: 0]	;
	assign	sdes_link_ddrs_bias	=		rv32_ecos_tlnk_memo[ 5][24: 0]	;
	assign	sdes_link_ddrs_rows	=		rv32_ecos_tlnk_memo[ 6][15: 0]	;

	assign	sdes_link_ddrs_size	=		sdes_link_ddrs_rows * 	sdes_hubs_cols_dims	;
	assign	sdes_meta_ddrs_base	=		sdes_link_ddrs_base +	sdes_link_ddrs_bias	;
	assign	sdes_meta_cols_dims	=		rv32_ecos_tlnk_memo[ 7][15: 0]	;
	
	assign	sdes_hubs_ddrs_base	=		sdes_link_ddrs_base				;
	assign	sdes_hubs_cols_dims	=		rv32_ecos_tlnk_memo[ 8][15: 0]	;
	assign	sdes_hubs_cols_dumy	=		rv32_ecos_tlnk_memo[ 9][15: 0]	;

	assign	sdes_link_mgth_csid	=		rv32_ecos_tlnk_memo[10][ 3: 0]	;
/**********************************************************************************************************/
	wire		[19: 0]				tlnk_meta_imag_rows	=	tpgs_link_cmnd_memo[ 6][19:0]	;
	wire		[19: 0]				tlnk_meta_imag_cols	=	tpgs_link_cmnd_memo[ 7][19:0]	;
	wire		[24: 0]				tlnk_meta_imag_size	=	tlnk_meta_imag_rows	* tlnk_meta_imag_cols[19:4]	;

	
	wire		[19: 0]				tlnk_edge_imag_rows	=	tpgs_link_cmnd_memo[ 8][19:0]	;
	wire		[19: 0]				tlnk_edge_imag_cols	=	tpgs_link_cmnd_memo[ 9][19:0]	;
 	wire		[24: 0]				tlnk_edge_imag_size	=	tlnk_edge_imag_rows * tlnk_edge_imag_cols[19:4]	;	

	always@(posedge link_sclk or negedge link_rstn)
	if(~link_rstn)					llmb_meta_imag_size	<=	0	;
	else if(tpgs_link_cmnd_updt)	llmb_meta_imag_size	<=	tlnk_meta_imag_size	;

	always@(posedge link_sclk or negedge link_rstn)
	if(~link_rstn)					llmb_edge_imag_size	<=	0	;
	else if(tpgs_link_cmnd_updt)	llmb_edge_imag_size	<=	tlnk_edge_imag_size	;
//----------------------------------------------------------------------
	assign	llmb_edge_imag_even	=	rv32_ecos_tlnk_memo[ 3]==32'H7	;	//0:even 1:odd
	assign	llmb_mast_ddrs_base	=	rv32_ecos_tlnk_memo[ 4][24: 0]	;
	assign	llmb_devs_ddrs_base	=	rv32_ecos_tlnk_memo[ 5][24: 0]	;
	
	assign	llmb_meta_imag_rows	=	rv32_ecos_tlnk_memo[ 6][19: 0]	;
	assign	llmb_meta_imag_cols	=	rv32_ecos_tlnk_memo[ 7][19: 0]	;
	
	assign	llmb_edge_imag_rows	=	rv32_ecos_tlnk_memo[ 8][19: 0]	;
	assign	llmb_edge_imag_cols	=	rv32_ecos_tlnk_memo[ 9][19: 0]	;
	assign	llmb_edge_imag_row2	=	rv32_ecos_tlnk_memo[10][	0]	;
	assign	llmb_mtrx_imag_cols	=	rv32_ecos_tlnk_memo[11][19: 0]	;
/**********************************************************************************************************************/
	assign	tpem_link_cmnd_data	=	tpem_link_cmnd_indx	== 4'H0	?	rv32_ecos_tlnk_memo[ 2]	://TPES_DEST_MARK
									tpem_link_cmnd_indx	== 4'H1	?	rv32_ecos_tlnk_memo[ 3]	://EDGE_DEST_MARK
									tpem_link_cmnd_indx	== 4'H2	?	rv32_ecos_tlnk_memo[ 5]	://SLAV_DDRS_BASE
									tpem_link_cmnd_indx	== 4'H3	?	rv32_ecos_tlnk_memo[ 8]	://META_ROWS_NUMB
									tpem_link_cmnd_indx	== 4'H4	?	rv32_ecos_tlnk_memo[ 9]	://META_ROWS_COLS
									tpem_link_cmnd_indx	== 4'H5	?	rv32_ecos_tlnk_memo[12]	:
									tpem_link_cmnd_indx	== 4'H6	?	rv32_ecos_tlnk_memo[13]	:
									tpem_link_cmnd_indx	== 4'H7	?	rv32_ecos_tlnk_memo[14]	: 
									tpem_link_cmnd_indx	== 4'H8	?	rv32_ecos_tlnk_memo[15]	: 32'H0	;


	assign	tpem_xdat_cmnd_data	=	tpem_xdat_cmnd_indx	== 4'H0	?	rv32_ecos_tlnk_memo[ 2]	://TPES_DEST_MARK
									tpem_xdat_cmnd_indx	== 4'H1	?	rv32_ecos_tlnk_memo[ 3]	://EDGE_DEST_MARK
									tpem_xdat_cmnd_indx	== 4'H2	?	rv32_ecos_tlnk_memo[ 5]	://SLAV_DDRS_BASE
									tpem_xdat_cmnd_indx	== 4'H3	?	rv32_ecos_tlnk_memo[ 8]	://EDGE_ROWS_NUMB
									tpem_xdat_cmnd_indx	== 4'H4	?	rv32_ecos_tlnk_memo[ 9]	://EDGE_ROWS_COLS
									tpem_xdat_cmnd_indx	== 4'H5	?	rv32_ecos_tlnk_memo[12]	:
									tpem_xdat_cmnd_indx	== 4'H6	?	rv32_ecos_tlnk_memo[13]	:
									tpem_xdat_cmnd_indx	== 4'H7	?	rv32_ecos_tlnk_memo[14]	: 
									tpem_xdat_cmnd_indx	== 4'H8	?	rv32_ecos_tlnk_memo[15]	: 32'H0	;

	assign	tpem_scfg_cmnd_data	=	tpem_scfg_cmnd_indx	== 4'H0	?	rv32_ecos_tlnk_memo[ 8]	:
									tpem_scfg_cmnd_indx	== 4'H1	?	rv32_ecos_tlnk_memo[ 9]	:
									tpem_scfg_cmnd_indx	== 4'H2	?	rv32_ecos_tlnk_memo[10]	:
									tpem_scfg_cmnd_indx	== 4'H3	?	rv32_ecos_tlnk_memo[11]	:
									tpem_scfg_cmnd_indx	== 4'H4	?	rv32_ecos_tlnk_memo[12]	:
									tpem_scfg_cmnd_indx	== 4'H5	?	rv32_ecos_tlnk_memo[13]	:
									tpem_scfg_cmnd_indx	== 4'H6	?	rv32_ecos_tlnk_memo[14]	:
									tpem_scfg_cmnd_indx	== 4'H7	?	rv32_ecos_tlnk_memo[15]	: 32'H0	;
/**********************************************************************************************************************/
endmodule
 