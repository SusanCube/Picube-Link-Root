/***********************************************************************************************************
WORD_00	:	TPGM_LINK_TPGS_STAT
WORD_01	:	TPGS_LINK_TPGM_STAT
WORD_02	:	TPGS_LINK_SDES_STAT
WORD_03	:	TPEM_LINK_SCUT_ENAB
WORD_04	:	TPEM_LINK_PORT_ENAB
WORD_05	:	SDES_XDMA_DDRS_BASE
WORD_06	:	TPGS_XDMA_DDRS_BASE
WORD_07	:	TPEM_XDMA_DDRS_BASE
WORD_08	:	TPGM_OMNI_TPGS_PILE
WORD_09	:	TPGM_THIS_TPGS_PILE
WORD_0A	:	OMNI_PILE_GNPU_NUMB
WORD_0B	:	NORM_PILE_GNPU_NUMB
WORD_0C	:	TPGS_MGTH_INTF_CFIG
WORD_0D	:	TPGS_LINK_DBUG_STAT
WORD_0E	:	TPGS_CRAM_DNLD_ADDR
WORD_0F	:	TPGS_CRAM_DNLD_DATA
//MODIFIED @20250103	
//	output							ecos_tpuc_cmnd_updt	,
//	output	reg	[24: 0]				ecos_tpuc_ddrs_base	,
//	output	reg	[ 7:0]				ecos_tpuc_tpem_port	,
//	output	reg	[ 3:0]				ecos_tpuc_mgth_port	,
//	output							xdma_link_mgth_init	,
	
***********************************************************************************************************/
`include	"agile_card_vars.vh"

module	rv32_link_tpgs_ctrl(
	output		[ 31:0 ]				rv32_tpgs_ctrl_rout	,
	input								rv32_tpgs_ctrl_csen	,
	input								rv32_tpgs_ctrl_wrcs	,
	input		[  3:0 ]				rv32_tpgs_ctrl_addr	,
	input		[ 31:0 ]				rv32_tpgs_ctrl_wdin	,
//-------------------------------------------------------
	output	reg	[ 11:0]					tpgs_cram_writ_addr	,
	output								tpgs_cram_writ_csen	,
//-------------------------------------------------------
	input								tpgs_link_ddrs_stat	,
	input								tpgs_link_port_idle	,
	output								tpgs_link_port_init	,
	output	reg							tpgs_link_scut_enab	,//------SHORTCUT CONTROL
	input								tpgs_link_scut_done	,

	output								tpgs_link_cmnd_updt	,
	output	reg	[ 7: 0]					tpem_link_port_enab	,
	
	output								xdma_link_meta_mtrx	,
	output								xdma_osde_rdma_enab	,
	input								xdma_osde_rdma_done	,
	output								xdma_isde_wdma_enab	,
	input								xdma_isde_wdma_done	,
	output								xdma_odat_rdma_enab	,
	input								xdma_odat_rdma_done	,
	output								xdma_idat_wdma_enab	,
	input								xdma_idat_wdma_done	,
//-------------------------------------------------------
	output								mgt1_pmau_init_ctrl	,
	output								mgt1_rstb_push_ctrl	,
	input								mgt1_intf_link_stat	,
	input								mgt1_clki			,

	output								mgt2_pmau_init_ctrl	,
	output								mgt2_rstb_push_ctrl	,
	input								mgt2_intf_link_stat	,
	input								mgt2_clki			,

	output								mgt3_pmau_init_ctrl	,
	output								mgt3_rstb_push_ctrl	,
	input								mgt3_intf_link_stat	,
	input								mgt3_clki			,
//-------------------------------------------------------
	output								tpgs_link_acks_reqs	,
	output								tpgs_link_resp_reqs	,
	input								tpgs_link_acks_done	,
	input								tpgs_link_resp_done	,

	input								tpgs_icfg_cmnd_mark	,//0
	input								tpgs_ocfg_cmnd_mark	,//1
	input								tpgs_nnex_cmnd_mark	,//2
	input								tpgs_ivct_cmnd_mark	,//3
	input								tpgs_ovct_cmnd_mark	,//4
	input								tpgs_imtx_cmnd_mark	,//5
	input								tpgs_omtx_cmnd_mark	,//6
	input								tpgs_rivt_cmnd_mark	,//7
	input								tpgs_rovt_cmnd_mark	,//8
	input								tpgs_rimt_cmnd_mark	,//9
	input								tpgs_romt_cmnd_mark	,//10
	input								tpgs_risv_cmnd_mark	,//11
	input								tpgs_rosv_cmnd_mark	,//12
	input								tpgs_rism_cmnd_mark	,//13
	input								tpgs_rosm_cmnd_mark	,//14
	input								tpgs_auxi_cmnd_mark	,//15
	input								tpgs_aset_cmnd_mark	,//16
	input								tpgs_dnld_cmnd_mark	,//17
	input								tpgs_boot_cmnd_mark	,//18
	input								tpgs_trim_cmnd_mark	,//19

	input								tpgs_link_cmnd_coda	,//19
	input								tpgs_dlys_ctrl_drdy	,	
//-------------------------------------------------------
	input								link_sclk			,
	input								link_rstn			);
/**********************************************************************************************************/
	wire	[31: 0]						tpgm_link_task_word	;//CAW::00
	wire	[31: 0]						tpgs_link_resp_word	;//CAW::01
	wire	[31: 0]						tpgs_link_xdma_stat	;//CAW::02
	wire	[31: 0]						tpgs_link_scut_stat	;//CAW::03
//	wire	[31: 0]						tpem_link_ecos_word	;//CAW::04
	wire	[31: 0]						tpem_port_enab_word	;//CAW::05
	wire	[31: 0]						sdes_port_enab_word	;//CAW::06
	wire	[31: 0]						mgth_link_intf_word	;//CAW::07
	wire	[31: 0]						tpgs_cram_addr_word	;//CAW::14
/**********************************************************************************************************/
	wire	[ 0:15]						rv32_tpgs_ctrl_csid	;
	wire	[ 0:15]						rv32_tpgs_ctrl_wrid	;
	
	assign	tpgs_link_port_init	=		rv32_tpgs_ctrl_wrid[0]	;

for(genvar i = 0 ; i <16 ; i++) begin	:	gens_tpgs_rwcs_ctrl
	assign	rv32_tpgs_ctrl_csid[i]=	&{	rv32_tpgs_ctrl_csen	,	rv32_tpgs_ctrl_addr==i	};
	assign	rv32_tpgs_ctrl_wrid[i]= &{	rv32_tpgs_ctrl_wrcs	,	rv32_tpgs_ctrl_csid[i]	};
end
/**********************************************************************************************************/
//WORD_ADDRESS:: 0X00----TPGM_LINK_TPGS_STAT
	reg									tpgm_misc_cmnd_stat	;

	reg									tpgs_trim_cmnd_stat	;
	reg									tpgs_auxi_cmnd_stat	;
	reg									tpgs_boot_cmnd_stat	;
	reg									tpgs_dnld_cmnd_stat	;
	reg									tpgs_aset_cmnd_stat	;
	reg									tpgs_rosm_cmnd_stat	;
	reg									tpgs_rism_cmnd_stat	;
	reg									tpgs_rosv_cmnd_stat	;
	reg									tpgs_risv_cmnd_stat	;
	reg									tpgs_romt_cmnd_stat	;
	reg									tpgs_rimt_cmnd_stat	;
	reg									tpgs_rovt_cmnd_stat	;
	reg									tpgs_rivt_cmnd_stat	;
	reg									tpgs_omtx_cmnd_stat	;
	reg									tpgs_imtx_cmnd_stat	;
	reg									tpgs_ovct_cmnd_stat	;
	reg									tpgs_ivct_cmnd_stat	;
	reg									tpgs_nnex_cmnd_stat	;
	reg									tpgs_ocfg_cmnd_stat	;
	reg									tpgs_icfg_cmnd_stat	;

	assign	tpgm_link_task_word	= {		tpgm_misc_cmnd_stat	,//BIT 	31
										1'B0				,//tpgs_link_ddrs_stat	,//BIT 	30
										10'H0				,//BIT	29:20
										tpgs_trim_cmnd_stat	,//BIT 	19
										tpgs_boot_cmnd_stat	,//BIT 	18
										tpgs_dnld_cmnd_stat	,//BIT 	17
										tpgs_aset_cmnd_stat	,//BIT 	16
										tpgs_auxi_cmnd_stat	,//BIT 	15	
										tpgs_rosm_cmnd_stat	,//BIT 	14
										tpgs_rism_cmnd_stat	,//BIT 	13
										tpgs_rosv_cmnd_stat	,//BIT 	12
										tpgs_risv_cmnd_stat	,//BIT 	11
										tpgs_romt_cmnd_stat	,//BIT 	10
										tpgs_rimt_cmnd_stat	,//BIT 	09
										tpgs_rovt_cmnd_stat	,//BIT 	08
										tpgs_rivt_cmnd_stat	,//BIT 	07
										tpgs_omtx_cmnd_stat	,//BIT 	06
										tpgs_imtx_cmnd_stat	,//BIT 	05
										tpgs_ovct_cmnd_stat	,//BIT 	04
										tpgs_ivct_cmnd_stat	,//BIT 	03
										tpgs_nnex_cmnd_stat	,//BIT 	02
										tpgs_ocfg_cmnd_stat	,//BIT 	01
										tpgs_icfg_cmnd_stat};//BIT 	00
									
	always@(posedge link_sclk or negedge link_rstn)
	if(!link_rstn)						tpgm_misc_cmnd_stat	<=	0	;
	else if(tpgs_link_port_init)    	tpgm_misc_cmnd_stat	<=	0	;
	else if(tpgs_link_cmnd_coda)		tpgm_misc_cmnd_stat	<=	1	;

	always@(posedge link_sclk or negedge link_rstn)
	if(!link_rstn)						tpgs_trim_cmnd_stat	<=	0	;
	else if(tpgs_link_port_init)    	tpgs_trim_cmnd_stat	<=	0	;
	else if(tpgs_trim_cmnd_mark)		tpgs_trim_cmnd_stat	<=	1	;

	always@(posedge link_sclk or negedge link_rstn)
	if(!link_rstn)						tpgs_auxi_cmnd_stat	<=	0	;
	else if(tpgs_link_port_init)    	tpgs_auxi_cmnd_stat	<=	0	;
	else if(tpgs_auxi_cmnd_mark)		tpgs_auxi_cmnd_stat	<=	1	;

	always@(posedge link_sclk or negedge link_rstn)
	if(!link_rstn)						tpgs_icfg_cmnd_stat	<=	0	;
	else if(tpgs_link_port_init)    	tpgs_icfg_cmnd_stat	<=	0	;
	else if(tpgs_icfg_cmnd_mark)		tpgs_icfg_cmnd_stat	<=	1	;

	always@(posedge link_sclk or negedge link_rstn)
	if(!link_rstn)						tpgs_ocfg_cmnd_stat	<=	0	;
	else if(tpgs_link_port_init)    	tpgs_ocfg_cmnd_stat	<=	0	;
	else if(tpgs_ocfg_cmnd_mark)		tpgs_ocfg_cmnd_stat	<=	1	;

	always@(posedge link_sclk or negedge link_rstn)
	if(!link_rstn)						tpgs_nnex_cmnd_stat	<=	0	;
	else if(tpgs_link_port_init)    	tpgs_nnex_cmnd_stat	<=	0	;
	else if(tpgs_nnex_cmnd_mark)		tpgs_nnex_cmnd_stat	<=	1	;

	always@(posedge link_sclk or negedge link_rstn)
	if(!link_rstn)						tpgs_ivct_cmnd_stat	<=	0	;
	else if(tpgs_link_port_init)    	tpgs_ivct_cmnd_stat	<=	0	;
	else if(tpgs_ivct_cmnd_mark)		tpgs_ivct_cmnd_stat	<=	1	;

	always@(posedge link_sclk or negedge link_rstn)
	if(!link_rstn)						tpgs_ovct_cmnd_stat	<=	0	;
	else if(tpgs_link_port_init)    	tpgs_ovct_cmnd_stat	<=	0	;
	else if(tpgs_ovct_cmnd_mark)		tpgs_ovct_cmnd_stat	<=	1	;

	always@(posedge link_sclk or negedge link_rstn)
	if(!link_rstn)						tpgs_imtx_cmnd_stat	<=	0	;
	else if(tpgs_link_port_init)    	tpgs_imtx_cmnd_stat	<=	0	;
	else if(tpgs_imtx_cmnd_mark)		tpgs_imtx_cmnd_stat	<=	1	;

	always@(posedge link_sclk or negedge link_rstn)
	if(!link_rstn)						tpgs_omtx_cmnd_stat	<=	0	;
	else if(tpgs_link_port_init)    	tpgs_omtx_cmnd_stat	<=	0	;
	else if(tpgs_omtx_cmnd_mark)		tpgs_omtx_cmnd_stat	<=	1	;

	always@(posedge link_sclk or negedge link_rstn)
	if(!link_rstn)						tpgs_rivt_cmnd_stat	<=	0	;
	else if(tpgs_link_port_init)    	tpgs_rivt_cmnd_stat	<=	0	;
	else if(tpgs_rivt_cmnd_mark)		tpgs_rivt_cmnd_stat	<=	1	;

	always@(posedge link_sclk or negedge link_rstn)
	if(!link_rstn)						tpgs_rovt_cmnd_stat	<=	0	;
	else if(tpgs_link_port_init)    	tpgs_rovt_cmnd_stat	<=	0	;
	else if(tpgs_rovt_cmnd_mark)		tpgs_rovt_cmnd_stat	<=	1	;

	always@(posedge link_sclk or negedge link_rstn)
	if(!link_rstn)						tpgs_rimt_cmnd_stat	<=	0	;
	else if(tpgs_link_port_init)    	tpgs_rimt_cmnd_stat	<=	0	;
	else if(tpgs_rimt_cmnd_mark)		tpgs_rimt_cmnd_stat	<=	1	;

	always@(posedge link_sclk or negedge link_rstn)
	if(!link_rstn)						tpgs_romt_cmnd_stat	<=	0	;
	else if(tpgs_link_port_init)    	tpgs_romt_cmnd_stat	<=	0	;
	else if(tpgs_romt_cmnd_mark)		tpgs_romt_cmnd_stat	<=	1	;

	always@(posedge link_sclk or negedge link_rstn)
	if(!link_rstn)						tpgs_risv_cmnd_stat	<=	0	;
	else if(tpgs_link_port_init)    	tpgs_risv_cmnd_stat	<=	0	;
	else if(tpgs_risv_cmnd_mark)		tpgs_risv_cmnd_stat	<=	1	;

	always@(posedge link_sclk or negedge link_rstn)
	if(!link_rstn)						tpgs_rosv_cmnd_stat	<=	0	;
	else if(tpgs_link_port_init)    	tpgs_rosv_cmnd_stat	<=	0	;
	else if(tpgs_rosv_cmnd_mark)		tpgs_rosv_cmnd_stat	<=	1	;

	always@(posedge link_sclk or negedge link_rstn)
	if(!link_rstn)						tpgs_rism_cmnd_stat	<=	0	;
	else if(tpgs_link_port_init)    	tpgs_rism_cmnd_stat	<=	0	;
	else if(tpgs_rism_cmnd_mark)		tpgs_rism_cmnd_stat	<=	1	;

	always@(posedge link_sclk or negedge link_rstn)
	if(!link_rstn)						tpgs_rosm_cmnd_stat	<=	0	;
	else if(tpgs_link_port_init)    	tpgs_rosm_cmnd_stat	<=	0	;
	else if(tpgs_rosm_cmnd_mark)		tpgs_rosm_cmnd_stat	<=	1	;

	always@(posedge link_sclk or negedge link_rstn)
	if(!link_rstn)						tpgs_aset_cmnd_stat	<=	0	;
	else if(tpgs_link_port_init)    	tpgs_aset_cmnd_stat	<=	0	;
	else if(tpgs_aset_cmnd_mark)		tpgs_aset_cmnd_stat	<=	1	;

	always@(posedge link_sclk or negedge link_rstn)
	if(!link_rstn)						tpgs_dnld_cmnd_stat	<=	0	;
	else if(tpgs_link_port_init)    	tpgs_dnld_cmnd_stat	<=	0	;
	else if(tpgs_dnld_cmnd_mark)		tpgs_dnld_cmnd_stat	<=	1	;

	always@(posedge link_sclk or negedge link_rstn)
	if(!link_rstn)						tpgs_boot_cmnd_stat	<=	0	;
	else if(tpgs_link_port_init)    	tpgs_boot_cmnd_stat	<=	0	;
	else if(tpgs_boot_cmnd_mark)		tpgs_boot_cmnd_stat	<=	1	;
/**********************************************************************************************************/
//WORD_ADDRESS:: 0X01----TPGS_LINK_TPGM_STAT
	reg		[ 7: 0]						tpgs_link_tpgm_cmnd	;
	reg									tpgs_link_acks_stat	;
	reg									tpgs_link_resp_stat	;
	
	wire								rv32_tpgs_misc_vlid	;
	wire								tpgs_link_tpgm_done	;
	
	assign	tpgs_link_acks_reqs	=		tpgs_link_tpgm_cmnd	==	`CUBE_LINK_ACKS_CMND	;
	assign	tpgs_link_resp_reqs	=		tpgs_link_tpgm_cmnd	==	`CUBE_LINK_RESP_CMND 	;
	
	assign	rv32_tpgs_misc_vlid	= &{	tpgs_link_port_idle	,	rv32_tpgs_ctrl_wrid[1]	};
	assign	tpgs_link_tpgm_done	= |{	tpgs_link_acks_reqs	&	tpgs_link_acks_done	,
										tpgs_link_resp_reqs	&	tpgs_link_resp_done	};

	always@(posedge link_sclk or negedge link_rstn)
	if(!link_rstn)						tpgs_link_tpgm_cmnd	<=	8'H0	;
	else if(rv32_tpgs_misc_vlid)		tpgs_link_tpgm_cmnd	<=	rv32_tpgs_ctrl_wdin[7:0];
	else if(tpgs_link_tpgm_done)		tpgs_link_tpgm_cmnd	<=	8'H0	;
	
	always@(posedge link_sclk or negedge link_rstn)
	if(!link_rstn)						tpgs_link_acks_stat	<=	0	;
	else if(rv32_tpgs_ctrl_wrid[1]) 	tpgs_link_acks_stat	<=	0	;
	else if(tpgs_link_acks_reqs)		tpgs_link_acks_stat	<=	tpgs_link_acks_done	;
	
	always@(posedge link_sclk or negedge link_rstn)
	if(!link_rstn)						tpgs_link_resp_stat	<=	0	;
	else if(rv32_tpgs_ctrl_wrid[1]) 	tpgs_link_resp_stat	<=	0	;
	else if(tpgs_link_resp_reqs)		tpgs_link_resp_stat	<=	tpgs_link_resp_done	;
	
	assign	tpgs_link_resp_word	= {		tpgs_link_ddrs_stat	,
										29'H0				,
										tpgs_link_resp_stat	,
										tpgs_link_acks_stat	};
/**********************************************************************************************************/
//WORD_ADDRESS:: 0X02----TPGS_LINK_SDES_STAT
	reg		[ 7: 0]						xdma_link_misc_cmnd	;
	reg									xdma_idat_wdma_stat	;
	reg									xdma_odat_rdma_stat	;
	reg									xdma_isde_wdma_stat	;
	reg									xdma_osde_rdma_stat	;
	reg		[ 1: 0]						xdma_link_cmnd_samp	;

	wire								xdma_link_post_done	;

	wire								xdma_osmt_rdma_cmnd	;
	wire								xdma_ismt_wdma_cmnd	;
	wire								xdma_osvt_rdma_cmnd	;
	wire								xdma_isvt_wdma_cmnd	;
	wire								xdma_omtx_rdma_cmnd	;
	wire								xdma_imtx_wdma_cmnd	;
	wire								xdma_ovct_rdma_cmnd	;
	wire								xdma_ivct_wdma_cmnd	;

	wire								xdma_link_mgth_cmnd	;
	wire								xdma_link_mgth_issu	;
	wire	rv32_tpgs_xdma_pset	=		rv32_tpgs_ctrl_wrid[2]	;

	assign	xdma_osmt_rdma_cmnd	=		xdma_link_misc_cmnd	== `TPGS_OSMT_RDMA_CMND	;
	assign	xdma_ismt_wdma_cmnd	=		xdma_link_misc_cmnd	== `TPGS_ISMT_WDMA_CMND	;
	assign	xdma_osvt_rdma_cmnd	=		xdma_link_misc_cmnd	== `TPGS_OSVT_RDMA_CMND	;
	assign	xdma_isvt_wdma_cmnd	=		xdma_link_misc_cmnd	== `TPGS_ISVT_WDMA_CMND	;
	assign	xdma_omtx_rdma_cmnd	=		xdma_link_misc_cmnd	== `TPGS_OMTX_RDMA_CMND	;
	assign	xdma_imtx_wdma_cmnd	=		xdma_link_misc_cmnd	== `TPGS_IMTX_WDMA_CMND	;
	assign	xdma_ovct_rdma_cmnd	=		xdma_link_misc_cmnd	== `TPGS_OVCT_RDMA_CMND	;
	assign	xdma_ivct_wdma_cmnd	=		xdma_link_misc_cmnd	== `TPGS_IVCT_WDMA_CMND	;

	assign	xdma_idat_wdma_enab	=		xdma_ivct_wdma_cmnd	|	xdma_imtx_wdma_cmnd	;
	assign	xdma_odat_rdma_enab	=		xdma_ovct_rdma_cmnd	|	xdma_omtx_rdma_cmnd	;
	assign	xdma_isde_wdma_enab	=		xdma_isvt_wdma_cmnd |	xdma_ismt_wdma_cmnd	;
	assign	xdma_osde_rdma_enab	=		xdma_osvt_rdma_cmnd	|	xdma_osmt_rdma_cmnd	;

	assign	xdma_link_meta_mtrx	=		xdma_ismt_wdma_cmnd	|	xdma_osmt_rdma_cmnd	|
										xdma_imtx_wdma_cmnd	|	xdma_omtx_rdma_cmnd	;

	assign	xdma_link_post_done	=		xdma_idat_wdma_done	|	xdma_odat_rdma_done	|
										xdma_isde_wdma_done	|	xdma_osde_rdma_done	;

	assign	xdma_link_mgth_cmnd	= |{	tpgs_rosm_cmnd_stat	,	tpgs_rism_cmnd_stat	,	tpgs_rosv_cmnd_stat	,	tpgs_risv_cmnd_stat};
	assign	xdma_link_mgth_issu	= &{	tpgs_link_cmnd_coda	,	xdma_link_mgth_cmnd};
//	assign	xdma_link_mgth_init	=	xdma_link_cmnd_samp	==	2'B10	;

	always@(posedge link_sclk or negedge link_rstn)
	if(!link_rstn)						xdma_link_misc_cmnd	<=	0	;
	else if(rv32_tpgs_xdma_pset)    	xdma_link_misc_cmnd	<=	rv32_tpgs_ctrl_wdin[ 7: 0];
	else if(xdma_link_post_done)		xdma_link_misc_cmnd	<=	0	;
	else								xdma_link_misc_cmnd	<=	xdma_link_misc_cmnd	;

	always@(posedge link_sclk or negedge link_rstn)
	if(!link_rstn)						xdma_link_cmnd_samp	<=	0	;
	else								xdma_link_cmnd_samp	<={	xdma_link_mgth_issu	,	xdma_link_cmnd_samp[1] };

	always@(posedge link_sclk or negedge link_rstn)
	if(!link_rstn)						xdma_idat_wdma_stat	<=	0	;
	else if(rv32_tpgs_xdma_pset)    	xdma_idat_wdma_stat	<=	0	;
	else if(xdma_idat_wdma_enab)		xdma_idat_wdma_stat	<=	xdma_idat_wdma_done	;
	
	always@(posedge link_sclk or negedge link_rstn)
	if(!link_rstn)						xdma_odat_rdma_stat	<=	0	;
	else if(rv32_tpgs_xdma_pset)    	xdma_odat_rdma_stat	<=	0	;
	else if(xdma_odat_rdma_enab)		xdma_odat_rdma_stat	<=	xdma_odat_rdma_done	;

	always@(posedge link_sclk or negedge link_rstn)
	if(!link_rstn)						xdma_isde_wdma_stat	<=	0	;
	else if(rv32_tpgs_xdma_pset)    	xdma_isde_wdma_stat	<=	0	;
	else if(xdma_isde_wdma_enab)		xdma_isde_wdma_stat	<=	xdma_isde_wdma_done	;
	
	always@(posedge link_sclk or negedge link_rstn)
	if(!link_rstn)						xdma_osde_rdma_stat	<=	0	;
	else if(rv32_tpgs_xdma_pset)    	xdma_osde_rdma_stat	<=	0	;
	else if(xdma_osde_rdma_enab)		xdma_osde_rdma_stat	<=	xdma_osde_rdma_done	;
	
	assign	tpgs_link_xdma_stat	={		28'H0				,
										xdma_osde_rdma_stat	,
										xdma_isde_wdma_stat	,
										xdma_odat_rdma_stat	,
										xdma_idat_wdma_stat};
//WORD_ADDRESS:: 0X04----TPGS_SCUT_ENAB
	assign	tpgs_link_scut_stat	= 	{	31'H0,	tpgs_link_scut_enab	};

	always@(posedge link_sclk or negedge link_rstn)
	if(!link_rstn)						tpgs_link_scut_enab	<=	0	;
	else if(rv32_tpgs_ctrl_wrid[4])		tpgs_link_scut_enab	<=	rv32_tpgs_ctrl_wdin[0]	;		//tpgs_link_scut_reqs ;
	else if(tpgs_link_scut_done)		tpgs_link_scut_enab	<=	0	;
//WORD_ADDRESS:: 0X05----TPEM_PORT_ENAB
	assign	tpem_port_enab_word	= 	{	24'H0,	tpem_link_port_enab	};

	always@(posedge link_sclk or negedge link_rstn)
	if(!link_rstn)						tpem_link_port_enab	<=	0	;
	else if(rv32_tpgs_ctrl_wrid[5])		tpem_link_port_enab	<=	rv32_tpgs_ctrl_wdin[7:0];
//WORD_ADDRESS:: 0X07----MGTH_LINK_INIT
	reg		[15: 0]						mgth_intf_init_cfig	= 	16'HFFFF	;

	reg		[ 7: 0]						mgt1_intf_clki_cnts	;
	reg		[ 7: 0]						mgt2_intf_clki_cnts	;
	reg		[ 7: 0]						mgt3_intf_clki_cnts	;

	wire								mgt1_clki_lock_trdy	;
	wire								mgt2_clki_lock_trdy	;
	wire								mgt3_clki_lock_trdy	;

	assign	mgt1_rstb_push_ctrl	=		mgth_intf_init_cfig[0]	;
	assign	mgt1_pmau_init_ctrl	=		mgth_intf_init_cfig[1]	;
	assign	mgt2_rstb_push_ctrl	=		mgth_intf_init_cfig[2]	;
	assign	mgt2_pmau_init_ctrl	=		mgth_intf_init_cfig[3]	;
	assign	mgt3_rstb_push_ctrl	=		mgth_intf_init_cfig[4]	;
	assign	mgt3_pmau_init_ctrl	=		mgth_intf_init_cfig[5]	;

	assign	mgt1_clki_lock_trdy	= &		mgt1_intf_clki_cnts	;
	assign	mgt2_clki_lock_trdy	= &		mgt2_intf_clki_cnts	;
	assign	mgt3_clki_lock_trdy	= &		mgt3_intf_clki_cnts	;

	always@(posedge link_sclk or negedge link_rstn)
	if(!link_rstn)						mgth_intf_init_cfig	<=	16'HFFFF	;
	else if(rv32_tpgs_ctrl_wrid[ 7])	mgth_intf_init_cfig	<=	rv32_tpgs_ctrl_wdin[15: 0]	;


	always@(posedge mgt1_clki or negedge mgt1_intf_link_stat)
	if(!mgt1_intf_link_stat)			mgt1_intf_clki_cnts	<=	0	;
	else if(~mgt1_clki_lock_trdy)		mgt1_intf_clki_cnts	<=	mgt1_intf_clki_cnts + 1	;

	always@(posedge mgt2_clki or negedge mgt2_intf_link_stat)
	if(!mgt2_intf_link_stat)			mgt2_intf_clki_cnts	<=	0	;
	else if(~mgt2_clki_lock_trdy)		mgt2_intf_clki_cnts	<=	mgt2_intf_clki_cnts + 1	;

	always@(posedge mgt3_clki or negedge mgt3_intf_link_stat)
	if(!mgt3_intf_link_stat)			mgt3_intf_clki_cnts	<=	0	;
	else if(~mgt3_clki_lock_trdy)		mgt3_intf_clki_cnts	<=	mgt3_intf_clki_cnts + 1	;

	assign	mgth_link_intf_word	= {		10'H0				,	
										mgt3_intf_link_stat	,	
										mgt3_clki_lock_trdy	,
										mgt2_intf_link_stat	,	
										mgt2_clki_lock_trdy	,
										mgt1_intf_link_stat	,	
										mgt1_clki_lock_trdy	,
										mgth_intf_init_cfig	};
/**********************************************************************************************************/
//WORD_ADDRESS:: 0X08----TPGS_CMND_UPDT
	assign	tpgs_link_cmnd_updt	=	rv32_tpgs_ctrl_wrid[8]	;
/**********************************************************************************************************/
//WORD_ADDRESS:: 0X09----TPGM_LINK_MISC_WRD
//WORD_ADDRESS:: 0X10----TPGS_LINK_MISC_WRD
//WORD_ADDRESS:: 0X11----TPEM_LINK_MISC_WRD
//WORD_ADDRESS:: 0X12----TPES_LINK_MISC_WRD
	reg		[31: 0]						tpgm_link_misc_word	;
	reg		[31: 0]						tpgs_link_misc_word	;
	reg		[31: 0]						tpem_link_misc_word	;
	reg		[31: 0]						tpes_link_misc_word	;
	
	always@(posedge link_sclk or negedge link_rstn)
	if(!link_rstn)						tpgm_link_misc_word	<=	32'H0	;
	else if(rv32_tpgs_ctrl_wrid[ 9])	tpgm_link_misc_word	<=	rv32_tpgs_ctrl_wdin	;

	always@(posedge link_sclk or negedge link_rstn)
	if(!link_rstn)						tpgs_link_misc_word	<=	32'H0	;
	else if(rv32_tpgs_ctrl_wrid[10])	tpgs_link_misc_word	<=	rv32_tpgs_ctrl_wdin	;

	always@(posedge link_sclk or negedge link_rstn)
	if(!link_rstn)						tpem_link_misc_word	<=	32'H0	;
	else if(rv32_tpgs_ctrl_wrid[11])	tpem_link_misc_word	<=	rv32_tpgs_ctrl_wdin	;

	always@(posedge link_sclk or negedge link_rstn)
	if(!link_rstn)						tpes_link_misc_word	<=	32'H0	;
	else if(rv32_tpgs_ctrl_wrid[12])	tpes_link_misc_word	<=	rv32_tpgs_ctrl_wdin	;
//WORD_ADDRESS:: 0X0D----TPGS_TIME_CTRL
	reg			[ 7: 0]					time_base_usec_cnts	;
	reg			[31: 0]					time_ecos_usec_cnts	;

	wire								time_base_usec_flag	;
	wire								time_ecos_usec_flag	;

	wire		[31: 0]					time_ecos_cnts_sub1	=	time_ecos_usec_cnts - 1	;
	wire		[31: 0]					time_ecos_cnts_next	=	time_base_usec_flag	?	time_ecos_cnts_sub1	:	time_ecos_usec_cnts	;	

	assign	time_base_usec_flag	=		time_base_usec_cnts	==	`USEC_TIME_CLKS_NUMB	;
	assign	time_ecos_usec_flag	=		time_ecos_usec_cnts	== 	32'H00	;
	
	always@(posedge link_sclk or negedge link_rstn)
	if(~link_rstn)						time_base_usec_cnts		<=	0	;
	else if(rv32_tpgs_ctrl_wrid[13])	time_base_usec_cnts		<=	0	;
	else if(time_base_usec_flag)		time_base_usec_cnts		<=	0	;
	else 								time_base_usec_cnts		<=	time_base_usec_cnts + 1	;	

	always@(posedge link_sclk or negedge link_rstn)
	if(~link_rstn)						time_ecos_usec_cnts	<=	0	;
	else if(rv32_tpgs_ctrl_wrid[13])	time_ecos_usec_cnts	<=	rv32_tpgs_ctrl_wdin;
	else if(~time_ecos_usec_flag)		time_ecos_usec_cnts	<=	time_ecos_cnts_next	;	
//WORD_ADDRESS:: 0X0E----TPGS_CRAM_ADDR
	always@(posedge link_sclk or negedge link_rstn)
	if(!link_rstn)						tpgs_cram_writ_addr	<=	0	;
	else if(rv32_tpgs_ctrl_wrid[14])	tpgs_cram_writ_addr	<=	rv32_tpgs_ctrl_wdin[11:0]	;
	else if(tpgs_cram_writ_csen)		tpgs_cram_writ_addr	<=	tpgs_cram_writ_addr	+ 1	;

	assign	tpgs_cram_writ_csen	=		rv32_tpgs_ctrl_wrid[15]	;
	assign	tpgs_cram_addr_word	= { 	22'H0	,	tpgs_cram_writ_addr	};
/**********************************************************************************************************/
	assign	rv32_tpgs_ctrl_rout	=		rv32_tpgs_ctrl_csid[ 0]	?	tpgm_link_task_word	:
										rv32_tpgs_ctrl_csid[ 1]	?	tpgs_link_resp_word	:
										rv32_tpgs_ctrl_csid[ 2]	?	tpgs_link_xdma_stat	:

						
										rv32_tpgs_ctrl_csid[ 4]	?	tpgs_link_scut_stat	:
										rv32_tpgs_ctrl_csid[ 5]	?	tpem_port_enab_word	:
										rv32_tpgs_ctrl_csid[ 7]	?	mgth_link_intf_word	:

										rv32_tpgs_ctrl_csid[ 9]	?	tpgm_link_misc_word	:
										rv32_tpgs_ctrl_csid[10]	?	tpgs_link_misc_word	:
										rv32_tpgs_ctrl_csid[11]	?	tpem_link_misc_word	:
										rv32_tpgs_ctrl_csid[12]	?	tpes_link_misc_word	:

										rv32_tpgs_ctrl_csid[13]	?	time_ecos_usec_cnts	:
										rv32_tpgs_ctrl_csid[14]	?	tpgs_cram_addr_word	:	
										rv32_tpgs_ctrl_csid[15]	?{31'H0,	tpgs_dlys_ctrl_drdy	}	:	32'H00	;

endmodule

 