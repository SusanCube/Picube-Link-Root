//**********************************************************************************************************

//**********************************************************************************************************
module	rv32_link_llmb_ctrl(
	output		[ 31: 0]				rv32_ecos_ctrl_rout	,
	input								rv32_ecos_ctrl_csen	,
	input								rv32_ecos_ctrl_wrcs	,
	input		[  3: 0]				rv32_ecos_ctrl_addr	,
	input		[ 31: 0]				rv32_ecos_ctrl_wdat	,
//-------------------------------------------------------
	output		[ 7: 0]					ecos_omni_edge_numb	,
	output		[ 4: 0]					ecos_pile_edge_numb	,
	output	reg	[ 4: 0]					ecos_pile_edge_tail	,
	
	output		[ 3: 0]					this_tpgs_pile_indx	,
	output	reg	[ 4: 0]					this_tpgs_pile_edge	,
	output								this_tpgs_pile_lead	,
	output								this_tpgs_pile_coda	,
//-------------------------------------------------------
	input								link_sclk			,
	input								link_rstn			);
/**********************************************************************************************************/
	reg			[ 0:15][31:0]		ecos_llmb_ctrl_vars	;

	wire							rv32_ecos_ctrl_wren	;
	wire		[ 0:15]				rv32_ecos_ctrl_csid	;
	wire		[ 0:15]				rv32_ecos_ctrl_wrid	;
	
	assign	rv32_ecos_ctrl_wren	= &{rv32_ecos_ctrl_csen	,	rv32_ecos_ctrl_wrcs	};

	for(genvar i = 0 ; i <16 ; i++) begin	:	rv32_ecos_argu_rwcs
		assign	rv32_ecos_ctrl_csid[i]	=	rv32_ecos_ctrl_addr	==	i	;
		assign	rv32_ecos_ctrl_wrid[i]	= &{rv32_ecos_ctrl_wren	,	rv32_ecos_ctrl_csid[i]	};
	
		always@(posedge link_sclk or negedge link_rstn)
		if(~link_rstn)					ecos_llmb_ctrl_vars[i]	<=	0						;
		else if(rv32_ecos_ctrl_wrid[i])	ecos_llmb_ctrl_vars[i]	<=	rv32_ecos_ctrl_wdat		;
	end
/**********************************************************************************************************/
	assign	ecos_omni_edge_numb	= ecos_llmb_ctrl_vars[12][ 7: 0]				;
	assign	ecos_pile_edge_numb	= ecos_llmb_ctrl_vars[14][ 4: 0]				;
	assign	this_tpgs_pile_indx	= ecos_llmb_ctrl_vars[15][ 3: 0]				;
/**********************************************************************************************************/
	wire	[ 7: 0]					ecos_pile_lead_edge	;
	wire	[ 3: 0]					ecos_pile_numb_dec1	;

	assign	ecos_pile_lead_edge	=	ecos_pile_numb_dec1 * ecos_pile_edge_numb	;		
	assign	this_tpgs_pile_lead	= 	this_tpgs_pile_indx	==	4'H0				;
	assign	this_tpgs_pile_coda	= 	this_tpgs_pile_indx	==	ecos_pile_numb_dec1	;
	
	always@(posedge link_sclk or negedge link_rstn)
	if(!link_rstn)					ecos_pile_edge_tail	<=	5'H00	;
	else 							ecos_pile_edge_tail	<=	ecos_omni_edge_numb - ecos_pile_lead_edge	;

	always@(posedge link_sclk or negedge link_rstn)
	if(!link_rstn)					this_tpgs_pile_edge	<=	5'H00	;
	else if(this_tpgs_pile_coda)	this_tpgs_pile_edge	<=	ecos_pile_edge_tail	;
	else							this_tpgs_pile_edge	<=	ecos_pile_edge_numb	;
/**********************************************************************************************************/
	assign	rv32_ecos_ctrl_rout	=	rv32_ecos_ctrl_csid[ 0]	?	ecos_llmb_ctrl_vars[ 0]	:
									rv32_ecos_ctrl_csid[ 1]	?	ecos_llmb_ctrl_vars[ 1]	:
									rv32_ecos_ctrl_csid[ 2]	?	ecos_llmb_ctrl_vars[ 2]	:
									rv32_ecos_ctrl_csid[ 3]	?	ecos_llmb_ctrl_vars[ 3]	:
									rv32_ecos_ctrl_csid[ 4]	?	ecos_llmb_ctrl_vars[ 4]	:
									rv32_ecos_ctrl_csid[ 5]	?	ecos_llmb_ctrl_vars[ 5]	:
									rv32_ecos_ctrl_csid[ 6]	?	ecos_llmb_ctrl_vars[ 6]	:
									rv32_ecos_ctrl_csid[ 7]	?	ecos_llmb_ctrl_vars[ 7]	:	
									rv32_ecos_ctrl_csid[ 8]	?	ecos_llmb_ctrl_vars[ 8]	:
									rv32_ecos_ctrl_csid[ 9]	?	ecos_llmb_ctrl_vars[ 9]	:
									rv32_ecos_ctrl_csid[10]	?	ecos_llmb_ctrl_vars[10]	:
									rv32_ecos_ctrl_csid[11]	?	ecos_llmb_ctrl_vars[11]	:
									rv32_ecos_ctrl_csid[12]	?	ecos_llmb_ctrl_vars[12]	:
									rv32_ecos_ctrl_csid[13]	?	ecos_llmb_ctrl_vars[13]	:
									rv32_ecos_ctrl_csid[14]	?	ecos_llmb_ctrl_vars[14]	:	
									rv32_ecos_ctrl_csid[15]	?	ecos_llmb_ctrl_vars[15]	:	32'H0	;
/**********************************************************************************************************/


endmodule
