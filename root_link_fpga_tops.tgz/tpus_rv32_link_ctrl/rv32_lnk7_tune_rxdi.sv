//**********************************************************************************************************
module	rv32_link_tune_rxdi(
	output		[31: 0]					rv32_tune_rxdi_rout	,
	input								rv32_tune_rxdi_csen	,
	input								rv32_tune_rxdi_wrcs	,
	input		[ 3: 0]					rv32_tune_rxdi_addr	,
	input		[31: 0]					rv32_tune_rxdi_wdin	,
//-----------------------------------------------------------
	input		[ 0: 7]					tpem_tune_rxdi_done	,
	output	reg	[ 0: 7]					tpem_tune_rxdi_enab	,	
	output	reg	[ 0: 7][8: 0]			tpem_tune_rxdi_taps	,	
	input		[ 0: 7][9: 0]			tpem_tune_rxdi_stat	,

	output	reg							tpem_sync_rxdi_reqs	,
	input		[ 0: 7]					tpem_sync_rxdi_done	,
//-----------------------------------------------------------
	input								link_sclk			,
	input								link_rstn			);
/**********************************************************************************************************/
	wire		[ 0: 7]					rv32_tune_rxdi_csid	;
	wire		[ 0: 7]					rv32_tune_rxdi_wrid	;
	wire		[ 0: 7][31: 0]			rv32_tune_rxdi_word	;

for(genvar i = 0 ; i < 8 ; i++ ) 	begin	:	rv32_tune_rxdi_rwcs

	assign	rv32_tune_rxdi_csid[i]	= &{rv32_tune_rxdi_csen	,	rv32_tune_rxdi_addr==i	};
	assign	rv32_tune_rxdi_wrid[i]	= &{rv32_tune_rxdi_wrcs	,	rv32_tune_rxdi_csid[i]	};
			
	always@(posedge link_sclk or negedge link_rstn)
	if(~link_rstn)						tpem_tune_rxdi_taps[i]	<=	0	;
	else if(rv32_tune_rxdi_wrid[i])		tpem_tune_rxdi_taps[i]	<=	rv32_tune_rxdi_wdin[8:0];

	always@(posedge link_sclk or negedge link_rstn)
	if(~link_rstn)						tpem_tune_rxdi_enab[i]	<=	0	;
	else if(rv32_tune_rxdi_wrid[i])		tpem_tune_rxdi_enab[i]	<=	1	;
	else if(tpem_tune_rxdi_done[i])		tpem_tune_rxdi_enab[i]	<=	0	;

	assign	rv32_tune_rxdi_word[i]	={ 	tpem_tune_rxdi_enab[i]	,
										5'H0					,
										tpem_tune_rxdi_stat[i]	,
										7'H0					,
										tpem_tune_rxdi_taps[i]	};
end
/**********************************************************************************************************/
	reg			[ 1: 0]					rv32_sync_done_samp	;

	wire								rv32_sync_rxdi_csen	;
	wire								rv32_sync_rxdi_wrcs	;
	wire								rv32_sync_rxdi_done	;
	wire								rv32_sync_rxdi_over	;
	
	assign	rv32_sync_rxdi_csen	=	&{	rv32_tune_rxdi_csen	,	rv32_tune_rxdi_addr== 8	};
	assign	rv32_sync_rxdi_wrcs	=	&{	rv32_sync_rxdi_csen	,	rv32_tune_rxdi_wrcs		};
	assign	rv32_sync_rxdi_done	=	&{	tpem_sync_rxdi_done	};
	assign	rv32_sync_rxdi_over	=		rv32_sync_done_samp	==	2'B10	;	
//----------------------------------------------------------------------------------------------------------

	always@(posedge link_sclk or negedge link_rstn)
	if(~link_rstn)						rv32_sync_done_samp	<=	0	;
	else 								rv32_sync_done_samp	<={	rv32_sync_rxdi_done	,	rv32_sync_done_samp[1]};
//----------------------------------------------------------------------------------------------------------
	always@(posedge link_sclk or negedge link_rstn)
	if(~link_rstn)						tpem_sync_rxdi_reqs	<=	0	;
	else if(rv32_sync_rxdi_wrcs)		tpem_sync_rxdi_reqs	<=	rv32_tune_rxdi_wdin[0];	
	else if(rv32_sync_rxdi_over)		tpem_sync_rxdi_reqs	<=	0	;	
	
/**********************************************************************************************************/
	assign	rv32_tune_rxdi_rout	=	rv32_tune_rxdi_csid[ 0]	?			rv32_tune_rxdi_word[ 0]	:
									rv32_tune_rxdi_csid[ 1]	?			rv32_tune_rxdi_word[ 1]	:
									rv32_tune_rxdi_csid[ 2]	?			rv32_tune_rxdi_word[ 2]	:
									rv32_tune_rxdi_csid[ 3]	?			rv32_tune_rxdi_word[ 3]	:
									rv32_tune_rxdi_csid[ 4]	?			rv32_tune_rxdi_word[ 4]	:
									rv32_tune_rxdi_csid[ 5]	?			rv32_tune_rxdi_word[ 5]	:
									rv32_tune_rxdi_csid[ 6]	?			rv32_tune_rxdi_word[ 6]	:
									rv32_tune_rxdi_csid[ 7]	?			rv32_tune_rxdi_word[ 7]	:	
									rv32_sync_rxdi_csen		?	{31'H0,	tpem_sync_rxdi_reqs	}	:	32'H0	;
									
endmodule

