//**********************************************************************************************************

//**********************************************************************************************************
module	rv32_link_acks_argu(
	input								rv32_acks_argu_csen	,
	input								rv32_acks_argu_wrcs	,
	input		[  3: 0]				rv32_acks_argu_addr	,
	input		[ 31: 0]				rv32_acks_argu_wdin	,
	output		[ 31: 0]				rv32_acks_argu_rout	,
//-------------------------------------------------------
//	input								tpem_link_port_init	,

	input		[ 3: 0]					tpgs_link_acks_indx	,
	output		[31: 0]					tpgs_link_acks_data	,

	input		[ 0: 7]					tpes_link_acks_wrcs	,
	input		[ 0: 7][31: 0]			tpes_link_acks_data	,

	input		[ 2: 0]					scut_acks_memo_indx	,
	output		[31: 0]					scut_acks_memo_data	,
//-------------------------------------------------------
	input								link_sclk			,
	input								link_rstn			);
/**********************************************************************************************************/
	reg		[ 0: 7][31: 0]				tpes_link_acks_memo	;			

	wire	[ 0: 7]						rv32_acks_argu_csid	;
	wire	[ 0: 7]						rv32_acks_argu_wrid	;

	wire	[ 0: 7]						tpgs_acks_argu_csid	;
	wire	[ 0: 7]						scut_acks_argu_csid	;
		

for(genvar i = 0 ; i < 8 ; i++) begin	:	rv32_acks_rwcs_ctrl
	assign	rv32_acks_argu_csid[i]	= &{rv32_acks_argu_csen	,	rv32_acks_argu_addr==i	};
	assign	rv32_acks_argu_wrid[i]	= &{rv32_acks_argu_wrcs	,	rv32_acks_argu_csid[i]	};

	assign	tpgs_acks_argu_csid[i]	= 	tpgs_link_acks_indx	==	i	;
	assign	scut_acks_argu_csid[i]	= 	scut_acks_memo_indx	==	i	;


	always@(posedge link_sclk or negedge link_rstn)
	if(!link_rstn)						tpes_link_acks_memo[i]	<=	0	;
//	else if(tpem_link_port_init)		tpes_link_acks_memo[i]	<=	32'H494E4954			;//"INIT"
	else if(rv32_acks_argu_wrid[i])		tpes_link_acks_memo[i]	<=	rv32_acks_argu_wdin		;
	else if(tpes_link_acks_wrcs[i])		tpes_link_acks_memo[i]	<=	tpes_link_acks_data[i]	;

end
/**********************************************************************************************************/
	assign	tpgs_link_acks_data	=		tpgs_acks_argu_csid[ 0]		?	tpes_link_acks_memo[0]	:
										tpgs_acks_argu_csid[ 1]		?	tpes_link_acks_memo[1]	:
										tpgs_acks_argu_csid[ 2]		?	tpes_link_acks_memo[2]	:
										tpgs_acks_argu_csid[ 3]		?	tpes_link_acks_memo[3]	:	
										tpgs_acks_argu_csid[ 4]		?	tpes_link_acks_memo[4]	:
										tpgs_acks_argu_csid[ 5]		?	tpes_link_acks_memo[5]	:
										tpgs_acks_argu_csid[ 6]		?	tpes_link_acks_memo[6]	:
										tpgs_acks_argu_csid[ 7]		?	tpes_link_acks_memo[7]	:	32'H0	;

	assign	rv32_acks_argu_rout	=		rv32_acks_argu_csid[ 0]		?	tpes_link_acks_memo[0]	:
										rv32_acks_argu_csid[ 1]		?	tpes_link_acks_memo[1]	:
										rv32_acks_argu_csid[ 2]		?	tpes_link_acks_memo[2]	:
										rv32_acks_argu_csid[ 3]		?	tpes_link_acks_memo[3]	:
										rv32_acks_argu_csid[ 4]		?	tpes_link_acks_memo[4]	:
										rv32_acks_argu_csid[ 5]		?	tpes_link_acks_memo[5]	:
										rv32_acks_argu_csid[ 6]		?	tpes_link_acks_memo[6]	:
										rv32_acks_argu_csid[ 7]		?	tpes_link_acks_memo[7]	:	32'H0	;

	assign	scut_acks_memo_data	=		scut_acks_argu_csid[ 0]		?	tpes_link_acks_memo[0]	:
										scut_acks_argu_csid[ 1]		?	tpes_link_acks_memo[1]	:
										scut_acks_argu_csid[ 2]		?	tpes_link_acks_memo[2]	:
										scut_acks_argu_csid[ 3]		?	tpes_link_acks_memo[3]	:
										scut_acks_argu_csid[ 4]		?	tpes_link_acks_memo[4]	:
										scut_acks_argu_csid[ 5]		?	tpes_link_acks_memo[5]	:
										scut_acks_argu_csid[ 6]		?	tpes_link_acks_memo[6]	:
										scut_acks_argu_csid[ 7]		?	tpes_link_acks_memo[7]	:	32'H0	;
/**********************************************************************************************************/
endmodule
