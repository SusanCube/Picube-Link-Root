//**********************************************************************************************************
//WORD		CODE	 
//RESET_TPGS_CORE	::	"RSTC"	"52535443"
//RESET_TPGS_LNK0	::	"RST0"	"52535430"
//RESET_TPGS_LNK1	::	"RST1"	"52535431"
//RESET_TPGS_LNK2	::	"RST2"	"52535432"
//IOBASE 	9		sdes_STAT	
//
//**********************************************************************************************************
`include	"agile_card_vars.vh"

module	rv32_link_tpem_ctrl(
	output		[ 31:0 ]				rv32_tpem_ctrl_rout	,
	input								rv32_tpem_ctrl_csen	,
	input								rv32_tpem_ctrl_wrcs	,
	input		[ 3: 0 ]				rv32_tpem_ctrl_addr	,
	input		[ 31:0 ]				rv32_tpem_ctrl_wdin	,
//----------------------------------------------------------------------
	input		[ 7: 0]					tpem_link_port_enab	,
	output		[ 0: 7]					tpem_tune_txdo_mode	,
	output		[ 0: 7]					tpem_tune_rxdi_mode	,
	output	reg	[ 0: 7]					tpem_link_port_rstn	,	
	output	reg	[ 0: 7]					tpem_link_port_rxen	,	

	input		[17: 0]					tpem_scfg_tpes_stat	,	

	output	reg							tpem_link_port_init	,
	input								tpem_link_port_idle	,
	input								tpem_link_acks_coda	,
	input								tpem_link_resp_coda	,

	output								tpem_link_trim_reqs	,
	output								tpem_link_icfg_reqs	,
	output								tpem_link_ocfg_reqs	,
	output								tpem_link_nnex_reqs	,
	output								tpem_link_ivct_reqs	,
	output								tpem_link_ovct_reqs	,
	output								tpem_link_imtx_reqs	,
	output								tpem_link_omtx_reqs	,
	output								tpem_link_aset_reqs	,
	output								tpem_link_dnld_reqs	,
	output								tpem_link_boot_reqs	,
	output								tpem_scfg_aset_reqs	,
	output								tpem_scfg_dnld_reqs	,
	output								tpem_scfg_boot_reqs	,

	input								tpem_link_trim_done	,//BIT 	02
	input								tpem_link_icfg_done	,//BIT 	02
	input								tpem_link_ocfg_done	,//BIT 	03
	input								tpem_link_nnex_done	,//BIT 	04
	input								tpem_link_ivct_done	,//BIT 	05
	input								tpem_link_ovct_done	,//BIT 	06
	input								tpem_link_imtx_done	,//BIT 	07
	input								tpem_link_omtx_done	,//BIT 	08
	input								tpem_link_aset_done	,//BIT 	09
	input								tpem_link_dnld_done	,//BIT 	0a
	input								tpem_link_boot_done	,//BIT 	0b
	input								tpem_scfg_aset_done	,//BIT 	0c
	input								tpem_scfg_dnld_done	,//BIT 	0d
	input								tpem_scfg_boot_done	,//BIT 	0e
			
	input								link_sclk			,
	input								link_rstn			);
/**********************************************************************************************************/
	wire	rv32_tpem_cs00	=			rv32_tpem_ctrl_addr	==	4'H0	;
	wire	rv32_tpem_cs01	=			rv32_tpem_ctrl_addr	==	4'H1	;
	wire	rv32_tpem_cs02	=			rv32_tpem_ctrl_addr	==	4'H2	;
	wire	rv32_tpem_cs03	=			rv32_tpem_ctrl_addr	==	4'H3	;
	wire	rv32_tpem_cs04	=			rv32_tpem_ctrl_addr	==	4'H4	;
	wire	rv32_tpem_cs05	=			rv32_tpem_ctrl_addr	==	4'H5	;
	
	wire	rv32_tpem_wren	=	  &{	rv32_tpem_ctrl_csen	,	rv32_tpem_ctrl_wrcs };
	wire	rv32_tpem_wcs0	=	  &{	rv32_tpem_wren	,	rv32_tpem_cs00 };
	wire	rv32_tpem_wcs1	=	  &{	rv32_tpem_wren	,	rv32_tpem_cs01 };
	wire	rv32_tpem_wcs4	=	  &{	rv32_tpem_wren	,	rv32_tpem_cs04 };
	wire	rv32_tpem_wcs5	=	  &{	rv32_tpem_wren	,	rv32_tpem_cs05 };
/**********************************************************************************************************/
	wire								tpem_link_tpes_init	;

	reg		[ 7: 0]						tpem_link_tpes_cmnd	;

	reg									tpem_link_trim_stat	;
	reg									tpem_link_icfg_stat	;
	reg									tpem_link_ocfg_stat	;
	reg									tpem_link_nnex_stat	;
	reg									tpem_link_ivct_stat	;
	reg									tpem_link_ovct_stat	;
	reg									tpem_link_imtx_stat	;
	reg									tpem_link_omtx_stat	;
	reg									tpem_link_aset_stat	;
	reg									tpem_link_dnld_stat	;
	reg									tpem_link_boot_stat	;
	reg									tpem_scfg_aset_stat	;
	reg									tpem_scfg_dnld_stat	;
	reg									tpem_scfg_boot_stat	;
	
//	assign	tpem_link_tpes_init	= &{	rv32_tpem_wcs0 		, 	tpem_link_port_idle};	
	assign	tpem_link_tpes_init	=  {	rv32_tpem_wcs0 		, 	tpem_link_port_idle	,	rv32_tpem_ctrl_wdin[7:0]	} == 10'H300		;

	
	assign	tpem_link_trim_reqs	= 		tpem_link_tpes_cmnd	== `CUBE_LINK_TRIM_CMND	;
	assign	tpem_link_icfg_reqs	= 		tpem_link_tpes_cmnd	== `CUBE_LINK_ICFG_CMND	;
	assign	tpem_link_ocfg_reqs	= 		tpem_link_tpes_cmnd	== `CUBE_LINK_OCFG_CMND	;
	assign	tpem_link_nnex_reqs	= 		tpem_link_tpes_cmnd	== `CUBE_LINK_NNEX_CMND	;
	assign	tpem_link_ivct_reqs	= 		tpem_link_tpes_cmnd	== `CUBE_LINK_IVCT_CMND	;
	assign	tpem_link_ovct_reqs	= 		tpem_link_tpes_cmnd	== `CUBE_LINK_OVCT_CMND	;
	assign	tpem_link_imtx_reqs	= 		tpem_link_tpes_cmnd	== `CUBE_LINK_IMTX_CMND	;
	assign	tpem_link_omtx_reqs	= 		tpem_link_tpes_cmnd	== `CUBE_LINK_OMTX_CMND	;
	assign	tpem_link_aset_reqs	= 		tpem_link_tpes_cmnd	== `CUBE_LINK_ASET_CMND	;
	assign	tpem_link_dnld_reqs	= 		tpem_link_tpes_cmnd	== `CUBE_LINK_DNLD_CMND	;
	assign	tpem_link_boot_reqs	= 		tpem_link_tpes_cmnd	== `CUBE_LINK_BOOT_CMND	;
	assign	tpem_scfg_aset_reqs	= 		tpem_link_tpes_cmnd	== `FPGA_SCFG_ASET_CMND	;
	assign	tpem_scfg_dnld_reqs	= 		tpem_link_tpes_cmnd	== `FPGA_SCFG_DNLD_CMND	;
	assign	tpem_scfg_boot_reqs	= 		tpem_link_tpes_cmnd	== `FPGA_SCFG_BOOT_CMND	;
	
	wire	tpem_link_tpes_done	= |{	tpem_link_trim_reqs	&	tpem_link_trim_done	,
									
										tpem_link_icfg_reqs	&	tpem_link_icfg_done	,
										tpem_link_ocfg_reqs	&	tpem_link_ocfg_done	,
										tpem_link_nnex_reqs	&	tpem_link_nnex_done	,
									
										tpem_link_ivct_reqs	&	tpem_link_ivct_done	,
										tpem_link_ovct_reqs	&	tpem_link_ovct_done	,
										tpem_link_imtx_reqs	&	tpem_link_imtx_done	,
										tpem_link_omtx_reqs	&	tpem_link_omtx_done	,
									
										tpem_link_aset_reqs	&	tpem_link_aset_done	,
										tpem_link_dnld_reqs	&	tpem_link_dnld_done	,
										tpem_link_boot_reqs	&	tpem_link_boot_done	,

										tpem_scfg_aset_reqs	&	tpem_scfg_aset_done	,
										tpem_scfg_dnld_reqs	&	tpem_scfg_dnld_done	,
										tpem_scfg_boot_reqs	&	tpem_scfg_boot_done};
//----------------------------------------------------------------------------------------------------------									
	always@(posedge link_sclk or negedge link_rstn)		
	if(!link_rstn)						tpem_link_port_init	<=	0	;
	else 								tpem_link_port_init	<=	tpem_link_tpes_init	;

	always@(posedge link_sclk or negedge link_rstn)		
	if(!link_rstn)						tpem_link_tpes_cmnd	<=	0	;
//	else if(tpem_link_tpes_init)		tpem_link_tpes_cmnd	<=	rv32_tpem_ctrl_wdin[7:0]	;
	else if(rv32_tpem_wcs0		)		tpem_link_tpes_cmnd	<=	rv32_tpem_ctrl_wdin[7:0]	;
	else if(tpem_link_tpes_done)		tpem_link_tpes_cmnd	<=	0	;

	always@(posedge link_sclk or negedge link_rstn)		
	if(!link_rstn)						tpem_link_icfg_stat	<=	0	;
	else if(tpem_link_tpes_init)		tpem_link_icfg_stat	<=	0	;
	else if(tpem_link_icfg_reqs)		tpem_link_icfg_stat	<=	tpem_link_icfg_done	;

	always@(posedge link_sclk or negedge link_rstn)		
	if(!link_rstn)						tpem_link_ocfg_stat	<=	0	;
	else if(tpem_link_tpes_init)		tpem_link_ocfg_stat	<=	0	;
	else if(tpem_link_ocfg_reqs)		tpem_link_ocfg_stat	<=	tpem_link_ocfg_done	;

	always@(posedge link_sclk or negedge link_rstn)		
	if(!link_rstn)						tpem_link_nnex_stat	<=	0	;
	else if(tpem_link_tpes_init)		tpem_link_nnex_stat	<=	0	;
	else if(tpem_link_nnex_reqs)		tpem_link_nnex_stat	<=	tpem_link_nnex_done	;

	always@(posedge link_sclk or negedge link_rstn)		
	if(!link_rstn)						tpem_link_ivct_stat	<=	0	;
	else if(tpem_link_tpes_init)		tpem_link_ivct_stat	<=	0	;
	else if(tpem_link_ivct_reqs)		tpem_link_ivct_stat	<=	tpem_link_ivct_done	;

	always@(posedge link_sclk or negedge link_rstn)		
	if(!link_rstn)						tpem_link_ovct_stat	<=	0	;
	else if(tpem_link_tpes_init)		tpem_link_ovct_stat	<=	0	;
	else if(tpem_link_ovct_reqs)		tpem_link_ovct_stat	<=	tpem_link_ovct_done	;

	always@(posedge link_sclk or negedge link_rstn)		
	if(!link_rstn)						tpem_link_imtx_stat	<=	0	;
	else if(tpem_link_tpes_init)		tpem_link_imtx_stat	<=	0	;
	else if(tpem_link_imtx_reqs)		tpem_link_imtx_stat	<=	tpem_link_imtx_done	;

	always@(posedge link_sclk or negedge link_rstn)		
	if(!link_rstn)						tpem_link_omtx_stat	<=	0	;
	else if(tpem_link_tpes_init)		tpem_link_omtx_stat	<=	0	;
	else if(tpem_link_omtx_reqs)		tpem_link_omtx_stat	<=	tpem_link_omtx_done	;

	always@(posedge link_sclk or negedge link_rstn)		
	if(!link_rstn)						tpem_link_aset_stat	<=	0	;
	else if(tpem_link_tpes_init)		tpem_link_aset_stat	<=	0	;
	else if(tpem_link_aset_reqs)		tpem_link_aset_stat	<=	tpem_link_aset_done	;

	always@(posedge link_sclk or negedge link_rstn)		
	if(!link_rstn)						tpem_link_dnld_stat	<=	0	;
	else if(tpem_link_tpes_init)		tpem_link_dnld_stat	<=	0	;
	else if(tpem_link_dnld_reqs)		tpem_link_dnld_stat	<=	tpem_link_dnld_done	;

	always@(posedge link_sclk or negedge link_rstn)		
	if(!link_rstn)						tpem_link_boot_stat	<=	0	;
	else if(tpem_link_tpes_init)		tpem_link_boot_stat	<=	0	;
	else if(tpem_link_boot_reqs)		tpem_link_boot_stat	<=	tpem_link_boot_done	;

	always@(posedge link_sclk or negedge link_rstn)		
	if(!link_rstn)						tpem_scfg_aset_stat	<=	0	;
	else if(tpem_link_tpes_init)		tpem_scfg_aset_stat	<=	0	;
	else if(tpem_scfg_aset_reqs)		tpem_scfg_aset_stat	<=	tpem_scfg_aset_done	;

	always@(posedge link_sclk or negedge link_rstn)		
	if(!link_rstn)						tpem_scfg_dnld_stat	<=	0	;
	else if(tpem_link_tpes_init)		tpem_scfg_dnld_stat	<=	0	;
	else if(tpem_scfg_dnld_reqs)		tpem_scfg_dnld_stat	<=	tpem_scfg_dnld_done	;

	always@(posedge link_sclk or negedge link_rstn)		
	if(!link_rstn)						tpem_scfg_boot_stat	<=	0	;
	else if(tpem_link_tpes_init)		tpem_scfg_boot_stat	<=	0	;
	else if(tpem_scfg_boot_reqs)		tpem_scfg_boot_stat	<=	tpem_scfg_boot_done	;

	always@(posedge link_sclk or negedge link_rstn)		
	if(!link_rstn)						tpem_link_trim_stat	<=	0	;
	else if(tpem_link_tpes_init)		tpem_link_trim_stat	<=	0	;
	else if(tpem_link_trim_reqs)		tpem_link_trim_stat	<=	tpem_link_trim_done	;
//----------------------------------------------------------------------------------------------------------
	wire	[31: 0]						tpem_link_stat_word	;

	wire	tpem_link_misc_done	= |{	tpem_link_trim_stat	,//bit 13
										tpem_scfg_boot_stat	,//bit 12
										tpem_scfg_dnld_stat	,//bit 11
										tpem_scfg_aset_stat	,//bit 10	
										tpem_link_boot_stat	,//bit 09
										tpem_link_dnld_stat	,//bit 08
										tpem_link_aset_stat	,//bit 07
										tpem_link_omtx_stat	,//bit 06
										tpem_link_imtx_stat	,//bit 05
										tpem_link_ovct_stat	,//bit 04
										tpem_link_ivct_stat	,//bit 03
										tpem_link_nnex_stat	,//bit 02
										tpem_link_ocfg_stat	,//bit 01
										tpem_link_icfg_stat};//bit 00
							
	assign	tpem_link_stat_word	= {		tpem_link_misc_done	,
										17'H0				,	
										tpem_link_trim_stat	,//bit 13
										tpem_scfg_boot_stat	,//bit 12
										tpem_scfg_dnld_stat	,//bit 11
										tpem_scfg_aset_stat	,//bit 10	
										tpem_link_boot_stat	,//bit 09
										tpem_link_dnld_stat	,//bit 08
										tpem_link_aset_stat	,//bit 07
										tpem_link_omtx_stat	,//bit 06
										tpem_link_imtx_stat	,//bit 05
										tpem_link_ovct_stat	,//bit 04
										tpem_link_ivct_stat	,//bit 03
										tpem_link_nnex_stat	,//bit 02
										tpem_link_ocfg_stat	,//bit 01
										tpem_link_icfg_stat};//bit 00
/**********************************************************************************************************/	
	reg		[ 7: 0]						tpem_tune_mode_ctrl	;
	wire	[31: 0]						tpem_tune_mode_word	;
	wire								tpem_tune_odly_enab	;
	wire								tpem_tune_idly_enab	;
	
	assign	tpem_tune_mode_word	={		24'H0	,	tpem_tune_mode_ctrl	};
	assign	tpem_tune_odly_enab	=		tpem_tune_mode_ctrl == 8'H88	;
	assign	tpem_tune_idly_enab	=		tpem_tune_mode_ctrl == 8'H99	;
	
	assign	tpem_tune_txdo_mode[0]	=	tpem_tune_odly_enab & tpem_link_port_enab[0]	;
	assign	tpem_tune_txdo_mode[1]	=	tpem_tune_odly_enab & tpem_link_port_enab[1]	;
	assign	tpem_tune_txdo_mode[2]	=	tpem_tune_odly_enab & tpem_link_port_enab[2]	;
	assign	tpem_tune_txdo_mode[3]	=	tpem_tune_odly_enab & tpem_link_port_enab[3]	;
	assign	tpem_tune_txdo_mode[4]	=	tpem_tune_odly_enab & tpem_link_port_enab[4]	;
	assign	tpem_tune_txdo_mode[5]	=	tpem_tune_odly_enab & tpem_link_port_enab[5]	;
	assign	tpem_tune_txdo_mode[6]	=	tpem_tune_odly_enab & tpem_link_port_enab[6]	;
	assign	tpem_tune_txdo_mode[7]	=	tpem_tune_odly_enab & tpem_link_port_enab[7]	;

	assign	tpem_tune_rxdi_mode[0]	=	tpem_tune_idly_enab & tpem_link_port_enab[0]	;
	assign	tpem_tune_rxdi_mode[1]	=	tpem_tune_idly_enab & tpem_link_port_enab[1]	;
	assign	tpem_tune_rxdi_mode[2]	=	tpem_tune_idly_enab & tpem_link_port_enab[2]	;
	assign	tpem_tune_rxdi_mode[3]	=	tpem_tune_idly_enab & tpem_link_port_enab[3]	;
	assign	tpem_tune_rxdi_mode[4]	=	tpem_tune_idly_enab & tpem_link_port_enab[4]	;
	assign	tpem_tune_rxdi_mode[5]	=	tpem_tune_idly_enab & tpem_link_port_enab[5]	;
	assign	tpem_tune_rxdi_mode[6]	=	tpem_tune_idly_enab & tpem_link_port_enab[6]	;
	assign	tpem_tune_rxdi_mode[7]	=	tpem_tune_idly_enab & tpem_link_port_enab[7]	;

	always@(posedge link_sclk or negedge link_rstn)
	if(!link_rstn)						tpem_tune_mode_ctrl	<=	0	;
	else if(rv32_tpem_wcs1	)			tpem_tune_mode_ctrl	<=	rv32_tpem_ctrl_wdin[7:0];
/**********************************************************************************************************/	
	reg									tpes_link_acks_stat	;
	reg									tpes_link_resp_stat	;

	wire	[31: 0]						tpes_link_stat_word	;
	
	always@(posedge link_sclk or negedge link_rstn)		
	if(!link_rstn)						tpes_link_acks_stat	<=	0	;
	else if(tpem_link_tpes_init)		tpes_link_acks_stat	<=	0	;
	else if(tpem_link_acks_coda)		tpes_link_acks_stat	<=	1	;

	always@(posedge link_sclk or negedge link_rstn)		
	if(!link_rstn)						tpes_link_resp_stat	<=	0	;
	else if(tpem_link_tpes_init)		tpes_link_resp_stat	<=	0	;
	else if(tpem_link_resp_coda)		tpes_link_resp_stat	<=	1	;

	assign	tpes_link_stat_word	= {		30'H0				,
										tpes_link_resp_stat	,
										tpes_link_acks_stat	};	
/**********************************************************************************************************/
	reg		[31: 0]						tpem_rstn_tpes_cnts	;
	
	wire								tpem_rstn_tpes_actv	;
	wire	[31: 0]						tpem_rstn_cnts_sub1	;

	assign	tpem_rstn_tpes_actv	=		tpem_rstn_tpes_cnts !=0 ;
	assign	tpem_rstn_cnts_sub1	=		tpem_rstn_tpes_cnts - 1	;

	always@(posedge link_sclk or negedge link_rstn)		
	if(!link_rstn)						tpem_rstn_tpes_cnts	<=	32'H0				;
	else if(rv32_tpem_wcs4)				tpem_rstn_tpes_cnts	<=	rv32_tpem_ctrl_wdin	;
	else if(tpem_rstn_tpes_actv)		tpem_rstn_tpes_cnts	<=	tpem_rstn_cnts_sub1	;

	wire	[ 0: 7]						tpem_rstn_tpes_csen	;

	assign	tpem_rstn_tpes_csen[0]=		tpem_link_port_enab[0]	? ~	tpem_rstn_tpes_actv	:	1'B1	;
	assign	tpem_rstn_tpes_csen[1]=		tpem_link_port_enab[1]	? ~	tpem_rstn_tpes_actv	:	1'B1	;
	assign	tpem_rstn_tpes_csen[2]=		tpem_link_port_enab[2]	? ~	tpem_rstn_tpes_actv	:	1'B1	;
	assign	tpem_rstn_tpes_csen[3]=		tpem_link_port_enab[3]	? ~	tpem_rstn_tpes_actv	:	1'B1	;
	assign	tpem_rstn_tpes_csen[4]=		tpem_link_port_enab[4]	? ~	tpem_rstn_tpes_actv	:	1'B1	;
	assign	tpem_rstn_tpes_csen[5]=		tpem_link_port_enab[5]	? ~	tpem_rstn_tpes_actv	:	1'B1	;
	assign	tpem_rstn_tpes_csen[6]=		tpem_link_port_enab[6]	? ~	tpem_rstn_tpes_actv	:	1'B1	;
	assign	tpem_rstn_tpes_csen[7]=		tpem_link_port_enab[7]	? ~	tpem_rstn_tpes_actv	:	1'B1	;

	always@(posedge link_sclk or negedge link_rstn)		
	if(!link_rstn)						tpem_link_port_rstn	<=	8'HFF				;
	else								tpem_link_port_rstn	<=	tpem_rstn_tpes_csen	;
/**********************************************************************************************************/
	wire	[31: 0]						tpem_link_rxen_word	;

	always@(posedge link_sclk or negedge link_rstn)		
	if(!link_rstn)						tpem_link_port_rxen	<=	8'H0				;
	else if(rv32_tpem_wcs5)				tpem_link_port_rxen	<=	rv32_tpem_ctrl_wdin[7:0]	;

	assign	tpem_link_rxen_word	=	{	24'H0 ,	tpem_link_port_rxen	};
/**********************************************************************************************************/	
	wire	[31: 0]		tpem_scfg_stat_word	=	{14'H0	,	tpem_scfg_tpes_stat	};	

	assign	rv32_tpem_ctrl_rout		=	rv32_tpem_cs00	?	tpem_link_stat_word	:
										rv32_tpem_cs01	?	tpem_tune_mode_word	:
										rv32_tpem_cs02	?	tpes_link_stat_word	:
										rv32_tpem_cs03	?	tpem_scfg_stat_word	:
										rv32_tpem_cs04	?	tpem_rstn_tpes_cnts	:	
										rv32_tpem_cs05	?	tpem_link_rxen_word	:	
										32'H0	;

endmodule
