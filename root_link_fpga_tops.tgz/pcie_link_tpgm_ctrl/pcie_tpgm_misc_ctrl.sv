/***********************************************************************************************************
//WORD		DESCRIPTION	 
***********************************************************************************************************/
`include	"agile_card_vars.vh"

module	pcie_tpgm_misc_ctrl(
	input								pcie_bar0_tpgm_csen	,
	input		[ 3: 0 ]				pcie_bar0_tpgm_addr	,
	input								pcie_bar0_tpgm_wrcs	,
	input		[ 31:0 ]				pcie_bar0_tpgm_wdin	,
	output		[ 31:0 ]				pcie_bar0_tpgm_rdat	,
	input								pcie_bclk			,
	input								pcie_rstn			,
//----------------------------------------------------------------------
	input								pcie_xdma_ddrs_stat	,
	output	reg	[ 24: 0]				pcie_xdma_ddrs_base	,
	output		[ 19: 0]				pcie_xdma_rows_numb	,
	output	reg	[ 31: 0]				pcie_xdma_cols_numb	,

	output	reg							pcie_rdma_ddrs_enab	,
	input								pcie_rdma_ddrs_done	,
	output	reg							pcie_wdma_ddrs_enab	,
	input								pcie_wdma_ddrs_done	,

	output								tpgm_link_supv_mode	,
//----------------------------------------------------------------------
	output	reg	[ 1: 3]					tpgm_link_tune_rxdi	,
	output	reg	[ 1: 3]					tpgm_link_tune_txdo	,

	input		[ 3: 0]					tpgm_link_port_enab	,
	input								tpgm_link_port_idle	,
	input		[ 3: 0]					tpgm_link_port_acks	,
	input		[ 3: 0]					tpgm_link_port_resp	,

	output								tpgm_link_port_init	,
	output	reg							tpgm_link_port_rstn	,
	output								tpgm_link_acks_init	,

	output								tpgm_link_trim_reqs	,
	output								tpgm_link_icfg_reqs	,
	output								tpgm_link_ocfg_reqs	,
	output								tpgm_link_nnex_reqs	,
	output								tpgm_link_ivct_reqs	,
	output								tpgm_link_ovct_reqs	,
	output								tpgm_link_imtx_reqs	,
	output								tpgm_link_omtx_reqs	,
	output								tpgm_link_rivt_reqs	,
	output								tpgm_link_rovt_reqs	,
	output								tpgm_link_rimt_reqs	,
	output								tpgm_link_romt_reqs	,
	output								tpgm_link_risv_reqs	,
	output								tpgm_link_rosv_reqs	,
	output								tpgm_link_rism_reqs	,
	output								tpgm_link_rosm_reqs	,
	output								tpgm_link_aset_reqs	,
	output								tpgm_link_dnld_reqs	,
	output								tpgm_link_boot_reqs	,

	input								tpgm_link_trim_done	,
	input								tpgm_link_icfg_done	,
	input								tpgm_link_ocfg_done	,
	input								tpgm_link_nnex_done	,
	input								tpgm_link_ivct_done	,
	input								tpgm_link_ovct_done	,
	input								tpgm_link_imtx_done	,
	input								tpgm_link_omtx_done	,
	input								tpgm_link_rivt_done	,
	input								tpgm_link_rovt_done	,
	input								tpgm_link_rimt_done	,
	input								tpgm_link_romt_done	,
	input								tpgm_link_risv_done	,
	input								tpgm_link_rosv_done	,
	input								tpgm_link_rism_done	,
	input								tpgm_link_rosm_done	,
	input								tpgm_link_aset_done	,
	input								tpgm_link_dnld_done	,
	input								tpgm_link_boot_done	,

	input								tpgm_sclk			,
	input								tpgm_rstn			);
/***********************************************************************************************************/
	wire								pcie_bar0_tpgm_wren	;
	wire	[0:15]						pcie_bar0_tpgm_csid	;
	wire	[0:15]						pcie_bar0_tpgm_wrid	;

	assign	pcie_bar0_tpgm_wren	=&{		pcie_bar0_tpgm_csen	,	pcie_bar0_tpgm_wrcs };
	
for(genvar i = 0 ; i < 16 ; i++) begin	:	pcie_link_tpgm_rwcs
	assign	pcie_bar0_tpgm_csid[i]	=	pcie_bar0_tpgm_addr	==	i	;
	assign	pcie_bar0_tpgm_wrid[i]	= &{pcie_bar0_tpgm_wren	,	pcie_bar0_tpgm_csid[i]	};
end 
/**********************************************************************************************************/
	reg		[ 1: 0]						tpgm_link_idle_samp	;
	reg									tpgm_link_clks_good	;

	wire	[31: 0]						tpgm_link_intf_stat	;

	wire								tpgm_link_idle_stat	=	tpgm_link_idle_samp[0]	;

	assign	tpgm_link_intf_stat	={		28'H0				,
										pcie_xdma_ddrs_stat	,
										tpgm_link_idle_stat	,
										tpgm_link_clks_good	,
										tpgm_link_port_rstn	};			

	always@(posedge pcie_bclk or negedge pcie_rstn)
	if(~pcie_rstn)						tpgm_link_idle_samp	<=	0	;
	else								tpgm_link_idle_samp	<={	tpgm_link_port_idle	,	tpgm_link_idle_samp[1]	};		

	always@(posedge tpgm_sclk or negedge tpgm_rstn)
	if(!tpgm_rstn)						tpgm_link_clks_good	<=	0		;
	else								tpgm_link_clks_good	<=	1		;
/**********************************************************************************************************/
	always@(posedge pcie_bclk or negedge pcie_rstn )
	if(~pcie_rstn)						tpgm_link_port_rstn	<=	0	;
	else if(pcie_bar0_tpgm_wrid[0] )	tpgm_link_port_rstn	<=	pcie_bar0_tpgm_wdin[0]	;
/**********************************************************************************************************/
	reg									tpgm_trim_tpgs_issu	;//indx 00
	reg									tpgm_icfg_tpgs_issu	;//indx 01
	reg									tpgm_ocfg_tpgs_issu	;//indx 02
	reg									tpgm_nnex_tpgs_issu	;//indx 03
	reg									tpgm_ivct_tpgs_issu	;//indx 04
	reg									tpgm_ovct_tpgs_issu	;//indx 05
	reg									tpgm_imtx_tpgs_issu	;//indx 06
	reg									tpgm_omtx_tpgs_issu	;//indx 07
	reg									tpgm_rivt_tpgs_issu	;//indx 08
	reg									tpgm_rovt_tpgs_issu	;//indx 09
	reg									tpgm_rimt_tpgs_issu	;//indx 0a
	reg									tpgm_romt_tpgs_issu	;//indx 0b
	reg									tpgm_risv_tpgs_issu	;//indx 0c
	reg									tpgm_rosv_tpgs_issu	;//indx 0d
	reg									tpgm_rism_tpgs_issu	;//indx 0e
	reg									tpgm_rosm_tpgs_issu	;//indx 0f
	reg									tpgm_aset_tpgs_issu	;//indx 10
	reg									tpgm_dnld_tpgs_issu	;//indx 11
	reg									tpgm_boot_tpgs_issu	;//indx 12

	reg		[ 1: 0]						tpgm_trim_reqs_samp	;
	reg		[ 1: 0]						tpgm_icfg_reqs_samp	;
	reg		[ 1: 0]						tpgm_ocfg_reqs_samp	;
	reg		[ 1: 0]						tpgm_nnex_reqs_samp	;
	reg		[ 1: 0]						tpgm_ivct_reqs_samp	;
	reg		[ 1: 0]						tpgm_ovct_reqs_samp	;
	reg		[ 1: 0]						tpgm_imtx_reqs_samp	;
	reg		[ 1: 0]						tpgm_omtx_reqs_samp	;
	reg		[ 1: 0]						tpgm_rivt_reqs_samp	;
	reg		[ 1: 0]						tpgm_rovt_reqs_samp	;
	reg		[ 1: 0]						tpgm_rimt_reqs_samp	;
	reg		[ 1: 0]						tpgm_romt_reqs_samp	;
	reg		[ 1: 0]						tpgm_risv_reqs_samp	;
	reg		[ 1: 0]						tpgm_rosv_reqs_samp	;
	reg		[ 1: 0]						tpgm_rism_reqs_samp	;
	reg		[ 1: 0]						tpgm_rosm_reqs_samp	;
	reg		[ 1: 0]						tpgm_aset_reqs_samp	;
	reg		[ 1: 0]						tpgm_dnld_reqs_samp	;
	reg		[ 1: 0]						tpgm_boot_reqs_samp	;

	reg		[ 2: 0]						tpgm_trim_done_samp	;
	reg		[ 2: 0]						tpgm_icfg_done_samp	;
	reg		[ 2: 0]						tpgm_ocfg_done_samp	;
	reg		[ 2: 0]						tpgm_nnex_done_samp	;
	reg		[ 2: 0]						tpgm_ivct_done_samp	;
	reg		[ 2: 0]						tpgm_ovct_done_samp	;
	reg		[ 2: 0]						tpgm_imtx_done_samp	;
	reg		[ 2: 0]						tpgm_omtx_done_samp	;
	reg		[ 2: 0]						tpgm_rivt_done_samp	;
	reg		[ 2: 0]						tpgm_rovt_done_samp	;
	reg		[ 2: 0]						tpgm_rimt_done_samp	;
	reg		[ 2: 0]						tpgm_romt_done_samp	;
	reg		[ 2: 0]						tpgm_risv_done_samp	;
	reg		[ 2: 0]						tpgm_rosv_done_samp	;
	reg		[ 2: 0]						tpgm_rism_done_samp	;
	reg		[ 2: 0]						tpgm_rosm_done_samp	;
	reg		[ 2: 0]						tpgm_aset_done_samp	;
	reg		[ 2: 0]						tpgm_dnld_done_samp	;
	reg		[ 2: 0]						tpgm_boot_done_samp	;

	reg									tpgm_trim_done_stat	;
	reg									tpgm_icfg_done_stat	;
	reg									tpgm_ocfg_done_stat	;
	reg									tpgm_nnex_done_stat	;
	reg									tpgm_ivct_done_stat	;
	reg									tpgm_ovct_done_stat	;
	reg									tpgm_imtx_done_stat	;
	reg									tpgm_omtx_done_stat	;
	reg									tpgm_rivt_done_stat	;
	reg									tpgm_rovt_done_stat	;
	reg									tpgm_rimt_done_stat	;
	reg									tpgm_romt_done_stat	;
	reg									tpgm_risv_done_stat	;
	reg									tpgm_rosv_done_stat	;
	reg									tpgm_rism_done_stat	;
	reg									tpgm_rosm_done_stat	;
	reg									tpgm_aset_done_stat	;
	reg									tpgm_dnld_done_stat	;
	reg									tpgm_boot_done_stat	;

	wire	[ 7: 0]						pcie_bar0_wlsb_byte	=	pcie_bar0_tpgm_wdin[7:0] ;

	wire	tpgm_link_tpgs_vlid	= 		1'b1	;//	|	tpgm_link_hubs_port	;

	wire	tpgm_link_null_cmnd	=&{		pcie_bar0_tpgm_wrid[1] , tpgm_link_tpgs_vlid , pcie_bar0_wlsb_byte == `CUBE_LINK_NULL_CMND	};
	wire	tpgm_trim_tpgs_cmnd	=&{		pcie_bar0_tpgm_wrid[1] , tpgm_link_tpgs_vlid ,~tpgm_trim_tpgs_issu ,pcie_bar0_wlsb_byte == `CUBE_LINK_TRIM_CMND	};//indx 00
	wire	tpgm_icfg_tpgs_cmnd	=&{		pcie_bar0_tpgm_wrid[1] , tpgm_link_tpgs_vlid ,~tpgm_icfg_tpgs_issu ,pcie_bar0_wlsb_byte == `CUBE_LINK_ICFG_CMND	};//indx 01
	wire	tpgm_ocfg_tpgs_cmnd	=&{		pcie_bar0_tpgm_wrid[1] , tpgm_link_tpgs_vlid ,~tpgm_ocfg_tpgs_issu ,pcie_bar0_wlsb_byte == `CUBE_LINK_OCFG_CMND	};//indx 02
	wire	tpgm_nnex_tpgs_cmnd	=&{		pcie_bar0_tpgm_wrid[1] , tpgm_link_tpgs_vlid ,~tpgm_nnex_tpgs_issu ,pcie_bar0_wlsb_byte == `CUBE_LINK_NNEX_CMND	};//indx 03
	wire	tpgm_ivct_tpgs_cmnd	=&{		pcie_bar0_tpgm_wrid[1] , tpgm_link_tpgs_vlid ,~tpgm_ivct_tpgs_issu ,pcie_bar0_wlsb_byte == `CUBE_LINK_IVCT_CMND	};//indx 04
	wire	tpgm_ovct_tpgs_cmnd	=&{		pcie_bar0_tpgm_wrid[1] , tpgm_link_tpgs_vlid ,~tpgm_ovct_tpgs_issu ,pcie_bar0_wlsb_byte == `CUBE_LINK_OVCT_CMND	};//indx 05
	wire	tpgm_imtx_tpgs_cmnd	=&{		pcie_bar0_tpgm_wrid[1] , tpgm_link_tpgs_vlid ,~tpgm_imtx_tpgs_issu ,pcie_bar0_wlsb_byte == `CUBE_LINK_IMTX_CMND	};//indx 06
	wire	tpgm_omtx_tpgs_cmnd	=&{		pcie_bar0_tpgm_wrid[1] , tpgm_link_tpgs_vlid ,~tpgm_omtx_tpgs_issu ,pcie_bar0_wlsb_byte == `CUBE_LINK_OMTX_CMND	};//indx 07
	wire	tpgm_rivt_tpgs_cmnd	=&{		pcie_bar0_tpgm_wrid[1] , tpgm_link_tpgs_vlid ,~tpgm_rivt_tpgs_issu ,pcie_bar0_wlsb_byte == `CUBE_LINK_RIVT_CMND	};//indx 08
	wire	tpgm_rovt_tpgs_cmnd	=&{		pcie_bar0_tpgm_wrid[1] , tpgm_link_tpgs_vlid ,~tpgm_rovt_tpgs_issu ,pcie_bar0_wlsb_byte == `CUBE_LINK_ROVT_CMND	};//indx 09
	wire	tpgm_rimt_tpgs_cmnd	=&{		pcie_bar0_tpgm_wrid[1] , tpgm_link_tpgs_vlid ,~tpgm_rimt_tpgs_issu ,pcie_bar0_wlsb_byte == `CUBE_LINK_RIMT_CMND	};//indx 0a
	wire	tpgm_romt_tpgs_cmnd	=&{		pcie_bar0_tpgm_wrid[1] , tpgm_link_tpgs_vlid ,~tpgm_romt_tpgs_issu ,pcie_bar0_wlsb_byte == `CUBE_LINK_ROMT_CMND	};//indx 0b
	wire	tpgm_risv_tpgs_cmnd	=&{		pcie_bar0_tpgm_wrid[1] , tpgm_link_tpgs_vlid ,~tpgm_risv_tpgs_issu ,pcie_bar0_wlsb_byte == `CUBE_LINK_RISV_CMND	};//indx 0c
	wire	tpgm_rosv_tpgs_cmnd	=&{		pcie_bar0_tpgm_wrid[1] , tpgm_link_tpgs_vlid ,~tpgm_rosv_tpgs_issu ,pcie_bar0_wlsb_byte == `CUBE_LINK_ROSV_CMND	};//indx 0d
	wire	tpgm_rism_tpgs_cmnd	=&{		pcie_bar0_tpgm_wrid[1] , tpgm_link_tpgs_vlid ,~tpgm_rism_tpgs_issu ,pcie_bar0_wlsb_byte == `CUBE_LINK_RISM_CMND	};//indx 0e
	wire	tpgm_rosm_tpgs_cmnd	=&{		pcie_bar0_tpgm_wrid[1] , tpgm_link_tpgs_vlid ,~tpgm_rosm_tpgs_issu ,pcie_bar0_wlsb_byte == `CUBE_LINK_ROSM_CMND	};//indx 0f
	wire	tpgm_aset_tpgs_cmnd	=&{		pcie_bar0_tpgm_wrid[1] , tpgm_link_tpgs_vlid ,~tpgm_aset_tpgs_issu ,pcie_bar0_wlsb_byte == `CUBE_LINK_ASET_CMND	};//indx 10
	wire	tpgm_dnld_tpgs_cmnd	=&{		pcie_bar0_tpgm_wrid[1] , tpgm_link_tpgs_vlid ,~tpgm_dnld_tpgs_issu ,pcie_bar0_wlsb_byte == `CUBE_LINK_DNLD_CMND	};//indx 11
	wire	tpgm_boot_tpgs_cmnd	=&{		pcie_bar0_tpgm_wrid[1] , tpgm_link_tpgs_vlid ,~tpgm_boot_tpgs_issu ,pcie_bar0_wlsb_byte == `CUBE_LINK_BOOT_CMND	};//indx 12
	
	wire	tpgm_issu_cmnd_reqs	=|{		tpgm_link_null_cmnd , tpgm_trim_tpgs_cmnd ,
										tpgm_icfg_tpgs_cmnd , tpgm_ocfg_tpgs_cmnd , tpgm_nnex_tpgs_cmnd , tpgm_ivct_tpgs_cmnd , 
										tpgm_ovct_tpgs_cmnd , tpgm_imtx_tpgs_cmnd ,	tpgm_omtx_tpgs_cmnd , tpgm_rivt_tpgs_cmnd , 
										tpgm_rovt_tpgs_cmnd , tpgm_rimt_tpgs_cmnd , tpgm_romt_tpgs_cmnd , tpgm_rism_tpgs_cmnd , 
										tpgm_rosm_tpgs_cmnd , tpgm_aset_tpgs_cmnd , tpgm_dnld_tpgs_cmnd , tpgm_boot_tpgs_cmnd};
//------------------------------------------------------------------------------
	reg		pcie_issu_tpgm_cmnd	;

	always@(posedge pcie_bclk or negedge pcie_rstn)
	if(~pcie_rstn)						pcie_issu_tpgm_cmnd	<=	0	;
	else								pcie_issu_tpgm_cmnd	<=	tpgm_issu_cmnd_reqs	;		
//-------------------------------------------------------------------------------------------------------------------------------------
	wire	tpgm_trim_tpgs_done	=		tpgm_trim_done_samp[1:0] == 2'B10	;
	wire	tpgm_icfg_tpgs_done	=		tpgm_icfg_done_samp[1:0] == 2'B10	;
	wire	tpgm_ocfg_tpgs_done	=		tpgm_ocfg_done_samp[1:0] == 2'B10	;
	wire	tpgm_nnex_tpgs_done	=		tpgm_nnex_done_samp[1:0] == 2'B10	;
	wire	tpgm_ivct_tpgs_done	=		tpgm_ivct_done_samp[1:0] == 2'B10	;
	wire	tpgm_ovct_tpgs_done	=		tpgm_ovct_done_samp[1:0] == 2'B10	;
	wire	tpgm_imtx_tpgs_done	=		tpgm_imtx_done_samp[1:0] == 2'B10	;
	wire	tpgm_omtx_tpgs_done	=		tpgm_omtx_done_samp[1:0] == 2'B10	;
	wire	tpgm_rivt_tpgs_done	=		tpgm_rivt_done_samp[1:0] == 2'B10	;
	wire	tpgm_rovt_tpgs_done	=		tpgm_rovt_done_samp[1:0] == 2'B10	;
	wire	tpgm_rimt_tpgs_done	=		tpgm_rimt_done_samp[1:0] == 2'B10	;
	wire	tpgm_romt_tpgs_done	=		tpgm_romt_done_samp[1:0] == 2'B10	;
	wire	tpgm_risv_tpgs_done	=		tpgm_risv_done_samp[1:0] == 2'B10	;
	wire	tpgm_rosv_tpgs_done	=		tpgm_rosv_done_samp[1:0] == 2'B10	;
	wire	tpgm_rism_tpgs_done	=		tpgm_rism_done_samp[1:0] == 2'B10	;
	wire	tpgm_rosm_tpgs_done	=		tpgm_rosm_done_samp[1:0] == 2'B10	;
	wire	tpgm_aset_tpgs_done	=		tpgm_aset_done_samp[1:0] == 2'B10	;
	wire	tpgm_dnld_tpgs_done	=		tpgm_dnld_done_samp[1:0] == 2'B10	;
	wire	tpgm_boot_tpgs_done	=		tpgm_boot_done_samp[1:0] == 2'B10	;

	assign	tpgm_link_trim_reqs	=		tpgm_trim_reqs_samp[0]	;
	assign	tpgm_link_boot_reqs	=		tpgm_boot_reqs_samp[0]	;
	assign	tpgm_link_dnld_reqs	=		tpgm_dnld_reqs_samp[0]	;
	assign	tpgm_link_aset_reqs	=		tpgm_aset_reqs_samp[0]	;
	assign	tpgm_link_rosm_reqs	=		tpgm_rosm_reqs_samp[0]	;
	assign	tpgm_link_rism_reqs	=		tpgm_rism_reqs_samp[0]	;
	assign	tpgm_link_rosv_reqs	=		tpgm_rosv_reqs_samp[0]	;
	assign	tpgm_link_risv_reqs	=		tpgm_risv_reqs_samp[0]	;
	assign	tpgm_link_romt_reqs	=		tpgm_romt_reqs_samp[0]	;
	assign	tpgm_link_rimt_reqs	=		tpgm_rimt_reqs_samp[0]	;
	assign	tpgm_link_rovt_reqs	=		tpgm_rovt_reqs_samp[0]	;
	assign	tpgm_link_rivt_reqs	=		tpgm_rivt_reqs_samp[0]	;
	assign	tpgm_link_omtx_reqs	=		tpgm_omtx_reqs_samp[0]	;
	assign	tpgm_link_imtx_reqs	=		tpgm_imtx_reqs_samp[0]	;
	assign	tpgm_link_ovct_reqs	=		tpgm_ovct_reqs_samp[0]	;
	assign	tpgm_link_ivct_reqs	=		tpgm_ivct_reqs_samp[0]	;
	assign	tpgm_link_nnex_reqs	=		tpgm_nnex_reqs_samp[0]	;
	assign	tpgm_link_ocfg_reqs	=		tpgm_ocfg_reqs_samp[0]	;
	assign	tpgm_link_icfg_reqs	=		tpgm_icfg_reqs_samp[0]	;
		
	wire	[31: 0]						pcie_link_mixs_reqs	;

	assign	pcie_link_mixs_reqs	= {		13'H0				,
										tpgm_link_trim_reqs	,//BIT18	
										tpgm_link_boot_reqs	,//BIT17	
										tpgm_link_dnld_reqs	,//BIT16	
										tpgm_link_aset_reqs	,//BIT15	
										tpgm_link_rosm_reqs	,//BIT14	
										tpgm_link_rism_reqs	,//BIT13	
										tpgm_link_rosv_reqs	,//BIT12	
										tpgm_link_risv_reqs	,//BIT11	
										tpgm_link_romt_reqs	,//BIT10	
										tpgm_link_rimt_reqs	,//BIT09	
										tpgm_link_rovt_reqs	,//BIT08	
										tpgm_link_rivt_reqs	,//BIT07	
										tpgm_link_omtx_reqs	,//BIT06	
										tpgm_link_imtx_reqs	,//BIT05	
										tpgm_link_ovct_reqs	,//BIT04	
										tpgm_link_ivct_reqs	,//BIT03	
										tpgm_link_nnex_reqs	,//BIT02	
										tpgm_link_ocfg_reqs	,//BIT01	
										tpgm_link_icfg_reqs};//BIT00	
/***********************************************************************************************************/
	reg		[ 4: 0]					pcie_issu_cmnd_samp	;
	reg								pcie_issu_cmnd_extn	;
	
	always@(posedge pcie_bclk or negedge pcie_rstn)
	if(~pcie_rstn)					pcie_issu_cmnd_samp	<=	0	;
	else 							pcie_issu_cmnd_samp	<= {pcie_issu_tpgm_cmnd	,	pcie_issu_cmnd_samp[4:1]};

	always@(posedge pcie_bclk or negedge pcie_rstn)
	if(~pcie_rstn)					pcie_issu_cmnd_extn	<=	0	;
	else 							pcie_issu_cmnd_extn	<= |pcie_issu_cmnd_samp	;

	reg		[ 2: 0]					tpgm_issu_cmnd_samp	;

	always@(posedge tpgm_sclk or negedge tpgm_rstn)
	if(~tpgm_rstn)					tpgm_issu_cmnd_samp	<=	0	;
	else							tpgm_issu_cmnd_samp	<={	pcie_issu_cmnd_extn	,	tpgm_issu_cmnd_samp[2:1]};

	assign	tpgm_link_port_init	=	tpgm_issu_cmnd_samp[1:0]==2'B10	;	
/***********************************************************************************************************/
	always@(posedge tpgm_sclk or negedge tpgm_rstn)
	if(~tpgm_rstn)	begin
		tpgm_trim_reqs_samp	<=	0	;
		tpgm_icfg_reqs_samp	<=	0	;
		tpgm_ocfg_reqs_samp	<=	0	;
		tpgm_nnex_reqs_samp	<=	0	;
		tpgm_ivct_reqs_samp	<=	0	;
		tpgm_ovct_reqs_samp	<=	0	;
		tpgm_imtx_reqs_samp	<=	0	;
		tpgm_omtx_reqs_samp	<=	0	;
		tpgm_rivt_reqs_samp	<=	0	;
		tpgm_rovt_reqs_samp	<=	0	;
		tpgm_rimt_reqs_samp	<=	0	;
		tpgm_romt_reqs_samp	<=	0	;
		tpgm_risv_reqs_samp	<=	0	;
		tpgm_rosv_reqs_samp	<=	0	;
		tpgm_rism_reqs_samp	<=	0	;
		tpgm_rosm_reqs_samp	<=	0	;
		tpgm_aset_reqs_samp	<=	0	;
		tpgm_dnld_reqs_samp	<=	0	;
		tpgm_boot_reqs_samp	<=	0	;
	end		else	begin 				
		tpgm_trim_reqs_samp	<={	tpgm_trim_tpgs_issu	,	tpgm_trim_reqs_samp[1]	};
		tpgm_icfg_reqs_samp	<={	tpgm_icfg_tpgs_issu	,	tpgm_icfg_reqs_samp[1]	};
		tpgm_ocfg_reqs_samp	<={	tpgm_ocfg_tpgs_issu	,	tpgm_ocfg_reqs_samp[1]	};
		tpgm_nnex_reqs_samp	<={	tpgm_nnex_tpgs_issu	,	tpgm_nnex_reqs_samp[1]	};
		tpgm_ivct_reqs_samp	<={	tpgm_ivct_tpgs_issu	,	tpgm_ivct_reqs_samp[1]	};
		tpgm_ovct_reqs_samp	<={	tpgm_ovct_tpgs_issu	,	tpgm_ovct_reqs_samp[1]	};
		tpgm_imtx_reqs_samp	<={	tpgm_imtx_tpgs_issu	,	tpgm_imtx_reqs_samp[1]	};
		tpgm_omtx_reqs_samp	<={	tpgm_omtx_tpgs_issu	,	tpgm_omtx_reqs_samp[1]	};
		tpgm_rivt_reqs_samp	<={	tpgm_rivt_tpgs_issu	,	tpgm_rivt_reqs_samp[1]	};
		tpgm_rovt_reqs_samp	<={	tpgm_rovt_tpgs_issu	,	tpgm_rovt_reqs_samp[1]	};
		tpgm_rimt_reqs_samp	<={	tpgm_rimt_tpgs_issu	,	tpgm_rimt_reqs_samp[1]	};
		tpgm_romt_reqs_samp	<={	tpgm_romt_tpgs_issu	,	tpgm_romt_reqs_samp[1]	};
		tpgm_risv_reqs_samp	<={	tpgm_risv_tpgs_issu	,	tpgm_risv_reqs_samp[1]	};
		tpgm_rosv_reqs_samp	<={	tpgm_rosv_tpgs_issu	,	tpgm_rosv_reqs_samp[1]	};
		tpgm_rism_reqs_samp	<={	tpgm_rism_tpgs_issu	,	tpgm_rism_reqs_samp[1]	};
		tpgm_rosm_reqs_samp	<={	tpgm_rosm_tpgs_issu	,	tpgm_rosm_reqs_samp[1]	};
		tpgm_aset_reqs_samp	<={	tpgm_aset_tpgs_issu	,	tpgm_aset_reqs_samp[1]	};
		tpgm_dnld_reqs_samp	<={	tpgm_dnld_tpgs_issu	,	tpgm_dnld_reqs_samp[1]	};
		tpgm_boot_reqs_samp	<={	tpgm_boot_tpgs_issu	,	tpgm_boot_reqs_samp[1]	};
	end
/***********************************************************************************************************/
	always@(posedge pcie_bclk or negedge tpgm_rstn)
	if(~tpgm_rstn)	begin
		tpgm_trim_done_samp	<=	0	;
		tpgm_icfg_done_samp	<=	0	;
		tpgm_ocfg_done_samp	<=	0	;
		tpgm_nnex_done_samp	<=	0	;
		tpgm_ivct_done_samp	<=	0	;
		tpgm_ovct_done_samp	<=	0	;
		tpgm_imtx_done_samp	<=	0	;
		tpgm_omtx_done_samp	<=	0	;
		tpgm_rivt_done_samp	<=	0	;
		tpgm_rovt_done_samp	<=	0	;
		tpgm_rimt_done_samp	<=	0	;
		tpgm_romt_done_samp	<=	0	;
		tpgm_risv_done_samp	<=	0	;
		tpgm_rosv_done_samp	<=	0	;
		tpgm_rism_done_samp	<=	0	;
		tpgm_rosm_done_samp	<=	0	;
		tpgm_aset_done_samp	<=	0	;
		tpgm_dnld_done_samp	<=	0	;
		tpgm_boot_done_samp	<=	0	;
	end		else	begin 				
		tpgm_trim_done_samp	<={	tpgm_link_trim_done	,	tpgm_trim_done_samp[2:1]	};
		tpgm_icfg_done_samp	<={	tpgm_link_icfg_done	,	tpgm_icfg_done_samp[2:1]	};
		tpgm_ocfg_done_samp	<={	tpgm_link_ocfg_done	,	tpgm_ocfg_done_samp[2:1]	};
		tpgm_nnex_done_samp	<={	tpgm_link_nnex_done	,	tpgm_nnex_done_samp[2:1]	};
		tpgm_ivct_done_samp	<={	tpgm_link_ivct_done	,	tpgm_ivct_done_samp[2:1]	};
		tpgm_ovct_done_samp	<={	tpgm_link_ovct_done	,	tpgm_ovct_done_samp[2:1]	};
		tpgm_imtx_done_samp	<={	tpgm_link_imtx_done	,	tpgm_imtx_done_samp[2:1]	};
		tpgm_omtx_done_samp	<={	tpgm_link_omtx_done	,	tpgm_omtx_done_samp[2:1]	};
		tpgm_rivt_done_samp	<={	tpgm_link_rivt_done	,	tpgm_rivt_done_samp[2:1]	};
		tpgm_rovt_done_samp	<={	tpgm_link_rovt_done	,	tpgm_rovt_done_samp[2:1]	};
		tpgm_rimt_done_samp	<={	tpgm_link_rimt_done	,	tpgm_rimt_done_samp[2:1]	};
		tpgm_romt_done_samp	<={	tpgm_link_romt_done	,	tpgm_romt_done_samp[2:1]	};
		tpgm_risv_done_samp	<={	tpgm_link_risv_done	,	tpgm_risv_done_samp[2:1]	};
		tpgm_rosv_done_samp	<={	tpgm_link_rosv_done	,	tpgm_rosv_done_samp[2:1]	};
		tpgm_rism_done_samp	<={	tpgm_link_rism_done	,	tpgm_rism_done_samp[2:1]	};
		tpgm_rosm_done_samp	<={	tpgm_link_rosm_done	,	tpgm_rosm_done_samp[2:1]	};
		tpgm_aset_done_samp	<={	tpgm_link_aset_done	,	tpgm_aset_done_samp[2:1]	};
		tpgm_dnld_done_samp	<={	tpgm_link_dnld_done	,	tpgm_dnld_done_samp[2:1]	};
		tpgm_boot_done_samp	<={	tpgm_link_boot_done	,	tpgm_boot_done_samp[2:1]	};
	end
/***********************************************************************************************************/
	always@(posedge pcie_bclk or negedge tpgm_rstn)
	if(~tpgm_rstn)					tpgm_trim_tpgs_issu	<=	0		;
	else if(tpgm_trim_tpgs_cmnd)	tpgm_trim_tpgs_issu	<=	tpgm_link_idle_stat		;
	else if(tpgm_trim_tpgs_done)	tpgm_trim_tpgs_issu	<=	0		;
	
	always@(posedge pcie_bclk or negedge tpgm_rstn)
	if(~tpgm_rstn)					tpgm_icfg_tpgs_issu	<=	0		;
	else if(tpgm_icfg_tpgs_cmnd)	tpgm_icfg_tpgs_issu	<=	tpgm_link_idle_stat		;
	else if(tpgm_icfg_tpgs_done)	tpgm_icfg_tpgs_issu	<=	0		;
	
	always@(posedge pcie_bclk or negedge tpgm_rstn)
	if(~tpgm_rstn)					tpgm_ocfg_tpgs_issu	<=	0		;
	else if(tpgm_ocfg_tpgs_cmnd)	tpgm_ocfg_tpgs_issu	<=	tpgm_link_idle_stat		;
	else if(tpgm_ocfg_tpgs_done)	tpgm_ocfg_tpgs_issu	<=	0		;
	
	always@(posedge pcie_bclk or negedge tpgm_rstn)
	if(~tpgm_rstn)					tpgm_nnex_tpgs_issu	<=	0		;
	else if(tpgm_nnex_tpgs_cmnd)	tpgm_nnex_tpgs_issu	<=	tpgm_link_idle_stat		;
	else if(tpgm_nnex_tpgs_done)	tpgm_nnex_tpgs_issu	<=	0		;
	
	always@(posedge pcie_bclk or negedge tpgm_rstn)
	if(~tpgm_rstn)					tpgm_ivct_tpgs_issu	<=	0		;
	else if(tpgm_ivct_tpgs_cmnd)	tpgm_ivct_tpgs_issu	<=	tpgm_link_idle_stat		;
	else if(tpgm_ivct_tpgs_done)	tpgm_ivct_tpgs_issu	<=	0		;
	
	always@(posedge pcie_bclk or negedge tpgm_rstn)
	if(~tpgm_rstn)					tpgm_ovct_tpgs_issu	<=	0		;
	else if(tpgm_ovct_tpgs_cmnd)	tpgm_ovct_tpgs_issu	<=	tpgm_link_idle_stat		;
	else if(tpgm_ovct_tpgs_done)	tpgm_ovct_tpgs_issu	<=	0		;
	
	always@(posedge pcie_bclk or negedge tpgm_rstn)
	if(~tpgm_rstn)					tpgm_imtx_tpgs_issu	<=	0		;
	else if(tpgm_imtx_tpgs_cmnd)	tpgm_imtx_tpgs_issu	<=	tpgm_link_idle_stat		;
	else if(tpgm_imtx_tpgs_done)	tpgm_imtx_tpgs_issu	<=	0		;
	
	always@(posedge pcie_bclk or negedge tpgm_rstn)
	if(~tpgm_rstn)					tpgm_omtx_tpgs_issu	<=	0		;
	else if(tpgm_omtx_tpgs_cmnd)	tpgm_omtx_tpgs_issu	<=	tpgm_link_idle_stat		;
	else if(tpgm_omtx_tpgs_done)	tpgm_omtx_tpgs_issu	<=	0		;
	
	always@(posedge pcie_bclk or negedge tpgm_rstn)
	if(~tpgm_rstn)					tpgm_rivt_tpgs_issu	<=	0		;
	else if(tpgm_rivt_tpgs_cmnd)	tpgm_rivt_tpgs_issu	<=	tpgm_link_idle_stat		;
	else if(tpgm_rivt_tpgs_done)	tpgm_rivt_tpgs_issu	<=	0		;
	
	always@(posedge pcie_bclk or negedge tpgm_rstn)
	if(~tpgm_rstn)					tpgm_rovt_tpgs_issu	<=	0		;
	else if(tpgm_rovt_tpgs_cmnd)	tpgm_rovt_tpgs_issu	<=	tpgm_link_idle_stat		;
	else if(tpgm_rovt_tpgs_done)	tpgm_rovt_tpgs_issu	<=	0		;
	
	always@(posedge pcie_bclk or negedge tpgm_rstn)
	if(~tpgm_rstn)					tpgm_rimt_tpgs_issu	<=	0		;
	else if(tpgm_rimt_tpgs_cmnd)	tpgm_rimt_tpgs_issu	<=	tpgm_link_idle_stat		;
	else if(tpgm_rimt_tpgs_done)	tpgm_rimt_tpgs_issu	<=	0		;
	
	always@(posedge pcie_bclk or negedge tpgm_rstn)
	if(~tpgm_rstn)					tpgm_romt_tpgs_issu	<=	0		;
	else if(tpgm_romt_tpgs_cmnd)	tpgm_romt_tpgs_issu	<=	tpgm_link_idle_stat		;
	else if(tpgm_romt_tpgs_done)	tpgm_romt_tpgs_issu	<=	0		;
		
	always@(posedge pcie_bclk or negedge tpgm_rstn)
	if(~tpgm_rstn)					tpgm_risv_tpgs_issu	<=	0		;
	else if(tpgm_risv_tpgs_cmnd)	tpgm_risv_tpgs_issu	<=	tpgm_link_idle_stat		;
	else if(tpgm_risv_tpgs_done)	tpgm_risv_tpgs_issu	<=	0		;
	
	always@(posedge pcie_bclk or negedge tpgm_rstn)
	if(~tpgm_rstn)					tpgm_rosv_tpgs_issu	<=	0		;
	else if(tpgm_rosv_tpgs_cmnd)	tpgm_rosv_tpgs_issu	<=	tpgm_link_idle_stat		;
	else if(tpgm_rosv_tpgs_done)	tpgm_rosv_tpgs_issu	<=	0		;
	
	always@(posedge pcie_bclk or negedge tpgm_rstn)
	if(~tpgm_rstn)					tpgm_rism_tpgs_issu	<=	0		;
	else if(tpgm_rism_tpgs_cmnd)	tpgm_rism_tpgs_issu	<=	tpgm_link_idle_stat		;
	else if(tpgm_rism_tpgs_done)	tpgm_rism_tpgs_issu	<=	0		;
	
	always@(posedge pcie_bclk or negedge tpgm_rstn)
	if(~tpgm_rstn)					tpgm_rosm_tpgs_issu	<=	0		;
	else if(tpgm_rosm_tpgs_cmnd)	tpgm_rosm_tpgs_issu	<=	tpgm_link_idle_stat		;
	else if(tpgm_rosm_tpgs_done)	tpgm_rosm_tpgs_issu	<=	0		;
	
	always@(posedge pcie_bclk or negedge tpgm_rstn)
	if(~tpgm_rstn)					tpgm_aset_tpgs_issu	<=	0		;
	else if(tpgm_aset_tpgs_cmnd)	tpgm_aset_tpgs_issu	<=	tpgm_link_idle_stat		;
	else if(tpgm_aset_tpgs_done)	tpgm_aset_tpgs_issu	<=	0		;
	
	always@(posedge pcie_bclk or negedge tpgm_rstn)
	if(~tpgm_rstn)					tpgm_dnld_tpgs_issu	<=	0		;
	else if(tpgm_dnld_tpgs_cmnd)	tpgm_dnld_tpgs_issu	<=	tpgm_link_idle_stat		;
	else if(tpgm_dnld_tpgs_done)	tpgm_dnld_tpgs_issu	<=	0		;
	
	always@(posedge pcie_bclk or negedge tpgm_rstn)
	if(~tpgm_rstn)					tpgm_boot_tpgs_issu	<=	0		;
	else if(tpgm_boot_tpgs_cmnd)	tpgm_boot_tpgs_issu	<=	tpgm_link_idle_stat		;
	else if(tpgm_boot_tpgs_done)	tpgm_boot_tpgs_issu	<=	0		;
/***********************************************************************************************************/
	always@(posedge pcie_bclk or negedge tpgm_rstn)
	if(~tpgm_rstn)					tpgm_trim_done_stat	<=	0		;
	else if(pcie_issu_tpgm_cmnd)	tpgm_trim_done_stat	<=	0		;
	else if(tpgm_trim_tpgs_done)	tpgm_trim_done_stat	<=	1		;

	always@(posedge pcie_bclk or negedge tpgm_rstn)
	if(~tpgm_rstn)					tpgm_icfg_done_stat	<=	0		;
	else if(pcie_issu_tpgm_cmnd)	tpgm_icfg_done_stat	<=	0		;
	else if(tpgm_icfg_tpgs_done)	tpgm_icfg_done_stat	<=	1		;

	always@(posedge pcie_bclk or negedge tpgm_rstn)
	if(~tpgm_rstn)					tpgm_ocfg_done_stat	<=	0		;
	else if(pcie_issu_tpgm_cmnd)	tpgm_ocfg_done_stat	<=	0		;
	else if(tpgm_ocfg_tpgs_done)	tpgm_ocfg_done_stat	<=	1		;

	always@(posedge pcie_bclk or negedge tpgm_rstn)
	if(~tpgm_rstn)					tpgm_nnex_done_stat	<=	0		;
	else if(pcie_issu_tpgm_cmnd)	tpgm_nnex_done_stat	<=	0		;
	else if(tpgm_nnex_tpgs_done)	tpgm_nnex_done_stat	<=	1		;

	always@(posedge pcie_bclk or negedge tpgm_rstn)
	if(~tpgm_rstn)					tpgm_ivct_done_stat	<=	0		;
	else if(pcie_issu_tpgm_cmnd)	tpgm_ivct_done_stat	<=	0		;
	else if(tpgm_ivct_tpgs_done)	tpgm_ivct_done_stat	<=	1		;

	always@(posedge pcie_bclk or negedge tpgm_rstn)
	if(~tpgm_rstn)					tpgm_ovct_done_stat	<=	0		;
	else if(pcie_issu_tpgm_cmnd)	tpgm_ovct_done_stat	<=	0		;
	else if(tpgm_ovct_tpgs_done)	tpgm_ovct_done_stat	<=	1		;

	always@(posedge pcie_bclk or negedge tpgm_rstn)
	if(~tpgm_rstn)					tpgm_imtx_done_stat	<=	0		;
	else if(pcie_issu_tpgm_cmnd)	tpgm_imtx_done_stat	<=	0		;
	else if(tpgm_imtx_tpgs_done)	tpgm_imtx_done_stat	<=	1		;

	always@(posedge pcie_bclk or negedge tpgm_rstn)
	if(~tpgm_rstn)					tpgm_omtx_done_stat	<=	0		;
	else if(pcie_issu_tpgm_cmnd)	tpgm_omtx_done_stat	<=	0		;
	else if(tpgm_omtx_tpgs_done)	tpgm_omtx_done_stat	<=	1		;

	always@(posedge pcie_bclk or negedge tpgm_rstn)
	if(~tpgm_rstn)					tpgm_rivt_done_stat	<=	0		;
	else if(pcie_issu_tpgm_cmnd)	tpgm_rivt_done_stat	<=	0		;
	else if(tpgm_rivt_tpgs_done)	tpgm_rivt_done_stat	<=	1		;

	always@(posedge pcie_bclk or negedge tpgm_rstn)
	if(~tpgm_rstn)					tpgm_rovt_done_stat	<=	0		;
	else if(pcie_issu_tpgm_cmnd)	tpgm_rovt_done_stat	<=	0		;
	else if(tpgm_rovt_tpgs_done)	tpgm_rovt_done_stat	<=	1		;

	always@(posedge pcie_bclk or negedge tpgm_rstn)
	if(~tpgm_rstn)					tpgm_rimt_done_stat	<=	0		;
	else if(pcie_issu_tpgm_cmnd)	tpgm_rimt_done_stat	<=	0		;
	else if(tpgm_rimt_tpgs_done)	tpgm_rimt_done_stat	<=	1		;

	always@(posedge pcie_bclk or negedge tpgm_rstn)
	if(~tpgm_rstn)					tpgm_romt_done_stat	<=	0		;
	else if(pcie_issu_tpgm_cmnd)	tpgm_romt_done_stat	<=	0		;
	else if(tpgm_romt_tpgs_done)	tpgm_romt_done_stat	<=	1		;

	always@(posedge pcie_bclk or negedge tpgm_rstn)
	if(~tpgm_rstn)					tpgm_risv_done_stat	<=	0		;
	else if(pcie_issu_tpgm_cmnd)	tpgm_risv_done_stat	<=	0		;
	else if(tpgm_risv_tpgs_done)	tpgm_risv_done_stat	<=	1		;

	always@(posedge pcie_bclk or negedge tpgm_rstn)
	if(~tpgm_rstn)					tpgm_rosv_done_stat	<=	0		;
	else if(pcie_issu_tpgm_cmnd)	tpgm_rosv_done_stat	<=	0		;
	else if(tpgm_rosv_tpgs_done)	tpgm_rosv_done_stat	<=	1		;

	always@(posedge pcie_bclk or negedge tpgm_rstn)
	if(~tpgm_rstn)					tpgm_rism_done_stat	<=	0		;
	else if(pcie_issu_tpgm_cmnd)	tpgm_rism_done_stat	<=	0		;
	else if(tpgm_rism_tpgs_done)	tpgm_rism_done_stat	<=	1		;

	always@(posedge pcie_bclk or negedge tpgm_rstn)
	if(~tpgm_rstn)					tpgm_rosm_done_stat	<=	0		;
	else if(pcie_issu_tpgm_cmnd)	tpgm_rosm_done_stat	<=	0		;
	else if(tpgm_rosm_tpgs_done)	tpgm_rosm_done_stat	<=	1		;

	always@(posedge pcie_bclk or negedge tpgm_rstn)
	if(~tpgm_rstn)					tpgm_aset_done_stat	<=	0		;
	else if(pcie_issu_tpgm_cmnd)	tpgm_aset_done_stat	<=	0		;
	else if(tpgm_aset_tpgs_done)	tpgm_aset_done_stat	<=	1		;

	always@(posedge pcie_bclk or negedge tpgm_rstn)
	if(~tpgm_rstn)					tpgm_dnld_done_stat	<=	0		;
	else if(pcie_issu_tpgm_cmnd)	tpgm_dnld_done_stat	<=	0		;
	else if(tpgm_dnld_tpgs_done)	tpgm_dnld_done_stat	<=	1		;

	always@(posedge pcie_bclk or negedge tpgm_rstn)
	if(~tpgm_rstn)					tpgm_boot_done_stat	<=	0		;
	else if(pcie_issu_tpgm_cmnd)	tpgm_boot_done_stat	<=	0		;
	else if(tpgm_boot_tpgs_done)	tpgm_boot_done_stat	<=	1		;
/***********************************************************************************************************/
	wire	[31:0]						tpgm_link_misc_stat	;

	assign	tpgm_link_misc_stat	= {		14'H0				,	
										tpgm_trim_done_stat	,//BIT 18
										tpgm_boot_done_stat	,//BIT 17
										tpgm_dnld_done_stat	,//BIT 16
										tpgm_aset_done_stat	,//BIT 15
										tpgm_rosm_done_stat	,//BIT 14
										tpgm_rism_done_stat	,//BIT 13
										tpgm_rosv_done_stat	,//BIT 12
										tpgm_risv_done_stat	,//BIT 11
										tpgm_romt_done_stat	,//BIT 10
										tpgm_rimt_done_stat	,//BIT 9
										tpgm_rovt_done_stat	,//BIT 8
										tpgm_rivt_done_stat	,//BIT 7
										tpgm_omtx_done_stat	,//BIT 6
										tpgm_imtx_done_stat	,//BIT 5
										tpgm_ovct_done_stat	,//BIT 4
										tpgm_ivct_done_stat	,//BIT 3
										tpgm_nnex_done_stat	,//BIT 2
										tpgm_ocfg_done_stat	,//BIT 1
										tpgm_icfg_done_stat};//BIT 0
//PCIE_XDMA_CMND_REQS***************************************************************************************
	reg								pcie_wdma_done_stat	;
	reg								pcie_rdma_done_stat	;

	wire	pcie_rdma_cmnd_issu	= &{pcie_bar0_tpgm_wrid[2]	, pcie_bar0_tpgm_wdin[7:0] == `PCIE_RDMA_CMND_CODE	};	
	wire	pcie_wdma_cmnd_issu	= &{pcie_bar0_tpgm_wrid[2]	, pcie_bar0_tpgm_wdin[7:0] == `PCIE_WDMA_CMND_CODE	};	
	wire	pcie_xdma_stat_clrs	= &{pcie_bar0_tpgm_wrid[2]	, pcie_bar0_tpgm_wdin[7:0] == 8'H00					};	

	wire	pcie_xdma_cmnd_init	= &{pcie_rdma_cmnd_issu		, pcie_rdma_cmnd_issu	};	
	
	always@(posedge pcie_bclk or negedge pcie_rstn)
	if(!pcie_rstn)					pcie_rdma_ddrs_enab	<=	0	;
	else if(pcie_rdma_cmnd_issu)	pcie_rdma_ddrs_enab	<=	1	;
	else if(pcie_rdma_ddrs_done)	pcie_rdma_ddrs_enab	<=	0	;
		
	always@(posedge pcie_bclk or negedge pcie_rstn)
	if(!pcie_rstn)					pcie_wdma_ddrs_enab	<=	0	;
	else if(pcie_wdma_cmnd_issu)	pcie_wdma_ddrs_enab	<=	1	;
	else if(pcie_wdma_ddrs_done)	pcie_wdma_ddrs_enab	<=	0	;
	
	always@(posedge pcie_bclk or negedge pcie_rstn)
	if(!pcie_rstn)					pcie_rdma_done_stat	<=	0	;
	else if(pcie_xdma_cmnd_init)	pcie_rdma_done_stat	<=	0	;
	else if(pcie_xdma_stat_clrs)	pcie_rdma_done_stat	<=	0	;
	else if(pcie_rdma_ddrs_done)	pcie_rdma_done_stat	<=	1	;

	always@(posedge pcie_bclk or negedge pcie_rstn)
	if(!pcie_rstn)					pcie_wdma_done_stat	<=	0	;
	else if(pcie_xdma_cmnd_init)	pcie_wdma_done_stat	<=	0	;
	else if(pcie_xdma_stat_clrs)	pcie_wdma_done_stat	<=	0	;
	else if(pcie_wdma_ddrs_done)	pcie_wdma_done_stat	<=	1	;

	wire	[31:0]					pcie_xdma_stat_word	;

	assign	pcie_xdma_stat_word	={	28'H0				,
									pcie_wdma_ddrs_enab	,
									pcie_wdma_done_stat	,
									pcie_rdma_ddrs_enab	,	
									pcie_rdma_done_stat	};
//XDMA_CTRL_PARA*******************************************************************************************	
	always@(posedge pcie_bclk or negedge pcie_rstn)
	if(!pcie_rstn)					pcie_xdma_ddrs_base	<=	0	;
	else if(pcie_bar0_tpgm_wrid[3])	pcie_xdma_ddrs_base	<=	pcie_bar0_tpgm_wdin[24: 0];
	else							pcie_xdma_ddrs_base	<=	pcie_xdma_ddrs_base	;	

	always@(posedge pcie_bclk or negedge pcie_rstn)
	if(!pcie_rstn)					pcie_xdma_cols_numb	<=	0	;
	else if(pcie_bar0_tpgm_wrid[5])	pcie_xdma_cols_numb	<=	pcie_bar0_tpgm_wdin[31: 0];
	else							pcie_xdma_cols_numb	<=	pcie_xdma_cols_numb	;	
	
	wire	[31:0]					pcie_xdma_addr_word	;
	wire	[31:0]					pcie_xdma_rows_word	;
	wire	[31:0]					pcie_xdma_cols_word	;
	
	assign	pcie_xdma_addr_word	={	7'H0, pcie_xdma_ddrs_base	};
	assign	pcie_xdma_rows_word	={ 32'H0						};	//, pcie_xdma_rows_numb	};
	assign	pcie_xdma_cols_word	={		  pcie_xdma_cols_numb	};
	assign	pcie_xdma_rows_numb	=	1	;//Modified at 20250217
/**********************************************************************************************************/
	reg		[ 1: 0]						pcie_tune_mode_ctrl	;

	wire	[31: 0]						pcie_tune_mode_word	;
	assign	pcie_tune_mode_word	={		30'H0	,	pcie_tune_mode_ctrl	};

	always@(posedge pcie_bclk or negedge pcie_rstn)
	if(!pcie_rstn)						pcie_tune_mode_ctrl	<=	0	;
	else if(pcie_bar0_tpgm_wrid[6])		pcie_tune_mode_ctrl	<=	pcie_bar0_tpgm_wdin[1:0];
//------------------------------------------------------------------------------
	reg		[ 1: 3]						pcie_tune_tpgm_rxdi	;
	reg		[ 1: 3]						pcie_tune_tpgm_txdo	;

	wire	[ 1: 3]						pcie_tune_rxdi_enab	;
	wire	[ 1: 3]						pcie_tune_txdo_enab	;
	
	wire	pcie_tune_rxdi_actv	=		pcie_tune_mode_ctrl == 2'H1	;
	wire	pcie_tune_txdo_actv	=		pcie_tune_mode_ctrl == 2'H2	;

	assign	pcie_tune_rxdi_enab	=	{	pcie_tune_rxdi_actv	&	tpgm_link_port_enab[1]	,
										pcie_tune_rxdi_actv	&	tpgm_link_port_enab[2]	,
										pcie_tune_rxdi_actv	&	tpgm_link_port_enab[3]	};

	assign	pcie_tune_txdo_enab	=	{	pcie_tune_txdo_actv	&	tpgm_link_port_enab[1]	,
										pcie_tune_txdo_actv	&	tpgm_link_port_enab[2]	,
										pcie_tune_txdo_actv	&	tpgm_link_port_enab[3]	};

	always@(posedge pcie_bclk or negedge pcie_rstn)
	if(!pcie_rstn)						pcie_tune_tpgm_rxdi	<=	0	;
	else 								pcie_tune_tpgm_rxdi	<=	pcie_tune_rxdi_enab;

	always@(posedge pcie_bclk or negedge pcie_rstn)
	if(!pcie_rstn)						pcie_tune_tpgm_txdo	<=	0	;
	else 								pcie_tune_tpgm_txdo	<=	pcie_tune_txdo_enab;
//------------------------------------------------------------------------------
	reg		[ 1: 3]						tpgm_sync_tune_rxdi	;
	reg		[ 1: 3]						tpgm_sync_tune_txdo	;

	always@(posedge tpgm_sclk or negedge tpgm_rstn)
	if(!tpgm_rstn)						begin
		tpgm_sync_tune_rxdi		<=		0	;
		tpgm_sync_tune_txdo		<=		0	;
		tpgm_link_tune_rxdi		<=		0	;
		tpgm_link_tune_txdo		<=		0	;
	end else 	begin
		tpgm_sync_tune_rxdi		<=		pcie_tune_tpgm_rxdi	;
		tpgm_sync_tune_txdo		<=		pcie_tune_tpgm_txdo	;
		tpgm_link_tune_rxdi		<=		tpgm_sync_tune_rxdi	;
		tpgm_link_tune_txdo		<=		tpgm_sync_tune_txdo	;
	end	
/**********************************************************************************************************/
	reg		[ 4: 0]					tpgm_acks_clrs_samp	;

	wire							tpgm_acks_clrs_extn	;
	assign	tpgm_acks_clrs_extn	=	tpgm_acks_clrs_samp[0]	;

	always@(posedge pcie_bclk or negedge pcie_rstn)
	if(~pcie_rstn)					tpgm_acks_clrs_samp	<=	0		;
	else if(pcie_bar0_tpgm_wrid[8])	tpgm_acks_clrs_samp	<= 5'H1F	;
	else 							tpgm_acks_clrs_samp	<={1'b0	,	tpgm_acks_clrs_samp[4:1]};


	reg		[ 2: 0]					tpgm_acks_clrs_reqs	;

	always@(posedge tpgm_sclk or negedge tpgm_rstn)
	if(~tpgm_rstn)					tpgm_acks_clrs_reqs	<=	0	;
	else							tpgm_acks_clrs_reqs	<={	tpgm_acks_clrs_extn	,	tpgm_acks_clrs_reqs[2:1]};

	assign	tpgm_link_acks_init	=	tpgm_acks_clrs_reqs[1:0]==2'B10	;	


	wire	[31: 0]					tpgm_tune_acks_word	;
	assign	tpgm_tune_acks_word	={	12'H0	,	tpgm_link_port_resp	,
									12'H0	,	tpgm_link_port_acks };
/**********************************************************************************************************/
//WORD_ADDRESS:: 0X09----TPGM_TIME_CTRL
	reg			[ 7: 0]				time_base_usec_cnts	;
	reg			[31: 0]				time_ecos_usec_cnts	;

	wire							time_base_usec_flag	;
	wire							time_ecos_usec_flag	;
	
	wire		[31: 0]				time_ecos_cnts_sub1	=	time_ecos_usec_cnts - 1	;
	wire		[31: 0]				time_ecos_cnts_next	=	time_base_usec_flag	?	time_ecos_cnts_sub1	:	time_ecos_usec_cnts	;	
	
	assign	time_base_usec_flag	=	time_base_usec_cnts	==	`USEC_TIME_CLKS_NUMB	;
	assign	time_ecos_usec_flag	=	time_ecos_usec_cnts	== 	32'H00	;
	
	always@(posedge pcie_bclk or negedge pcie_rstn)
	if(~pcie_rstn)					time_base_usec_cnts		<=	0	;
	else if(pcie_bar0_tpgm_wrid[9])	time_base_usec_cnts		<=	0	;
	else if(time_base_usec_flag)	time_base_usec_cnts		<=	0	;
	else 							time_base_usec_cnts		<=	time_base_usec_cnts + 1	;	

	always@(posedge pcie_bclk or negedge pcie_rstn)
	if(~pcie_rstn)					time_ecos_usec_cnts		<=	0	;
	else if(pcie_bar0_tpgm_wrid[9])	time_ecos_usec_cnts		<=	pcie_bar0_tpgm_wdin	;
	else if(~time_ecos_usec_flag)	time_ecos_usec_cnts		<=	time_ecos_cnts_next	;	
/**********************************************************************************************************/
	reg		[31: 0]						tpgm_supv_mode_code	;
	wire								tpgm_link_supv_sets	;
//	wire								tpgm_link_supv_mode	;
	
	assign	tpgm_link_supv_sets	=		tpgm_supv_mode_code	==	32'H53555056	;

	always@(posedge pcie_bclk or negedge pcie_rstn)
	if(!pcie_rstn)						tpgm_supv_mode_code	<=	0	;
	else if(pcie_bar0_tpgm_wrid[10])	tpgm_supv_mode_code	<=	pcie_bar0_tpgm_wdin[31: 0];


	gens_sign_fast_slow #(	.EXTN(2)	)
									u_gens_sign_fast_slow(	
		.fast_sign 						(tpgm_link_supv_sets	),//input	
		.fast_clki						(pcie_bclk				),//input	
		.fast_rstn						(pcie_rstn				),//input	
		.slow_sign						(tpgm_link_supv_mode	),//output	
		.slow_clki						(tpgm_sclk				),//input	
		.slow_rstn						(tpgm_rstn				));//input	

/**********************************************************************************************************/
	reg		[11:15][31: 0]				pcie_ecos_llmb_vars		;

	for(genvar i =11 ; i < 16 ; i++) begin	:	pcie_link_ecos_rwcs
		always@(posedge pcie_bclk or negedge pcie_rstn)
		if(!pcie_rstn)					pcie_ecos_llmb_vars[i]	<=	0	;
		else if(pcie_bar0_tpgm_wrid[i])	pcie_ecos_llmb_vars[i]	<=	pcie_bar0_tpgm_wdin[31: 0];
	end 
/**********************************************************************************************************/
	assign	pcie_bar0_tpgm_rdat	=	pcie_bar0_tpgm_csid[00]	?	tpgm_link_intf_stat		:
									pcie_bar0_tpgm_csid[01]	?	tpgm_link_misc_stat		:
									pcie_bar0_tpgm_csid[02]	?	pcie_xdma_stat_word		:	
									pcie_bar0_tpgm_csid[03]	?	pcie_xdma_addr_word		:
									pcie_bar0_tpgm_csid[04]	?	pcie_xdma_rows_word		:
									pcie_bar0_tpgm_csid[05]	?	pcie_xdma_cols_word		:
									
									pcie_bar0_tpgm_csid[06]	?	pcie_tune_mode_word		:	
									pcie_bar0_tpgm_csid[07]	?	pcie_link_mixs_reqs		:	
									pcie_bar0_tpgm_csid[08]	?	tpgm_tune_acks_word		:	
									pcie_bar0_tpgm_csid[09]	?	time_ecos_usec_cnts		://pcie_ecos_llmb_vars[09]	:	

									pcie_bar0_tpgm_csid[10]	?	tpgm_supv_mode_code		:	
									pcie_bar0_tpgm_csid[11]	?	pcie_ecos_llmb_vars[11]	:	
									pcie_bar0_tpgm_csid[12]	?	pcie_ecos_llmb_vars[12]	:	
									pcie_bar0_tpgm_csid[13]	?	pcie_ecos_llmb_vars[13]	:	
									pcie_bar0_tpgm_csid[14]	?	pcie_ecos_llmb_vars[14]	:	
									pcie_bar0_tpgm_csid[15]	?	pcie_ecos_llmb_vars[15]	:	32'H0	;
/**********************************************************************************************************/
//--ILA USAGE
//	wire	[31:0]					ila_probe_signal	;
//	assign	ila_probe_signal	= {	14'H0				,
//									pcie_issu_tpgm_cmnd	,
//									tpgm_link_port_idle	,
//									tpgm_link_idle_stat	,
//									
//									tpgm_trim_tpgs_issu	,
//									tpgm_link_trim_reqs	,
//									tpgm_link_trim_done	,
//									tpgm_trim_done_stat	,
//									tpgm_trim_tpgs_done	,
//
//									tpgm_icfg_tpgs_issu	,
//									tpgm_link_icfg_reqs	,
//									tpgm_link_icfg_done	,
//									tpgm_icfg_done_stat	,
//									tpgm_icfg_tpgs_done	,
//
//									tpgm_ocfg_tpgs_issu	,
//									tpgm_link_ocfg_reqs	,
//									tpgm_link_ocfg_done	,
//									tpgm_ocfg_done_stat	,
//									tpgm_ocfg_tpgs_done	};	




endmodule
 //	reg		[ 2: 0]					tpgm_acks_pcie_samp	;
//	reg		[ 3: 0]					tpgm_tune_acks_stat	;
//
//	wire							tpgm_acks_samp_rise	; 
//	wire	[31: 0]					tpgm_tune_acks_word	;
//
//	assign	tpgm_tune_acks_word	={	31'H0	,	tpgm_tune_acks_stat };
//	assign	tpgm_acks_samp_rise	=	tpgm_acks_pcie_samp[1:0] == 2'B10	; 
//	
//	always@(posedge tpgm_sclk or negedge tpgm_rstn)
//	if(!tpgm_rstn)					tpgm_port_acks_sync	<=	1'B0	;
//	else							tpgm_port_acks_sync	<=	tpgm_link_port_acks	;
//
//	always@(posedge pcie_bclk or negedge pcie_rstn)
//	if(!pcie_rstn)					tpgm_acks_pcie_samp	<=	3'B000	;
//	else							tpgm_acks_pcie_samp	<={	tpgm_port_acks_sync	,	tpgm_acks_pcie_samp[2:1]};
//
//	always@(posedge pcie_bclk or negedge pcie_rstn)
//	if(!pcie_rstn)					tpgm_tune_acks_stat	<=	1'B0	;
//	else if(pcie_issu_tpgm_cmnd)	tpgm_tune_acks_stat	<=	1'B0	;
//	else if(tpgm_acks_samp_rise)	tpgm_tune_acks_stat	<=	1'B1	;
 