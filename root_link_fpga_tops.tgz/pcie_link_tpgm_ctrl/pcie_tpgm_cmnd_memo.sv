//**********************************************************************************************************
//20240822-add ::	output		[24: 0]				tpgm_xdma_ddrs_base	,
	
//**********************************************************************************************************
module	pcie_tpgm_cmnd_memo(
	input							pcie_tpgm_cmnd_csen	,
	input		[  3: 0]			pcie_tpgm_cmnd_addr	,
	input							pcie_tpgm_cmnd_wrcs	,
	input		[ 31: 0]			pcie_tpgm_cmnd_wdin,
	output		[ 31: 0]			pcie_tpgm_cmnd_rout,

	output	reg	[ 3: 0]				tpgm_link_port_enab	,
//	output		[ 3: 0]				pcie_link_port_enab	,

	input		[ 3: 0]				tpgm_link_cmnd_indx	,
	output		[31: 0]				tpgm_link_cmnd_data	,
	input		[ 3: 0]				tpgm_link_acmd_indx	,
	output		[31: 0]				tpgm_link_acmd_data	,

	output		[24: 0]				tpgm_xdma_ddrs_base	,
	output		[19: 0]				tpgm_xdma_meta_rows	,
	output		[19: 0]				tpgm_xdma_meta_cols	,
	output		[19: 0]				tpgm_xdma_edge_rows	,
	output		[19: 0]				tpgm_xdma_edge_cols	,
	
	input							pcie_bclk			,
	input							pcie_rstn			,
	input							tpgm_sclk			,
	input							tpgm_rstn			);
//----------------------------------------------------------------------------------------------------------
	reg		[ 0:15][31:0]			pcie_cmnd_argu_buff	;

	
	wire							pcie_cmnd_argu_wren	;
	wire	[ 0:15]					pcie_cmnd_argu_csid	;
	wire	[ 0:15]					pcie_cmnd_argu_wrid	;
	wire	[ 0:15]					tpgm_cmnd_argu_csid	;
	
	assign	pcie_cmnd_argu_wren	= &{pcie_tpgm_cmnd_csen	,	pcie_tpgm_cmnd_wrcs	};

	for(genvar i = 0 ; i < 16 ; i++) begin	:	rv32_link_cmnd_rwcs
	
		assign	pcie_cmnd_argu_csid[i]	=	pcie_tpgm_cmnd_addr	==	i	;
		assign	pcie_cmnd_argu_wrid[i]	= &{pcie_cmnd_argu_wren	,	pcie_cmnd_argu_csid[i]	};
		assign	tpgm_cmnd_argu_csid[i]	=	tpgm_link_cmnd_indx	==	i	;

		always@(posedge pcie_bclk or negedge pcie_rstn)
		if(~pcie_rstn)					pcie_cmnd_argu_buff[i]	<=	0	;
		else if(pcie_cmnd_argu_wrid[i])	pcie_cmnd_argu_buff[i]	<=	pcie_tpgm_cmnd_wdin	;

	end 
//----------------------------------------------------------------------------------------------------------
	wire		[31: 0]				tpgs_link_dest_port	;

	assign	tpgs_link_dest_port	= {	16'H0 ,	pcie_cmnd_argu_buff[ 0][15: 0] };
	assign	tpgm_xdma_ddrs_base	=			pcie_cmnd_argu_buff[ 4][24: 0]	;

	assign	tpgm_xdma_meta_rows	=			pcie_cmnd_argu_buff[ 6][19: 0]	;
	assign	tpgm_xdma_meta_cols	=			pcie_cmnd_argu_buff[ 7][19: 0]	;

	assign	tpgm_xdma_edge_rows	=			pcie_cmnd_argu_buff[ 8][19: 0]	;
	assign	tpgm_xdma_edge_cols	=			pcie_cmnd_argu_buff[ 9][19: 0]	;

//----------------------------------------------------------------------
	assign	pcie_tpgm_cmnd_rout=	pcie_cmnd_argu_csid[ 0]	?	pcie_cmnd_argu_buff[ 0]	:
									pcie_cmnd_argu_csid[ 1]	?	pcie_cmnd_argu_buff[ 1]	:
									pcie_cmnd_argu_csid[ 2]	?	pcie_cmnd_argu_buff[ 2]	:
									pcie_cmnd_argu_csid[ 3]	?	pcie_cmnd_argu_buff[ 3]	:
									pcie_cmnd_argu_csid[ 4]	?	pcie_cmnd_argu_buff[ 4]	:
									pcie_cmnd_argu_csid[ 5]	?	pcie_cmnd_argu_buff[ 5]	:
									pcie_cmnd_argu_csid[ 6]	?	pcie_cmnd_argu_buff[ 6]	:	
									pcie_cmnd_argu_csid[ 7]	?	pcie_cmnd_argu_buff[ 7]	:
									pcie_cmnd_argu_csid[ 8]	?	pcie_cmnd_argu_buff[ 8]	:
									pcie_cmnd_argu_csid[ 9]	?	pcie_cmnd_argu_buff[ 9]	:
									pcie_cmnd_argu_csid[10]	?	pcie_cmnd_argu_buff[10]	:	
									pcie_cmnd_argu_csid[11]	?	pcie_cmnd_argu_buff[11]	:	
									pcie_cmnd_argu_csid[12]	?	pcie_cmnd_argu_buff[12]	:	
									pcie_cmnd_argu_csid[13]	?	pcie_cmnd_argu_buff[13]	:	
									pcie_cmnd_argu_csid[14]	?	pcie_cmnd_argu_buff[14]	:	
									pcie_cmnd_argu_csid[15]	?	pcie_cmnd_argu_buff[15]	:	32'H0	;
//----------------------------------------------------------------------
	assign	tpgm_link_cmnd_data=	tpgm_cmnd_argu_csid[ 0]	?	tpgs_link_dest_port		:
									tpgm_cmnd_argu_csid[ 1]	?	pcie_cmnd_argu_buff[ 1]	:
									tpgm_cmnd_argu_csid[ 2]	?	pcie_cmnd_argu_buff[ 2]	:
									tpgm_cmnd_argu_csid[ 3]	?	pcie_cmnd_argu_buff[ 3]	:
									tpgm_cmnd_argu_csid[ 4]	?	pcie_cmnd_argu_buff[ 4]	:
									tpgm_cmnd_argu_csid[ 5]	?	pcie_cmnd_argu_buff[ 5]	:
									tpgm_cmnd_argu_csid[ 6]	?	pcie_cmnd_argu_buff[ 6]	:	
									tpgm_cmnd_argu_csid[ 7]	?	pcie_cmnd_argu_buff[ 7]	:
									tpgm_cmnd_argu_csid[ 8]	?	pcie_cmnd_argu_buff[ 8]	:
									tpgm_cmnd_argu_csid[ 9]	?	pcie_cmnd_argu_buff[ 9]	:
									tpgm_cmnd_argu_csid[10]	?	pcie_cmnd_argu_buff[10]	:	
									tpgm_cmnd_argu_csid[11]	?	pcie_cmnd_argu_buff[11]	:	
									tpgm_cmnd_argu_csid[12]	?	pcie_cmnd_argu_buff[12]	:	
									tpgm_cmnd_argu_csid[13]	?	pcie_cmnd_argu_buff[13]	:	
									tpgm_cmnd_argu_csid[14]	?	pcie_cmnd_argu_buff[14]	:	
									tpgm_cmnd_argu_csid[15]	?	pcie_cmnd_argu_buff[15]	:	32'H0	;

	assign	tpgm_link_acmd_data	=	32'H0	;
//----------------------------------------------------------------------
	reg		[ 3: 0]					tpgm_link_enab_samp		;
//	assign	pcie_link_port_enab	=	pcie_cmnd_argu_buff[ 0][19:16]	;	

	always@(posedge tpgm_sclk or negedge tpgm_rstn)
	if(!tpgm_rstn)					tpgm_link_enab_samp	<=	0	;
	else							tpgm_link_enab_samp	<=	pcie_cmnd_argu_buff[ 0][19:16]	;		//pcie_link_port_enab	;

	always@(posedge tpgm_sclk or negedge tpgm_rstn)
	if(!tpgm_rstn)					tpgm_link_port_enab	<=	0	;
	else							tpgm_link_port_enab	<=	tpgm_link_enab_samp	;
									
endmodule
/*	
		tpgm_link_acmd_indx == 4'H0	?	pcie_tpgm_acmd_arg0	:
									tpgm_link_acmd_indx == 4'H1	?	pcie_tpgm_acmd_arg1	:
									tpgm_link_acmd_indx == 4'H2	?	pcie_tpgm_acmd_arg2	:
									tpgm_link_acmd_indx == 4'H3	?	pcie_tpgm_acmd_arg3	:	32'H0	;
*/																	
