//**********************************************************************************************************
//20240822-add ::	output		[24: 0]				tpgm_xdma_ddrs_base	,
//**********************************************************************************************************
module	pcie_link_tpgm_ctrl(
	output								pile_pack_wdma_enab	,
//----------------------------------------------------------------------
	input								pcie_bar0_csen		,
	input		[  6:0 ]				pcie_bar0_addr		,
	input								pcie_bar0_wrcs		,
	input		[ 31:0 ]				pcie_bar0_wdata		,
	output		[ 31:0 ]				pcie_bar0_rdata		,

	input								pcie_xdma_ddrs_stat	,
	output		[ 24: 0]				pcie_xdma_ddrs_base	,
	output		[ 19: 0]				pcie_xdma_rows_numb	,
	output		[ 31: 0]				pcie_xdma_cols_numb	,

	output								pcie_wdma_ddrs_enab	,
	input								pcie_wdma_ddrs_done	,
	output								pcie_rdma_ddrs_enab	,
	input								pcie_rdma_ddrs_done	,

	input								pcie_bclk			,
	input								pcie_rstn			,

	output		[ 3: 0]					tpgm_link_port_enab	,

	input								tpgm_dlys_ctrl_drdy	,

	output		[ 1: 3]					tpgm_link_tune_rxdi	,
	output		[ 1: 3]					tpgm_link_tune_txdo	,
		
	output		[  1: 3]				pcie_tune_txdo_enab	,	
	output		[  1: 3][ 8:0]			pcie_tune_txdo_taps	,	
	input		[  1: 3]				pcie_tune_txdo_done	,	

	output		[  1: 3]				pcie_tune_rxdi_enab	,	
	output		[  1: 3][ 8:0]			pcie_tune_rxdi_taps	,	
	input		[  1: 3]				pcie_tune_rxdi_done	,	
	input		[  1: 3][ 9:0]			pcie_tune_rxdi_stat	,	

	output								tpgm_port_txdo_rstn	,
	output		[0:3][7:0]				tpgm_port_txdo_fram	,
	output		[0:3][7:0]				tpgm_port_txdo_dat0	,
	output		[0:3][7:0]				tpgm_port_txdo_dat1	,
	output		[0:3][7:0]				tpgm_port_txdo_dat2	,
	output		[0:3][7:0]				tpgm_port_txdo_dat3	,

	input		[0:3][7:0]				tpgm_port_rxdi_fram	,
	input		[0:3][7:0]				tpgm_port_rxdi_dat0	,
	input		[0:3][7:0]				tpgm_port_rxdi_dat1	,
	input		[0:3][7:0]				tpgm_port_rxdi_dat2	,
	input		[0:3][7:0]				tpgm_port_rxdi_dat3	,

	output								ubus_tpgm_rdma_csen	,
	output		[ 24: 0]				ubus_tpgm_rdma_addr	,
	input								ubus_tpgm_rdma_trdy	,
	input		[255: 0]				ubus_tpgm_rdma_data	,
	input								ubus_tpgm_rdma_drdy	,

	output								ubus_tpgm_wdma_csen	,
	output		[ 24: 0]				ubus_tpgm_wdma_addr	,
	output		[255: 0]				ubus_tpgm_wdma_data	,
	input								ubus_tpgm_wdma_trdy	,
	input								ubus_tpgm_wdma_wrdy	,

	input								ubus_clki			,
	input								link_cclk			,
	input								ubus_rstn			,
	input								tpgm_sclk			,
	input								tpgm_rstn			);
//PCIE IOSPACE DECODER-------------------------------------------------------------------------------------------
	wire							pcie_tpgm_cmnd_csen	=	pcie_bar0_addr[6:4]	==	3'H0	;
	wire							pcie_tpgm_acks_cs00	=	pcie_bar0_addr[6:4]	==	3'H1	;
	wire							pcie_tpgm_acks_cs01	=	pcie_bar0_addr[6:4]	==	3'H2	;
	wire							pcie_tpgm_misc_csen	=	pcie_bar0_addr[6:4]	==	3'H3	;
	wire							pcie_tune_txdo_csen	=	pcie_bar0_addr[6:4]	==	3'H4	;
	wire							pcie_tune_rxdi_csen	=	pcie_bar0_addr[6:4]	==	3'H5	;
	wire							pcie_moni_fpga_csen	=	pcie_bar0_addr[6:4]	==	3'H6	;
	wire							pcie_supv_cmnd_csen	=	pcie_bar0_addr[6:4]	==	3'H7	;


	wire	[ 3: 0]					pcie_bar0_lsb4_addr	=	pcie_bar0_addr[3:0]	;

	wire	[31: 0]					pcie_tpgm_cmnd_rout	;
	wire	[31: 0]					pcie_tpgm_ack0_rout	;
	wire	[31: 0]					pcie_tpgm_ack1_rout	;
	wire	[31: 0]					pcie_tpgm_misc_rout	;
	wire	[31: 0]					pcie_tune_txdo_rout	;
	wire	[31: 0]					pcie_tune_rxdi_rout	;
	wire	[31: 0]					pcie_moni_fpga_rout	;
	wire	[31: 0]					pcie_supv_cmnd_rout	;
		
	assign		pcie_bar0_rdata	=	pcie_tpgm_cmnd_csen	?	pcie_tpgm_cmnd_rout	:
									pcie_tpgm_acks_cs00	?	pcie_tpgm_ack0_rout	:
									pcie_tpgm_acks_cs01	?	pcie_tpgm_ack1_rout	:
									pcie_tpgm_misc_csen	?	pcie_tpgm_misc_rout	:	
									pcie_tune_txdo_csen	?	pcie_tune_txdo_rout	:	
									pcie_tune_rxdi_csen	?	pcie_tune_rxdi_rout	:	
									pcie_moni_fpga_csen	?	pcie_moni_fpga_rout	:	
									pcie_supv_cmnd_csen	?	pcie_supv_cmnd_rout	:	32'H0	;
//PCIE_BAR0 <-->	MISC--------------------------supv_cmnd_argu_data----------------------------------------------------------
	wire								tpgm_link_supv_mode	;
	
	wire		[31: 0]					tpgm_link_cmnd_data	;
	wire		[31: 0]					user_link_cmnd_data	;
	wire		[31: 0]					supv_link_cmnd_data	;

	wire		[ 3: 0]					user_link_hubs_port	;
	wire		[ 3: 0]					supv_link_hubs_port	;

	assign	tpgm_link_cmnd_data	=		tpgm_link_supv_mode	?	supv_link_cmnd_data	:	user_link_cmnd_data	;	
	assign	tpgm_link_port_enab	=		tpgm_link_supv_mode	?	supv_link_hubs_port	:	user_link_hubs_port	;	
	
	wire		[ 3: 0]					tpgm_link_cmnd_indx	;

	wire		[ 3: 0]					tpgm_link_acmd_indx	;
	wire		[31: 0]					tpgm_link_acmd_data	;

	wire		[ 0: 3]					tpgs_link_acks_lead	;
	wire		[ 0: 3]					tpgs_link_acks_wrcs	;
	wire		[ 0: 3][31:0]			tpgs_link_acks_data	;	

	wire		[24: 0]					tpgm_xdma_ddrs_base	;
	wire		[19: 0]					tpgm_xdma_meta_rows	;
	wire		[19: 0]					tpgm_xdma_meta_cols	;
	wire		[19: 0]					tpgm_xdma_edge_rows	;
	wire		[19: 0]					tpgm_xdma_edge_cols	;

	wire		[24: 0]					user_xdma_ddrs_base	;
	wire		[19: 0]					user_xdma_meta_rows	;
	wire		[19: 0]					user_xdma_meta_cols	;
	wire		[19: 0]					user_xdma_edge_rows	;
	wire		[19: 0]					user_xdma_edge_cols	;

	wire		[24: 0]					supv_xdma_ddrs_base	;
	wire		[19: 0]					supv_xdma_meta_rows	;
	wire		[19: 0]					supv_xdma_meta_cols	;
	wire		[19: 0]					supv_xdma_edge_rows	;
	wire		[19: 0]					supv_xdma_edge_cols	;

	assign	tpgm_xdma_ddrs_base	=		tpgm_link_supv_mode	?	supv_xdma_ddrs_base	:	user_xdma_ddrs_base	;
	assign	tpgm_xdma_meta_rows	=		tpgm_link_supv_mode	?	supv_xdma_meta_rows	:	user_xdma_meta_rows	;
	assign	tpgm_xdma_meta_cols	=		tpgm_link_supv_mode	?	supv_xdma_meta_cols	:	user_xdma_meta_cols	;
	assign	tpgm_xdma_edge_rows	=		tpgm_link_supv_mode	?	supv_xdma_edge_rows	:	user_xdma_edge_rows	;
	assign	tpgm_xdma_edge_cols	=		tpgm_link_supv_mode	?	supv_xdma_edge_cols	:	user_xdma_edge_cols	;

	wire	[ 3: 0]						tpgm_link_port_acks	;
	wire	[ 3: 0]						tpgm_link_port_resp	;
//----------------------------------------------------------------------------------------------------------
	pcie_tpgm_cmnd_memo				u_pcie_tpgm_cmnd_memo(
		.pcie_tpgm_cmnd_csen			(pcie_tpgm_cmnd_csen	),//input				
		.pcie_tpgm_cmnd_addr			(pcie_bar0_lsb4_addr	),//input		[  3: 0]
		.pcie_tpgm_cmnd_wrcs			(pcie_bar0_wrcs			),//input				
		.pcie_tpgm_cmnd_wdin			(pcie_bar0_wdata		),//input		[ 31: 0]
		.pcie_tpgm_cmnd_rout			(pcie_tpgm_cmnd_rout	),//output		[ 31: 0]
	
		.tpgm_link_port_enab			(user_link_hubs_port	),//output	[3: 0]
		.tpgm_link_cmnd_data			(user_link_cmnd_data	),//output		[31: 0]	
		.tpgm_link_cmnd_indx			(tpgm_link_cmnd_indx	),//input		[ 3: 0]	
		.tpgm_link_acmd_indx			(tpgm_link_acmd_indx	),//input		[ 3: 0]	
		.tpgm_link_acmd_data			(tpgm_link_acmd_data	),//output		[31: 0]	
	
		.tpgm_xdma_ddrs_base			(user_xdma_ddrs_base	),//output	[24:0]
		.tpgm_xdma_meta_rows			(user_xdma_meta_rows	),//output	[19:0]
		.tpgm_xdma_meta_cols			(user_xdma_meta_cols	),//output	[15:0]
		.tpgm_xdma_edge_rows			(user_xdma_edge_rows	),//output	[19:0]
		.tpgm_xdma_edge_cols			(user_xdma_edge_cols	),//output	[15:0]
					
		.pcie_bclk						(pcie_bclk				),//input				
		.pcie_rstn						(pcie_rstn				),
		.tpgm_sclk						(tpgm_sclk				),//input
		.tpgm_rstn						(tpgm_rstn				));//input
//------------------------------------------------------------------------------
	pcie_supv_cmnd_gens				u_pcie_supv_cmnd_gens(
		.pcie_supv_cmnd_csen			(pcie_supv_cmnd_csen	),//input					
		.pcie_supv_cmnd_addr			(pcie_bar0_lsb4_addr	),//input		[ 3: 0]		
		.pcie_supv_cmnd_wrcs			(pcie_bar0_wrcs			),//input					
		.pcie_supv_cmnd_wdin			(pcie_bar0_wdata		),//input		[31: 0]		
		.pcie_supv_cmnd_rout			(pcie_supv_cmnd_rout	),//output		[31: 0]		
	
		.supv_link_port_enab			(supv_link_hubs_port	),//output		[31: 0]		
		.supv_cmnd_argu_data			(supv_link_cmnd_data	),//output		[31: 0]	
		.supv_cmnd_argu_indx			(tpgm_link_cmnd_indx	),//input		[31: 0]	

		.supv_xdma_ddrs_base			(supv_xdma_ddrs_base	),//output		[24: 0]		
		.supv_xdma_meta_rows			(supv_xdma_meta_rows	),//output		[19: 0]		
		.supv_xdma_meta_cols			(supv_xdma_meta_cols	),//output		[19: 0]		
		.supv_xdma_edge_rows			(supv_xdma_edge_rows	),//output		[19: 0]		
		.supv_xdma_edge_cols			(supv_xdma_edge_cols	),//output		[19: 0]		

		.pcie_bclk						(pcie_bclk				),//input
		.pcie_rstn						(pcie_rstn				),//input
		.tpgm_sclk						(tpgm_sclk				),//input
		.tpgm_rstn						(tpgm_rstn				));//input
//------------------------------------------------------------------------------
	pcie_tpgm_acks_memo				u_pcie_tpgm_acks_mem0(
		.tpgm_link_acks_init			(tpgm_link_acks_init				),
		.pcie_tpgm_acks_csen			(pcie_tpgm_acks_cs00				),//input	[ 3: 0]	
		.pcie_tpgm_acks_addr			(pcie_bar0_lsb4_addr				),//input	[ 3: 0]	
		.pcie_tpgm_acks_rdata			(pcie_tpgm_ack0_rout				),//output	[31:0]			
		.tpgs_link_acks_lead			(tpgs_link_acks_lead[0:1] 			),//input
		.tpgs_link_acks_wrcs			(tpgs_link_acks_wrcs[0:1] 			),//input
		.tpgs_link_acks_data			(tpgs_link_acks_data[0:1]			),//input	[31:0]
		.tpgm_sclk						(tpgm_sclk							),//input
		.tpgm_rstn						(tpgm_rstn							));//input

	pcie_tpgm_acks_memo				u_pcie_tpgm_acks_mem1(
		.tpgm_link_acks_init			(tpgm_link_acks_init				),
		.pcie_tpgm_acks_csen			(pcie_tpgm_acks_cs01				),//input	[ 3: 0]	
		.pcie_tpgm_acks_addr			(pcie_bar0_lsb4_addr				),//input	[ 3: 0]	
		.pcie_tpgm_acks_rdata			(pcie_tpgm_ack1_rout				),//output	[31:0]			
		.tpgs_link_acks_lead			(tpgs_link_acks_lead[2:3] 		 	),//input
		.tpgs_link_acks_wrcs			(tpgs_link_acks_wrcs[2:3] 		 	),//input
		.tpgs_link_acks_data			(tpgs_link_acks_data[2:3]		 	),//input	[31:0]
		.tpgm_sclk						(tpgm_sclk							),//input
		.tpgm_rstn						(tpgm_rstn							));//input

 	pcie_tpgm_misc_ctrl				u_pcie_tpgm_misc_ctrl(
		.pcie_bar0_tpgm_csen			(pcie_tpgm_misc_csen	),//input				
		.pcie_bar0_tpgm_addr			(pcie_bar0_lsb4_addr	),//input		[ 3: 0 ]
		.pcie_bar0_tpgm_wrcs			(pcie_bar0_wrcs			),//input				
		.pcie_bar0_tpgm_wdin			(pcie_bar0_wdata		),//input		[ 31:0 ]
		.pcie_bar0_tpgm_rdat			(pcie_tpgm_misc_rout	),//output		[ 31:0 ]
		.pcie_bclk						(pcie_bclk				),//input				
		.pcie_rstn						(pcie_rstn				),//input	

		.pcie_xdma_ddrs_stat			(pcie_xdma_ddrs_stat	),//input	
		.pcie_xdma_ddrs_base			(pcie_xdma_ddrs_base	),//output	reg	[ 24: 0]
		.pcie_xdma_rows_numb			(pcie_xdma_rows_numb	),//output	reg	[ 19: 0]
		.pcie_xdma_cols_numb			(pcie_xdma_cols_numb	),//output	reg	[ 15: 0]

		.pcie_rdma_ddrs_enab			(pcie_rdma_ddrs_enab	),//output		reg	
		.pcie_rdma_ddrs_done			(pcie_rdma_ddrs_done	),//input			
		.pcie_wdma_ddrs_enab			(pcie_wdma_ddrs_enab	),//output		reg	
		.pcie_wdma_ddrs_done			(pcie_wdma_ddrs_done	),//input			

		.tpgm_link_supv_mode			(tpgm_link_supv_mode	),
		
		.tpgm_link_tune_rxdi			(tpgm_link_tune_rxdi	),//output	[3:1]
		.tpgm_link_tune_txdo			(tpgm_link_tune_txdo	),//output	[3:1]

		.tpgm_link_port_enab			(tpgm_link_port_enab	),//input	[3: 0]
		.tpgm_link_port_idle			(tpgm_link_port_idle	),//input	
		.tpgm_link_port_acks			(tpgm_link_port_acks	),//input
		.tpgm_link_port_resp			(tpgm_link_port_resp	),//input

		.tpgm_link_port_init			(tpgm_link_port_init	),//output
		.tpgm_link_port_rstn			(tpgm_link_port_rstn	),//output
		.tpgm_link_acks_init			(tpgm_link_acks_init	),

		.tpgm_link_trim_reqs			(tpgm_link_trim_reqs	),//2//input		
		.tpgm_link_icfg_reqs			(tpgm_link_icfg_reqs	),//output	
		.tpgm_link_ocfg_reqs			(tpgm_link_ocfg_reqs	),//output	
		.tpgm_link_nnex_reqs			(tpgm_link_nnex_reqs	),//output	
		.tpgm_link_ivct_reqs			(tpgm_link_ivct_reqs	),//output	
		.tpgm_link_ovct_reqs			(tpgm_link_ovct_reqs	),//output	
		.tpgm_link_imtx_reqs			(tpgm_link_imtx_reqs	),//output	
		.tpgm_link_omtx_reqs			(tpgm_link_omtx_reqs	),//output	
		.tpgm_link_rivt_reqs			(tpgm_link_rivt_reqs	),//output	
		.tpgm_link_rovt_reqs			(tpgm_link_rovt_reqs	),//output	
		.tpgm_link_rimt_reqs			(tpgm_link_rimt_reqs	),//output	
		.tpgm_link_romt_reqs			(tpgm_link_romt_reqs	),//output	
		.tpgm_link_risv_reqs			(tpgm_link_risv_reqs	),//output	
		.tpgm_link_rosv_reqs			(tpgm_link_rosv_reqs	),//output	
		.tpgm_link_rism_reqs			(tpgm_link_rism_reqs	),//output	
		.tpgm_link_rosm_reqs			(tpgm_link_rosm_reqs	),//output	
		.tpgm_link_aset_reqs			(tpgm_link_aset_reqs	),//output	
		.tpgm_link_dnld_reqs			(tpgm_link_dnld_reqs	),//output	
		.tpgm_link_boot_reqs			(tpgm_link_boot_reqs	),//output	


		.tpgm_link_trim_done			(tpgm_link_trim_done	),//2//input		
		.tpgm_link_icfg_done			(tpgm_link_icfg_done	),//input	
		.tpgm_link_ocfg_done			(tpgm_link_ocfg_done	),//input	
		.tpgm_link_nnex_done			(tpgm_link_nnex_done	),//input	
		.tpgm_link_ivct_done			(tpgm_link_ivct_done	),//input	
		.tpgm_link_ovct_done			(tpgm_link_ovct_done	),//input	
		.tpgm_link_imtx_done			(tpgm_link_imtx_done	),//input	
		.tpgm_link_omtx_done			(tpgm_link_omtx_done	),//input	
		.tpgm_link_rivt_done			(tpgm_link_rivt_done	),//input	
		.tpgm_link_rovt_done			(tpgm_link_rovt_done	),//input	
		.tpgm_link_rimt_done			(tpgm_link_rimt_done	),//input	
		.tpgm_link_romt_done			(tpgm_link_romt_done	),//input	
		.tpgm_link_risv_done			(tpgm_link_risv_done	),//input	
		.tpgm_link_rosv_done			(tpgm_link_rosv_done	),//input	
		.tpgm_link_rism_done			(tpgm_link_rism_done	),//input	
		.tpgm_link_rosm_done			(tpgm_link_rosm_done	),//input	
		.tpgm_link_aset_done			(tpgm_link_aset_done	),//input	
		.tpgm_link_dnld_done			(tpgm_link_dnld_done	),//input	
		.tpgm_link_boot_done			(tpgm_link_boot_done	),//input	

		.tpgm_sclk						(tpgm_sclk				),//input
		.tpgm_rstn						(tpgm_rstn				));//output

	pcie_tune_txdo_ctrl				u_pcie_tune_txdo_ctrl(
		.pcie_tune_txdo_enab			(pcie_tune_txdo_enab	),//output	reg	[  1: 3]		
		.pcie_tune_txdo_taps			(pcie_tune_txdo_taps	),//output	reg	[  1: 3][ 8:0]	
		.pcie_tune_txdo_done			(pcie_tune_txdo_done	),//input		[  1: 3]		

		.pcie_tune_txdo_csen			(pcie_tune_txdo_csen	),//input						
		.pcie_tune_txdo_addr			(pcie_bar0_lsb4_addr	),//input		[  3: 0]		
		.pcie_tune_txdo_wrcs			(pcie_bar0_wrcs			),//input						
		.pcie_tune_txdo_wdin			(pcie_bar0_wdata		),//input		[ 31:0]		
		.pcie_tune_txdo_rout			(pcie_tune_txdo_rout	),//output		[ 31:0]		
		.pcie_bclk						(pcie_bclk				),//input						
		.pcie_rstn						(pcie_rstn				));//input						

	pcie_tune_rxdi_ctrl				u_pcie_tune_rxdi_ctrl(
		.pcie_tune_rxdi_enab			(pcie_tune_rxdi_enab	),//output	reg	[  1: 3]		
		.pcie_tune_rxdi_taps			(pcie_tune_rxdi_taps	),//output	reg	[  1: 3][ 8:0]	
		.pcie_tune_rxdi_done			(pcie_tune_rxdi_done	),//input		[  1: 3]		
		.pcie_tune_rxdi_stat			(pcie_tune_rxdi_stat	),//input		[  1: 3][10:0]	

		.pcie_tune_rxdi_csen			(pcie_tune_rxdi_csen	),//input				
		.pcie_tune_rxdi_addr			(pcie_bar0_lsb4_addr	),//input		[  3: 0]
		.pcie_tune_rxdi_wrcs			(pcie_bar0_wrcs			),//input				
		.pcie_tune_rxdi_wdin			(pcie_bar0_wdata		),//input		[ 31: 0]
		.pcie_tune_rxdi_rout			(pcie_tune_rxdi_rout	),//output		[ 31: 0]
		.pcie_bclk						(pcie_bclk				),//input				
		.pcie_rstn						(pcie_rstn				));//input						
//------------------------------------------------------------------------------
	pcie_moni_fpga_stat				U_pcie_moni_fpga_stat(
		.pcie_moni_fpga_csen			(pcie_moni_fpga_csen	),//input					    
		.pcie_moni_fpga_addr			(pcie_bar0_lsb4_addr	),//input		[  3: 0]	    
		.pcie_moni_fpga_rout			(pcie_moni_fpga_rout	),//output		[ 31: 0]	    

		.tpgm_dlys_ctrl_drdy			(tpgm_dlys_ctrl_drdy	),//input		[ 0: 24]

		.pcie_bclk						(pcie_bclk				),//input					    
		.pcie_rstn						(pcie_rstn				),//input					    
	    .link_cclk						(link_cclk				),//input						
	    .link_rstn						(tpgm_rstn				));//input			

/***********************************************************************************************************/
/***********************************************************************************************************/		
	assign	tpgm_port_txdo_rstn	=		tpgm_link_port_rstn	;	

	tpgm_link_esse_unit				u_tpgm_link_esse_unit(
		.pile_pack_wdma_enab			(pile_pack_wdma_enab	),

		.tpgm_link_port_idle			(tpgm_link_port_idle	),//output			
		.tpgm_link_port_enab			(tpgm_link_port_enab	),//input		[3:0]				
		.tpgm_link_port_init			(tpgm_link_port_init	),//input
		.tpgm_link_port_acks			(tpgm_link_port_acks	),//output		[3:0]
		.tpgm_link_port_resp			(tpgm_link_port_resp	),//output		[3:0]

		.tpgm_port_txdo_fram			(tpgm_port_txdo_fram	),//output		[0:3][7:0]
		.tpgm_port_txdo_dat0			(tpgm_port_txdo_dat0	),//output		[0:3][7:0]
		.tpgm_port_txdo_dat1			(tpgm_port_txdo_dat1	),//output		[0:3][7:0]
		.tpgm_port_txdo_dat2			(tpgm_port_txdo_dat2	),//output		[0:3][7:0]
		.tpgm_port_txdo_dat3			(tpgm_port_txdo_dat3	),//output		[0:3][7:0]

		.tpgm_port_rxdi_fram			(tpgm_port_rxdi_fram	),//input		[0:3][7:0]
		.tpgm_port_rxdi_dat0			(tpgm_port_rxdi_dat0	),//input		[0:3][7:0]
		.tpgm_port_rxdi_dat1			(tpgm_port_rxdi_dat1	),//input		[0:3][7:0]
		.tpgm_port_rxdi_dat2			(tpgm_port_rxdi_dat2	),//input		[0:3][7:0]
		.tpgm_port_rxdi_dat3			(tpgm_port_rxdi_dat3	),//input		[0:3][7:0]

		.tpgm_link_cmnd_indx			(tpgm_link_cmnd_indx	),//output		[ 3: 0]	
		.tpgm_link_cmnd_data			(tpgm_link_cmnd_data	),//input		[31: 0]	
		.tpgm_link_acmd_indx			(tpgm_link_acmd_indx	),//output		[ 3: 0]	
		.tpgm_link_acmd_data			(tpgm_link_acmd_data	),//input		[31: 0]	

		.tpgs_link_acks_lead			(tpgs_link_acks_lead	),//output		[ 0: 3]			
		.tpgs_link_acks_wrcs			(tpgs_link_acks_wrcs	),//output		[ 0: 3]			
		.tpgs_link_acks_data			(tpgs_link_acks_data	),//output		[ 0: 3][31:0]	

		.tpgm_link_trim_reqs			(tpgm_link_trim_reqs	),//2//input		
		.tpgm_link_icfg_reqs			(tpgm_link_icfg_reqs	),//2//input		
		.tpgm_link_ocfg_reqs			(tpgm_link_ocfg_reqs	),//3//input		
		.tpgm_link_nnex_reqs			(tpgm_link_nnex_reqs	),//4//input		
		.tpgm_link_aset_reqs			(tpgm_link_aset_reqs	),//5//input		
		.tpgm_link_dnld_reqs			(tpgm_link_dnld_reqs	),//6//input		
		.tpgm_link_boot_reqs			(tpgm_link_boot_reqs	),//7//input		
		.tpgm_link_rivt_reqs			(tpgm_link_rivt_reqs	),//8//input		
		.tpgm_link_rovt_reqs			(tpgm_link_rovt_reqs	),//9//input		
		.tpgm_link_rimt_reqs			(tpgm_link_rimt_reqs	),//10//input 		
		.tpgm_link_romt_reqs			(tpgm_link_romt_reqs	),//11//input		
		.tpgm_link_ivct_reqs			(tpgm_link_ivct_reqs	),//12//input		
		.tpgm_link_ovct_reqs			(tpgm_link_ovct_reqs	),//13//input		
		.tpgm_link_imtx_reqs			(tpgm_link_imtx_reqs	),//14//input		
		.tpgm_link_omtx_reqs			(tpgm_link_omtx_reqs	),//15//input		
		.tpgm_link_rism_reqs			(tpgm_link_rism_reqs	),//16//input		
		.tpgm_link_rosm_reqs			(tpgm_link_rosm_reqs	),//17//input		
		.tpgm_link_risv_reqs			(tpgm_link_risv_reqs	),//16//input		
		.tpgm_link_rosv_reqs			(tpgm_link_rosv_reqs	),//17//input		

		.tpgm_link_trim_done			(tpgm_link_trim_done	),//2//output		
		.tpgm_link_icfg_done			(tpgm_link_icfg_done	),//2//output		
		.tpgm_link_ocfg_done			(tpgm_link_ocfg_done	),//3//output		
		.tpgm_link_nnex_done			(tpgm_link_nnex_done	),//4//output		
		.tpgm_link_aset_done			(tpgm_link_aset_done	),//5//output		
		.tpgm_link_dnld_done			(tpgm_link_dnld_done	),//6//output		
		.tpgm_link_boot_done			(tpgm_link_boot_done	),//7//output		
		.tpgm_link_rivt_done			(tpgm_link_rivt_done	),//8//output		
		.tpgm_link_rovt_done			(tpgm_link_rovt_done	),//9//output		
		.tpgm_link_rimt_done			(tpgm_link_rimt_done	),//10//output 		
		.tpgm_link_romt_done			(tpgm_link_romt_done	),//11//output		
		.tpgm_link_ivct_done			(tpgm_link_ivct_done	),//12//output		
		.tpgm_link_ovct_done			(tpgm_link_ovct_done	),//13//output		
		.tpgm_link_imtx_done			(tpgm_link_imtx_done	),//14//output		
		.tpgm_link_omtx_done			(tpgm_link_omtx_done	),//15//output		
		.tpgm_link_rism_done			(tpgm_link_rism_done	),//16//output		
		.tpgm_link_rosm_done			(tpgm_link_rosm_done	),//17//output		
		.tpgm_link_risv_done			(tpgm_link_risv_done	),//input	
		.tpgm_link_rosv_done			(tpgm_link_rosv_done	),//input	

		.tpgm_xdma_ddrs_base			(tpgm_xdma_ddrs_base	),//input	[24: 0]	
		.tpgm_xdma_meta_rows			(tpgm_xdma_meta_rows	),//input	[19: 0]	
		.tpgm_xdma_meta_cols			(tpgm_xdma_meta_cols	),//input	[15: 0]	
		.tpgm_xdma_edge_rows			(tpgm_xdma_edge_rows	),//input	[19: 0]	
		.tpgm_xdma_edge_cols			(tpgm_xdma_edge_cols	),//input	[15: 0]	

		.ubus_tpgm_rdma_csen			(ubus_tpgm_rdma_csen	),//output				//output	reg			
		.ubus_tpgm_rdma_addr			(ubus_tpgm_rdma_addr	),//output		[ 24: 0]//output	reg	[ 27: 0]
		.ubus_tpgm_rdma_trdy			(ubus_tpgm_rdma_trdy	),//input				//input				
		.ubus_tpgm_rdma_data			(ubus_tpgm_rdma_data	),//input		[255: 0]//input		[255: 0]
		.ubus_tpgm_rdma_drdy			(ubus_tpgm_rdma_drdy	),//input				//input		

		.ubus_tpgm_wdma_csen			(ubus_tpgm_wdma_csen	),//output				
		.ubus_tpgm_wdma_addr			(ubus_tpgm_wdma_addr	),//output		[ 24: 0]
		.ubus_tpgm_wdma_data			(ubus_tpgm_wdma_data	),//output		[255: 0]
		.ubus_tpgm_wdma_trdy			(ubus_tpgm_wdma_trdy	),//input				
		.ubus_tpgm_wdma_wrdy			(ubus_tpgm_wdma_wrdy	),//input				

		.tpgm_sclk						(tpgm_sclk				),//input	
		.tpgm_rstn						(tpgm_rstn				),//input	
		.ubus_clki						(ubus_clki				),//input	
		.ubus_rstn						(ubus_rstn				));	//input	


endmodule
