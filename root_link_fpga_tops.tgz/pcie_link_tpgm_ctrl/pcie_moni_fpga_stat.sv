//**********************************************************************************************************
//20240822-add ::	output		[24: 0]				tpgm_xdma_ddrs_base	,
	
//**********************************************************************************************************
module	pcie_moni_fpga_stat(
	input					    		pcie_moni_fpga_csen	,
	input		[  3: 0]	    		pcie_moni_fpga_addr	,
	output		[ 31: 0]	    		pcie_moni_fpga_rout	,

	input								tpgm_dlys_ctrl_drdy	,

	input					    		pcie_bclk			,
	input					    		pcie_rstn			,

	input						    	link_cclk			,
	input						    	link_rstn			);
//----------------------------------------------------------------------------------------------------------
    wire        [159: 0]                fpga_moni_info_dout ;

    xcku_sysmon                     u_xcku_sysmon(
		.MEASURED_TEMP		            (fpga_moni_info_dout[159:144]   ),//output reg	[15:0] 	
		.MEASURED_VCCINT		        (fpga_moni_info_dout[143:128]   ),//output reg	[15:0] 	
		.MEASURED_VCCAUX		        (fpga_moni_info_dout[127:112]   ),//output reg	[15:0] 	
		.MEASURED_VCCBRAM	            (fpga_moni_info_dout[111: 96]   ),//output reg	[15:0] 	
		.DCLK				            (link_cclk                      ),//input 				
		.RESET				            (~link_rstn                     ));//input 				

    xcku_sysdna	                    u_xcku_sysdna(
		.fdna_code	                    (fpga_moni_info_dout[ 95:  0]   ),//output	reg	[95: 0]
		.link_cclk	                    (link_cclk                      ),//input				
		.init_rstn	                    (link_rstn                      ));	//input				
//----------------------------------------------------------------------------------------------------------
    wire		[159: 0]				gray_moni_fpga_stat	;

	gens_sync_gray #( .MSB( 159 ))	
									u_gens_fpga_stat_gray(
		.data_asyn						(fpga_moni_info_dout			),//input	[MSB: 0]		
		.data_sync						(gray_moni_fpga_stat			),//output	reg [MSB: 0]	
		.scki							(link_cclk						),//input					
		.clki							(pcie_bclk						),//input					
		.rstn							(pcie_rstn						));//input					

	wire		[ 0: 5]					pcie_fpga_moni_csen	;

	for(genvar i = 0 ; i < 6 ; i = i + 1)	begin	:	gens_moni_fpga_stat
		assign	pcie_fpga_moni_csen[i]	=	&{pcie_moni_fpga_csen	,	pcie_moni_fpga_addr	==	i	};
	end
//----------------------------------------------------------------------------------------------------------
	reg			[159:0]					sync_moni_fpga_stat	;
//	reg									sync_dlys_ctrl_drdy	;

	always@(posedge pcie_bclk or negedge pcie_rstn)
	if(~pcie_rstn)						sync_moni_fpga_stat	<=	0	;
	else 								sync_moni_fpga_stat	<=	gray_moni_fpga_stat	;

//	always@(posedge pcie_bclk or negedge pcie_rstn)
//	if(~pcie_rstn)						sync_dlys_ctrl_drdy	<=	0	;
//	else 								sync_dlys_ctrl_drdy	<=	tpgm_dlys_ctrl_drdy	;

//----------------------------------------------------------------------------------------------------------
	assign	pcie_moni_fpga_rout	=		pcie_fpga_moni_csen[0]	?	sync_moni_fpga_stat[ 31:  0]	:
										pcie_fpga_moni_csen[1]	?	sync_moni_fpga_stat[ 63: 32]	:
										pcie_fpga_moni_csen[2]	?	sync_moni_fpga_stat[ 95: 64]	:
										pcie_fpga_moni_csen[3]	?	sync_moni_fpga_stat[127: 96]	:
										pcie_fpga_moni_csen[4]	?	sync_moni_fpga_stat[159:128]	:	
										pcie_fpga_moni_csen[5]	? {	31'H00 ,tpgm_dlys_ctrl_drdy	}	:	32'H0	;
										

endmodule

 