//**********************************************************************************************************
//**********************************************************************************************************
module	pcie_tpgm_acks_memo(
	input							tpgm_link_acks_init	,

	input							pcie_tpgm_acks_csen	,
	input		[  3: 0]			pcie_tpgm_acks_addr	,
	output		[ 31: 0]			pcie_tpgm_acks_rdata,		
//	input							pcie_tpgm_acks_wrcs	,
//	input		[  3: 0]			pcie_tpgm_acks_wdata	,
	
	input		[ 0 : 1]			tpgs_link_acks_lead	,
	input		[ 0 : 1]			tpgs_link_acks_wrcs	,
	input		[ 0 : 1][31:0]		tpgs_link_acks_data	,
	input							tpgm_sclk			,
	input							tpgm_rstn			);
/**********************************************************************************************************/
	wire							tpgs_lnk0_acks_lead	=	tpgs_link_acks_lead[0]	;
	wire							tpgs_lnk0_acks_wrcs	=	tpgs_link_acks_wrcs[0]	;
	wire		[31:0]				tpgs_lnk0_acks_data	=	tpgs_link_acks_data[0]	;
	wire							tpgs_lnk1_acks_lead	=	tpgs_link_acks_lead[1]	;
	wire							tpgs_lnk1_acks_wrcs	=	tpgs_link_acks_wrcs[1]	;
	wire		[31:0]				tpgs_lnk1_acks_data	=	tpgs_link_acks_data[1]	;
/**********************************************************************************************************/
	reg		[ 2: 0]					tpgs_lnk0_acks_indx	;
	reg		[ 0: 7][31:0]			tpgs_lnk0_acks_memo	;
	wire	[ 0: 7]					tpgs_lnk0_acks_csid	;
	wire	[ 0: 7]					tpgs_lnk0_acks_wren	;

	
	always@(posedge tpgm_sclk or negedge tpgm_rstn)
	if(!tpgm_rstn)					tpgs_lnk0_acks_indx	<=	0	;
	else if(tpgs_lnk0_acks_lead)	tpgs_lnk0_acks_indx	<=	0	;
	else if(tpgs_lnk0_acks_wrcs)	tpgs_lnk0_acks_indx	<=	1 +	tpgs_lnk0_acks_indx	;

	for(genvar i = 0 ; i <8 ; i++) begin		
		assign	tpgs_lnk0_acks_csid[i]	=	tpgs_lnk0_acks_indx	==	i						;
		assign	tpgs_lnk0_acks_wren[i]	= &{tpgs_lnk0_acks_wrcs	,	tpgs_lnk0_acks_csid[i] };
	
		always@(posedge tpgm_sclk or negedge tpgm_rstn)
		if(!tpgm_rstn)					tpgs_lnk0_acks_memo[i]	<=	0	;
		else if(tpgs_lnk0_acks_lead)	tpgs_lnk0_acks_memo[i]	<=	0	;
		else if(tpgm_link_acks_init)	tpgs_lnk0_acks_memo[i]	<=	0	;
		else if(tpgs_lnk0_acks_wren[i])	tpgs_lnk0_acks_memo[i]	<=	tpgs_lnk0_acks_data		;
	
	end

/**********************************************************************************************************/
	reg		[ 2: 0]					tpgs_lnk1_acks_indx	;
	reg		[ 0: 7][31:0]			tpgs_lnk1_acks_memo	;
	wire	[ 0: 7]					tpgs_lnk1_acks_csid	;
	wire	[ 0: 7]					tpgs_lnk1_acks_wren	;

	
	always@(posedge tpgm_sclk or negedge tpgm_rstn)
	if(!tpgm_rstn)					tpgs_lnk1_acks_indx	<=	0	;
	else if(tpgs_lnk1_acks_lead)	tpgs_lnk1_acks_indx	<=	0	;
	else if(tpgs_lnk1_acks_wrcs)	tpgs_lnk1_acks_indx	<=	1 +	tpgs_lnk1_acks_indx	;

	for(genvar i = 0 ; i <8 ; i++) begin		
		assign	tpgs_lnk1_acks_csid[i]	=	tpgs_lnk1_acks_indx	==	i						;
		assign	tpgs_lnk1_acks_wren[i]	= &{tpgs_lnk1_acks_wrcs	,	tpgs_lnk1_acks_csid[i] };
	
		always@(posedge tpgm_sclk or negedge tpgm_rstn)
		if(!tpgm_rstn)					tpgs_lnk1_acks_memo[i]	<=	0	;
		else if(tpgs_lnk1_acks_lead)	tpgs_lnk1_acks_memo[i]	<=	0	;
		else if(tpgm_link_acks_init)	tpgs_lnk1_acks_memo[i]	<=	0	;
		else if(tpgs_lnk1_acks_wren[i])	tpgs_lnk1_acks_memo[i]	<=	tpgs_lnk1_acks_data		;
	
	end
/**********************************************************************************************************/
	wire	[ 0:15]					pcie_tpgm_acks_csid	;

	for(genvar i = 0 ; i <16 ; i++) begin		
		assign	pcie_tpgm_acks_csid[i]	= (	pcie_tpgm_acks_addr	==	i)	&	pcie_tpgm_acks_csen	;	
	end
	
	
	assign	pcie_tpgm_acks_rdata=	pcie_tpgm_acks_csid[ 0]	?	tpgs_lnk0_acks_memo[0]	:	
									pcie_tpgm_acks_csid[ 1]	?	tpgs_lnk0_acks_memo[1]	:	
									pcie_tpgm_acks_csid[ 2]	?	tpgs_lnk0_acks_memo[2]	:	
									pcie_tpgm_acks_csid[ 3]	?	tpgs_lnk0_acks_memo[3]	:	
									pcie_tpgm_acks_csid[ 4]	?	tpgs_lnk0_acks_memo[4]	:	
									pcie_tpgm_acks_csid[ 5]	?	tpgs_lnk0_acks_memo[5]	:	
									pcie_tpgm_acks_csid[ 6]	?	tpgs_lnk0_acks_memo[6]	:	
									pcie_tpgm_acks_csid[ 7]	?	tpgs_lnk0_acks_memo[7]	:
									pcie_tpgm_acks_csid[ 8]	?	tpgs_lnk1_acks_memo[0]	:	
									pcie_tpgm_acks_csid[ 9]	?	tpgs_lnk1_acks_memo[1]	:	
									pcie_tpgm_acks_csid[10]	?	tpgs_lnk1_acks_memo[2]	:	
									pcie_tpgm_acks_csid[11]	?	tpgs_lnk1_acks_memo[3]	:	
									pcie_tpgm_acks_csid[12]	?	tpgs_lnk1_acks_memo[4]	:	
									pcie_tpgm_acks_csid[13]	?	tpgs_lnk1_acks_memo[5]	:	
									pcie_tpgm_acks_csid[14]	?	tpgs_lnk1_acks_memo[6]	:	
									pcie_tpgm_acks_csid[15]	?	tpgs_lnk1_acks_memo[7]	:	32'H0	;

endmodule
