//**********************************************************************************************************
//20240822-add ::	output		[24: 0]				tpgm_xdma_ddrs_base	,
//	input		[ 1: 3]					tpgm_tune_rxdi_crdy	,	
//**********************************************************************************************************
module	pcie_tune_rxdi_ctrl(
	output	reg	[  1: 3]				pcie_tune_rxdi_enab	,	
	output	reg	[  1: 3][ 8:0]			pcie_tune_rxdi_taps	,	
	input		[  1: 3]				pcie_tune_rxdi_done	,	
	input		[  1: 3][ 9:0]			pcie_tune_rxdi_stat	,
	
	input								pcie_tune_rxdi_csen	,
	input		[  3: 0]				pcie_tune_rxdi_addr	,
	input								pcie_tune_rxdi_wrcs	,
	input		[ 31: 0]				pcie_tune_rxdi_wdin	,
	output		[ 31: 0]				pcie_tune_rxdi_rout	,
	input								pcie_bclk			,
	input								pcie_rstn			);
/**********************************************************************************************************/
	reg 	[ 1: 3][ 2: 0]				pcie_tune_done_samp	;
	reg 	[ 1: 3]						pcie_tune_rxdi_flag	;
	
	wire	[ 1: 3]						pcie_tune_rxdi_beok	;
	wire	[ 1: 3][31: 0]				pcie_tune_rxdi_word	;

	wire	[ 1: 3]						pcie_tune_cfig_csid	;
	wire	[ 1: 3]						pcie_tune_cfig_wrid	;


for(genvar i = 1 ; i < 4 ; i = i + 1 ) 	begin	:	pcie_tune_port_rdly
	assign	pcie_tune_cfig_csid[i]	=&{	pcie_tune_rxdi_csen	,	pcie_tune_rxdi_addr==i	};
	assign	pcie_tune_cfig_wrid[i]	=&{	pcie_tune_rxdi_wrcs	,	pcie_tune_cfig_csid[i]	};

	always@(posedge pcie_bclk or negedge pcie_rstn)
	if(~pcie_rstn)						pcie_tune_rxdi_enab[i]	<=	0	;
	else if(pcie_tune_cfig_wrid[i])		pcie_tune_rxdi_enab[i]	<=	1	;
	else if(pcie_tune_rxdi_beok[i])		pcie_tune_rxdi_enab[i]	<=	0	;


	always@(posedge pcie_bclk or negedge pcie_rstn)
	if(~pcie_rstn)						pcie_tune_rxdi_taps[i]	<=	0	;
	else if(pcie_tune_cfig_wrid[i])		pcie_tune_rxdi_taps[i]	<=	pcie_tune_rxdi_wdin[8:0];


	always@(posedge pcie_bclk or negedge pcie_rstn)
	if(~pcie_rstn)						pcie_tune_rxdi_flag[i]	<=	0	;
	else if(pcie_tune_cfig_wrid[i])		pcie_tune_rxdi_flag[i]	<=	0	;
	else if(pcie_tune_rxdi_beok[i])		pcie_tune_rxdi_flag[i]	<=	1	;

	always@(posedge pcie_bclk or negedge pcie_rstn)
	if(~pcie_rstn)						pcie_tune_done_samp[i]	<=	0	;
	else if(~pcie_tune_rxdi_enab[i])	pcie_tune_done_samp[i]	<=	0	;
	else 								pcie_tune_done_samp[i]	<= {pcie_tune_rxdi_done[i]	,	pcie_tune_done_samp[i][2:1]	};

	assign	pcie_tune_rxdi_beok[i]	=	pcie_tune_done_samp[i][1:0]	==	2'B10	;

	assign	pcie_tune_rxdi_word[i]	= {	pcie_tune_rxdi_flag[i]	,	//BIT 31
										5'H0					,	//BIT 30:26 
										pcie_tune_rxdi_stat[i]	,	//tpgm_tune_rxdi_eyes[i],  //BIT 25:21	tpgm_tune_rxdi_slip[i]	,	//BIT 20:16	
										4'H0					,	//tpgm_tune_rxdi_mfsm[i]	,	
										3'H0					,	//BIT 15: 9	
										pcie_tune_rxdi_taps[i]	};	//BIT  8: 0

end	
//----------------------------------------------------------------------------------------------------------
	assign	pcie_tune_rxdi_rout	=	pcie_tune_cfig_csid[ 1]	?	pcie_tune_rxdi_word[ 1]	:
									pcie_tune_cfig_csid[ 2]	?	pcie_tune_rxdi_word[ 2]	:
									pcie_tune_cfig_csid[ 3]	?	pcie_tune_rxdi_word[ 3]	:	32'H0	;
					
endmodule

