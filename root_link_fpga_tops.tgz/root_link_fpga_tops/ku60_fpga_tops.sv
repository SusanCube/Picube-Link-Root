//**********************************************************************************************************
module	ku60_fpga_tops(
	input								chip_clki_inpp		,
	input								chip_clki_inpn		,

	output 	[ 7: 0] 					pci_exp_txp			,
    output 	[ 7: 0] 					pci_exp_txn			,
    input 	[ 7: 0] 					pci_exp_rxp			,
    input 	[ 7: 0] 					pci_exp_rxn			,

	input								pcie_clkp_io		,
    input								pcie_clkn_io		,
	input								pcie_rstn_io		,

	input		[ 0: 3]					mgt1_rxp_io			,
	input		[ 0: 3]					mgt1_rxn_io			,
	input								mgt1_rclk_p			,
	input								mgt1_rclk_n			,

	input		[ 0: 3]					mgt2_rxp_io			,
	input		[ 0: 3]					mgt2_rxn_io			,
	input								mgt2_rclk_p			,
	input								mgt2_rclk_n			,

	input		[ 0: 3]					mgt3_rxp_io			,
	input		[ 0: 3]					mgt3_rxn_io			,
	input								mgt3_rclk_p			,
	input								mgt3_rclk_n			,

   	output 		[ 9: 0]  				c0_lpddr3_ca		,
   	output 		[ 0: 0]  				c0_lpddr3_ck_t		,      
   	output 		[ 0: 0]  				c0_lpddr3_ck_c		,
   	output 		[ 0: 0]  				c0_lpddr3_cs_n		, 
   	output 		[ 0: 0]	 				c0_lpddr3_cke		,
   	output 		[ 0: 0]	 				c0_lpddr3_odt		,
   	inout  		[31: 0]  				c0_lpddr3_dq		,
   	inout  		[ 3: 0]  				c0_lpddr3_dqs_t		,
   	inout  		[ 3: 0]  				c0_lpddr3_dqs_c		,
   	output 		[ 3: 0]  				c0_lpddr3_dm		,

	output		[ 1: 3]					tpgm_link_rstn_outp	,
	output		[ 1: 3]					tpgm_link_rstn_outn	,
	output		[ 1: 3]					tpgm_link_tune_rxdi	,
	output		[ 1: 3]					tpgm_link_tune_txdo	,

	output		[ 1: 3]					tpgm_link_fclk_outp	,
	output		[ 1: 3]					tpgm_link_fclk_outn	,
	output		[ 1: 3]					tpgm_link_fram_outp	,
	output		[ 1: 3]					tpgm_link_fram_outn	,
	output		[ 1: 3]					tpgm_link_dat0_outp	,
	output		[ 1: 3]					tpgm_link_dat0_outn	,
	output		[ 1: 3]					tpgm_link_dat1_outp	,
	output		[ 1: 3]					tpgm_link_dat1_outn	,
	output		[ 1: 3]					tpgm_link_dat2_outp	,
	output		[ 1: 3]					tpgm_link_dat2_outn	,
	output		[ 1: 3]					tpgm_link_dat3_outp	,
	output		[ 1: 3]					tpgm_link_dat3_outn	,

	input		[ 1: 3]					tpgs_link_fclk_inpp	,
	input		[ 1: 3]					tpgs_link_fclk_inpn	,
	input		[ 1: 3]					tpgs_link_fram_inpp	,
	input		[ 1: 3]					tpgs_link_fram_inpn	,
	input		[ 1: 3]					tpgs_link_dat0_inpp	,
	input		[ 1: 3]					tpgs_link_dat0_inpn	,
	input		[ 1: 3]					tpgs_link_dat1_inpp	,
	input		[ 1: 3]					tpgs_link_dat1_inpn	,
	input		[ 1: 3]					tpgs_link_dat2_inpp	,
	input		[ 1: 3]					tpgs_link_dat2_inpn	,
	input		[ 1: 3]					tpgs_link_dat3_inpp	,
	input		[ 1: 3]					tpgs_link_dat3_inpn	,

	output		[ 0: 7]					tpem_link_rstn_outp	,
	input		[ 0: 7]					slx9_link_ilas_inpp	,

	output		[ 0: 7]					tpem_link_tune_txdo	,
	output		[ 0: 7]					tpem_link_tune_rxdi	,

	output		[ 0: 7]					tpem_link_fclk_outp	,
	output		[ 0: 7]					tpem_link_fclk_outn	,
	output		[ 0: 7]					tpem_link_fram_outp	,
	output		[ 0: 7]					tpem_link_fram_outn	,
	output		[ 0: 7]					tpem_link_dat0_outp	,
	output		[ 0: 7]					tpem_link_dat0_outn	,
	output		[ 0: 7]					tpem_link_dat1_outp	,
	output		[ 0: 7]					tpem_link_dat1_outn	,
	output		[ 0: 7]					tpem_link_dat2_outp	,
	output		[ 0: 7]					tpem_link_dat2_outn	,
	output		[ 0: 7]					tpem_link_dat3_outp	,
	output		[ 0: 7]					tpem_link_dat3_outn	,

	input		[ 0: 7]					tpes_link_fclk_inpp	,
	input		[ 0: 7]					tpes_link_fclk_inpn	,
	input		[ 0: 7]					tpes_link_fram_inpp	,
	input		[ 0: 7]					tpes_link_fram_inpn	,
	input		[ 0: 7]					tpes_link_dat0_inpp	,
	input		[ 0: 7]					tpes_link_dat0_inpn	,
	input		[ 0: 7]					tpes_link_dat1_inpp	,
	input		[ 0: 7]					tpes_link_dat1_inpn	,
	input		[ 0: 7]					tpes_link_dat2_inpp	,
	input		[ 0: 7]					tpes_link_dat2_inpn	,
	input		[ 0: 7]					tpes_link_dat3_inpp	,
	input		[ 0: 7]					tpes_link_dat3_inpn	,

	output		[ 0: 7]					tpem_scfg_prog_outp	,
	output		[ 0: 7]					tpem_scfg_cclk_outp	,
	output		[ 0: 7]					tpem_scfg_data_outp	,
	input		[ 0: 7]					tpem_scfg_init_inpp	,
	input		[ 0: 7]					tpem_scfg_done_inpp	);
/***********************************************************************************************************/
	IBUFDS							u_CHIP_CLKI_IPAD (
		.O								( chip_clki_w		), 
		.I								( chip_clki_inpp	),
		.IB								( chip_clki_inpn	));
	
	(* KEEP = "TRUE" *)
	BUFG 							BUFG_CHIP_CLKI(
		.O  						 	(chip_clki     		),
    	.I  						 	(chip_clki_w    	));		
/***********************************************************************************************************/
//PCIE XDMA CONTROLLER
	wire								pcie_bram_csen		;
	wire	[  3: 0]					pcie_bram_wben		;
	wire	[ 19: 0]					pcie_bram_addr		;
	wire	[ 31: 0]					pcie_bram_wdata		;
	wire	[ 31: 0]					pcie_bram_rdata		;
	
	wire	[255: 0]					pcie_axis_read_data	;
	wire								pcie_axis_read_last	;
	wire								pcie_axis_read_vlid	;
	wire								pcie_axis_read_trdy	;
	
	wire	[255: 0]					pcie_axis_writ_data	;
	wire								pcie_axis_writ_last	;
	wire								pcie_axis_writ_vlid	;
	wire								pcie_axis_writ_trdy	;
	
    wire 	[ 31: 0]					m_axil_awaddr		;
    wire 	[  2: 0]  					m_axil_awprot		;
    wire 								m_axil_awvalid		;
    wire 								m_axil_awready		;
	
    wire 	[ 31: 0]					m_axil_wdata		;
    wire 	[  3: 0]  					m_axil_wstrb		;
    wire 								m_axil_wvalid		;
    wire 								m_axil_wready		;
	
    wire 								m_axil_bvalid		;
    wire 	[  1: 0]  					m_axil_bresp		;
    wire 								m_axil_bready		;
	
    wire 	[ 31: 0] 					m_axil_araddr		;
    wire 	[  2: 0] 					m_axil_arprot		;
    wire 								m_axil_arvalid		;
    wire 								m_axil_arready		;
	
    wire 	[ 31: 0] 					m_axil_rdata		;
    wire 	[  1: 0] 					m_axil_rresp		;
    wire 								m_axil_rvalid		;
    wire 								m_axil_rready		;

	IBUFDS_GTE3 # (.REFCLK_HROW_CK_SEL(2'b00)) 
									pcie_rclk_ibuf (
		.O								(pcie_rclk			), 
		.ODIV2							(pcie_rclk_d2 		), 
		.CEB							(1'b0				), 
		.I								(pcie_clkp_io		), 			
		.IB								(pcie_clkn_io		));


	pcie_xdma_ctrl 					u_pcie_exp8_ctrl(
      	.sys_clk						(pcie_rclk_d2 			),//input
    	.sys_clk_gt						(pcie_rclk				),//input
		.sys_rst_n						(pcie_rstn_io 			),//input

		.pci_exp_txn     				(pci_exp_txn			),//output[3:0]
		.pci_exp_txp     				(pci_exp_txp			),//output[3:0]

		.pci_exp_rxn					(pci_exp_rxn			),//input[3:0]
		.pci_exp_rxp					(pci_exp_rxp			),//input[3:0]

		.s_axis_c2h_tkeep_0				(32'HFFFFFFFF			),//input   [31 : 0] 	s_axis_c2h_tkeep_0
		.s_axis_c2h_tlast_0				(pcie_axis_read_last	),//input  				s_axis_c2h_tlast_0
		.s_axis_c2h_tdata_0				(pcie_axis_read_data	),//input 	[255 : 0] 	s_axis_c2h_tdata_0
		.s_axis_c2h_tvalid_0			(pcie_axis_read_vlid	),//input  				s_axis_c2h_tvalid_0
		.s_axis_c2h_tready_0			(pcie_axis_read_trdy	),//output 			 	s_axis_c2h_tready_0

		.m_axis_h2c_tkeep_0				(						),//output  [31 : 0] 	m_axis_h2c_tkeep_0 
		.m_axis_h2c_tlast_0				(pcie_axis_writ_last	),//output 	 			m_axis_h2c_tlast_0
		.m_axis_h2c_tdata_0				(pcie_axis_writ_data	),//output  [255 : 0] 	m_axis_h2c_tdata_0
		.m_axis_h2c_tvalid_0			(pcie_axis_writ_vlid	),//output 				m_axis_h2c_tvalid_0 
		.m_axis_h2c_tready_0			(pcie_axis_writ_trdy	),//input 			 	m_axis_h2c_tready_0 

      	.m_axil_awaddr    				(m_axil_awaddr			),//output 	[31 : 0] 	m_axil_awaddr
      	.m_axil_awprot    				(m_axil_awprot			),//output 	[2 : 0] 	m_axil_awprot
      	.m_axil_awvalid   				(m_axil_awvalid			),//output 			 	m_axil_awvalid
      	.m_axil_awready   				(m_axil_awready			),//input  				m_axil_awready

      	.m_axil_wdata     				(m_axil_wdata			),//output 	[31 : 0] 	m_axil_wdata
      	.m_axil_wstrb     				(m_axil_wstrb			),//output 	[3 : 0]	 	m_axil_wstrb
      	.m_axil_wvalid    				(m_axil_wvalid			),//output 				m_axil_wvalid
      	.m_axil_wready    				(m_axil_wready			),//input  				m_axil_wready

      	.m_axil_bvalid    				(m_axil_bvalid			),//input  				m_axil_bvalid
      	.m_axil_bresp     				(m_axil_bresp			),//input  [1 : 0] 		m_axil_bresp
      	.m_axil_bready    				(m_axil_bready			),//output  			m_axil_bready

      	.m_axil_araddr    				(m_axil_araddr			),//output 	[31 : 0] 	m_axil_araddr;
      	.m_axil_arprot    				(m_axil_arprot			),//output  [2 : 0] 	m_axil_arprot;
      	.m_axil_arvalid   				(m_axil_arvalid			),//output  			m_axil_arvalid
      	.m_axil_arready   				(m_axil_arready			),//input  				m_axil_arready

      	.m_axil_rdata     				(m_axil_rdata			),//input  [31 : 0] 	m_axil_rdata;(
      	.m_axil_rresp     				(m_axil_rresp			),//input  [1 : 0] 		m_axil_rresp;(
      	.m_axil_rready    				(m_axil_rready			),//output  			m_axil_rready;
      	.m_axil_rvalid    				(m_axil_rvalid			),//input  				m_axil_rvalid;

		.cfg_mgmt_addr  				( 19'b0 				),
		.cfg_mgmt_write 				( 1'b0 					),
		.cfg_mgmt_write_data 			( 32'b0 				),
		.cfg_mgmt_byte_enable 			( 4'b0 					),
		.cfg_mgmt_read  				( 1'b0 					),
		.cfg_mgmt_type1_cfg_reg_access 	( 1'b0					),	
		.cfg_mgmt_read_data 			(),	
		.cfg_mgmt_read_write_done 		(),	

	    .usr_irq_req  					(1'b0					),//input
	    .usr_irq_ack  					(						),//output
	    .msi_enable        				(						),//output	
	    .msi_vector_width  				(						),//output	
		.axi_aclk        				(axi4_aclk 				),//output 250MHz
		.axi_aresetn     				(axi4_rstn 				),//output 
		.user_lnk_up     				(						));//output

	pcie_bram_ctrl 					u_axil_bram_ctrl(
		.s_axi_awaddr 					(m_axil_awaddr[19:0]	),//: IN STD_LOGIC_VECTOR(19 DOWNTO 0);
		.s_axi_awprot 					(m_axil_awprot			),//: IN STD_LOGIC_VECTOR(2 DOWNTO 0);
		.s_axi_awvalid 					(m_axil_awvalid			),//: IN STD_LOGIC;
		.s_axi_awready 					(m_axil_awready			),//: OUT STD_LOGIC;

		.s_axi_wdata 					(m_axil_wdata			),//: IN STD_LOGIC_VECTOR(31 DOWNTO 0);
		.s_axi_wstrb 					(m_axil_wstrb			),//: IN STD_LOGIC_VECTOR(3 DOWNTO 0);
		.s_axi_wvalid 					(m_axil_wvalid			),//: IN STD_LOGIC;
		.s_axi_wready 					(m_axil_wready			),//: OUT STD_LOGIC;

		.s_axi_bresp 					(m_axil_bresp			),//: OUT STD_LOGIC_VECTOR(1 DOWNTO 0);
		.s_axi_bvalid 					(m_axil_bvalid			),//: OUT STD_LOGIC;
		.s_axi_bready 					(m_axil_bready			),//: IN STD_LOGIC;

		.s_axi_araddr 					(m_axil_araddr[19:0]	),//: IN STD_LOGIC_VECTOR(19 DOWNTO 0);
		.s_axi_arprot 					(m_axil_arprot			),//: IN STD_LOGIC_VECTOR(2 DOWNTO 0);
		.s_axi_arvalid 					(m_axil_arvalid			),//: IN STD_LOGIC;
		.s_axi_arready 					(m_axil_arready			),//: OUT STD_LOGIC;

		.s_axi_rdata 					(m_axil_rdata			),//: OUT STD_LOGIC_VECTOR(31 DOWNTO 0);
		.s_axi_rresp 					(m_axil_rresp			),//: OUT STD_LOGIC_VECTOR(1 DOWNTO 0);
		.s_axi_rvalid 					(m_axil_rvalid			),//: OUT STD_LOGIC;
		.s_axi_rready 					(m_axil_rready			),//: IN STD_LOGIC;

		.s_axi_aclk 					(axi4_aclk 				),//: IN STD_LOGIC;
		.s_axi_aresetn 					(axi4_rstn 				),//: IN STD_LOGIC;
		
    
		.bram_en_a 						(pcie_bram_csen			),// OUT STD_LOGIC;
		.bram_addr_a 					(pcie_bram_addr			),// OUT STD_LOGIC_VECTOR(19 DOWNTO 0);
		.bram_we_a 						(pcie_bram_wben			),// OUT STD_LOGIC_VECTOR(3 DOWNTO 0);
		.bram_wrdata_a 					(pcie_bram_wdata		),// OUT STD_LOGIC_VECTOR(31 DOWNTO 0);
		.bram_rddata_a 					(pcie_bram_rdata		),// IN STD_LOGIC_VECTOR(31 DOWNTO 0)
		.bram_rst_a 					(),//pcie_rset				),// OUT STD_LOGIC; active high
		.bram_clk_a 					(pcie_bclk				));// OUT STD_LOGIC;
/**********************************************************************************************************/
	wire								link_cclk				;
	wire								mgt1_pmau_init_ctrl		;
	wire								mgt1_rstb_push_ctrl		;
	wire								mgt1_intf_link_stat		;
	wire		[255:0]					mgt1_isde_wdma_data		;
    wire								mgt1_isde_wdma_drdy		;
	wire								mgt1_clki				;

	wire								mgt2_pmau_init_ctrl		;
	wire								mgt2_rstb_push_ctrl		;
	wire								mgt2_intf_link_stat		;
	wire		[255:0]					mgt2_isde_wdma_data		;
    wire								mgt2_isde_wdma_drdy		;
	wire								mgt2_clki				;

	wire								mgt3_pmau_init_ctrl		;
	wire								mgt3_rstb_push_ctrl		;
	wire								mgt3_intf_link_stat		;
	wire		[255:0]					mgt3_isde_wdma_data		;
    wire								mgt3_isde_wdma_drdy		;
	wire								mgt3_clki				;
	
	
	ku60_fpga_core					u_ku60_fpga_core(
		.chip_clki						(chip_clki				),//input	
		.link_cclk						(link_cclk				),//output	

		.mgt1_pmau_init_ctrl			(mgt1_pmau_init_ctrl	),//output				
		.mgt1_rstb_push_ctrl			(mgt1_rstb_push_ctrl	),//output				
		.mgt1_intf_link_stat			(mgt1_intf_link_stat	),//input				
		.mgt1_isde_wdma_data			(mgt1_isde_wdma_data	),//input				
    	.mgt1_isde_wdma_drdy			(mgt1_isde_wdma_drdy	),//input				
		.mgt1_clki						(mgt1_clki				),//input				

		.mgt2_pmau_init_ctrl			(mgt2_pmau_init_ctrl	),//output				
		.mgt2_rstb_push_ctrl			(mgt2_rstb_push_ctrl	),//output				
		.mgt2_intf_link_stat			(mgt2_intf_link_stat	),//input				
		.mgt2_isde_wdma_data			(mgt2_isde_wdma_data	),//input				
    	.mgt2_isde_wdma_drdy			(mgt2_isde_wdma_drdy	),//input				
		.mgt2_clki						(mgt2_clki				),//input				

		.mgt3_pmau_init_ctrl			(mgt3_pmau_init_ctrl	),//output				
		.mgt3_rstb_push_ctrl			(mgt3_rstb_push_ctrl	),//output				
		.mgt3_intf_link_stat			(mgt3_intf_link_stat	),//input				
		.mgt3_isde_wdma_data			(mgt3_isde_wdma_data	),//input				
    	.mgt3_isde_wdma_drdy			(mgt3_isde_wdma_drdy	),//input				
		.mgt3_clki						(mgt3_clki				),//input				

		.c0_lpddr3_ca					(c0_lpddr3_ca			),//   	output 		[ 9: 0]
		.c0_lpddr3_ck_t					(c0_lpddr3_ck_t			),//   	output 		[ 0: 0]
		.c0_lpddr3_ck_c					(c0_lpddr3_ck_c			),//   	output 		[ 0: 0]
		.c0_lpddr3_cs_n					(c0_lpddr3_cs_n			),//   	output 		[ 0: 0]
		.c0_lpddr3_cke					(c0_lpddr3_cke			),//   	output 		[ 0: 0]
		.c0_lpddr3_odt					(c0_lpddr3_odt			),//   	output 		[ 0: 0]
		.c0_lpddr3_dq					(c0_lpddr3_dq			),//   	inout  		[31: 0]
		.c0_lpddr3_dqs_t				(c0_lpddr3_dqs_t		),//   	inout  		[ 3: 0]
		.c0_lpddr3_dqs_c				(c0_lpddr3_dqs_c		),//   	inout  		[ 3: 0]
		.c0_lpddr3_dm					(c0_lpddr3_dm			),//   	output 		[ 3: 0]

		.pcie_axis_read_data			(pcie_axis_read_data	),//output	[255: 0]
		.pcie_axis_read_last			(pcie_axis_read_last	),//output			
		.pcie_axis_read_vlid			(pcie_axis_read_vlid	),//output			
		.pcie_axis_read_trdy			(pcie_axis_read_trdy	),//input			
		.pcie_axis_writ_data			(pcie_axis_writ_data	),//input	[255: 0]
		.pcie_axis_writ_last			(pcie_axis_writ_last	),//input			
		.pcie_axis_writ_vlid			(pcie_axis_writ_vlid	),//input			
		.pcie_axis_writ_trdy			(pcie_axis_writ_trdy	),//output			
		.pcie_aclk						(axi4_aclk				),//input

		.pcie_bram_csen					(pcie_bram_csen			),//input			
		.pcie_bram_wben					(|pcie_bram_wben		),//input		
		.pcie_bram_addr					(pcie_bram_addr			),//input	[ 19: 0]
		.pcie_bram_wdata				(pcie_bram_wdata		),//input	[ 31: 0]
		.pcie_bram_rdata				(pcie_bram_rdata		),//output	[ 31: 0]
		.pcie_bclk						(pcie_bclk				),//input
		.pcie_rstn						(pcie_rstn_io			),//input

		.tpgm_link_rstn_outp			(tpgm_link_rstn_outp	),//output		[ 1: 3]	
		.tpgm_link_rstn_outn			(tpgm_link_rstn_outn	),//output		[ 1: 3]	
		.tpgm_link_tune_rxdi			(tpgm_link_tune_rxdi	),//output		[ 1: 3]	
		.tpgm_link_tune_txdo			(tpgm_link_tune_txdo	),//output		[ 1: 3]	

		.tpgm_link_fclk_outp			(tpgm_link_fclk_outp	),//output		[ 1: 3]	
		.tpgm_link_fclk_outn			(tpgm_link_fclk_outn	),//output		[ 1: 3]	
		.tpgm_link_fram_outp			(tpgm_link_fram_outp	),//output		[ 1: 3]	
		.tpgm_link_fram_outn			(tpgm_link_fram_outn	),//output		[ 1: 3]	
		.tpgm_link_dat0_outp			(tpgm_link_dat0_outp	),//output		[ 1: 3]	
		.tpgm_link_dat0_outn			(tpgm_link_dat0_outn	),//output		[ 1: 3]	
		.tpgm_link_dat1_outp			(tpgm_link_dat1_outp	),//output		[ 1: 3]	
		.tpgm_link_dat1_outn			(tpgm_link_dat1_outn	),//output		[ 1: 3]	
		.tpgm_link_dat2_outp			(tpgm_link_dat2_outp	),//output		[ 1: 3]	
		.tpgm_link_dat2_outn			(tpgm_link_dat2_outn	),//output		[ 1: 3]	
		.tpgm_link_dat3_outp			(tpgm_link_dat3_outp	),//output		[ 1: 3]	
		.tpgm_link_dat3_outn			(tpgm_link_dat3_outn	),//output		[ 1: 3]	

		.tpgs_link_fclk_inpp			(tpgs_link_fclk_inpp	),//input		[ 1: 3]	
		.tpgs_link_fclk_inpn			(tpgs_link_fclk_inpn	),//input		[ 1: 3]	
		.tpgs_link_fram_inpp			(tpgs_link_fram_inpp	),//input		[ 1: 3]	
		.tpgs_link_fram_inpn			(tpgs_link_fram_inpn	),//input		[ 1: 3]	
		.tpgs_link_dat0_inpp			(tpgs_link_dat0_inpp	),//input		[ 1: 3]	
		.tpgs_link_dat0_inpn			(tpgs_link_dat0_inpn	),//input		[ 1: 3]	
		.tpgs_link_dat1_inpp			(tpgs_link_dat1_inpp	),//input		[ 1: 3]	
		.tpgs_link_dat1_inpn			(tpgs_link_dat1_inpn	),//input		[ 1: 3]	
		.tpgs_link_dat2_inpp			(tpgs_link_dat2_inpp	),//input		[ 1: 3]	
		.tpgs_link_dat2_inpn			(tpgs_link_dat2_inpn	),//input		[ 1: 3]	
		.tpgs_link_dat3_inpp			(tpgs_link_dat3_inpp	),//input		[ 1: 3]	
		.tpgs_link_dat3_inpn			(tpgs_link_dat3_inpn	),//input		[ 1: 3]	

		.tpem_link_rstn_outp			(tpem_link_rstn_outp	),//output		[ 0: 7]	
		.slx9_link_ilas_inpp			(slx9_link_ilas_inpp	),//output		[ 0: 7]	

		.tpem_tune_txdo_mode			(tpem_link_tune_txdo	),//output		[ 0: 7]	
		.tpem_tune_rxdi_mode			(tpem_link_tune_rxdi	),//output		[ 0: 7]	

		.tpem_link_fclk_outp			(tpem_link_fclk_outp	),//output		[ 0: 7]	
		.tpem_link_fclk_outn			(tpem_link_fclk_outn	),//output		[ 0: 7]	
		.tpem_link_fram_outp			(tpem_link_fram_outp	),//output		[ 0: 7]	
		.tpem_link_fram_outn			(tpem_link_fram_outn	),//output		[ 0: 7]	
		.tpem_link_dat0_outp			(tpem_link_dat0_outp	),//output		[ 0: 7]	
		.tpem_link_dat0_outn			(tpem_link_dat0_outn	),//output		[ 0: 7]	
		.tpem_link_dat1_outp			(tpem_link_dat1_outp	),//output		[ 0: 7]	
		.tpem_link_dat1_outn			(tpem_link_dat1_outn	),//output		[ 0: 7]	
		.tpem_link_dat2_outp			(tpem_link_dat2_outp	),//output		[ 0: 7]	
		.tpem_link_dat2_outn			(tpem_link_dat2_outn	),//output		[ 0: 7]	
		.tpem_link_dat3_outp			(tpem_link_dat3_outp	),//output		[ 0: 7]	
		.tpem_link_dat3_outn			(tpem_link_dat3_outn	),//output		[ 0: 7]	

		.tpes_link_fclk_inpp			(tpes_link_fclk_inpp	),//input		[ 0: 7]	
		.tpes_link_fclk_inpn			(tpes_link_fclk_inpn	),//input		[ 0: 7]	
		.tpes_link_fram_inpp			(tpes_link_fram_inpp	),//input		[ 0: 7]	
		.tpes_link_fram_inpn			(tpes_link_fram_inpn	),//input		[ 0: 7]	
		.tpes_link_dat0_inpp			(tpes_link_dat0_inpp	),//input		[ 0: 7]	
		.tpes_link_dat0_inpn			(tpes_link_dat0_inpn	),//input		[ 0: 7]	
		.tpes_link_dat1_inpp			(tpes_link_dat1_inpp	),//input		[ 0: 7]	
		.tpes_link_dat1_inpn			(tpes_link_dat1_inpn	),//input		[ 0: 7]	
		.tpes_link_dat2_inpp			(tpes_link_dat2_inpp	),//input		[ 0: 7]	
		.tpes_link_dat2_inpn			(tpes_link_dat2_inpn	),//input		[ 0: 7]	
		.tpes_link_dat3_inpp			(tpes_link_dat3_inpp	),//input		[ 0: 7]	
		.tpes_link_dat3_inpn			(tpes_link_dat3_inpn	),//input		[ 0: 7]	

		.tpem_scfg_prog_outp			(tpem_scfg_prog_outp	),//output		[ 0: 7]	
		.tpem_scfg_cclk_outp			(tpem_scfg_cclk_outp	),//output		[ 0: 7]	
		.tpem_scfg_data_outp			(tpem_scfg_data_outp	),//output		[ 0: 7]	
		.tpem_scfg_init_inpp			(tpem_scfg_init_inpp	),//input		[ 0: 7]	
		.tpem_scfg_done_inpp			(tpem_scfg_done_inpp	));//input		[ 0: 7]	
/**********************************************************************************************************/
	ku60_mgt1_sdes_rxo				u_ku60_mgt1_sdes(
		.mgt1_rxp_io					(mgt1_rxp_io			),//input	[ 0: 3]	
		.mgt1_rxn_io					(mgt1_rxn_io			),//input	[ 0: 3]	
		.mgt1_rclk_p					(mgt1_rclk_p			),//input			
		.mgt1_rclk_n					(mgt1_rclk_n			),//input			

		.mgt1_intf_link_stat			(mgt1_intf_link_stat	),//output			
		.mgt1_pmau_init_ctrl			(mgt1_pmau_init_ctrl	),//input			
		.mgt1_rstb_push_ctrl			(mgt1_rstb_push_ctrl	),//input			
		.mgt1_isde_wdma_data			(mgt1_isde_wdma_data	), //output	[255:0]	
    	.mgt1_isde_wdma_drdy			(mgt1_isde_wdma_drdy	),//output			
		.mgt1_clki						(mgt1_clki				),//output	
		.link_cclk						(link_cclk				));//input	

	ku60_mgt2_sdes_rxo				u_ku60_mgt2_sdes(
		.mgt2_rxp_io					(mgt2_rxp_io			),//input	[ 0: 3]	
		.mgt2_rxn_io					(mgt2_rxn_io			),//input	[ 0: 3]	
		.mgt2_rclk_p					(mgt2_rclk_p			),//input			
		.mgt2_rclk_n					(mgt2_rclk_n			),//input			

		.mgt2_intf_link_stat			(mgt2_intf_link_stat	),//output			
		.mgt2_pmau_init_ctrl			(mgt2_pmau_init_ctrl	),//input			
		.mgt2_rstb_push_ctrl			(mgt2_rstb_push_ctrl	),//input			
		.mgt2_isde_wdma_data			(mgt2_isde_wdma_data	),//output	[255:0]	
    	.mgt2_isde_wdma_drdy			(mgt2_isde_wdma_drdy	),//output			
		.mgt2_clki						(mgt2_clki				),//output	
		.link_cclk						(link_cclk				));//input	

	ku60_mgt3_sdes_rxo				u_ku60_mgt3_sdes(
		.mgt3_rxp_io					(mgt3_rxp_io			),//input	[ 0: 3]	
		.mgt3_rxn_io					(mgt3_rxn_io			),//input	[ 0: 3]	
		.mgt3_rclk_p					(mgt3_rclk_p			),//input			
		.mgt3_rclk_n					(mgt3_rclk_n			),//input			

		.mgt3_intf_link_stat			(mgt3_intf_link_stat	),//output			
		.mgt3_pmau_init_ctrl			(mgt3_pmau_init_ctrl	),//input			
		.mgt3_rstb_push_ctrl			(mgt3_rstb_push_ctrl	),//input			
		.mgt3_isde_wdma_data			(mgt3_isde_wdma_data	), //output	[255:0]	
    	.mgt3_isde_wdma_drdy			(mgt3_isde_wdma_drdy	),//output			
		.mgt3_clki						(mgt3_clki				),//output	
		.link_cclk						(link_cclk				));//input	

endmodule	
 