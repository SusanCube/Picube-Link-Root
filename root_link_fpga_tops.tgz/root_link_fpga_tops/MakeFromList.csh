#!/bin/csh -f
# cpFromList.csh  LIST_FILE  DEST_DIR  RSRC_ROOT

#set fpgaPath	=   /home/home1/yangxg/X11/agile_p4e08/fpgaproj
#set listIPSFile =   $rsrcPath/fpga_ku60_tops/ku60_fpga_tops.flst.ips

set rsrcPath	=   /home/home1/yangxg/X11/agile_p4e08/rsrc
set listRTLFile =   $rsrcPath/fpga_ku60_tops/ku60_fpga_tops.flst.rtl

# -----------------------------

set timeStamp   = `date +%Y%m%d%H`

set rootPath    = "ku60_${timeStamp}"

mkdir -p "$rootPath"

if ( $status != 0 ) then
    echo "ERROR: cannot create destination directory $rootPath"
    exit 1
endif

cd  "$rootPath"
# -----------------------------
set destPath    = "fpga_rsrc"
set implPath    = "fpga_impl"


mkdir -p "$destPath"
if ( $status != 0 ) then
    echo "ERROR: cannot create destination directory $destPath"
    exit 2
endif

mkdir -p "$implPath"
if ( $status != 0 ) then
    echo "ERROR: cannot create destination directory $implPath"
    exit 3
endif



# --------------- each file copy ---------------
foreach fileName (`cat "$listRTLFile"`)
    if ( "$fileName" == "" ) continue

    set thisFile = "$rsrcPath/$fileName"
    if ( ! -e "$thisFile" ) then
        echo "ERROR: source file not found  $thisFile"
        exit 3
    endif

    cp "$thisFile" "$destPath"/
    
    if ( $status != 0 ) then
        echo "ERROR: copy failed �� $thisFile"
        exit 4
    endif
end

#foreach fileName (`cat "$listIPSFile"`)
#    if ( "$fileName" == "" ) continue
#
#    set thisFile = "$fpgaPath/$fileName"
#    if ( ! -e "$thisFile" ) then
#        echo "ERROR: source file not found  $thisFile"
#        exit 3
#    endif
#
#    cp "$thisFile" "$destPath"/
#    
#    if ( $status != 0 ) then
#        echo "ERROR: copy failed �� $thisFile"
#        exit 4
#    endif
#end
#


echo "All files copied to $destPath"

ls -l "$destPath"/

cd  "$implPath"
pwd

vivado &