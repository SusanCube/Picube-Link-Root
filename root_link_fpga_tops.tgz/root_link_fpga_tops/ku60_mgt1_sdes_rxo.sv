//--MGT1::ku60_aurora_64b66b_x1y2_rxo
//--MGT2::ku60_aurora_64b66b_x1y3_rxo
//--MGT3::ku60_aurora_64b66b_x1y4_rxo

module	ku60_mgt1_sdes_rxo(
	input	[ 0: 3]						mgt1_rxp_io			,
	input	[ 0: 3]						mgt1_rxn_io			,
	input								mgt1_rclk_p			,
	input								mgt1_rclk_n			,
	
	output								mgt1_intf_link_stat	,
	input								mgt1_pmau_init_ctrl	,
	input								mgt1_rstb_push_ctrl	,
	output	[255:0]						mgt1_isde_wdma_data	, 	 
    output								mgt1_isde_wdma_drdy	,
	
	output								mgt1_clki			,
	input								link_cclk			);
/**********************************************************************************************************/
	wire  	[0:3]     					mgt1_lane_up		;
	wire 	[3:0]      					mgt1_powr_up		;
	wire            					mgt1_chnl_up		;
	wire            					mgt1_qpll_up		;
	
	wire            					mgt1_dnot_lock		;
	wire								mgt1_link_rsto		;
	wire            					mgt1_txrx_rsto		;
	wire            					mgt1_msys_rsto		;
		
	wire								mgt1_hard_errs		;
	wire								mgt1_soft_errs		;
	
	assign	mgt1_intf_link_stat	=	&{	mgt1_lane_up		,//15:12
										mgt1_powr_up		,//11: 8
										mgt1_chnl_up		,//7
										mgt1_qpll_up		,//6
								 	 ~	mgt1_hard_errs		,//5
								 	 ~	mgt1_soft_errs		,//4
								 	 ~	mgt1_dnot_lock		,//5
								 	 ~	mgt1_link_rsto		,//2
								 	 ~	mgt1_txrx_rsto		,//1
								 	 ~	mgt1_msys_rsto		};//0
/*********************************************************************************************************/

/*********************************************************************************************************/
	ku60_mgth_x1y2_rxo		//	ku60_aurora_x1y2_c1				
									u_mgt1_isde_quad(
		.m_axi_rx_tdata					(mgt1_isde_wdma_data	),
		.m_axi_rx_tvalid				(mgt1_isde_wdma_drdy	),

		.rxp							(mgt1_rxp_io			),
		.rxn							(mgt1_rxn_io			),

		.gt_refclk1_p					(mgt1_rclk_p			),
		.gt_refclk1_n					(mgt1_rclk_n			),
		.gt_refclk1_out					(						),

		.rx_hard_err					(mgt1_hard_errs			),
		.rx_soft_err					(mgt1_soft_errs			),

		.rx_channel_up  				(mgt1_chnl_up			),
		.rx_lane_up     				(mgt1_lane_up			),

		.init_clk						(link_cclk				),
		.user_clk_out          			(mgt1_clki				),
        .tx_out_clk                 	(						),//Keep Not Connect


        .gt_rxcdrovrden_in				(1'B0					),
		.mmcm_not_locked_out			(mgt1_dnot_lock			),
        .gt_pll_lock					(mgt1_qpll_up			),

		.reset2fc						(						),
        .reset_pb						(mgt1_rstb_push_ctrl	),
		.pma_init						(mgt1_pmau_init_ctrl	),


		.gt_powergood					(mgt1_powr_up			),
		.power_down						(1'B0					),

        .link_reset_out					(mgt1_link_rsto			),
		.sys_reset_out					(mgt1_msys_rsto			),
		.gt_reset_out					(mgt1_txrx_rsto			),

		.gt0_drpaddr					(9'H0					),//    input   [8:0]     
		.gt0_drpdi						(16'H0000				),//    input   [15:0]  
		.gt0_drpen						(1'H0					),//    input            
		.gt0_drpwe						(1'H0					),//    input            
		.gt0_drpdo						(),//    output  [15:0]   
		.gt0_drprdy						(),//    output            

		.gt1_drpaddr					(9'H0					),
		.gt1_drpdi						(16'H0000				),
		.gt1_drpen						(1'H0					), 
		.gt1_drpwe						(1'H0					), 
		.gt1_drpdo						(), 
		.gt1_drprdy						(), 

		.gt2_drpaddr					(9'H0					),
		.gt2_drpdi						(16'H0000				),
		.gt2_drpen						(1'H0					), 
		.gt2_drpwe						(1'H0					), 
		.gt2_drpdo						(), 
		.gt2_drprdy						(), 

		.gt3_drpaddr					(9'H0					),
		.gt3_drpdi						(16'H0000				),
		.gt3_drpen						(1'H0					), 
		.gt3_drpwe						(1'H0					), 
		.gt3_drpdo						(), 
		.gt3_drprdy						() 

        );
 

endmodule
	
