//**********************************************************************************************************
module	ku60_fpga_duts(
	input							chip_clki			,
/**********************************************************************************************************/
	input	[255: 0]				mgt1_isde_wdma_data	,
    input							mgt1_isde_wdma_drdy	,
	input							mgt1_clki			,

	input	[255: 0]				mgt2_isde_wdma_data	,
    input							mgt2_isde_wdma_drdy	,
	input							mgt2_clki			,

	input	[255: 0]				mgt3_isde_wdma_data	,
    input							mgt3_isde_wdma_drdy	,
	input							mgt3_clki			,
/**********************************************************************************************************/
	output	[255: 0]				pcie_axis_read_data	,
	output							pcie_axis_read_last	,
	output							pcie_axis_read_vlid	,
	input							pcie_axis_read_trdy	,
	input	[255: 0]				pcie_axis_writ_data	,
	input							pcie_axis_writ_last	,
	input							pcie_axis_writ_vlid	,
	output							pcie_axis_writ_trdy	,	
	input							pcie_aclk			,
	
	input							pcie_bram_csen		,
	input							pcie_bram_wben		,
	input	[ 19: 0]				pcie_bram_addr		,
	input	[ 31: 0]				pcie_bram_wdata		,
	output	[ 31: 0]				pcie_bram_rdata		,
	input							pcie_bclk			,
	input							pcie_rstn			,	
/**********************************************************************************************************/
	output		[ 1: 3]				tpgm_link_rstn_outp	,
	output		[ 1: 3]				tpgm_link_rstn_outn	,
	output		[ 1: 3]				tpgm_link_tune_rxdi	,
	output		[ 1: 3]				tpgm_link_tune_txdo	,
	output		[ 1: 3]				tpgm_link_fclk_outp	,
	output		[ 1: 3]				tpgm_link_fclk_outn	,
	output		[ 1: 3]				tpgm_link_fram_outp	,
	output		[ 1: 3]				tpgm_link_fram_outn	,
	output		[ 1: 3]				tpgm_link_dat0_outp	,
	output		[ 1: 3]				tpgm_link_dat0_outn	,
	output		[ 1: 3]				tpgm_link_dat1_outp	,
	output		[ 1: 3]				tpgm_link_dat1_outn	,
	output		[ 1: 3]				tpgm_link_dat2_outp	,
	output		[ 1: 3]				tpgm_link_dat2_outn	,
	output		[ 1: 3]				tpgm_link_dat3_outp	,
	output		[ 1: 3]				tpgm_link_dat3_outn	,
	input		[ 1: 3]				tpgs_link_fclk_inpp	,
	input		[ 1: 3]				tpgs_link_fclk_inpn	,
	input		[ 1: 3]				tpgs_link_fram_inpp	,
	input		[ 1: 3]				tpgs_link_fram_inpn	,
	input		[ 1: 3]				tpgs_link_dat0_inpp	,
	input		[ 1: 3]				tpgs_link_dat0_inpn	,
	input		[ 1: 3]				tpgs_link_dat1_inpp	,
	input		[ 1: 3]				tpgs_link_dat1_inpn	,
	input		[ 1: 3]				tpgs_link_dat2_inpp	,
	input		[ 1: 3]				tpgs_link_dat2_inpn	,
	input		[ 1: 3]				tpgs_link_dat3_inpp	,
	input		[ 1: 3]				tpgs_link_dat3_inpn	);
/***********************************************************************************************************/
	wire		[ 0: 7]					tpem_link_rstn_outp	;

	wire		[ 0: 7]					tpem_link_tune_txdo	;
	wire		[ 0: 7]					tpem_link_tune_rxdi	;


	wire		[ 0: 7]					tpem_scfg_prog_outp	;
	wire		[ 0: 7]					tpem_scfg_cclk_outp	;
	wire		[ 0: 7]					tpem_scfg_data_outp	;
	wire		[ 0: 7]					tpem_scfg_init_inpp	;
	wire		[ 0: 7]					tpem_scfg_done_inpp	;

	wire	[0:7][3:0]					tpem_scfg_fpga_indx	;

	assign		tpem_scfg_fpga_indx[0]	=	4'H0	;	
	assign		tpem_scfg_fpga_indx[1]	=	4'H1	;	
	assign		tpem_scfg_fpga_indx[2]	=	4'H2	;	
	assign		tpem_scfg_fpga_indx[3]	=	4'H3	;	
	assign		tpem_scfg_fpga_indx[4]	=	4'H4	;	
	assign		tpem_scfg_fpga_indx[5]	=	4'H5	;	
	assign		tpem_scfg_fpga_indx[6]	=	4'H6	;	
	assign		tpem_scfg_fpga_indx[7]	=	4'H7	;	
	
	
	
	wire			[ 0: 7]					tpem_link_fclk_outp	;
	wire			[ 0: 7]					tpem_link_fclk_outn	;
	wire			[ 0: 7]					tpem_link_fram_outp	;
	wire			[ 0: 7]					tpem_link_fram_outn	;
	wire			[ 0: 7]					tpem_link_dat0_outp	;
	wire			[ 0: 7]					tpem_link_dat0_outn	;
	wire			[ 0: 7]					tpem_link_dat1_outp	;
	wire			[ 0: 7]					tpem_link_dat1_outn	;
	wire			[ 0: 7]					tpem_link_dat2_outp	;
	wire			[ 0: 7]					tpem_link_dat2_outn	;
	wire			[ 0: 7]					tpem_link_dat3_outp	;
	wire			[ 0: 7]					tpem_link_dat3_outn	;
	
	wire			[ 0: 7]					tpes_link_fclk_inpp	;
	wire			[ 0: 7]					tpes_link_fclk_inpn	;
	wire			[ 0: 7]					tpes_link_fram_inpp	;
	wire			[ 0: 7]					tpes_link_fram_inpn	;
	wire			[ 0: 7]					tpes_link_dat0_inpp	;
	wire			[ 0: 7]					tpes_link_dat0_inpn	;
	wire			[ 0: 7]					tpes_link_dat1_inpp	;
	wire			[ 0: 7]					tpes_link_dat1_inpn	;
	wire			[ 0: 7]					tpes_link_dat2_inpp	;
	wire			[ 0: 7]					tpes_link_dat2_inpn	;
	wire			[ 0: 7]					tpes_link_dat3_inpp	;
	wire			[ 0: 7]					tpes_link_dat3_inpn	;

	wire			[ 0: 7]					tpem_link_fclk_inpp	;
	wire			[ 0: 7]					tpem_link_fclk_inpn	;
	wire			[ 0: 7]					tpem_link_fram_inpp	;
	wire			[ 0: 7]					tpem_link_fram_inpn	;
	wire			[ 0: 7]					tpem_link_dat0_inpp	;
	wire			[ 0: 7]					tpem_link_dat0_inpn	;
	wire			[ 0: 7]					tpem_link_dat1_inpp	;
	wire			[ 0: 7]					tpem_link_dat1_inpn	;
	wire			[ 0: 7]					tpem_link_dat2_inpp	;
	wire			[ 0: 7]					tpem_link_dat2_inpn	;
	wire			[ 0: 7]					tpem_link_dat3_inpp	;
	wire			[ 0: 7]					tpem_link_dat3_inpn	;

	wire			[ 0: 7]					tpes_link_fclk_outp	;
	wire			[ 0: 7]					tpes_link_fclk_outn	;
	wire			[ 0: 7]					tpes_link_fram_outp	;
	wire			[ 0: 7]					tpes_link_fram_outn	;
	wire			[ 0: 7]					tpes_link_dat0_outp	;
	wire			[ 0: 7]					tpes_link_dat0_outn	;
	wire			[ 0: 7]					tpes_link_dat1_outp	;
	wire			[ 0: 7]					tpes_link_dat1_outn	;
	wire			[ 0: 7]					tpes_link_dat2_outp	;
	wire			[ 0: 7]					tpes_link_dat2_outn	;
	wire			[ 0: 7]					tpes_link_dat3_outp	;
	wire			[ 0: 7]					tpes_link_dat3_outn	;


for(genvar i = 0 ; i < 8 ; i++) begin	:	gens_tpgs_tpem_link

//	dlys_inst	udly_00	(	.dlys_sout	(	tpes_link_fclk_inpp[i]	),	.dlys_sdin	(	tpem_link_fclk_outp[i]	),	.dlys_vals	(8'D16)	);
//	dlys_inst	udly_01	(	.dlys_sout	(	tpes_link_fclk_inpn[i]	),	.dlys_sdin	(	tpem_link_fclk_outn[i]	),	.dlys_vals	(8'D16)	);
//	dlys_inst	udly_02	(	.dlys_sout	(	tpes_link_fram_inpp[i]	),	.dlys_sdin	(	tpem_link_fram_outp[i]	),	.dlys_vals	(8'D00)	);
//	dlys_inst	udly_03	(	.dlys_sout	(	tpes_link_fram_inpn[i]	),	.dlys_sdin	(	tpem_link_fram_outn[i]	),	.dlys_vals	(8'D00)	);
//	dlys_inst	udly_04	(	.dlys_sout	(	tpes_link_dat0_inpp[i]	),	.dlys_sdin	(	tpem_link_dat0_outp[i]	),	.dlys_vals	(8'D00)	);
//	dlys_inst	udly_05	(	.dlys_sout	(	tpes_link_dat0_inpn[i]	),	.dlys_sdin	(	tpem_link_dat0_outn[i]	),	.dlys_vals	(8'D00)	);
//	dlys_inst	udly_06	(	.dlys_sout	(	tpes_link_dat1_inpp[i]	),	.dlys_sdin	(	tpem_link_dat1_outp[i]	),	.dlys_vals	(8'D00)	);
//	dlys_inst	udly_07	(	.dlys_sout	(	tpes_link_dat1_inpn[i]	),	.dlys_sdin	(	tpem_link_dat1_outn[i]	),	.dlys_vals	(8'D00)	);
//	dlys_inst	udly_08	(	.dlys_sout	(	tpes_link_dat2_inpp[i]	),	.dlys_sdin	(	tpem_link_dat2_outp[i]	),	.dlys_vals	(8'D00)	);
//	dlys_inst	udly_09	(	.dlys_sout	(	tpes_link_dat2_inpn[i]	),	.dlys_sdin	(	tpem_link_dat2_outn[i]	),	.dlys_vals	(8'D00)	);
//	dlys_inst	udly_0a	(	.dlys_sout	(	tpes_link_dat3_inpp[i]	),	.dlys_sdin	(	tpem_link_dat3_outp[i]	),	.dlys_vals	(8'D00)	);
//	dlys_inst	udly_0b	(	.dlys_sout	(	tpes_link_dat3_inpn[i]	),	.dlys_sdin	(	tpem_link_dat3_outn[i]	),	.dlys_vals	(8'D00)	);
//	
//	dlys_inst	udly_10	(	.dlys_sout	(	tpem_link_fclk_inpp[i]	),	.dlys_sdin	(	tpes_link_fclk_outp[i]	),	.dlys_vals	(8'D05)	);
//	dlys_inst	udly_11	(	.dlys_sout	(	tpem_link_fclk_inpn[i]	),	.dlys_sdin	(	tpes_link_fclk_outn[i]	),	.dlys_vals	(8'D05)	);
//	dlys_inst   udly_12	(	.dlys_sout	(	tpem_link_fram_inpp[i]	),	.dlys_sdin	(	tpes_link_fram_outp[i]	),	.dlys_vals	(8'D00)	);
//	dlys_inst   udly_13	(	.dlys_sout	(	tpem_link_fram_inpn[i]	),	.dlys_sdin	(	tpes_link_fram_outn[i]	),	.dlys_vals	(8'D00)	);
//	dlys_inst   udly_14	(	.dlys_sout	(	tpem_link_dat0_inpp[i]	),	.dlys_sdin	(	tpes_link_dat0_outp[i]	),	.dlys_vals	(8'D00)	);
//	dlys_inst   udly_15	(	.dlys_sout	(	tpem_link_dat0_inpn[i]	),	.dlys_sdin	(	tpes_link_dat0_outn[i]	),	.dlys_vals	(8'D00)	);
//	dlys_inst   udly_16	(	.dlys_sout	(	tpem_link_dat1_inpp[i]	),	.dlys_sdin	(	tpes_link_dat1_outp[i]	),	.dlys_vals	(8'D00)	);
//	dlys_inst   udly_17	(	.dlys_sout	(	tpem_link_dat1_inpn[i]	),	.dlys_sdin	(	tpes_link_dat1_outn[i]	),	.dlys_vals	(8'D00)	);
//	dlys_inst   udly_18	(	.dlys_sout	(	tpem_link_dat2_inpp[i]	),	.dlys_sdin	(	tpes_link_dat2_outp[i]	),	.dlys_vals	(8'D00)	);
//	dlys_inst   udly_19	(	.dlys_sout	(	tpem_link_dat2_inpn[i]	),	.dlys_sdin	(	tpes_link_dat2_outn[i]	),	.dlys_vals	(8'D00)	);
//	dlys_inst   udly_1a	(	.dlys_sout	(	tpem_link_dat3_inpp[i]	),	.dlys_sdin	(	tpes_link_dat3_outp[i]	),	.dlys_vals	(8'D00)	);
//	dlys_inst   udly_1b	(	.dlys_sout	(	tpem_link_dat3_inpn[i]	),	.dlys_sdin	(	tpes_link_dat3_outn[i]	),	.dlys_vals	(8'D00)	);

	dlys_inst 	buf_00		(.dlys_sout	(	tpes_link_fclk_inpp[i]	),	.dlys_sdin	(	tpem_link_fclk_outp[i]	)	);
	dlys_inst 	buf_01		(.dlys_sout	(	tpes_link_fclk_inpn[i]	),	.dlys_sdin	(	tpem_link_fclk_outn[i]	)	);

// 	buf #0.0	buf_00		(	tpes_link_fclk_inpp[i]	,	tpem_link_fclk_outp[i]	);//
//	buf #0.0	buf_01		(	tpes_link_fclk_inpn[i]	,	tpem_link_fclk_outn[i]	);//
	buf #0.0	buf_02		(	tpes_link_fram_inpp[i]	,	tpem_link_fram_outp[i]	);
	buf #0.0	buf_03		(	tpes_link_fram_inpn[i]	,	tpem_link_fram_outn[i]	);
	buf #0.0	buf_04		(	tpes_link_dat0_inpp[i]	,	tpem_link_dat0_outp[i]	);
	buf #0.0	buf_05		(	tpes_link_dat0_inpn[i]	,	tpem_link_dat0_outn[i]	);
	buf #0.0	buf_06		(	tpes_link_dat1_inpp[i]	,	tpem_link_dat1_outp[i]	);
	buf #0.0	buf_07		(	tpes_link_dat1_inpn[i]	,	tpem_link_dat1_outn[i]	);
	buf #0.0	buf_08		(	tpes_link_dat2_inpp[i]	,	tpem_link_dat2_outp[i]	);
	buf #0.0	buf_09		(	tpes_link_dat2_inpn[i]	,	tpem_link_dat2_outn[i]	);
	buf #0.0	buf_0a		(	tpes_link_dat3_inpp[i]	,	tpem_link_dat3_outp[i]	);
	buf #0.0	buf_0b		(	tpes_link_dat3_inpn[i]	,	tpem_link_dat3_outn[i]	);
			
	buf #500ps	buf_10		(	tpem_link_fclk_inpp[i]	,	tpes_link_fclk_outp[i]	);
	buf #500ps	buf_11		(	tpem_link_fclk_inpn[i]	,	tpes_link_fclk_outn[i]	);
	buf #0.0	buf_12		(	tpem_link_fram_inpp[i]	,	tpes_link_fram_outp[i]	);
	buf #0.0	buf_13		(	tpem_link_fram_inpn[i]	,	tpes_link_fram_outn[i]	);
	buf #0.0	buf_14		(	tpem_link_dat0_inpp[i]	,	tpes_link_dat0_outp[i]	);
	buf #0.0	buf_15		(	tpem_link_dat0_inpn[i]	,	tpes_link_dat0_outn[i]	);
	buf #0.0	buf_16		(	tpem_link_dat1_inpp[i]	,	tpes_link_dat1_outp[i]	);
	buf #0.0	buf_17		(	tpem_link_dat1_inpn[i]	,	tpes_link_dat1_outn[i]	);
	buf #0.0	buf_18		(	tpem_link_dat2_inpp[i]	,	tpes_link_dat2_outp[i]	);
	buf #0.0	buf_19		(	tpem_link_dat2_inpn[i]	,	tpes_link_dat2_outn[i]	);
	buf #0.0	buf_1a		(	tpem_link_dat3_inpp[i]	,	tpes_link_dat3_outp[i]	);
	buf #0.0	buf_1b		(	tpem_link_dat3_inpn[i]	,	tpes_link_dat3_outn[i]	);
	


	tpes_simu_link_behv			u_tpes_simu_link_behv(
		.scfg_pile_indx				(4'H0		),
		.scfg_fpga_indx				(tpem_scfg_fpga_indx[i]		),//input	[5: 0]	
		
		.scfg_prog_inpp				(tpem_scfg_prog_outp[i]		),//input			
		.scfg_cclk_inpp				(tpem_scfg_cclk_outp[i]		),//input			
		.scfg_data_inpp				(tpem_scfg_data_outp[i]		),//input			
		.scfg_init_outp				(tpem_scfg_init_inpp[i]		),//output			
		.scfg_done_outp				(tpem_scfg_done_inpp[i]		),//output			
		
		.tpem_txdo_tune				(tpem_link_tune_txdo[i]		),//output		[ 0: 7]	),
		.tpem_rxdi_tune				(tpem_link_tune_rxdi[i]		),//output		[ 0: 7]	),


		.tpem_rstn_inpp				(   tpem_link_rstn_outp[i]	),//input			
		.tpem_rstn_inpn				( ~ tpem_link_rstn_outp[i]	),//input	

		.tpem_fclk_inpp				(tpes_link_fclk_inpp[i]		),//input			
		.tpem_fclk_inpn				(tpes_link_fclk_inpn[i]		),//input		
		.tpem_fram_inpp				(tpes_link_fram_inpp[i]		),//input			
		.tpem_fram_inpn				(tpes_link_fram_inpn[i]		),//input			
		.tpem_dat0_inpp				(tpes_link_dat0_inpp[i]		),//input			
		.tpem_dat0_inpn				(tpes_link_dat0_inpn[i]		),//input			
		.tpem_dat1_inpp				(tpes_link_dat1_inpp[i]		),//input			
		.tpem_dat1_inpn				(tpes_link_dat1_inpn[i]		),//input			
		.tpem_dat2_inpp				(tpes_link_dat2_inpp[i]		),//input			
		.tpem_dat2_inpn				(tpes_link_dat2_inpn[i]		),//input			
		.tpem_dat3_inpp				(tpes_link_dat3_inpp[i]		),//input			
		.tpem_dat3_inpn				(tpes_link_dat3_inpn[i]		),//input			
		
		.tpes_fclk_outp				(tpes_link_fclk_outp[i]		),//output			
		.tpes_fclk_outn				(tpes_link_fclk_outn[i]		),//output			
		.tpes_fram_outp				(tpes_link_fram_outp[i]		),//output			
		.tpes_fram_outn				(tpes_link_fram_outn[i]		),//output			
		.tpes_dat0_outp				(tpes_link_dat0_outp[i]		),//output			
		.tpes_dat0_outn				(tpes_link_dat0_outn[i]		),//output			
		.tpes_dat1_outp				(tpes_link_dat1_outp[i]		),//output			
		.tpes_dat1_outn				(tpes_link_dat1_outn[i]		),//output			
		.tpes_dat2_outp				(tpes_link_dat2_outp[i]		),//output			
		.tpes_dat2_outn				(tpes_link_dat2_outn[i]		),//output			
		.tpes_dat3_outp				(tpes_link_dat3_outp[i]		),//output			
		.tpes_dat3_outn				(tpes_link_dat3_outn[i]		));//output			
end
/***********************************************************************************************************/
	noddr_ku60_fpga_core			u_ku60_fpga_core(	
		.chip_clki					(chip_clki				),//input
		.init_clki					(						),//output
//----------------------------------------------------------------------
		.mgt1_pmau_init_ctrl		(		),//output				
		.mgt1_rstb_push_ctrl		(		),//output				
		.mgt1_intf_link_stat		(1'B1	),//input				
		.mgt1_isde_wdma_data		(mgt1_isde_wdma_data	),//input				
    	.mgt1_isde_wdma_drdy		(mgt1_isde_wdma_drdy	),//input				
		.mgt1_clki					(mgt1_clki				),//input				

		.mgt2_pmau_init_ctrl		(		),//output				
		.mgt2_rstb_push_ctrl		(		),//output				
		.mgt2_intf_link_stat		(1'B1	),//input				
		.mgt2_isde_wdma_data		(mgt2_isde_wdma_data	),//input				
    	.mgt2_isde_wdma_drdy		(mgt2_isde_wdma_drdy	),//input				
		.mgt2_clki					(mgt2_clki				),//input				

		.mgt3_pmau_init_ctrl		(		),//output				
		.mgt3_rstb_push_ctrl		(		),//output				
		.mgt3_intf_link_stat		(1'B1	),//input								
		.mgt3_isde_wdma_data		(mgt3_isde_wdma_data	),//input				
    	.mgt3_isde_wdma_drdy		(mgt3_isde_wdma_drdy	),//input				
		.mgt3_clki					(mgt3_clki				),//input				
//----------------------------------------------------------------------
		.pcie_axis_read_data		(pcie_axis_read_data	),//output	[255: 0]
		.pcie_axis_read_last		(pcie_axis_read_last	),//output			
		.pcie_axis_read_vlid		(pcie_axis_read_vlid	),//output			
		.pcie_axis_read_trdy		(pcie_axis_read_trdy	),//input			
		.pcie_axis_writ_data		(pcie_axis_writ_data	),//input	[255: 0]
		.pcie_axis_writ_last		(pcie_axis_writ_last	),//input			
		.pcie_axis_writ_vlid		(pcie_axis_writ_vlid	),//input			
		.pcie_axis_writ_trdy		(pcie_axis_writ_trdy	),//output			
		.pcie_aclk					(pcie_aclk				),//input			

		.pcie_bram_csen				(pcie_bram_csen			),//input			
		.pcie_bram_wben				(pcie_bram_wben			),//input			
		.pcie_bram_addr				(pcie_bram_addr			),//input	[ 19: 0]
		.pcie_bram_wdata			(pcie_bram_wdata		),//input	[ 31: 0]
		.pcie_bram_rdata			(pcie_bram_rdata		),//output	[ 31: 0]
		.pcie_bclk					(pcie_bclk				),//input			
		.pcie_rstn					(pcie_rstn				),//input			
//----------------------------------------------------------------------
		.tpgm_link_rstn_outp		(tpgm_link_rstn_outp	),//output		[ 1: 3]
		.tpgm_link_rstn_outn		(tpgm_link_rstn_outn	),//output		[ 1: 3]
		
		.tpgm_link_tune_rxdi		(tpgm_link_tune_rxdi	),//output		[ 1: 3]
		.tpgm_link_tune_txdo		(tpgm_link_tune_txdo	),//output		[ 1: 3]

		.tpgm_link_fclk_outp		(tpgm_link_fclk_outp	),//output		[ 1: 3]
		.tpgm_link_fclk_outn		(tpgm_link_fclk_outn	),//output		[ 1: 3]
		.tpgm_link_fram_outp		(tpgm_link_fram_outp	),//output		[ 1: 3]
		.tpgm_link_fram_outn		(tpgm_link_fram_outn	),//output		[ 1: 3]
		.tpgm_link_dat0_outp		(tpgm_link_dat0_outp	),//output		[ 1: 3]
		.tpgm_link_dat0_outn		(tpgm_link_dat0_outn	),//output		[ 1: 3]
		.tpgm_link_dat1_outp		(tpgm_link_dat1_outp	),//output		[ 1: 3]
		.tpgm_link_dat1_outn		(tpgm_link_dat1_outn	),//output		[ 1: 3]
		.tpgm_link_dat2_outp		(tpgm_link_dat2_outp	),//output		[ 1: 3]
		.tpgm_link_dat2_outn		(tpgm_link_dat2_outn	),//output		[ 1: 3]
		.tpgm_link_dat3_outp		(tpgm_link_dat3_outp	),//output		[ 1: 3]
		.tpgm_link_dat3_outn		(tpgm_link_dat3_outn	),//output		[ 1: 3]

		.tpgs_link_fclk_inpp		(tpgs_link_fclk_inpp	),//input		[ 1: 3]
		.tpgs_link_fclk_inpn		(tpgs_link_fclk_inpn	),//input		[ 1: 3]
		.tpgs_link_fram_inpp		(tpgs_link_fram_inpp	),//input		[ 1: 3]
		.tpgs_link_fram_inpn		(tpgs_link_fram_inpn	),//input		[ 1: 3]
		.tpgs_link_dat0_inpp		(tpgs_link_dat0_inpp	),//input		[ 1: 3]
		.tpgs_link_dat0_inpn		(tpgs_link_dat0_inpn	),//input		[ 1: 3]
		.tpgs_link_dat1_inpp		(tpgs_link_dat1_inpp	),//input		[ 1: 3]
		.tpgs_link_dat1_inpn		(tpgs_link_dat1_inpn	),//input		[ 1: 3]
		.tpgs_link_dat2_inpp		(tpgs_link_dat2_inpp	),//input		[ 1: 3]
		.tpgs_link_dat2_inpn		(tpgs_link_dat2_inpn	),//input		[ 1: 3]
		.tpgs_link_dat3_inpp		(tpgs_link_dat3_inpp	),//input		[ 1: 3]
		.tpgs_link_dat3_inpn		(tpgs_link_dat3_inpn	),//input		[ 1: 3]
//----------------------------------------------------------------------
		.tpem_tune_txdo_mode		(tpem_link_tune_txdo	),//output		[ 0: 7]	
		.tpem_tune_rxdi_mode		(tpem_link_tune_rxdi	),//output		[ 0: 7]	

		.tpem_link_fclk_outp		(tpem_link_fclk_outp	),//output		[ 0: 7]	
		.tpem_link_fclk_outn		(tpem_link_fclk_outn	),//output		[ 0: 7]	
		.tpem_link_rstn_outp		(tpem_link_rstn_outp	),//output		[ 0: 7]	

		.tpem_link_fram_outp		(tpem_link_fram_outp	),//output		[ 0: 7]	
		.tpem_link_fram_outn		(tpem_link_fram_outn	),//output		[ 0: 7]	
		.tpem_link_dat0_outp		(tpem_link_dat0_outp	),//output		[ 0: 7]	
		.tpem_link_dat0_outn		(tpem_link_dat0_outn	),//output		[ 0: 7]	
		.tpem_link_dat1_outp		(tpem_link_dat1_outp	),//output		[ 0: 7]	
		.tpem_link_dat1_outn		(tpem_link_dat1_outn	),//output		[ 0: 7]	
		.tpem_link_dat2_outp		(tpem_link_dat2_outp	),//output		[ 0: 7]	
		.tpem_link_dat2_outn		(tpem_link_dat2_outn	),//output		[ 0: 7]	
		.tpem_link_dat3_outp		(tpem_link_dat3_outp	),//output		[ 0: 7]	
		.tpem_link_dat3_outn		(tpem_link_dat3_outn	),//output		[ 0: 7]	

		.tpes_link_fclk_inpp		(tpem_link_fclk_inpp	),//input		[ 0: 7]	
		.tpes_link_fclk_inpn		(tpem_link_fclk_inpn	),//input		[ 0: 7]	
		.tpes_link_fram_inpp		(tpem_link_fram_inpp	),//input		[ 0: 7]	
		.tpes_link_fram_inpn		(tpem_link_fram_inpn	),//input		[ 0: 7]	
		.tpes_link_dat0_inpp		(tpem_link_dat0_inpp	),//input		[ 0: 7]	
		.tpes_link_dat0_inpn		(tpem_link_dat0_inpn	),//input		[ 0: 7]	
		.tpes_link_dat1_inpp		(tpem_link_dat1_inpp	),//input		[ 0: 7]	
		.tpes_link_dat1_inpn		(tpem_link_dat1_inpn	),//input		[ 0: 7]	
		.tpes_link_dat2_inpp		(tpem_link_dat2_inpp	),//input		[ 0: 7]	
		.tpes_link_dat2_inpn		(tpem_link_dat2_inpn	),//input		[ 0: 7]	
		.tpes_link_dat3_inpp		(tpem_link_dat3_inpp	),//input		[ 0: 7]	
		.tpes_link_dat3_inpn		(tpem_link_dat3_inpn	),//input		[ 0: 7]	
		
		.tpem_scfg_prog_outp		(tpem_scfg_prog_outp	),//output		[ 0: 7]	
		.tpem_scfg_cclk_outp		(tpem_scfg_cclk_outp	),//output		[ 0: 7]	
		.tpem_scfg_data_outp		(tpem_scfg_data_outp	),//output		[ 0: 7]	
		.tpem_scfg_init_inpp		(tpem_scfg_init_inpp	),//input		[ 0: 7]	
		.tpem_scfg_done_inpp		(tpem_scfg_done_inpp	));//input		[ 0: 7]	
/***********************************************************************************************************/
endmodule	


