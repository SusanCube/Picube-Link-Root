/*----------------------------------------------------------------------
AUTHOR	: EDWARD YANG
----------------------------------------------------------------------*/
module	tpus_root_link_unit(
	input								tpus_link_ddrs_stat	,
	input		[ 3: 0]					tpgm_link_port_enab	,
//----------------------------------------------------------------------
	output		[ 0: 7]					tpem_link_port_rstn	,
	output		[ 0: 7]					tpem_link_port_rxen	,
	
	output		[ 0: 7]					tpem_tune_txdo_mode	,
	output		[ 0: 7]					tpem_tune_rxdi_mode	,
	
	input		[ 0: 7]					tpem_tune_txdo_done	,
	output		[ 0: 7]					tpem_tune_txdo_enab	,
	output		[ 0: 7][8: 0]			tpem_tune_txdo_taps	,
	
	input		[ 0: 7]					tpem_tune_rxdi_done	,
	output		[ 0: 7]					tpem_tune_rxdi_enab	,
	output		[ 0: 7][ 8: 0]			tpem_tune_rxdi_taps	,
	input		[ 0: 7][ 9: 0]			tpem_tune_rxdi_stat	,

	output								tpem_sync_rxdi_reqs	,
	input		[ 0: 7]					tpem_sync_rxdi_done	,
//-------------------------TPGM_TPGS PORT-------------------------------
	output		[ 7: 0]					tpgs_port_txdo_fram	,
	output		[ 7: 0]					tpgs_port_txdo_dat0	,
	output		[ 7: 0]					tpgs_port_txdo_dat1	,
	output		[ 7: 0]					tpgs_port_txdo_dat2	,
	output		[ 7: 0]					tpgs_port_txdo_dat3	,

	input		[ 7: 0]					tpgs_port_rxdi_fram	,
	input		[ 7: 0]					tpgs_port_rxdi_dat0	,
	input		[ 7: 0]					tpgs_port_rxdi_dat1	,
	input		[ 7: 0]					tpgs_port_rxdi_dat2	,
	input		[ 7: 0]					tpgs_port_rxdi_dat3	,
//-------------------------TPEM_TPES PORT-------------------------------
//	output		[ 0: 7]					tpem_port_txdo_tune	,
	output		[ 0: 7][ 7: 0]			tpem_port_txdo_fram	,
	output		[ 0: 7][ 7: 0]			tpem_port_txdo_dat0	,
	output		[ 0: 7][ 7: 0]			tpem_port_txdo_dat1	,
	output		[ 0: 7][ 7: 0]			tpem_port_txdo_dat2	,
	output		[ 0: 7][ 7: 0]			tpem_port_txdo_dat3	,

//	input		[ 0: 7][ 7: 0]			tpem_port_rxdi_fram	,
	input		[ 7: 0]					tpem_port_rxdi_lead	,
	input		[ 7: 0]					tpem_port_rxdi_body	,
	input		[ 7: 0]					tpem_port_rxdi_coda	,
	input		[ 0: 7][ 7: 0]			tpem_port_rxdi_dat0	,
	input		[ 0: 7][ 7: 0]			tpem_port_rxdi_dat1	,
	input		[ 0: 7][ 7: 0]			tpem_port_rxdi_dat2	,
	input		[ 0: 7][ 7: 0]			tpem_port_rxdi_dat3	,

	output		[ 0: 7]					tpem_scfg_prog_outp	,
	output		[ 0: 7]					tpem_scfg_cclk_outp	,
	output		[ 0: 7]					tpem_scfg_data_outp	,
	input		[ 0: 7]					tpem_scfg_init_inpp	,
	input		[ 0: 7]					tpem_scfg_done_inpp	,
//-------------------------MGTH_CFIG PORT-------------------------------
	input								mgt1_intf_link_stat	,
	output								mgt1_pmau_init_ctrl	,
	output								mgt1_rstb_push_ctrl	,
	input								mgt1_isde_wdma_drdy	,
	input		[255: 0]				mgt1_isde_wdma_data	,
	input								mgt1_clki			,
	input								mgt1_rstn			,

	input								mgt2_intf_link_stat	,
	output								mgt2_pmau_init_ctrl	,
	output								mgt2_rstb_push_ctrl	,
	input								mgt2_isde_wdma_drdy	,
	input		[255: 0]				mgt2_isde_wdma_data	,
	input								mgt2_clki			,
	input								mgt2_rstn			,

	input								mgt3_intf_link_stat	,
	output								mgt3_pmau_init_ctrl	,
	output								mgt3_rstb_push_ctrl	,
	input								mgt3_isde_wdma_drdy	,
	input		[255: 0]				mgt3_isde_wdma_data	,
	input								mgt3_clki			,
	input								mgt3_rstn			,
//-------------------------DDRS_UBUS PORT-------------------------------
	output								ubus_tpgs_wdma_csen	,
	output		[ 24: 0]				ubus_tpgs_wdma_addr	,
	output		[255: 0]				ubus_tpgs_wdma_data	,
	input								ubus_tpgs_wdma_trdy	,
	input								ubus_tpgs_wdma_wrdy	,

	output	reg							ubus_tpgs_rdma_csen	,
	output	reg	[ 24: 0]				ubus_tpgs_rdma_addr	,
	input								ubus_tpgs_rdma_trdy	,
	input		[255: 0]				ubus_tpgs_rdma_data	,
	input								ubus_tpgs_rdma_drdy	,

	output								ubus_tpem_wdma_csen	,
	output		[ 24: 0]				ubus_tpem_wdma_addr	,
	output		[255: 0]				ubus_tpem_wdma_data	,
	input								ubus_tpem_wdma_trdy	,
	input								ubus_tpem_wdma_wrdy	,

	output								ubus_tpem_rdma_csen	,
	output		[ 24: 0]				ubus_tpem_rdma_addr	,
	input								ubus_tpem_rdma_trdy	,
	input		[255: 0]				ubus_tpem_rdma_data	,
	input								ubus_tpem_rdma_drdy	,

	output								ubus_isde_wdma_csen	,
	output		[ 24: 0]				ubus_isde_wdma_addr	,
	output		[255: 0]				ubus_isde_wdma_data	,
	input								ubus_isde_wdma_trdy	,
	input								ubus_isde_wdma_wrdy	,
//-------------------------CLKS RSTN PORT-------------------------------
	input								link_sclk			,
	input								link_rstn			,
	input								ubus_clki			,
	input								ubus_rstn			);
/**********************************************************************************************************/
//RV32 CPU_CORE
	wire								rv32_link_tpus_csen	;
	wire								rv32_link_tpus_wrcs	;
	wire		[11: 0]					rv32_link_tpus_addr	;
	wire		[31: 0]					rv32_link_tpus_wdin	;
	wire		[31: 0]					rv32_link_tpus_rout	;

	wire								tpgs_cram_writ_csen	;
	wire		[11: 0]					tpgs_cram_writ_addr	;

	tpgs_sisc_rv32_cpu				u_rv32_sisc_mcpu(
		.rv32_tpgs_csen					(rv32_link_tpus_csen	),//output				
		.rv32_tpgs_wrcs					(rv32_link_tpus_wrcs	),//output				
		.rv32_tpgs_addr					(rv32_link_tpus_addr	),//output		[ 9: 0]	
		.rv32_tpgs_wdata				(rv32_link_tpus_wdin	),//output		[31: 0]	
		.rv32_tpgs_rdata				(rv32_link_tpus_rout	),//input		[31: 0]	
		.tpgs_cram_wrcs					(tpgs_cram_writ_csen	),//input				
		.tpgs_cram_addr					(tpgs_cram_writ_addr	),//input		[ 9: 0]	
		.mclk							(link_sclk	    		),//input                
    	.rstn							(link_rstn	    		));//input          
/**********************************************************************************************************/
//RV32 TPUC_CORE
	wire		[ 7: 0]					tpem_link_port_enab	;

	wire		[ 3: 0]					tpgs_txdo_acks_indx	;
	wire		[31: 0]					tpgs_txdo_acks_data	;
	wire		[31: 0]					tpgs_rxdi_data_word	;

	wire		[ 3: 0]					tpem_link_cmnd_indx	;
	wire		[31: 0]					tpem_link_cmnd_data	;
	wire		[ 3: 0]					tpem_xdat_cmnd_indx	;
	wire		[31: 0]					tpem_xdat_cmnd_data	;
	wire		[ 3: 0]					tpem_scfg_cmnd_indx	;
	wire		[31: 0]					tpem_scfg_cmnd_data	;

	wire		[ 0: 7]					tpes_link_acks_wrcs	;
	wire		[ 0: 7][31: 0]			tpes_link_acks_data	;

	wire		[ 2: 0]					scut_acks_memo_indx	;
	wire		[31: 0]					scut_acks_memo_data	;

	wire		[17: 0]					tpem_scfg_tpes_stat	;

	wire		[ 7:0]					ecos_omni_edge_numb	;
	wire		[ 4:0]					ecos_pile_edge_numb	;
	wire		[ 4:0]					ecos_pile_edge_tail	;

	wire		[ 3: 0]					this_tpgs_pile_indx	;
	wire		[ 4: 0]					this_tpgs_pile_edge	;
	wire								this_tpgs_pile_lead	;
	wire								this_tpgs_pile_coda	;

	wire		[24: 0]					llmb_meta_imag_size	;
	wire		[19: 0]					llmb_meta_imag_rows	;
	wire		[19: 0]					llmb_meta_imag_cols	;
	wire		[19: 0]					llmb_mtrx_imag_cols	;
	

	wire		[24: 0]					llmb_edge_imag_size	;
	wire		[19: 0]					llmb_edge_imag_rows	;
	wire		[19: 0]					llmb_edge_imag_cols	;
	wire								llmb_edge_imag_even	;
	wire								llmb_edge_imag_row2	;
	
	wire		[24: 0]					llmb_mast_ddrs_base	;
	wire		[24: 0]					llmb_devs_ddrs_base	;

	wire		[3 : 0]					sdes_link_mgth_csid	;
	wire		[24: 0]					sdes_link_ddrs_size	;
	wire		[24: 0]					sdes_meta_ddrs_base	;
	wire		[15: 0]					sdes_meta_cols_dims	;
	wire		[24: 0]					sdes_hubs_ddrs_base	;
	wire		[15: 0]					sdes_hubs_cols_dims	;
	wire		[15: 0]					sdes_hubs_cols_dumy	;

	rv32_link_tpus_ctrl				u_rv32_link_tpus_ctrl(
//--------------RV32 RWBUS		
		.rv32_link_tpus_csen			(rv32_link_tpus_csen	),
		.rv32_link_tpus_addr			(rv32_link_tpus_addr	),
		.rv32_link_tpus_wrcs			(rv32_link_tpus_wrcs	),
		.rv32_link_tpus_wdin			(rv32_link_tpus_wdin	),
		.rv32_link_tpus_rout			(rv32_link_tpus_rout	),

		.tpgs_cram_writ_addr			(tpgs_cram_writ_addr	),
		.tpgs_cram_writ_csen			(tpgs_cram_writ_csen	),
//--------------TUNE CONTROL	
		.tpem_link_port_enab			(tpem_link_port_enab	),
		.tpem_tune_txdo_mode			(tpem_tune_txdo_mode	),//output	[ 0: 7]			
		.tpem_tune_rxdi_mode			(tpem_tune_rxdi_mode	),//output	[ 0: 7]			

		.tpem_tune_txdo_done			(tpem_tune_txdo_done	),//input	[ 0: 7]	
		.tpem_tune_txdo_enab			(tpem_tune_txdo_enab	),//output	[ 0: 7]			
		.tpem_tune_txdo_taps			(tpem_tune_txdo_taps	),//output	[ 0: 7][8: 0]	

		.tpem_tune_rxdi_done			(tpem_tune_rxdi_done	),//input	[ 0: 7]
		.tpem_tune_rxdi_enab			(tpem_tune_rxdi_enab	),//output	[ 0: 7]			
		.tpem_tune_rxdi_taps			(tpem_tune_rxdi_taps	),//output	[ 0: 7][ 8: 0]	
		.tpem_tune_rxdi_stat			(tpem_tune_rxdi_stat	),//input	[ 0: 7][ 9: 0]	

		.tpem_sync_rxdi_reqs			(tpem_sync_rxdi_reqs	),//output	reg			
		.tpem_sync_rxdi_done			(tpem_sync_rxdi_done	),//input		[ 0: 7]	
//--------------ECOS CONFIG PARAMETER
		.ecos_omni_edge_numb			(ecos_omni_edge_numb	),//output	[ 7:0]	
		.ecos_pile_edge_numb			(ecos_pile_edge_numb	),//output	[ 4:0]	
		.ecos_pile_edge_tail			(ecos_pile_edge_tail	),//output	[ 4:0]	

		.this_tpgs_pile_indx			(this_tpgs_pile_indx	),//output		[ 3: 0]	
		.this_tpgs_pile_edge			(this_tpgs_pile_edge	),//output		[ 4: 0]	
		.this_tpgs_pile_lead			(this_tpgs_pile_lead	),//output				
		.this_tpgs_pile_coda			(this_tpgs_pile_coda	),//output				
//--------------LLM  BLASTER PARAMETER
		.llmb_meta_imag_size			(llmb_meta_imag_size	),//output	reg	[24: 0]	
		.llmb_meta_imag_rows			(llmb_meta_imag_rows	),//output		[19: 0]	
		.llmb_meta_imag_cols			(llmb_meta_imag_cols	),//output		[19: 0]	
		.llmb_mtrx_imag_cols			(llmb_mtrx_imag_cols	),//output		[19: 0]	

		.llmb_edge_imag_size			(llmb_edge_imag_size	),//output	reg	[24: 0]	
		.llmb_edge_imag_rows			(llmb_edge_imag_rows	),//output		[19: 0]	
		.llmb_edge_imag_cols			(llmb_edge_imag_cols	),//output		[19: 0]	
		.llmb_edge_imag_even			(llmb_edge_imag_even	),//output		[19: 0]	
		.llmb_edge_imag_row2			(llmb_edge_imag_row2	),//output		[19: 0]	

		.llmb_mast_ddrs_base			(llmb_mast_ddrs_base	),//output		[24: 0]	
		.llmb_devs_ddrs_base			(llmb_devs_ddrs_base	),//output		[24: 0]	

		.sdes_link_mgth_csid			(sdes_link_mgth_csid	),//output		[3 : 0]	
		.sdes_link_ddrs_size			(sdes_link_ddrs_size	),//output		[24: 0]	
		.sdes_meta_ddrs_base			(sdes_meta_ddrs_base	),//output		[24: 0]	
		.sdes_meta_cols_dims			(sdes_meta_cols_dims	),//output		[15: 0]	
		.sdes_hubs_ddrs_base			(sdes_hubs_ddrs_base	),//output		[24: 0]	
		.sdes_hubs_cols_dims			(sdes_hubs_cols_dims	),//output		[15: 0]	
		.sdes_hubs_cols_dumy			(sdes_hubs_cols_dumy	),//output		[15: 0]	
//XDMA		
		.xdma_link_meta_mtrx			(xdma_link_meta_mtrx	),//xdma_link_meta_mtrx	),//output		
		.xdma_isde_wdma_enab			(sdes_link_isde_enab	),//output		
		.xdma_isde_wdma_done			(sdes_link_isde_done	),//input		
		.xdma_osde_rdma_enab			(						),//output		
		.xdma_osde_rdma_done			(1'b0					),//input		
		.xdma_odat_rdma_enab			(tpgs_odat_rdma_enab	),//output		
		.xdma_odat_rdma_done			(tpgs_odat_rdma_done	),//input		
		.xdma_idat_wdma_enab			(tpgs_idat_wdma_enab	),//output		
		.xdma_idat_wdma_done			(tpgs_idat_wdma_done	),//input		
//MGTH LINK MISC CTRL
		.mgt1_pmau_init_ctrl			(mgt1_pmau_init_ctrl	),//output	
		.mgt1_rstb_push_ctrl			(mgt1_rstb_push_ctrl	),//output	
		.mgt1_intf_link_stat			(mgt1_intf_link_stat	),//input	
		.mgt1_clki						(mgt1_clki				),//input	

		.mgt2_pmau_init_ctrl			(mgt2_pmau_init_ctrl	),//output	
		.mgt2_rstb_push_ctrl			(mgt2_rstb_push_ctrl	),//output	
		.mgt2_intf_link_stat			(mgt2_intf_link_stat	),//input	
		.mgt2_clki						(mgt2_clki				),//input	

		.mgt3_pmau_init_ctrl			(mgt3_pmau_init_ctrl	),//output	
		.mgt3_rstb_push_ctrl			(mgt3_rstb_push_ctrl	),//output	
		.mgt3_intf_link_stat			(mgt3_intf_link_stat	),//input	
		.mgt3_clki						(mgt3_clki				),	//input	
//TPGS LINK MISC CTRL
		.tpus_link_ddrs_stat			(tpus_link_ddrs_stat	),//input
		.tpgs_link_port_idle			(tpgs_link_port_idle	),//input
		.tpgs_link_port_init			(tpgs_link_port_init	),//output

		.tpgs_link_cmnd_lead			(tpgs_rxdi_cmnd_lead	),//input				
		.tpgs_link_cmnd_wrcs			(tpgs_rxdi_cmnd_wrcs	),//input				
		.tpgs_link_cmnd_coda			(tpgs_rxdi_cmnd_coda	),//input				
		.tpgs_link_cmnd_data			(tpgs_rxdi_data_word	),//input		[31: 0]	

		.tpgs_link_acks_reqs			(tpgs_txdo_acks_reqs	),//output	
		.tpgs_link_resp_reqs			(tpgs_txdo_resp_reqs	),//output	
		.tpgs_link_acks_done			(tpgs_txdo_acks_done	),//input	
		.tpgs_link_resp_done			(tpgs_txdo_resp_done	),//input	
		.tpgs_link_acks_indx			(tpgs_txdo_acks_indx	),//input		[ 0: 3]
		.tpgs_link_acks_data			(tpgs_txdo_acks_data	),//output		[31: 0]

		.tpgs_trim_cmnd_mark			(tpgs_rxdi_trim_mark	),//input//0
		.tpgs_icfg_cmnd_mark			(tpgs_rxdi_icfg_mark	),//input//0
		.tpgs_ocfg_cmnd_mark			(tpgs_rxdi_ocfg_mark	),//input//1
		.tpgs_nnex_cmnd_mark			(tpgs_rxdi_nnex_mark	),//input//2
		.tpgs_ivct_cmnd_mark			(tpgs_rxdi_ivct_mark	),//input//3
		.tpgs_ovct_cmnd_mark			(tpgs_rxdi_ovct_mark	),//input//4
		.tpgs_imtx_cmnd_mark			(tpgs_rxdi_imtx_mark	),//input//5
		.tpgs_omtx_cmnd_mark			(tpgs_rxdi_omtx_mark	),//input//6
		.tpgs_rivt_cmnd_mark			(tpgs_rxdi_rivt_mark	),//input//7
		.tpgs_rovt_cmnd_mark			(tpgs_rxdi_rovt_mark	),//input//8
		.tpgs_rimt_cmnd_mark			(tpgs_rxdi_rimt_mark	),//input//9
		.tpgs_romt_cmnd_mark			(tpgs_rxdi_romt_mark	),//input//10
		.tpgs_risv_cmnd_mark			(tpgs_rxdi_risv_mark	),//input//11
		.tpgs_rosv_cmnd_mark			(tpgs_rxdi_rosv_mark	),//input//12
		.tpgs_rism_cmnd_mark			(tpgs_rxdi_rism_mark	),//input//11
		.tpgs_rosm_cmnd_mark			(tpgs_rxdi_rosm_mark	),//input//12
		.tpgs_aset_cmnd_mark			(tpgs_rxdi_aset_mark	),//input//13
		.tpgs_dnld_cmnd_mark			(tpgs_rxdi_dnld_mark	),//input//14
		.tpgs_boot_cmnd_mark			(tpgs_rxdi_boot_mark	),//input//15
		.tpgs_auxi_cmnd_mark			(tpgs_rxdi_auxi_mark	),//input//16
//TPEM LINK MISC CTRL	
		.tpem_link_port_idle			(tpem_link_port_idle	),//input	
		.tpem_link_port_init			(tpem_link_port_init	),//output	
		.tpem_link_port_rstn			(tpem_link_port_rstn	),//output	[ 0: 7]
		.tpem_link_port_rxen			(tpem_link_port_rxen	),//output	[ 0: 7]

		.tpgs_link_scut_enab			(tpgs_link_scut_enab	),//output	
		.tpgs_link_scut_done			(tpgs_link_scut_done	),//input	
		.tpem_link_acks_coda			(tpem_link_acks_coda	),//input	
		.tpem_link_resp_coda			(tpem_link_resp_coda	),//input	

		.tpem_link_trim_reqs			(tpem_link_trim_reqs	),//output	
		.tpem_link_icfg_reqs			(tpem_link_icfg_reqs	),//output	
		.tpem_link_ocfg_reqs			(tpem_link_ocfg_reqs	),//output	
		.tpem_link_nnex_reqs			(tpem_link_nnex_reqs	),//output	
		.tpem_link_ivct_reqs			(tpem_link_ivct_reqs	),//output	
		.tpem_link_ovct_reqs			(tpem_link_ovct_reqs	),//output	
		.tpem_link_imtx_reqs			(tpem_link_imtx_reqs	),//output	
		.tpem_link_omtx_reqs			(tpem_link_omtx_reqs	),//output	
		.tpem_link_aset_reqs			(tpem_link_aset_reqs	),//output	
		.tpem_link_dnld_reqs			(tpem_link_dnld_reqs	),//output	
		.tpem_link_boot_reqs			(tpem_link_boot_reqs	),//output	
		.tpem_scfg_aset_reqs			(tpem_scfg_aset_reqs	),//output	
		.tpem_scfg_dnld_reqs			(tpem_scfg_dnld_reqs	),//output	
		.tpem_scfg_boot_reqs			(tpem_scfg_boot_reqs	),//output	

		.tpem_link_trim_done			(tpem_link_trim_done	),//input	//BIT 	02
		.tpem_link_icfg_done			(tpem_link_icfg_done	),//input	//BIT 	02
		.tpem_link_ocfg_done			(tpem_link_ocfg_done	),//input	//BIT 	03
		.tpem_link_nnex_done			(tpem_link_nnex_done	),//input	//BIT 	04
		.tpem_link_ivct_done			(tpem_link_ivct_done	),//input	//BIT  05
		.tpem_link_ovct_done			(tpem_link_ovct_done	),//input	//BIT  06
		.tpem_link_imtx_done			(tpem_link_imtx_done	),//input	//BIT  07
		.tpem_link_omtx_done			(tpem_link_omtx_done	),//input	//BIT  08
		.tpem_link_aset_done			(tpem_link_aset_done	),//input	//BIT 	09
		.tpem_link_dnld_done			(tpem_link_dnld_done	),//input	//BIT 	10
		.tpem_link_boot_done			(tpem_link_boot_done	),//input	//BIT 	11
		.tpem_scfg_aset_done			(tpem_scfg_aset_done	),//input	//BIT 	12
		.tpem_scfg_dnld_done			(tpem_scfg_dnld_done	),//input	//BIT 	13
		.tpem_scfg_boot_done			(tpem_scfg_boot_done	),//input	//BIT 	14

		.tpem_scfg_tpes_stat			(tpem_scfg_tpes_stat	),	

		.tpem_link_cmnd_indx			(tpem_link_cmnd_indx	),//input		[ 0: 3]		
		.tpem_link_cmnd_data			(tpem_link_cmnd_data	),//output		[31: 0]		

		.tpem_xdat_cmnd_indx			(tpem_xdat_cmnd_indx	),//input		[ 0: 3]		
		.tpem_xdat_cmnd_data			(tpem_xdat_cmnd_data	),//output		[31: 0]		

		.tpem_scfg_cmnd_indx			(tpem_scfg_cmnd_indx	),//input		[ 0: 3]		
		.tpem_scfg_cmnd_data			(tpem_scfg_cmnd_data	),//output		[31: 0]		

		.tpes_link_acks_wrcs			(tpes_link_acks_wrcs	),//input		[ 0: 7]		
		.tpes_link_acks_data			(tpes_link_acks_data	),//input		[ 0: 7][31: 0]

		.scut_acks_memo_indx			(scut_acks_memo_indx	),//input		[ 2: 0]	
		.scut_acks_memo_data			(scut_acks_memo_data	),//output		[31: 0]	

		.tpgs_dlys_ctrl_drdy			(1'H0					),

		.link_sclk						(link_sclk				),//input
		.link_rstn						(link_rstn				));//input

/**********************************************************************************************************/
//TPEM LINK CTRL
	wire	[ 7: 0]						tpem_scut_tpgs_fram	;
	wire	[ 7: 0]						tpem_scut_tpgs_dat3	;
	wire	[ 7: 0]						tpem_scut_tpgs_dat2	;
	wire	[ 7: 0]						tpem_scut_tpgs_dat1	;
	wire	[ 7: 0]						tpem_scut_tpgs_dat0	;

	wire	[ 7: 0]						tpgs_scut_tpem_fram	;
	wire	[ 7: 0]						tpgs_scut_tpem_dat3	;
	wire	[ 7: 0]						tpgs_scut_tpem_dat2	;
	wire	[ 7: 0]						tpgs_scut_tpem_dat1	;
	wire	[ 7: 0]						tpgs_scut_tpem_dat0	;

	tpem_link_esse_unit				u_tpem_link_esse_unit(
		.tpem_port_txdo_fram			(tpem_port_txdo_fram	),//output		[ 0: 7][ 7: 0]	
		.tpem_port_txdo_dat0			(tpem_port_txdo_dat0	),//output		[ 0: 7][ 7: 0]	
		.tpem_port_txdo_dat1			(tpem_port_txdo_dat1	),//output		[ 0: 7][ 7: 0]	
		.tpem_port_txdo_dat2			(tpem_port_txdo_dat2	),//output		[ 0: 7][ 7: 0]	
		.tpem_port_txdo_dat3			(tpem_port_txdo_dat3	),//output		[ 0: 7][ 7: 0]	

		.tpem_port_rxdi_lead			(tpem_port_rxdi_lead	),//input		[ 7: 0]		
		.tpem_port_rxdi_body			(tpem_port_rxdi_body	),//input		[ 7: 0]		
		.tpem_port_rxdi_coda			(tpem_port_rxdi_coda	),//input		[ 7: 0]		
		.tpem_port_rxdi_dat0			(tpem_port_rxdi_dat0	),//input		[ 0: 7][ 7: 0]	
		.tpem_port_rxdi_dat1			(tpem_port_rxdi_dat1	),//input		[ 0: 7][ 7: 0]	
		.tpem_port_rxdi_dat2			(tpem_port_rxdi_dat2	),//input		[ 0: 7][ 7: 0]	
		.tpem_port_rxdi_dat3			(tpem_port_rxdi_dat3	),//input		[ 0: 7][ 7: 0]	

		.tpem_scfg_prog_outp			(tpem_scfg_prog_outp	),//output		[ 0: 7]			
		.tpem_scfg_cclk_outp			(tpem_scfg_cclk_outp	),//output		[ 0: 7]			
		.tpem_scfg_data_outp			(tpem_scfg_data_outp	),//output		[ 0: 7]			
		.tpem_scfg_init_inpp			(tpem_scfg_init_inpp	),//input		[ 0: 7]			
		.tpem_scfg_done_inpp			(tpem_scfg_done_inpp	),//input		[ 0: 7]			

		.tpem_link_pile_lead			(1'b1					),
		.tpem_link_port_idle			(tpem_link_port_idle	),//output				
		.tpem_link_port_enab			(tpem_link_port_enab	),//input		[7:0]	
		.tpem_link_port_init			(tpem_link_port_init	),//input				

		.tpgs_link_scut_enab			(tpgs_link_scut_enab	),//input				
		.tpgs_link_scut_done			(tpgs_link_scut_done	),//output				
		.tpem_link_acks_coda			(tpem_link_acks_coda	),//output				
		.tpem_link_resp_coda			(tpem_link_resp_coda	),//output				

		.tpem_link_trim_reqs			(tpem_link_trim_reqs	),//input
		.tpem_link_icfg_reqs			(tpem_link_icfg_reqs	),//input
		.tpem_link_ocfg_reqs			(tpem_link_ocfg_reqs	),//input
		.tpem_link_nnex_reqs			(tpem_link_nnex_reqs	),//input
		.tpem_link_ivct_reqs			(tpem_link_ivct_reqs	),//input
		.tpem_link_ovct_reqs			(tpem_link_ovct_reqs	),//input
		.tpem_link_imtx_reqs			(tpem_link_imtx_reqs	),//input
		.tpem_link_omtx_reqs			(tpem_link_omtx_reqs	),//input
		.tpem_link_aset_reqs			(tpem_link_aset_reqs	),//input
		.tpem_link_dnld_reqs			(tpem_link_dnld_reqs	),//input
		.tpem_link_boot_reqs			(tpem_link_boot_reqs	),//input
		.tpem_scfg_aset_reqs			(tpem_scfg_aset_reqs	),//input
		.tpem_scfg_dnld_reqs			(tpem_scfg_dnld_reqs	),//input
		.tpem_scfg_boot_reqs			(tpem_scfg_boot_reqs	),//input

		.tpem_link_trim_done			(tpem_link_trim_done	),//output
		.tpem_link_icfg_done			(tpem_link_icfg_done	),//output
		.tpem_link_ocfg_done			(tpem_link_ocfg_done	),//output
		.tpem_link_nnex_done			(tpem_link_nnex_done	),//output
		.tpem_link_ivct_done			(tpem_link_ivct_done	),//output
		.tpem_link_ovct_done			(tpem_link_ovct_done	),//output
		.tpem_link_imtx_done			(tpem_link_imtx_done	),//output
		.tpem_link_omtx_done			(tpem_link_omtx_done	),//output
		.tpem_link_aset_done			(tpem_link_aset_done	),//output
		.tpem_link_dnld_done			(tpem_link_dnld_done	),//output
		.tpem_link_boot_done			(tpem_link_boot_done	),//output
		.tpem_scfg_aset_done			(tpem_scfg_aset_done	),//output
		.tpem_scfg_dnld_done			(tpem_scfg_dnld_done	),//output
		.tpem_scfg_boot_done			(tpem_scfg_boot_done	),//output
		.tpem_scfg_tpes_stat			(tpem_scfg_tpes_stat	),	

		.tpem_link_cmnd_indx			(tpem_link_cmnd_indx	),//output		[ 3: 0]			
		.tpem_link_cmnd_data			(tpem_link_cmnd_data	),//input		[31: 0]	

		.tpem_xdat_cmnd_indx			(tpem_xdat_cmnd_indx	),//output		[ 3: 0]			
		.tpem_xdat_cmnd_data			(tpem_xdat_cmnd_data	),//input		[31: 0]	

		.tpem_scfg_cmnd_indx			(tpem_scfg_cmnd_indx	),//input		[ 0: 3]		
		.tpem_scfg_cmnd_data			(tpem_scfg_cmnd_data	),//output		[31: 0]		

		.tpes_link_acks_wrcs			(tpes_link_acks_wrcs	),//output		[ 0: 7]			
		.tpes_link_acks_data			(tpes_link_acks_data	),//output		[ 0: 7][31: 0]	

		.scut_acks_memo_indx			(scut_acks_memo_indx	),//input		[ 2: 0]	
		.scut_acks_memo_data			(scut_acks_memo_data	),//output		[31: 0]	

		.llmb_mast_ddrs_base			(llmb_mast_ddrs_base	),//input		[24: 0]	
		.llmb_mtrx_imag_cols			(llmb_mtrx_imag_cols	),//input		[19: 0]	
		.llmb_meta_imag_rows			(llmb_meta_imag_rows	),//input		[19: 0]	
		.llmb_meta_imag_cols			(llmb_meta_imag_cols	),//input		[19: 0]	

		.llmb_edge_imag_size			(llmb_edge_imag_size	),//input		[24: 0]	
		.llmb_edge_imag_rows			(llmb_edge_imag_rows	),//input		[19: 0]	
		.llmb_edge_imag_cols			(llmb_edge_imag_cols	),//input		[19: 0]	
		.llmb_edge_imag_even			(llmb_edge_imag_even	),//input				
		.llmb_edge_imag_row2			(llmb_edge_imag_row2	),//input				

		.ubus_tpem_wdma_csen			(ubus_tpem_wdma_csen	),//output				
		.ubus_tpem_wdma_addr			(ubus_tpem_wdma_addr	),//output		[ 24: 0]
		.ubus_tpem_wdma_data			(ubus_tpem_wdma_data	),//output		[255: 0]
		.ubus_tpem_wdma_trdy			(ubus_tpem_wdma_trdy	),//input				
		.ubus_tpem_wdma_wrdy			(ubus_tpem_wdma_wrdy	),//input				

		.ubus_tpem_rdma_csen			(ubus_tpem_rdma_csen	),//output				
		.ubus_tpem_rdma_addr			(ubus_tpem_rdma_addr	),//output		[ 24: 0]
		.ubus_tpem_rdma_trdy			(ubus_tpem_rdma_trdy	),//input				
		.ubus_tpem_rdma_data			(ubus_tpem_rdma_data	),//input		[255: 0]
		.ubus_tpem_rdma_drdy			(ubus_tpem_rdma_drdy	),//input				

		.tpgs_scut_tpem_fram			(tpgs_scut_tpem_fram	),//input		[ 7: 0]	
		.tpgs_scut_tpem_dat0			(tpgs_scut_tpem_dat0	),//input		[ 7: 0]	
		.tpgs_scut_tpem_dat1			(tpgs_scut_tpem_dat1	),//input		[ 7: 0]	
		.tpgs_scut_tpem_dat2			(tpgs_scut_tpem_dat2	),//input		[ 7: 0]	
		.tpgs_scut_tpem_dat3			(tpgs_scut_tpem_dat3	),//input		[ 7: 0]	

		.tpem_scut_tpgs_fram			(tpem_scut_tpgs_fram	),//output		[ 7: 0]	
		.tpem_scut_tpgs_dat3			(tpem_scut_tpgs_dat3	),//output		[ 7: 0]	
		.tpem_scut_tpgs_dat2			(tpem_scut_tpgs_dat2	),//output		[ 7: 0]	
		.tpem_scut_tpgs_dat1			(tpem_scut_tpgs_dat1	),//output		[ 7: 0]	
		.tpem_scut_tpgs_dat0			(tpem_scut_tpgs_dat0	),//output		[ 7: 0]	

		.tpem_clki						(link_sclk				),//input	
		.tpem_rstn						(link_rstn				),
		.ubus_clki						(ubus_clki				),//input	
		.ubus_rstn						(ubus_rstn				));	//input	
/**********************************************************************************************************/
//TPGS LINK CTRL
	tpgs_link_esse_unit				u_tpgs_link_esse_unit(
		.tpgs_link_port_idle			(tpgs_link_port_idle	),//output	
		.tpgs_link_port_init			(tpgs_link_port_init	),//input	

		.tpgs_port_txdo_fram			(tpgs_port_txdo_fram	),//output		[ 7: 0]	
		.tpgs_port_txdo_dat0			(tpgs_port_txdo_dat0	),//output		[ 7: 0]	
		.tpgs_port_txdo_dat1			(tpgs_port_txdo_dat1	),//output		[ 7: 0]	
		.tpgs_port_txdo_dat2			(tpgs_port_txdo_dat2	),//output		[ 7: 0]	
		.tpgs_port_txdo_dat3			(tpgs_port_txdo_dat3	),//output		[ 7: 0]	

		.tpgs_port_rxdi_fram			(tpgs_port_rxdi_fram	),//input		[ 7: 0]	
		.tpgs_port_rxdi_dat0			(tpgs_port_rxdi_dat0	),//input		[ 7: 0]	
		.tpgs_port_rxdi_dat1			(tpgs_port_rxdi_dat1	),//input		[ 7: 0]	
		.tpgs_port_rxdi_dat2			(tpgs_port_rxdi_dat2	),//input		[ 7: 0]	
		.tpgs_port_rxdi_dat3			(tpgs_port_rxdi_dat3	),//input		[ 7: 0]	

		.tpgs_txdo_acks_reqs			(tpgs_txdo_acks_reqs	),//input				
		.tpgs_txdo_resp_reqs			(tpgs_txdo_resp_reqs	),//input				
		.tpgs_txdo_acks_done			(tpgs_txdo_acks_done	),//output					
		.tpgs_txdo_resp_done			(tpgs_txdo_resp_done	),//output				

		.tpgs_txdo_acks_indx			(tpgs_txdo_acks_indx	),//output		[ 3: 0]
		.tpgs_txdo_acks_data			(tpgs_txdo_acks_data	),//input		[31: 0]
		.tpgs_txdo_resp_indx			(						),//output		[ 3: 0]	
		.tpgs_txdo_resp_data			(32'H0					),//input		[31: 0]	

		.tpgs_rxdi_cmnd_lead			(tpgs_rxdi_cmnd_lead	),//output				
		.tpgs_rxdi_cmnd_wrcs			(tpgs_rxdi_cmnd_wrcs	),//output				
		.tpgs_rxdi_cmnd_coda			(tpgs_rxdi_cmnd_coda	),//output				
		.tpgs_rxdi_data_word			(tpgs_rxdi_data_word	),//output		[31: 0]	

		.tpgs_rxdi_trim_mark			(tpgs_rxdi_trim_mark	),//output//1
		.tpgs_rxdi_icfg_mark			(tpgs_rxdi_icfg_mark	),//output//1
		.tpgs_rxdi_ocfg_mark			(tpgs_rxdi_ocfg_mark	),//output//1
		.tpgs_rxdi_nnex_mark			(tpgs_rxdi_nnex_mark	),//output//2
		.tpgs_rxdi_ivct_mark			(tpgs_rxdi_ivct_mark	),//output//3
		.tpgs_rxdi_ovct_mark			(tpgs_rxdi_ovct_mark	),//output//4
		.tpgs_rxdi_imtx_mark			(tpgs_rxdi_imtx_mark	),//output//5
		.tpgs_rxdi_omtx_mark			(tpgs_rxdi_omtx_mark	),//output//6
		.tpgs_rxdi_rivt_mark			(tpgs_rxdi_rivt_mark	),//output//7
		.tpgs_rxdi_rovt_mark			(tpgs_rxdi_rovt_mark	),//output//8
		.tpgs_rxdi_rimt_mark			(tpgs_rxdi_rimt_mark	),//output//9
		.tpgs_rxdi_romt_mark			(tpgs_rxdi_romt_mark	),//output//10
		.tpgs_rxdi_risv_mark			(tpgs_rxdi_risv_mark	),//output//11
		.tpgs_rxdi_rosv_mark			(tpgs_rxdi_rosv_mark	),//output//12
		.tpgs_rxdi_rism_mark			(tpgs_rxdi_rism_mark	),//output//11
		.tpgs_rxdi_rosm_mark			(tpgs_rxdi_rosm_mark	),//output//12
		.tpgs_rxdi_aset_mark			(tpgs_rxdi_aset_mark	),//output//13
		.tpgs_rxdi_dnld_mark			(tpgs_rxdi_dnld_mark	),//output//14
		.tpgs_rxdi_boot_mark			(tpgs_rxdi_boot_mark	),//output//15
		.tpgs_rxdi_auxi_mark			(tpgs_rxdi_auxi_mark	),//output//16	//-----SPLIT LINE------//

		.llmb_devs_ddrs_base			(llmb_devs_ddrs_base	),//input		[24: 0]	
		.llmb_meta_imag_rows			(llmb_meta_imag_rows	),//input		[19: 0]	
		.llmb_meta_imag_cols			(llmb_meta_imag_cols	),//input		[19: 0]	
		.llmb_edge_imag_rows			(llmb_edge_imag_rows	),//input		[19: 0]	
		.llmb_edge_imag_cols			(llmb_edge_imag_cols	),//input		[19: 0]	

		.tpgs_idat_wdma_enab			(tpgs_idat_wdma_enab	),//input				
		.tpgs_idat_wdma_done			(tpgs_idat_wdma_done	),//input				
		.tpgs_odat_rdma_enab			(tpgs_odat_rdma_enab	),//input				
		.tpgs_odat_rdma_done			(tpgs_odat_rdma_done	),//input				

		.tpgs_link_scut_enab			(tpgs_link_scut_enab	),//input
		.tpem_scut_tpgs_fram			(tpem_scut_tpgs_fram	),//input		[ 7: 0]	
		.tpem_scut_tpgs_dat3			(tpem_scut_tpgs_dat3	),//input		[ 7: 0]	
		.tpem_scut_tpgs_dat2			(tpem_scut_tpgs_dat2	),//input		[ 7: 0]	
		.tpem_scut_tpgs_dat1			(tpem_scut_tpgs_dat1	),//input		[ 7: 0]	
		.tpem_scut_tpgs_dat0			(tpem_scut_tpgs_dat0	),//input		[ 7: 0]	

		.tpgs_scut_tpem_fram			(tpgs_scut_tpem_fram	),//output		[ 7: 0]	
		.tpgs_scut_tpem_dat3			(tpgs_scut_tpem_dat3	),//output		[ 7: 0]	
		.tpgs_scut_tpem_dat2			(tpgs_scut_tpem_dat2	),//output		[ 7: 0]	
		.tpgs_scut_tpem_dat1			(tpgs_scut_tpem_dat1	),//output		[ 7: 0]	
		.tpgs_scut_tpem_dat0			(tpgs_scut_tpem_dat0	),//output		[ 7: 0]	

		.ubus_tpgs_wdma_csen			(ubus_tpgs_wdma_csen	),//output				
		.ubus_tpgs_wdma_addr			(ubus_tpgs_wdma_addr	),//output		[ 24: 0]
		.ubus_tpgs_wdma_data			(ubus_tpgs_wdma_data	),//output		[255: 0]
		.ubus_tpgs_wdma_trdy			(ubus_tpgs_wdma_trdy	),//input				
		.ubus_tpgs_wdma_wrdy			(ubus_tpgs_wdma_wrdy	),//input				

		.ubus_tpgs_rdma_csen			(ubus_tpgs_rdma_csen	),//output	reg			
		.ubus_tpgs_rdma_addr			(ubus_tpgs_rdma_addr	),//output	reg	[ 24: 0]
		.ubus_tpgs_rdma_trdy			(ubus_tpgs_rdma_trdy	),//input				
		.ubus_tpgs_rdma_data			(ubus_tpgs_rdma_data	),//input		[255: 0]
		.ubus_tpgs_rdma_drdy			(ubus_tpgs_rdma_drdy	),//input				

		.ubus_clki						(ubus_clki				),	//input	
		.ubus_rstn						(ubus_rstn				),	//input	
		.tpgs_sclk						(link_sclk				),	//input	
		.tpgs_rstn						(link_rstn				));	//input			
/**********************************************************************************************************/
//MGTH MASTER LINK CTRL
 	mgth_isde_link_dmau				u_mgth_isde_link_dmau(
		.sdes_link_isde_done			(sdes_link_isde_done	),//output				
		.sdes_link_isde_enab			(sdes_link_isde_enab	),//input				
		.sdes_link_isde_csid			(sdes_link_mgth_csid	),//input		[ 3: 0]	
		.sdes_link_ddrs_size			(sdes_link_ddrs_size	),//input		[24: 0]	
		.sdes_meta_ddrs_base			(sdes_meta_ddrs_base	),//input		[24: 0]	
		.sdes_meta_cols_dims			(sdes_meta_cols_dims	),//input		[15: 0]	
		.sdes_hubs_cols_dims			(sdes_hubs_cols_dims	),//input		[15: 0]	
		
		.link_clki						(link_sclk				),//input					
		.link_rstn						(link_rstn				),	//input					


		.mgt1_isde_rxdi_drdy			(mgt1_isde_wdma_drdy	),//input				
		.mgt1_isde_rxdi_data			(mgt1_isde_wdma_data	),//input		[255:0]	
		.mgt1_clki						(mgt1_clki				),//input				
		.mgt1_rstn						(mgt1_rstn				),//input				

		.mgt2_isde_rxdi_drdy			(mgt2_isde_wdma_drdy	),//input				
		.mgt2_isde_rxdi_data			(mgt2_isde_wdma_data	),//input		[255:0]	
		.mgt2_clki						(mgt2_clki				),//input				
		.mgt2_rstn						(mgt2_rstn				),//input				

		.mgt3_isde_rxdi_drdy			(mgt3_isde_wdma_drdy	),//input				
		.mgt3_isde_rxdi_data			(mgt3_isde_wdma_data	),//input		[255:0]	
		.mgt3_clki						(mgt3_clki				),//input				
		.mgt3_rstn						(mgt3_rstn				),//input				

		.ubus_isde_wdma_csen			(ubus_isde_wdma_csen	),//output				
		.ubus_isde_wdma_addr			(ubus_isde_wdma_addr	),//output		[ 24: 0]
		.ubus_isde_wdma_data			(ubus_isde_wdma_data	),//output		[255: 0]
		.ubus_isde_wdma_trdy			(ubus_isde_wdma_trdy	),//input				
		.ubus_isde_wdma_wrdy			(ubus_isde_wdma_wrdy	),//input				
		.ubus_clki						(ubus_clki				),//input				
		.ubus_rstn						(ubus_rstn				));//input				


endmodule
  