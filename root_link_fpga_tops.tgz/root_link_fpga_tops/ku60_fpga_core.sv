module	ku60_fpga_core(
	input								chip_clki			,
	output								link_cclk			,			
/**********************************************************************************************************/
	output								mgt1_pmau_init_ctrl	,
	output								mgt1_rstb_push_ctrl	,
	input								mgt1_intf_link_stat	,
	input		[255: 0]				mgt1_isde_wdma_data	,
    input								mgt1_isde_wdma_drdy	,
	input								mgt1_clki			,

	output								mgt2_pmau_init_ctrl	,
	output								mgt2_rstb_push_ctrl	,
	input								mgt2_intf_link_stat	,
	input		[255: 0]				mgt2_isde_wdma_data	,
    input								mgt2_isde_wdma_drdy	,
	input								mgt2_clki			,

	output								mgt3_pmau_init_ctrl	,
	output								mgt3_rstb_push_ctrl	,
	input								mgt3_intf_link_stat	,
	input		[255: 0]				mgt3_isde_wdma_data	,
    input								mgt3_isde_wdma_drdy	,
	input								mgt3_clki			,
/**********************************************************************************************************/
   	output 		[ 9: 0]  				c0_lpddr3_ca		,
   	output 		[ 0: 0]  				c0_lpddr3_ck_t		,      
   	output 		[ 0: 0]  				c0_lpddr3_ck_c		,
   	output 		[ 0: 0]  				c0_lpddr3_cs_n		, 
   	output 		[ 0: 0]	 				c0_lpddr3_cke		,
   	output 		[ 0: 0]	 				c0_lpddr3_odt		,
   	inout  		[31: 0]  				c0_lpddr3_dq		,
   	inout  		[ 3: 0]  				c0_lpddr3_dqs_t		,
   	inout  		[ 3: 0]  				c0_lpddr3_dqs_c		,
   	output 		[ 3: 0]  				c0_lpddr3_dm		,
/**********************************************************************************************************/
	output	[255: 0]					pcie_axis_read_data	,
	output								pcie_axis_read_last	,
	output								pcie_axis_read_vlid	,
	input								pcie_axis_read_trdy	,
	input	[255: 0]					pcie_axis_writ_data	,
	input								pcie_axis_writ_last	,
	input								pcie_axis_writ_vlid	,
	output								pcie_axis_writ_trdy	,	
	input								pcie_aclk			,

	input								pcie_bram_csen		,
	input								pcie_bram_wben		,
	input	[ 19: 0]					pcie_bram_addr		,
	input	[ 31: 0]					pcie_bram_wdata		,
	output	[ 31: 0]					pcie_bram_rdata		,
	input								pcie_bclk			,
	input								pcie_rstn			,	
/**********************************************************************************************************/
	output		[ 1: 3]					tpgm_link_rstn_outp	,
	output		[ 1: 3]					tpgm_link_rstn_outn	,

	output		[ 1: 3]					tpgm_link_tune_rxdi	,
	output		[ 1: 3]					tpgm_link_tune_txdo	,

	output		[ 1: 3]					tpgm_link_fclk_outp	,
	output		[ 1: 3]					tpgm_link_fclk_outn	,
	output		[ 1: 3]					tpgm_link_fram_outp	,
	output		[ 1: 3]					tpgm_link_fram_outn	,
	output		[ 1: 3]					tpgm_link_dat0_outp	,
	output		[ 1: 3]					tpgm_link_dat0_outn	,
	output		[ 1: 3]					tpgm_link_dat1_outp	,
	output		[ 1: 3]					tpgm_link_dat1_outn	,
	output		[ 1: 3]					tpgm_link_dat2_outp	,
	output		[ 1: 3]					tpgm_link_dat2_outn	,
	output		[ 1: 3]					tpgm_link_dat3_outp	,
	output		[ 1: 3]					tpgm_link_dat3_outn	,

	input		[ 1: 3]					tpgs_link_fclk_inpp	,
	input		[ 1: 3]					tpgs_link_fclk_inpn	,
	input		[ 1: 3]					tpgs_link_fram_inpp	,
	input		[ 1: 3]					tpgs_link_fram_inpn	,
	input		[ 1: 3]					tpgs_link_dat0_inpp	,
	input		[ 1: 3]					tpgs_link_dat0_inpn	,
	input		[ 1: 3]					tpgs_link_dat1_inpp	,
	input		[ 1: 3]					tpgs_link_dat1_inpn	,
	input		[ 1: 3]					tpgs_link_dat2_inpp	,
	input		[ 1: 3]					tpgs_link_dat2_inpn	,
	input		[ 1: 3]					tpgs_link_dat3_inpp	,
	input		[ 1: 3]					tpgs_link_dat3_inpn	,
/**********************************************************************************************************/
	output		[ 0: 7]					tpem_link_rstn_outp	,
	input		[ 0: 7]					slx9_link_ilas_inpp	,

	output		[ 0: 7]					tpem_tune_txdo_mode	,
	output		[ 0: 7]					tpem_tune_rxdi_mode	,

	output		[ 0: 7]					tpem_link_fclk_outp	,
	output		[ 0: 7]					tpem_link_fclk_outn	,
	output		[ 0: 7]					tpem_link_fram_outp	,
	output		[ 0: 7]					tpem_link_fram_outn	,
	output		[ 0: 7]					tpem_link_dat0_outp	,
	output		[ 0: 7]					tpem_link_dat0_outn	,
	output		[ 0: 7]					tpem_link_dat1_outp	,
	output		[ 0: 7]					tpem_link_dat1_outn	,
	output		[ 0: 7]					tpem_link_dat2_outp	,
	output		[ 0: 7]					tpem_link_dat2_outn	,
	output		[ 0: 7]					tpem_link_dat3_outp	,
	output		[ 0: 7]					tpem_link_dat3_outn	,

	input		[ 0: 7]					tpes_link_fclk_inpp	,
	input		[ 0: 7]					tpes_link_fclk_inpn	,
	input		[ 0: 7]					tpes_link_fram_inpp	,
	input		[ 0: 7]					tpes_link_fram_inpn	,
	input		[ 0: 7]					tpes_link_dat0_inpp	,
	input		[ 0: 7]					tpes_link_dat0_inpn	,
	input		[ 0: 7]					tpes_link_dat1_inpp	,
	input		[ 0: 7]					tpes_link_dat1_inpn	,
	input		[ 0: 7]					tpes_link_dat2_inpp	,
	input		[ 0: 7]					tpes_link_dat2_inpn	,
	input		[ 0: 7]					tpes_link_dat3_inpp	,
	input		[ 0: 7]					tpes_link_dat3_inpn	,

	output		[ 0: 7]					tpem_scfg_prog_outp	,
	output		[ 0: 7]					tpem_scfg_cclk_outp	,
	output		[ 0: 7]					tpem_scfg_data_outp	,
	input		[ 0: 7]					tpem_scfg_init_inpp	,
	input		[ 0: 7]					tpem_scfg_done_inpp	);
/**********************************************************************************************************************/
	wire								tpgm_rstn_gens	;
	
	wire								link_fclk	;
	wire								link_sclk	;
	wire								link_strb	;
	
	wire								link_rstn	;
	wire								chip_rstn	;
	wire								dlys_rstn	;
//------------------------------------------------------------------------------
	xcku_sysclk						u_xcku_clks_gens(	
		.link_fclk						(link_fclk			),//output	
		.link_sclk						(link_sclk			),//output	
		.link_cclk						(link_cclk			),//output	
		
		.link_rstn						(link_rstn			),//output	
		.chip_rstn						(chip_rstn			),//output	
		.dlys_rstn						(dlys_rstn			),//output	
		
		.auxi_rstn						(tpgm_rstn_gens		),//input	
		.cold_rstn						(pcie_rstn			),//input	
		.chip_clki						(chip_clki			));//input	
//------------------------------------------------------------------------------
	wire								dlys_brst			;
	wire								tpgm_dlys_ctrl_drdy	;

	ku60_dlys_ctrl					u_ku60_dlys_ctrl(
		.dlys_brst						(dlys_brst			),//output		reg	
		.dlys_drdy						(tpgm_dlys_ctrl_drdy),//output			
		.dlys_fclk						(link_fclk			),//input			
		.dlys_sclk						(link_sclk			),//input			
		.dlys_rstn						(dlys_rstn			));//input			
//------------------------------------------------------------------------------
	(*MARK_DEBUG = "TRUE"*)				reg		[ 0: 7]		ilas_slx9_moni	;//=	slx9_link_ilas_inpp	;
	always@(posedge link_sclk)			ilas_slx9_moni	<=	slx9_link_ilas_inpp	;
/**********************************************************************************************************************/
//DECLARE-BEGIN :: TPGM_LVDS_LINK
	wire		[ 3: 0]					tpgm_link_port_enab	;

	wire		[0:3][7:0]				tpgm_port_txdo_fram	;
	wire		[0:3][7:0]				tpgm_port_txdo_dat0	;
	wire		[0:3][7:0]				tpgm_port_txdo_dat1	;
	wire		[0:3][7:0]				tpgm_port_txdo_dat2	;
	wire		[0:3][7:0]				tpgm_port_txdo_dat3	;

	wire		[0:3]					tpgm_port_rxdi_lead	;
	wire		[0:3]					tpgm_port_rxdi_coda	;
	wire		[0:3]					tpgm_port_rxdi_body	;
	wire		[0:3][7:0]				tpgm_port_rxdi_fram	;
	wire		[0:3][7:0]				tpgm_port_rxdi_dat0	;
	wire		[0:3][7:0]				tpgm_port_rxdi_dat1	;
	wire		[0:3][7:0]				tpgm_port_rxdi_dat2	;
	wire		[0:3][7:0]				tpgm_port_rxdi_dat3	;


	
	wire		[  1: 3]				pcie_tune_txdo_enab	;	
	wire		[  1: 3][ 8:0]			pcie_tune_txdo_taps	;	
	wire		[  1: 3]				pcie_tune_txdo_done	;	

	wire		[  1: 3]				pcie_tune_rxdi_enab	;	
	wire		[  1: 3][ 8:0]			pcie_tune_rxdi_taps	;	
	wire		[  1: 3]				pcie_tune_rxdi_done	;	
	wire		[  1: 3][ 9:0]			pcie_tune_rxdi_stat	;	

	gens_sync_rstn					u_tpgm_rstn_gens(
    	.rstn_gens						(tpgm_rstn	),//output		
		.rstn_reqs						(link_rstn	),//input		
		.main_clki						(link_sclk	));//input		
/**********************************************************************************************************************/
for(genvar i = 1 ; i < 4 ; i++)		begin:gens_tpgm_link_port

	OBUFDS							u_tpgm_link_rstn(
		.I								(tpgm_rstn				),
		.O								(tpgm_link_rstn_outp[i]	),
		.OB								(tpgm_link_rstn_outn[i]	));

	link_root_rxdi_pmau				u_tpgm_link_rxdi_pmau(
		.host_tune_rxdi_enab			(pcie_tune_rxdi_enab[i]		),//input				
		.host_tune_rxdi_taps			(pcie_tune_rxdi_taps[i]		),//input		[ 8: 0]	
		.host_tune_rxdi_done			(pcie_tune_rxdi_done[i]		),//output				
		.host_tune_rxdi_stat			(pcie_tune_rxdi_stat[i]		),//output		[10: 0]	
		.host_clki						(pcie_bclk				),//input				
		.host_rstn						(link_rstn				),//input				
		
		.root_tune_rxdi					(tpgm_link_tune_rxdi[i]	),
		
		.lane_fclk_inpp					(tpgs_link_fclk_inpp[i]	),//input	
		.lane_fclk_inpn					(tpgs_link_fclk_inpn[i]	),//input	
		.lane_fram_inpp					(tpgs_link_fram_inpp[i]	),//input	
		.lane_fram_inpn					(tpgs_link_fram_inpn[i]	),//input	
		.lane_dat0_inpp					(tpgs_link_dat0_inpp[i]	),//input	
		.lane_dat0_inpn					(tpgs_link_dat0_inpn[i]	),//input	
		.lane_dat1_inpp					(tpgs_link_dat1_inpp[i]	),//input	
		.lane_dat1_inpn					(tpgs_link_dat1_inpn[i]	),//input	
		.lane_dat2_inpp					(tpgs_link_dat2_inpp[i]	),//input	
		.lane_dat2_inpn					(tpgs_link_dat2_inpn[i]	),//input	
		.lane_dat3_inpp					(tpgs_link_dat3_inpp[i]	),//input	
		.lane_dat3_inpn					(tpgs_link_dat3_inpn[i]	),//input	
		
		.pmau_fram_lead					(tpgm_port_rxdi_lead[i]	),//output	reg	[ 7: 0]	
		.pmau_fram_body					(tpgm_port_rxdi_body[i]	),//output	reg	[ 7: 0]	
		.pmau_fram_coda					(tpgm_port_rxdi_coda[i]	),//output	reg	[ 7: 0]	
		.pmau_fram_mbdo					(tpgm_port_rxdi_fram[i]	),//output	reg	[ 7: 0]	
		.pmau_dat0_mbdo					(tpgm_port_rxdi_dat0[i]	),//output	reg	[ 7: 0]	
		.pmau_dat1_mbdo					(tpgm_port_rxdi_dat1[i]	),//output	reg	[ 7: 0]	
		.pmau_dat2_mbdo					(tpgm_port_rxdi_dat2[i]	),//output	reg	[ 7: 0]	
		.pmau_dat3_mbdo					(tpgm_port_rxdi_dat3[i]	),//output	reg	[ 7: 0]	

		.dlys_brst						(dlys_brst				),//output	
		.link_sclk						(link_sclk				),//input	
		.link_rstn						(tpgm_rstn				));//input	

	link_root_txdo_pmau				u_tpgm_link_txdo_pmau(
		.host_tune_txdo_enab			(pcie_tune_txdo_enab[i]		),//input				
		.host_tune_txdo_taps			(pcie_tune_txdo_taps[i]		),//input		[ 8: 0]	
		.host_tune_txdo_done			(pcie_tune_txdo_done[i]		),//output				
		.host_clki						(pcie_bclk				),//input				
		.host_rstn						(link_rstn				),//input				

		.root_tune_txdo					(tpgm_link_tune_txdo[i]	),

		.lane_fclk_outp					(tpgm_link_fclk_outp[i]	),//output			
		.lane_fclk_outn					(tpgm_link_fclk_outn[i]	),//output			
		.lane_fram_outp					(tpgm_link_fram_outp[i]	),//output			
		.lane_fram_outn					(tpgm_link_fram_outn[i]	),//output			
		.lane_dat0_outp					(tpgm_link_dat0_outp[i]	),//output			
		.lane_dat0_outn					(tpgm_link_dat0_outn[i]	),//output			
		.lane_dat1_outp					(tpgm_link_dat1_outp[i]	),//output			
		.lane_dat1_outn					(tpgm_link_dat1_outn[i]	),//output			
		.lane_dat2_outp					(tpgm_link_dat2_outp[i]	),//output			
		.lane_dat2_outn					(tpgm_link_dat2_outn[i]	),//output			
		.lane_dat3_outp					(tpgm_link_dat3_outp[i]	),//output			
		.lane_dat3_outn					(tpgm_link_dat3_outn[i]	),//output			
		
		.pmau_fram_mbdi					(tpgm_port_txdo_fram[i]	),//input	[7:0]	
		.pmau_dat0_mbdi					(tpgm_port_txdo_dat0[i]	),//input	[7:0]	
		.pmau_dat1_mbdi					(tpgm_port_txdo_dat1[i]	),//input	[7:0]	
		.pmau_dat2_mbdi					(tpgm_port_txdo_dat2[i]	),//input	[7:0]	
		.pmau_dat3_mbdi					(tpgm_port_txdo_dat3[i]	),//input	[7:0]	

		.dlys_brst						(dlys_brst				),//output	
		.link_fclk						(link_fclk				),//input	
		.link_sclk						(link_sclk				),//input	
		.link_rstn						(tpgm_rstn				));//input	
end
/**********************************************************************************************************/
//DECLARE-BEGIN :: TPEM_LVDS_PORT
	wire	[ 0: 7]						tpem_link_port_rstn	;
	wire	[ 0: 7]						tpem_link_port_rxen	;
	
	wire	[ 0: 7][ 7: 0]				tpem_port_txdo_fram	;
	wire	[ 0: 7][ 7: 0]				tpem_port_txdo_dat0	;
	wire	[ 0: 7][ 7: 0]				tpem_port_txdo_dat1	;
	wire	[ 0: 7][ 7: 0]				tpem_port_txdo_dat2	;
	wire	[ 0: 7][ 7: 0]				tpem_port_txdo_dat3	;

	wire	[ 7: 0]						tpem_port_rxdi_lead	;
	wire	[ 7: 0]						tpem_port_rxdi_body	;
	wire	[ 7: 0]						tpem_port_rxdi_coda	;

	wire	[ 0: 7][ 7: 0]				tpem_port_rxdi_dat0	;
	wire	[ 0: 7][ 7: 0]				tpem_port_rxdi_dat1	;
	wire	[ 0: 7][ 7: 0]				tpem_port_rxdi_dat2	;
	wire	[ 0: 7][ 7: 0]				tpem_port_rxdi_dat3	;

	wire	[ 0: 7]						tpem_tune_txdo_enab	;	
	wire	[ 0: 7][ 8:0]				tpem_tune_txdo_taps	;	
	wire	[ 0: 7]						tpem_tune_txdo_done	;	

	wire	[ 0: 7]						tpem_tune_rxdi_reqs	;
	wire	[ 0: 7]						tpem_tune_rxdi_enab	;	
	wire	[ 0: 7][ 8:0]				tpem_tune_rxdi_taps	;	
	wire	[ 0: 7]						tpem_tune_rxdi_done	;	
	wire	[ 0: 7][ 9:0]				tpem_tune_rxdi_stat	;	

	wire								tpem_sync_rxdi_reqs	;
	wire	[ 0: 7]						tpem_sync_rxdi_done	;
	
	gens_sync_rstn				tpem_rstn_gens(
    	.rstn_gens						(tpem_rstn	),//output		
		.rstn_reqs						(link_rstn	),//input		
		.main_clki						(link_sclk	));//input		
/**********************************************************************************************************/
	for(genvar j = 0 ; j < 8 ; j++)		begin:gens_tpem_link_port
		
		assign  tpem_link_rstn_outp[j] 	=	tpem_link_port_rstn[j]	& tpem_rstn	;

		link_edge_rxdi_pmau			u_tpem_link_rxdi_pmau(
			.host_tune_rxdi_mode		(tpem_tune_rxdi_reqs[j]	),//input				
			.host_tune_rxdi_enab		(tpem_tune_rxdi_enab[j]	),//input				
			.host_tune_rxdi_taps		(tpem_tune_rxdi_taps[j]	),//input		[ 8: 0]	
			.host_tune_rxdi_done		(tpem_tune_rxdi_done[j]	),//output				
			.host_tune_rxdi_stat		(tpem_tune_rxdi_stat[j]	),//output		[10: 0]	
			
			.host_sync_rxdi_reqs		(tpem_sync_rxdi_reqs	),//output		[10: 0]	
			.host_sync_rxdi_done		(tpem_sync_rxdi_done[j]	),//output				

			.host_data_rxdi_enab		(tpem_link_port_rxen[j]	),//output	[ 0: 7]

			.host_clki					(link_sclk				),//input				
			.host_rstn					(link_rstn				),//input				

			.lane_tune_rxdi				(tpem_tune_rxdi_mode[j]	),//input	

			.lane_fclk_inpp				(tpes_link_fclk_inpp[j]	),//input	
			.lane_fclk_inpn				(tpes_link_fclk_inpn[j]	),//input	
			.lane_fram_inpp				(tpes_link_fram_inpp[j]	),//input	
			.lane_fram_inpn				(tpes_link_fram_inpn[j]	),//input	
			.lane_dat0_inpp				(tpes_link_dat0_inpp[j]	),//input	
			.lane_dat0_inpn				(tpes_link_dat0_inpn[j]	),//input	
			.lane_dat1_inpp				(tpes_link_dat1_inpp[j]	),//input	
			.lane_dat1_inpn				(tpes_link_dat1_inpn[j]	),//input	
			.lane_dat2_inpp				(tpes_link_dat2_inpp[j]	),//input	
			.lane_dat2_inpn				(tpes_link_dat2_inpn[j]	),//input	
			.lane_dat3_inpp				(tpes_link_dat3_inpp[j]	),//input	
			.lane_dat3_inpn				(tpes_link_dat3_inpn[j]	),//input	

			.pmau_fram_lead				(tpem_port_rxdi_lead[j]	),//output	reg	[ 7: 0]	
			.pmau_fram_body				(tpem_port_rxdi_body[j]	),//output	reg	[ 7: 0]	
			.pmau_fram_coda				(tpem_port_rxdi_coda[j]	),//output	reg	[ 7: 0]	
			.pmau_dat0_mbdo				(tpem_port_rxdi_dat0[j]	),//output	reg	[ 7: 0]	
			.pmau_dat1_mbdo				(tpem_port_rxdi_dat1[j]	),//output	reg	[ 7: 0]	
			.pmau_dat2_mbdo				(tpem_port_rxdi_dat2[j]	),//output	reg	[ 7: 0]	
			.pmau_dat3_mbdo				(tpem_port_rxdi_dat3[j]	),//output	reg	[ 7: 0]	

			.dlys_brst					( dlys_brst				),//output	
			.link_sclk					( link_sclk				),//input	
			.link_rstn					( tpem_rstn				));//input	

		link_edge_txdo_pmau			u_tpem_link_txdo_pmau(
			
			.host_tune_txdo_enab		(tpem_tune_txdo_enab[j]		),//input				
			.host_tune_txdo_taps		(tpem_tune_txdo_taps[j]		),//input		[ 8: 0]	
			.host_tune_txdo_done		(tpem_tune_txdo_done[j]		),//output				
			.host_clki					(link_sclk				),//input				
			.host_rstn					(link_rstn				),//input				

			.root_tune_txdo				(tpem_tune_txdo_mode[j]	),
			
			.lane_fclk_outp				(tpem_link_fclk_outp[j]	),//output			
			.lane_fclk_outn				(tpem_link_fclk_outn[j]	),//output			
			.lane_fram_outp				(tpem_link_fram_outp[j]	),//output			
			.lane_fram_outn				(tpem_link_fram_outn[j]	),//output			
			.lane_dat0_outp				(tpem_link_dat0_outp[j]	),//output			
			.lane_dat0_outn				(tpem_link_dat0_outn[j]	),//output			
			.lane_dat1_outp				(tpem_link_dat1_outp[j]	),//output			
			.lane_dat1_outn				(tpem_link_dat1_outn[j]	),//output			
			.lane_dat2_outp				(tpem_link_dat2_outp[j]	),//output			
			.lane_dat2_outn				(tpem_link_dat2_outn[j]	),//output			
			.lane_dat3_outp				(tpem_link_dat3_outp[j]	),//output			
			.lane_dat3_outn				(tpem_link_dat3_outn[j]	),//output		

			.pmau_fram_mbdi				(tpem_port_txdo_fram[j]	),//output	[7:0]	
			.pmau_dat0_mbdi				(tpem_port_txdo_dat0[j]	),//output	[7:0]	
			.pmau_dat1_mbdi				(tpem_port_txdo_dat1[j]	),//output	[7:0]	
			.pmau_dat2_mbdi				(tpem_port_txdo_dat2[j]	),//output	[7:0]	
			.pmau_dat3_mbdi				(tpem_port_txdo_dat3[j]	),//output	[7:0]	

		//	.dlys_brst					( dlys_brst				),//output	
			.link_fclk					( link_fclk				),//input	
			.link_sclk					( link_sclk				),//input	
			.link_rstn					( tpem_rstn				));//input	
	end
/**********************************************************************************************************************/
//DECLARE-BEGIN ::	LPDDR3
	wire								ubus_clki			;
	wire								ubus_prst			;
	wire								ubus_rstn = ~ubus_prst			;

	wire								pcie_xdma_ddrs_stat	;


	wire          						ddrs_ubus_intf_wrdy;
	wire          						ddrs_ubus_intf_trdy	;		
	wire								ddrs_ubus_intf_csen	;			
	wire	[  2:0]						ddrs_ubus_intf_cmnd	;		
	wire 	[27 :0]						ddrs_ubus_intf_addr	;
	wire 	[255:0]						ddrs_ubus_read_data	;		
	wire								ddrs_ubus_read_vlid	;		
	wire								ddrs_ubus_writ_enab	;			
	wire	[255:0]						ddrs_ubus_writ_data	;		
	wire								ddrs_ubus_writ_last	;			


	wire								ubus_pcie_wdma_csen	;
	wire	[ 24: 0]					ubus_pcie_wdma_addr	;
	wire	[255: 0]					ubus_pcie_wdma_data	;
	wire								ubus_pcie_wdma_trdy	=	ddrs_ubus_intf_trdy	;
	wire								ubus_pcie_wdma_wrdy	=	ddrs_ubus_intf_wrdy	;

	wire								ubus_pcie_rdma_csen	;
	wire	[ 24: 0]					ubus_pcie_rdma_addr	;
	wire	[255: 0]					ubus_pcie_rdma_data	=	ddrs_ubus_read_data	;
	wire								ubus_pcie_rdma_trdy	=	ddrs_ubus_intf_trdy	;
	wire								ubus_pcie_rdma_drdy	=	ddrs_ubus_read_vlid	;

	wire								ubus_tpgm_wdma_csen	;
	wire	[ 24: 0]					ubus_tpgm_wdma_addr	;
	wire	[255: 0]					ubus_tpgm_wdma_data	;
	wire								ubus_tpgm_wdma_trdy	=	ddrs_ubus_intf_trdy	;
	wire								ubus_tpgm_wdma_wrdy	=	ddrs_ubus_intf_wrdy	;

	wire								ubus_tpgm_rdma_csen	;
	wire	[ 24: 0]					ubus_tpgm_rdma_addr	;
	wire	[255: 0]					ubus_tpgm_rdma_data	=	ddrs_ubus_read_data	;
	wire								ubus_tpgm_rdma_trdy	=	ddrs_ubus_intf_trdy	;
	wire								ubus_tpgm_rdma_drdy	=	ddrs_ubus_read_vlid	;


	wire								ubus_tpgs_wdma_csen	;
	wire	[ 24: 0]					ubus_tpgs_wdma_addr	;
	wire	[255: 0]					ubus_tpgs_wdma_data	;
	wire								ubus_tpgs_wdma_trdy	=	ddrs_ubus_intf_trdy	;
	wire								ubus_tpgs_wdma_wrdy	=	ddrs_ubus_intf_wrdy	;

	wire								ubus_tpgs_rdma_csen	;
	wire	[ 24: 0]					ubus_tpgs_rdma_addr	;
	wire	[255: 0]					ubus_tpgs_rdma_data	=	ddrs_ubus_read_data	;
	wire								ubus_tpgs_rdma_trdy	=	ddrs_ubus_intf_trdy	;
	wire								ubus_tpgs_rdma_drdy	=	ddrs_ubus_read_vlid	;

	wire								ubus_tpem_wdma_csen	;
	wire	[ 24: 0]					ubus_tpem_wdma_addr	;
	wire	[255: 0]					ubus_tpem_wdma_data	;
	wire								ubus_tpem_wdma_trdy	=	ddrs_ubus_intf_trdy	;
	wire								ubus_tpem_wdma_wrdy	=	ddrs_ubus_intf_wrdy	;

	wire								ubus_tpem_rdma_csen	;
	wire	[ 24: 0]					ubus_tpem_rdma_addr	;
	wire	[255: 0]					ubus_tpem_rdma_data	=	ddrs_ubus_read_data	;
	wire								ubus_tpem_rdma_trdy	=	ddrs_ubus_intf_trdy	;
	wire								ubus_tpem_rdma_drdy	=	ddrs_ubus_read_vlid	;

	wire								ubus_isde_wdma_csen	;
	wire	[ 24: 0]					ubus_isde_wdma_addr	;
	wire	[255: 0]					ubus_isde_wdma_data	;
	wire								ubus_isde_wdma_trdy	=	ddrs_ubus_intf_trdy	;
	wire								ubus_isde_wdma_wrdy	=	ddrs_ubus_intf_wrdy	;

	wire								ubus_wdma_intf_csen	;
	wire								ubus_rdma_intf_csen	;

	assign	ubus_wdma_intf_csen	=|{		ubus_pcie_wdma_csen	, ubus_tpgm_wdma_csen ,	ubus_tpgs_wdma_csen	, ubus_tpem_wdma_csen ,	ubus_isde_wdma_csen	};
	assign	ubus_rdma_intf_csen	=|{		ubus_pcie_rdma_csen	, ubus_tpgm_rdma_csen , ubus_tpgs_rdma_csen	, ubus_tpem_rdma_csen };
	assign	ddrs_ubus_intf_csen	=		ubus_wdma_intf_csen	| ubus_rdma_intf_csen ;
	assign	ddrs_ubus_writ_enab	= 		ubus_wdma_intf_csen	;

	assign	ddrs_ubus_intf_addr	=		ubus_pcie_wdma_csen	? {	ubus_pcie_wdma_addr	, 3'H0 }:
										ubus_pcie_rdma_csen	? {	ubus_pcie_rdma_addr	, 3'H0 }:
										ubus_tpgm_wdma_csen	? {	ubus_tpgm_wdma_addr	, 3'H0 }:
										ubus_tpgm_rdma_csen	? {	ubus_tpgm_rdma_addr	, 3'H0 }:	 
										ubus_tpgs_wdma_csen	? {	ubus_tpgs_wdma_addr	, 3'H0 }:
										ubus_tpgs_rdma_csen	? {	ubus_tpgs_rdma_addr	, 3'H0 }:	 
										ubus_tpem_wdma_csen	? {	ubus_tpem_wdma_addr	, 3'H0 }:
										ubus_tpem_rdma_csen	? {	ubus_tpem_rdma_addr	, 3'H0 }:	 
										ubus_isde_wdma_csen	? {	ubus_isde_wdma_addr	, 3'H0 }:	 28'H0	;	

	assign	ddrs_ubus_writ_data	=		ubus_pcie_wdma_csen	?	ubus_pcie_wdma_data	:	
										ubus_tpgm_wdma_csen	?	ubus_tpgm_wdma_data	:	
										ubus_tpgs_wdma_csen	?	ubus_tpgs_wdma_data	:	
										ubus_tpem_wdma_csen	?	ubus_tpem_wdma_data	:	
										ubus_isde_wdma_csen	?	ubus_isde_wdma_data	:	256'H0	;

	assign	ddrs_ubus_intf_cmnd	=		ubus_wdma_intf_csen	?	3'H0	:	3'H1	;
	assign	ddrs_ubus_writ_last	= 		ubus_wdma_intf_csen	;
	
	xcku_lpddr3_256m  				u_lpddr3_256m(
    	.sys_rst						(~chip_rstn				),//INPUT
   		.c0_sys_clk_i					( chip_clki				),//INPUT
   		.c0_init_calib_complete			( tpus_link_ddrs_stat	),//OUTPUT	

    	.c0_lpddr3_ca               	(c0_lpddr3_ca			),
    	.c0_lpddr3_ck_t             	(c0_lpddr3_ck_t			),
    	.c0_lpddr3_ck_c             	(c0_lpddr3_ck_c			),
    	.c0_lpddr3_cs_n             	(c0_lpddr3_cs_n			),
    	.c0_lpddr3_cke              	(c0_lpddr3_cke			),
    	.c0_lpddr3_odt              	(c0_lpddr3_odt			),
    	.c0_lpddr3_dq               	(c0_lpddr3_dq			),
    	.c0_lpddr3_dqs_t            	(c0_lpddr3_dqs_t		),
    	.c0_lpddr3_dqs_c            	(c0_lpddr3_dqs_c		),
    	.c0_lpddr3_dm               	(c0_lpddr3_dm			),

    	.c0_lpddr3_app_rdy				(ddrs_ubus_intf_trdy	),
    	.c0_lpddr3_app_addr				(ddrs_ubus_intf_addr	),
		.c0_lpddr3_app_cmd				(ddrs_ubus_intf_cmnd	),
		.c0_lpddr3_app_en				(ddrs_ubus_intf_csen	),
		.c0_lpddr3_app_wdf_rdy			(ddrs_ubus_intf_wrdy	),
    	.c0_lpddr3_app_wdf_wren			(ddrs_ubus_writ_enab	),
    	.c0_lpddr3_app_wdf_data			(ddrs_ubus_writ_data	),
    	.c0_lpddr3_app_wdf_mask			(32'H0					),
    	.c0_lpddr3_app_wdf_end			(ddrs_ubus_writ_last	),

		.c0_lpddr3_app_rd_data			(ddrs_ubus_read_data	),
		.c0_lpddr3_app_rd_data_valid	(ddrs_ubus_read_vlid	),
		.c0_lpddr3_app_rd_data_end		(						),

	 	.c0_lpddr3_app_hi_pri			(1'b0					),
     	.dbg_clk						(						),
 		.c0_lpddr3_ui_clk				(ubus_clki				),//OUTPUT	
  		.c0_lpddr3_ui_clk_sync_rst		(ubus_prst				));//OUTPUT		
/**********************************************************************************************************************/
//DECLARE ::	PCIE XDMA MISC CONTRL
	wire		[ 24: 0]				pcie_xdma_ddrs_base	;
	wire		[ 19: 0]				pcie_xdma_rows_numb	;
	wire		[ 31: 0]				pcie_xdma_cols_numb	;
	wire								pcie_wdma_ddrs_enab	;
	wire								pcie_wdma_ddrs_done	;
	wire								pcie_rdma_ddrs_enab	;
	wire								pcie_rdma_ddrs_done	;

	gens_sync_rstn					xdma_rstn_gens(
    	.rstn_gens						(xdma_rstn	),//output		
		.rstn_reqs						(link_rstn	),//input		
		.main_clki						(ubus_clki	));//input		

	gens_sync_rstn					pcia_rstn_gens(
    	.rstn_gens						(pcia_rstn	),//output		
		.rstn_reqs						(link_rstn	),//input		
		.main_clki						(pcie_aclk	));//input		

	pcie_link_xdma_ctrl				u_pcie_link_xdma_ctrl(
		.pcie_xdma_ddrs_base			(pcie_xdma_ddrs_base	),//input		[24 : 0]	
		.pcie_xdma_rows_numb			(pcie_xdma_rows_numb	),//input		[19 : 0]
		.pcie_xdma_cols_numb			(pcie_xdma_cols_numb	),//input		[15 : 0]
		.pcie_link_wdma_enab			(pcie_wdma_ddrs_enab	),//input				-//write enable
		.pcie_link_wdma_done			(pcie_wdma_ddrs_done	),//output				-//pcie bar clock domain
		.pcie_link_rdma_enab			(pcie_rdma_ddrs_enab	),//input	-write enable
		.pcie_link_rdma_done			(pcie_rdma_ddrs_done	),//output	-pcie bar clock domain

		.pcie_axis_rdma_data			(pcie_axis_read_data	),//output		[255:0]	
		.pcie_axis_rdma_drdy			(pcie_axis_read_vlid	),//output				
		.pcie_axis_rdma_last			(pcie_axis_read_last	),//output				
		.pcie_axis_rdma_trdy			(pcie_axis_read_trdy	),//input				

		.pcie_axis_wdma_data			(pcie_axis_writ_data	),//input		[255:0]	
		.pcie_axis_wdma_drdy			(pcie_axis_writ_vlid	),//input				
		.pcie_axis_wdma_trdy			(pcie_axis_writ_trdy	),//output				

		.pcie_aclk						(pcie_aclk				),//input
		.pcie_bclk						(pcie_bclk				),//input
		.pcie_rstn						(pcia_rstn				),//input

		.ubus_pcie_wdma_csen			(ubus_pcie_wdma_csen	),//output				
		.ubus_pcie_wdma_addr			(ubus_pcie_wdma_addr	),//output		[ 24: 0]
		.ubus_pcie_wdma_data			(ubus_pcie_wdma_data	),//output		[255: 0]
		.ubus_pcie_wdma_trdy			(ddrs_ubus_intf_trdy	),//input				
		.ubus_pcie_wdma_wrdy			(ddrs_ubus_intf_wrdy	),//input				

		.ubus_pcie_rdma_csen			(ubus_pcie_rdma_csen	),//output				
		.ubus_pcie_rdma_addr			(ubus_pcie_rdma_addr	),//output		[ 27: 0]
		.ubus_pcie_rdma_data			(ddrs_ubus_read_data	),//input		[255: 0]
		.ubus_pcie_rdma_trdy			(ddrs_ubus_intf_trdy	),//input				
		.ubus_pcie_rdma_drdy			(ddrs_ubus_read_vlid	),//input				

		.ubus_clki						(ubus_clki				),//input
		.ubus_rstn						(xdma_rstn				));//input
/**********************************************************************************************************************/
//DECLARE ::	PCIE BAR0 MISC CONTRL
	pcie_link_tpgm_ctrl				u_pcie_link_tpgm_ctrl(
		.pile_pack_wdma_enab			(pile_pack_wdma_enab	),

		.pcie_bar0_csen					(pcie_bram_csen			),//input				
		.pcie_bar0_addr					(pcie_bram_addr[8:2]	),//input		[  5:0 ]
		.pcie_bar0_wrcs					(pcie_bram_wben			),//input				
		.pcie_bar0_wdata				(pcie_bram_wdata		),//input		[ 31:0 ]
		.pcie_bar0_rdata				(pcie_bram_rdata		),//output		[ 31:0 ]

		.pcie_xdma_ddrs_stat			(tpus_link_ddrs_stat	),//input
		.pcie_xdma_ddrs_base			(pcie_xdma_ddrs_base	),//output	reg	[ 24: 0]
		.pcie_xdma_rows_numb			(pcie_xdma_rows_numb	),//output	reg	[ 19: 0]
		.pcie_xdma_cols_numb			(pcie_xdma_cols_numb	),//output	reg	[ 15: 0]
		.pcie_wdma_ddrs_enab			(pcie_wdma_ddrs_enab	),//output	
		.pcie_wdma_ddrs_done			(pcie_wdma_ddrs_done	),//input	
		.pcie_rdma_ddrs_enab			(pcie_rdma_ddrs_enab	),//output	
		.pcie_rdma_ddrs_done			(pcie_rdma_ddrs_done	),//input	

		.pcie_bclk						(pcie_bclk				),//input	
		.pcie_rstn						(pcie_rstn				),//input	

		.tpgm_dlys_ctrl_drdy			(tpgm_dlys_ctrl_drdy	),//input
		.tpgm_link_port_enab			(tpgm_link_port_enab	),
		
		.tpgm_link_tune_rxdi			(tpgm_link_tune_rxdi	),//output		[ 1: 3]		
		.tpgm_link_tune_txdo			(tpgm_link_tune_txdo	),//output		[ 1: 3]		
		
		.pcie_tune_txdo_done			(pcie_tune_txdo_done	),//output		[ 1: 3]		
		.pcie_tune_txdo_enab			(pcie_tune_txdo_enab	),//output		[ 1: 3]		
		.pcie_tune_txdo_taps			(pcie_tune_txdo_taps	),//output		[ 1: 3][ 8: 0]

		.pcie_tune_rxdi_enab			(pcie_tune_rxdi_enab	),//output		[ 1: 3]		
		.pcie_tune_rxdi_taps			(pcie_tune_rxdi_taps	),//output		[ 1: 3][ 8: 0]		
		.pcie_tune_rxdi_done			(pcie_tune_rxdi_done	),//input		[ 1: 3]
		.pcie_tune_rxdi_stat			(pcie_tune_rxdi_stat	),//input		[ 1: 3][ 3: 0]
		
		.tpgm_port_txdo_rstn			(tpgm_rstn_gens			),//output				
		.tpgm_port_txdo_fram			(tpgm_port_txdo_fram	),//output		[0:3][7:0]
		.tpgm_port_txdo_dat0			(tpgm_port_txdo_dat0	),//output		[0:3][7:0]
		.tpgm_port_txdo_dat1			(tpgm_port_txdo_dat1	),//output		[0:3][7:0]
		.tpgm_port_txdo_dat2			(tpgm_port_txdo_dat2	),//output		[0:3][7:0]
		.tpgm_port_txdo_dat3			(tpgm_port_txdo_dat3	),//output		[0:3][7:0]

		.tpgm_port_rxdi_fram			(tpgm_port_rxdi_fram	),//input		[0:3][7:0]
		.tpgm_port_rxdi_dat0			(tpgm_port_rxdi_dat0	),//input		[0:3][7:0]
		.tpgm_port_rxdi_dat1			(tpgm_port_rxdi_dat1	),//input		[0:3][7:0]
		.tpgm_port_rxdi_dat2			(tpgm_port_rxdi_dat2	),//input		[0:3][7:0]
		.tpgm_port_rxdi_dat3			(tpgm_port_rxdi_dat3	),//input		[0:3][7:0]

		.ubus_tpgm_rdma_csen			(ubus_tpgm_rdma_csen	),//output				
		.ubus_tpgm_rdma_addr			(ubus_tpgm_rdma_addr	),//output		[ 24: 0]
		.ubus_tpgm_rdma_trdy			(ubus_tpgm_rdma_trdy	),//input				
		.ubus_tpgm_rdma_data			(ubus_tpgm_rdma_data	),//input		[255: 0]
		.ubus_tpgm_rdma_drdy			(ubus_tpgm_rdma_drdy	),//input				

		.ubus_tpgm_wdma_csen			(ubus_tpgm_wdma_csen	),//output				
		.ubus_tpgm_wdma_addr			(ubus_tpgm_wdma_addr	),//output		[ 24: 0]
		.ubus_tpgm_wdma_data			(ubus_tpgm_wdma_data	),//output		[255: 0]
		.ubus_tpgm_wdma_trdy			(ubus_tpgm_wdma_trdy	),//input				
		.ubus_tpgm_wdma_wrdy			(ubus_tpgm_wdma_wrdy	),//input				

		.link_cclk						(link_cclk				),//input	
		.ubus_clki						(ubus_clki				),//input	
		.ubus_rstn						(xdma_rstn				),//ubus_rstn				),//input	
		.tpgm_sclk						(link_sclk				),//input	
		.tpgm_rstn						(tpgm_rstn				));//input	
/**********************************************************************************************************************/
//DECLARE-BEGIN ::	TPUC MAST MISC CONTRL

	gens_sync_rstn					tpus_rstn_gens(
    	.rstn_gens						(tpus_rstn	),//output		
		.rstn_reqs						(link_rstn	),//input		
		.main_clki						(link_sclk	));//input		

	tpus_root_link_unit				u_tpus_root_link_unit(
		.tpus_link_ddrs_stat			(tpus_link_ddrs_stat	),//input
		.tpgm_link_port_enab			(tpgm_link_port_enab	),//input 	[ 3: 0]
		.tpem_link_port_rstn			(tpem_link_port_rstn	),//output	[ 0: 7]
		.tpem_link_port_rxen			(tpem_link_port_rxen	),//output	[ 0: 7]

		.tpem_tune_txdo_mode			(tpem_tune_txdo_mode	),//output	[ 0: 7]			
		.tpem_tune_rxdi_mode			(tpem_tune_rxdi_reqs	),//output	[ 0: 7]			

		.tpem_tune_txdo_done			(tpem_tune_txdo_done	),//input	[ 0: 7]	
		.tpem_tune_txdo_enab			(tpem_tune_txdo_enab	),//output	[ 0: 7]			
		.tpem_tune_txdo_taps			(tpem_tune_txdo_taps	),//output	[ 0: 7][8: 0]	

		.tpem_tune_rxdi_done			(tpem_tune_rxdi_done	),//input	[ 0: 7]
		.tpem_tune_rxdi_enab			(tpem_tune_rxdi_enab	),//output	[ 0: 7]			
		.tpem_tune_rxdi_taps			(tpem_tune_rxdi_taps	),//output	[ 0: 7][ 8: 0]	
		.tpem_tune_rxdi_stat			(tpem_tune_rxdi_stat	),//input	[ 0: 7][ 9: 0]	

		.tpem_sync_rxdi_reqs			(tpem_sync_rxdi_reqs	),//output	reg			
		.tpem_sync_rxdi_done			(tpem_sync_rxdi_done	),//input		[ 0: 7]	

		.tpgs_port_txdo_fram			(tpgm_port_rxdi_fram[0]	),//tpgs_port_txdo_fram[0]	),//output		[ 7: 0]	
		.tpgs_port_txdo_dat0			(tpgm_port_rxdi_dat0[0]	),//tpgs_port_txdo_dat0[0]	),//output		[ 7: 0]	
		.tpgs_port_txdo_dat1			(tpgm_port_rxdi_dat1[0]	),//tpgs_port_txdo_dat1[0]	),//output		[ 7: 0]	
		.tpgs_port_txdo_dat2			(tpgm_port_rxdi_dat2[0]	),//tpgs_port_txdo_dat2[0]	),//output		[ 7: 0]	
		.tpgs_port_txdo_dat3			(tpgm_port_rxdi_dat3[0]	),//tpgs_port_txdo_dat3[0]	),//output		[ 7: 0]	

		.tpgs_port_rxdi_fram			(tpgm_port_txdo_fram[0]	),//tpgs_port_rxdi_fram[0]	),//input		[ 7: 0]	
		.tpgs_port_rxdi_dat0			(tpgm_port_txdo_dat0[0]	),//tpgs_port_rxdi_dat0[0]	),//input		[ 7: 0]	
		.tpgs_port_rxdi_dat1			(tpgm_port_txdo_dat1[0]	),//tpgs_port_rxdi_dat1[0]	),//input		[ 7: 0]	
		.tpgs_port_rxdi_dat2			(tpgm_port_txdo_dat2[0]	),//tpgs_port_rxdi_dat2[0]	),//input		[ 7: 0]	
		.tpgs_port_rxdi_dat3			(tpgm_port_txdo_dat3[0]	),//tpgs_port_rxdi_dat3[0]	),//input		[ 7: 0]	

		.tpem_port_txdo_fram			(tpem_port_txdo_fram	),//output		[ 0: 7][ 7: 0]	
		.tpem_port_txdo_dat0			(tpem_port_txdo_dat0	),//output		[ 0: 7][ 7: 0]	
		.tpem_port_txdo_dat1			(tpem_port_txdo_dat1	),//output		[ 0: 7][ 7: 0]	
		.tpem_port_txdo_dat2			(tpem_port_txdo_dat2	),//output		[ 0: 7][ 7: 0]	
		.tpem_port_txdo_dat3			(tpem_port_txdo_dat3	),//output		[ 0: 7][ 7: 0]	

		.tpem_port_rxdi_lead			(tpem_port_rxdi_lead	)	,//output	reg	[ 7: 0]	
		.tpem_port_rxdi_body			(tpem_port_rxdi_body	)	,//output	reg	[ 7: 0]	
		.tpem_port_rxdi_coda			(tpem_port_rxdi_coda	)	,//output	reg	[ 7: 0]	

		.tpem_port_rxdi_dat0			(tpem_port_rxdi_dat0	),//input		[ 0: 7][ 7: 0]	
		.tpem_port_rxdi_dat1			(tpem_port_rxdi_dat1	),//input		[ 0: 7][ 7: 0]	
		.tpem_port_rxdi_dat2			(tpem_port_rxdi_dat2	),//input		[ 0: 7][ 7: 0]	
		.tpem_port_rxdi_dat3			(tpem_port_rxdi_dat3	),//input		[ 0: 7][ 7: 0]	

		.tpem_scfg_prog_outp			(tpem_scfg_prog_outp	),//output		[ 0: 7]			
		.tpem_scfg_cclk_outp			(tpem_scfg_cclk_outp	),//output		[ 0: 7]			
		.tpem_scfg_data_outp			(tpem_scfg_data_outp	),//output		[ 0: 7]			
		.tpem_scfg_init_inpp			(tpem_scfg_init_inpp	),//input		[ 0: 7]			
		.tpem_scfg_done_inpp			(tpem_scfg_done_inpp	),//input		[ 0: 7]			

		.mgt1_intf_link_stat			(mgt1_intf_link_stat	),//input				
		.mgt1_pmau_init_ctrl			(mgt1_pmau_init_ctrl	),//output				
		.mgt1_rstb_push_ctrl			(mgt1_rstb_push_ctrl	),//output				
		.mgt1_isde_wdma_drdy			(mgt1_isde_wdma_drdy	),//input				
		.mgt1_isde_wdma_data			(mgt1_isde_wdma_data	),//input		[255: 0]
		.mgt1_clki						(mgt1_clki				),//input				
		.mgt1_rstn						(tpus_rstn				),//input				

		.mgt2_intf_link_stat			(mgt2_intf_link_stat	),//input				
		.mgt2_pmau_init_ctrl			(mgt2_pmau_init_ctrl	),//output				
		.mgt2_rstb_push_ctrl			(mgt2_rstb_push_ctrl	),//output				
		.mgt2_isde_wdma_drdy			(mgt2_isde_wdma_drdy	),//input				
		.mgt2_isde_wdma_data			(mgt2_isde_wdma_data	),//input		[255: 0]
		.mgt2_clki						(mgt2_clki				),//input				
		.mgt2_rstn						(tpus_rstn				),//input				

		.mgt3_intf_link_stat			(mgt3_intf_link_stat	),//input				
		.mgt3_pmau_init_ctrl			(mgt3_pmau_init_ctrl	),//output				
		.mgt3_rstb_push_ctrl			(mgt3_rstb_push_ctrl	),//output				
		.mgt3_isde_wdma_drdy			(mgt3_isde_wdma_drdy	),//input				
		.mgt3_isde_wdma_data			(mgt3_isde_wdma_data	),//input		[255: 0]
		.mgt3_clki						(mgt3_clki				),//input				
		.mgt3_rstn						(tpus_rstn				),//input				

		.ubus_tpgs_wdma_csen			(ubus_tpgs_wdma_csen	),//output				
		.ubus_tpgs_wdma_addr			(ubus_tpgs_wdma_addr	),//output		[ 24: 0]
		.ubus_tpgs_wdma_data			(ubus_tpgs_wdma_data	),//output		[255: 0]
		.ubus_tpgs_wdma_trdy			(ubus_tpgs_wdma_trdy	),//input				
		.ubus_tpgs_wdma_wrdy			(ubus_tpgs_wdma_wrdy	),//input				

		.ubus_tpgs_rdma_csen			(ubus_tpgs_rdma_csen	),//output	reg			
		.ubus_tpgs_rdma_addr			(ubus_tpgs_rdma_addr	),//output	reg	[ 24: 0]
		.ubus_tpgs_rdma_trdy			(ubus_tpgs_rdma_trdy	),//input				
		.ubus_tpgs_rdma_data			(ubus_tpgs_rdma_data	),//input		[255: 0]
		.ubus_tpgs_rdma_drdy			(ubus_tpgs_rdma_drdy	),//input				

		.ubus_tpem_wdma_csen			(ubus_tpem_wdma_csen	),//output				
		.ubus_tpem_wdma_addr			(ubus_tpem_wdma_addr	),//output		[ 24: 0]
		.ubus_tpem_wdma_data			(ubus_tpem_wdma_data	),//output		[255: 0]
		.ubus_tpem_wdma_trdy			(ubus_tpem_wdma_trdy	),//input				
		.ubus_tpem_wdma_wrdy			(ubus_tpem_wdma_wrdy	),//input				

		.ubus_tpem_rdma_csen			(ubus_tpem_rdma_csen	),//output				
		.ubus_tpem_rdma_addr			(ubus_tpem_rdma_addr	),//output		[ 24: 0]
		.ubus_tpem_rdma_trdy			(ubus_tpem_rdma_trdy	),//input				
		.ubus_tpem_rdma_data			(ubus_tpem_rdma_data	),//input		[255: 0]
		.ubus_tpem_rdma_drdy			(ubus_tpem_rdma_drdy	),//input				

		.ubus_isde_wdma_csen			(ubus_isde_wdma_csen	),//output				
		.ubus_isde_wdma_addr			(ubus_isde_wdma_addr	),//output		[ 24: 0]
		.ubus_isde_wdma_data			(ubus_isde_wdma_data	),//output		[255: 0]
		.ubus_isde_wdma_trdy			(ubus_isde_wdma_trdy	),//input				
		.ubus_isde_wdma_wrdy			(ubus_isde_wdma_wrdy	),//input				

		.ubus_clki						(ubus_clki				),//input	
		.ubus_rstn						(xdma_rstn				),//input	
		.link_sclk						(link_sclk				),//input	
		.link_rstn						(tpus_rstn				));//input	
/**********************************************************************************************************************/
endmodule	


