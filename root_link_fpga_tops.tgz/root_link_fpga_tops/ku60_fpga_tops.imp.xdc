
#####################################################################################################################################
	
	create_clock -period 10.000 -name chip_clki 	[get_ports chip_clki_inpp]
#####################################################################################################################################
#	set    mcmi_clk0					[get_pins u_ku60_fpga_core/u_xcku_clks_gens/CHIP_MMCM/CLKIN1]
	set    mcmi_clk0					[get_pins BUFG_CHIP_CLKI/O]
	
	set    mcmo_clk0					[get_pins u_ku60_fpga_core/u_xcku_clks_gens/CHIP_MMCM/CLKOUT0]
	set    mcmo_clk1					[get_pins u_ku60_fpga_core/u_xcku_clks_gens/CHIP_MMCM/CLKOUT1]
	set    mcmo_clk2					[get_pins u_ku60_fpga_core/u_xcku_clks_gens/CHIP_MMCM/CLKOUT2]

	create_generated_clock 				-name 			mmcm_200m				[get_pins $mcmo_clk0]	\
	                       				-source    			           			[get_pins $mcmi_clk0]   \
	                       				-mul    		10          	                               	\ 
	                       				-div    		5               	                           	
	                       				#\	                       				-master_clock 	chip_clki		  		-add

	create_generated_clock 				-name 			mmcm_040m				[get_pins $mcmo_clk1]	\
	                       				-source    			           			[get_pins $mcmi_clk0]   \
	                       				-mul    		10          	                               	\ 
	                       				-div    		25               	                           	
	                       				#\	                       				-master_clock 	chip_clki		  		-add
#####################################################################################################################################
	set	chip_clki_bufg	BUFG_CHIP_CLKI
    set	link_cclk_bufg	u_ku60_fpga_core/u_xcku_clks_gens/BUFG_040M
	set	link_fclk_bufg	u_ku60_fpga_core/u_xcku_clks_gens/BUFG_FCLK
	set	link_sclk_bufg	u_ku60_fpga_core/u_xcku_clks_gens/BUFG_SCLK

	set_property CLOCK_REGION X4Y2 		[get_cells 	$chip_clki_bufg]
	set_property CLOCK_REGION X4Y2 		[get_cells 	$link_fclk_bufg]
	set_property CLOCK_REGION X4Y2 		[get_cells 	$link_sclk_bufg]
	set_property CLOCK_REGION X4Y2 		[get_cells 	$link_cclk_bufg]

	create_generated_clock	-name	link_cclk	[get_pins $link_cclk_bufg/O]	-source	[get_pins $link_cclk_bufg/I]	-div 1	-master_clock	mmcm_040m	-add
	create_generated_clock	-name	link_fclk	[get_pins $link_fclk_bufg/O]	-source	[get_pins $link_fclk_bufg/I]	-div 1	-master_clock	mmcm_200m	-add
	create_generated_clock	-name	link_sclk	[get_pins $link_sclk_bufg/O]	-source	[get_pins $link_sclk_bufg/I]	-div 4	-master_clock	mmcm_200m	-add
#####################################################################################################################################
	create_generated_clock -name tpg1_txdo_clko  [get_ports tpgm_link_fclk_outp[1] ] -source [get_pins $link_fclk_bufg/O] -div 1 -master_clock link_fclk -add
	create_generated_clock -name tpg2_txdo_clko  [get_ports tpgm_link_fclk_outp[2] ] -source [get_pins $link_fclk_bufg/O] -div 1 -master_clock link_fclk -add
	create_generated_clock -name tpg3_txdo_clko  [get_ports tpgm_link_fclk_outp[3] ] -source [get_pins $link_fclk_bufg/O] -div 1 -master_clock link_fclk -add
#	create_generated_clock -name tpe0_txdo_clko  [get_ports tpem_link_fclk_outp[0] ] -source [get_pins $link_fclk_bufg/O] -div 1 -master_clock link_fclk -add
#	create_generated_clock -name tpe1_txdo_clko  [get_ports tpem_link_fclk_outp[1] ] -source [get_pins $link_fclk_bufg/O] -div 1 -master_clock link_fclk -add
#	create_generated_clock -name tpe2_txdo_clko  [get_ports tpem_link_fclk_outp[2] ] -source [get_pins $link_fclk_bufg/O] -div 1 -master_clock link_fclk -add
#	create_generated_clock -name tpe3_txdo_clko  [get_ports tpem_link_fclk_outp[3] ] -source [get_pins $link_fclk_bufg/O] -div 1 -master_clock link_fclk -add
#	create_generated_clock -name tpe4_txdo_clko  [get_ports tpem_link_fclk_outp[4] ] -source [get_pins $link_fclk_bufg/O] -div 1 -master_clock link_fclk -add
#	create_generated_clock -name tpe5_txdo_clko  [get_ports tpem_link_fclk_outp[5] ] -source [get_pins $link_fclk_bufg/O] -div 1 -master_clock link_fclk -add
#	create_generated_clock -name tpe6_txdo_clko  [get_ports tpem_link_fclk_outp[6] ] -source [get_pins $link_fclk_bufg/O] -div 1 -master_clock link_fclk -add
#	create_generated_clock -name tpe7_txdo_clko  [get_ports tpem_link_fclk_outp[7] ] -source [get_pins $link_fclk_bufg/O] -div 1 -master_clock link_fclk -add
#####################################################################################################################################
	create_clock -period 10.000 -name pcie_base_clki 	[get_ports pcie_clkp_io]
	create_clock -period 10.000 -name mgt1_base_clki   	[get_ports mgt1_rclk_p]
	create_clock -period 10.000 -name mgt2_base_clki   	[get_ports mgt2_rclk_p]
	create_clock -period 10.000 -name mgt3_base_clki  	[get_ports mgt3_rclk_p]

	create_clock -period  5.0	-name tpg1_rxdi_clki 	[get_ports tpgs_link_fclk_inpp[1] ]
	create_clock -period  5.0	-name tpg2_rxdi_clki 	[get_ports tpgs_link_fclk_inpp[2] ]
	create_clock -period  5.0	-name tpg3_rxdi_clki 	[get_ports tpgs_link_fclk_inpp[3] ]
	
	create_clock -period  10.0 	-name tpe0_rxdi_clki 	[get_ports tpes_link_fclk_inpp[0] ]
	create_clock -period  10.0 	-name tpe1_rxdi_clki 	[get_ports tpes_link_fclk_inpp[1] ]
	create_clock -period  10.0 	-name tpe2_rxdi_clki 	[get_ports tpes_link_fclk_inpp[2] ]
	create_clock -period  10.0 	-name tpe3_rxdi_clki 	[get_ports tpes_link_fclk_inpp[3] ]
	create_clock -period  10.0 	-name tpe4_rxdi_clki 	[get_ports tpes_link_fclk_inpp[4] ]
	create_clock -period  10.0 	-name tpe5_rxdi_clki 	[get_ports tpes_link_fclk_inpp[5] ]
	create_clock -period  10.0 	-name tpe6_rxdi_clki 	[get_ports tpes_link_fclk_inpp[6] ]
	create_clock -period  10.0 	-name tpe7_rxdi_clki 	[get_ports tpes_link_fclk_inpp[7] ]
#####################################################################################################################################
	set	tpg1_fcki_bufg	u_ku60_fpga_core/gens_tpgm_link_port[1].u_tpgm_link_rxdi_pmau/LVDS_FCLK_BUFG
	set	tpg2_fcki_bufg	u_ku60_fpga_core/gens_tpgm_link_port[2].u_tpgm_link_rxdi_pmau/LVDS_FCLK_BUFG
	set	tpg3_fcki_bufg	u_ku60_fpga_core/gens_tpgm_link_port[3].u_tpgm_link_rxdi_pmau/LVDS_FCLK_BUFG
	set	tpe0_fcki_bufg	u_ku60_fpga_core/gens_tpem_link_por*[0].u_tpem_link_rxdi_pmau/LVDS_FCLK_BUFG
	set	tpe1_fcki_bufg	u_ku60_fpga_core/gens_tpem_link_port[1].u_tpem_link_rxdi_pmau/LVDS_FCLK_BUFG
	set	tpe2_fcki_bufg	u_ku60_fpga_core/gens_tpem_link_port[2].u_tpem_link_rxdi_pmau/LVDS_FCLK_BUFG
	set	tpe3_fcki_bufg	u_ku60_fpga_core/gens_tpem_link_port[3].u_tpem_link_rxdi_pmau/LVDS_FCLK_BUFG
	set	tpe4_fcki_bufg	u_ku60_fpga_core/gens_tpem_link_port[4].u_tpem_link_rxdi_pmau/LVDS_FCLK_BUFG
	set	tpe5_fcki_bufg	u_ku60_fpga_core/gens_tpem_link_port[5].u_tpem_link_rxdi_pmau/LVDS_FCLK_BUFG
	set	tpe6_fcki_bufg	u_ku60_fpga_core/gens_tpem_link_port[6].u_tpem_link_rxdi_pmau/LVDS_FCLK_BUFG
	set	tpe7_fcki_bufg	u_ku60_fpga_core/gens_tpem_link_port[7].u_tpem_link_rxdi_pmau/LVDS_FCLK_BUFG

	set	tpg1_scki_bufg	u_ku60_fpga_core/gens_tpgm_link_port[1].u_tpgm_link_rxdi_pmau/LVDS_SCLK_BUFG
	set	tpg2_scki_bufg	u_ku60_fpga_core/gens_tpgm_link_port[2].u_tpgm_link_rxdi_pmau/LVDS_SCLK_BUFG
	set	tpg3_scki_bufg	u_ku60_fpga_core/gens_tpgm_link_port[3].u_tpgm_link_rxdi_pmau/LVDS_SCLK_BUFG
	set	tpe0_scki_bufg	u_ku60_fpga_core/gens_tpem_link_por*[0].u_tpem_link_rxdi_pmau/LVDS_SCLK_BUFG
	set	tpe1_scki_bufg	u_ku60_fpga_core/gens_tpem_link_port[1].u_tpem_link_rxdi_pmau/LVDS_SCLK_BUFG
	set	tpe2_scki_bufg	u_ku60_fpga_core/gens_tpem_link_port[2].u_tpem_link_rxdi_pmau/LVDS_SCLK_BUFG
	set	tpe3_scki_bufg	u_ku60_fpga_core/gens_tpem_link_port[3].u_tpem_link_rxdi_pmau/LVDS_SCLK_BUFG
	set	tpe4_scki_bufg	u_ku60_fpga_core/gens_tpem_link_port[4].u_tpem_link_rxdi_pmau/LVDS_SCLK_BUFG
	set	tpe5_scki_bufg	u_ku60_fpga_core/gens_tpem_link_port[5].u_tpem_link_rxdi_pmau/LVDS_SCLK_BUFG
	set	tpe6_scki_bufg	u_ku60_fpga_core/gens_tpem_link_port[6].u_tpem_link_rxdi_pmau/LVDS_SCLK_BUFG
	set	tpe7_scki_bufg	u_ku60_fpga_core/gens_tpem_link_port[7].u_tpem_link_rxdi_pmau/LVDS_SCLK_BUFG
#20251120
	set_property CLOCK_REGION X4Y2 [get_cells 	$tpg1_fcki_bufg]
	set_property CLOCK_REGION X2Y4 [get_cells 	$tpg2_fcki_bufg]
	set_property CLOCK_REGION X2Y4 [get_cells 	$tpg3_fcki_bufg]
	set_property CLOCK_REGION X2Y2 [get_cells 	$tpe0_fcki_bufg]
	set_property CLOCK_REGION X2Y1 [get_cells 	$tpe1_fcki_bufg]
	set_property CLOCK_REGION X2Y2 [get_cells 	$tpe2_fcki_bufg]
	set_property CLOCK_REGION X2Y0 [get_cells 	$tpe3_fcki_bufg]
	set_property CLOCK_REGION X2Y3 [get_cells 	$tpe4_fcki_bufg]
	set_property CLOCK_REGION X2Y3 [get_cells 	$tpe5_fcki_bufg]
	set_property CLOCK_REGION X2Y1 [get_cells 	$tpe6_fcki_bufg]
	set_property CLOCK_REGION X2Y0 [get_cells 	$tpe7_fcki_bufg]

	set_property CLOCK_REGION X4Y2 [get_cells 	$tpg1_scki_bufg]
	set_property CLOCK_REGION X2Y4 [get_cells 	$tpg2_scki_bufg]
	set_property CLOCK_REGION X2Y4 [get_cells 	$tpg3_scki_bufg]
	set_property CLOCK_REGION X2Y2 [get_cells 	$tpe0_scki_bufg]
	set_property CLOCK_REGION X2Y1 [get_cells 	$tpe1_scki_bufg]
	set_property CLOCK_REGION X2Y2 [get_cells 	$tpe2_scki_bufg]
	set_property CLOCK_REGION X2Y0 [get_cells 	$tpe3_scki_bufg]
	set_property CLOCK_REGION X2Y3 [get_cells 	$tpe4_scki_bufg]
	set_property CLOCK_REGION X2Y3 [get_cells 	$tpe5_scki_bufg]
	set_property CLOCK_REGION X2Y1 [get_cells 	$tpe6_scki_bufg]
	set_property CLOCK_REGION X2Y0 [get_cells 	$tpe7_scki_bufg]
################################################################################################################################
	set_property CLOCK_DEDICATED_ROUTE BACKBONE [get_nets chip_clki]

	set_property CLOCK_DEDICATED_ROUTE FALSE [get_nets u_ku60_fpga_core/gens_tpgm_link_port[1].u_tpgm_link_rxdi_pmau/LVDS_FCLK_PAD/O ]
	set_property CLOCK_DEDICATED_ROUTE FALSE [get_nets u_ku60_fpga_core/gens_tpgm_link_port[2].u_tpgm_link_rxdi_pmau/LVDS_FCLK_PAD/O ]
	set_property CLOCK_DEDICATED_ROUTE FALSE [get_nets u_ku60_fpga_core/gens_tpgm_link_port[3].u_tpgm_link_rxdi_pmau/LVDS_FCLK_PAD/O ]

	set_property CLOCK_DEDICATED_ROUTE FALSE [get_nets u_ku60_fpga_core/gens_tpem_link_port[0].u_tpem_link_rxdi_pmau/LVDS_FCLK_PAD/O ]
	set_property CLOCK_DEDICATED_ROUTE FALSE [get_nets u_ku60_fpga_core/gens_tpem_link_port[1].u_tpem_link_rxdi_pmau/LVDS_FCLK_PAD/O ]
	set_property CLOCK_DEDICATED_ROUTE FALSE [get_nets u_ku60_fpga_core/gens_tpem_link_port[2].u_tpem_link_rxdi_pmau/LVDS_FCLK_PAD/O ]
	set_property CLOCK_DEDICATED_ROUTE FALSE [get_nets u_ku60_fpga_core/gens_tpem_link_port[3].u_tpem_link_rxdi_pmau/LVDS_FCLK_PAD/O ]
	set_property CLOCK_DEDICATED_ROUTE FALSE [get_nets u_ku60_fpga_core/gens_tpem_link_port[4].u_tpem_link_rxdi_pmau/LVDS_FCLK_PAD/O ]
	set_property CLOCK_DEDICATED_ROUTE FALSE [get_nets u_ku60_fpga_core/gens_tpem_link_port[5].u_tpem_link_rxdi_pmau/LVDS_FCLK_PAD/O ]
	set_property CLOCK_DEDICATED_ROUTE FALSE [get_nets u_ku60_fpga_core/gens_tpem_link_port[6].u_tpem_link_rxdi_pmau/LVDS_FCLK_PAD/O ]
	set_property CLOCK_DEDICATED_ROUTE FALSE [get_nets u_ku60_fpga_core/gens_tpem_link_port[7].u_tpem_link_rxdi_pmau/LVDS_FCLK_PAD/O ]
########################################################################################################################################
	set_input_delay   -clock pcie_base_clki 1	[get_ports pcie_rstn_io    ]
########################################################################################################################################
################ TPGL iodelay####################
	set	tpg1_func_rxdi	[get_ports tpgs_link_*_inp*[1] 	-filter {NAME !~ "*fclk*" }]		
	set	tpg2_func_rxdi	[get_ports tpgs_link_*_inp*[2] 	-filter {NAME !~ "*fclk*" }]	
	set	tpg3_func_rxdi	[get_ports tpgs_link_*_inp*[3] 	-filter {NAME !~ "*fclk*" }]	

	set_input_delay 	-clock tpg1_rxdi_clki 	0.01	[get_ports $tpg1_func_rxdi]
	set_input_delay 	-clock tpg1_rxdi_clki 	0.01	[get_ports $tpg1_func_rxdi] -clock_fall -add_delay

	set_input_delay 	-clock tpg2_rxdi_clki 	0.01	[get_ports $tpg2_func_rxdi]
	set_input_delay 	-clock tpg2_rxdi_clki 	0.01	[get_ports $tpg2_func_rxdi] -clock_fall -add_delay

	set_input_delay 	-clock tpg3_rxdi_clki 	0.01	[get_ports $tpg3_func_rxdi]
	set_input_delay 	-clock tpg3_rxdi_clki 	0.01	[get_ports $tpg3_func_rxdi] -clock_fall -add_delay
########################################
	set	tpg1_func_txdo	[get_ports tpgm_link_*_out*[1] -filter {NAME !~ "*fclk*" && NAME !~ "*rstn*" && NAME !~ "*tune*" }]	
	set	tpg2_func_txdo	[get_ports tpgm_link_*_out*[2] -filter {NAME !~ "*fclk*" && NAME !~ "*rstn*" && NAME !~ "*tune*" }]	
	set	tpg3_func_txdo	[get_ports tpgm_link_*_out*[3] -filter {NAME !~ "*fclk*" && NAME !~ "*rstn*" && NAME !~ "*tune*" }]	

	set_output_delay -clock tpg1_txdo_clko 0.01	[get_ports $tpg1_func_txdo]
	set_output_delay -clock tpg1_txdo_clko 0.01	[get_ports $tpg1_func_txdo] -clock_fall -add_delay

	set_output_delay -clock tpg2_txdo_clko 0.01	[get_ports $tpg2_func_txdo]
	set_output_delay -clock tpg2_txdo_clko 0.01	[get_ports $tpg2_func_txdo] -clock_fall -add_delay

	set_output_delay -clock tpg3_txdo_clko 0.01	[get_ports $tpg3_func_txdo]
	set_output_delay -clock tpg3_txdo_clko 0.01	[get_ports $tpg3_func_txdo] -clock_fall -add_delay
########################################
	set	tpgl_ctrl_txdo	[get_ports tpgm_link_*_out*[*] 	-filter {NAME =~ "*rstn*" || NAME =~ "*tune*" }]	
	set	tpel_ctrl_txdo	[get_ports tpem_link_*[*] 		-filter {NAME =~ "*rstn*" || NAME =~ "*tune*" }]	
	
	set_output_delay 	-clock link_sclk 	1.0		[get_ports $tpgl_ctrl_txdo]
	set_output_delay 	-clock link_sclk 	1.0		[get_ports $tpel_ctrl_txdo]
########################################################################################################################################
################ TPEL iodelay####################
	set	tpe0_func_rxdi	[get_ports tpes_link_*_inp*[0] -filter {NAME !~ "*fclk*" }]	
	set	tpe1_func_rxdi	[get_ports tpes_link_*_inp*[1] -filter {NAME !~ "*fclk*" }]	
	set	tpe2_func_rxdi	[get_ports tpes_link_*_inp*[2] -filter {NAME !~ "*fclk*" }]	
	set	tpe3_func_rxdi	[get_ports tpes_link_*_inp*[3] -filter {NAME !~ "*fclk*" }]	
	set	tpe4_func_rxdi	[get_ports tpes_link_*_inp*[4] -filter {NAME !~ "*fclk*" }]	
	set	tpe5_func_rxdi	[get_ports tpes_link_*_inp*[5] -filter {NAME !~ "*fclk*" }]	
	set	tpe6_func_rxdi	[get_ports tpes_link_*_inp*[6] -filter {NAME !~ "*fclk*" }]	
	set	tpe7_func_rxdi	[get_ports tpes_link_*_inp*[7] -filter {NAME !~ "*fclk*" }]	

	set_input_delay -clock tpe0_rxdi_clki 0.01	[get_ports $tpe0_func_rxdi]
	set_input_delay -clock tpe0_rxdi_clki 0.01	[get_ports $tpe0_func_rxdi] -clock_fall -add_delay

	set_input_delay -clock tpe1_rxdi_clki 0.01	[get_ports $tpe1_func_rxdi]
	set_input_delay -clock tpe1_rxdi_clki 0.01	[get_ports $tpe1_func_rxdi] -clock_fall -add_delay

	set_input_delay -clock tpe2_rxdi_clki 0.01	[get_ports $tpe2_func_rxdi]
	set_input_delay -clock tpe2_rxdi_clki 0.01	[get_ports $tpe2_func_rxdi] -clock_fall -add_delay

	set_input_delay -clock tpe3_rxdi_clki 0.01	[get_ports $tpe3_func_rxdi]
	set_input_delay -clock tpe3_rxdi_clki 0.01	[get_ports $tpe3_func_rxdi] -clock_fall -add_delay

	set_input_delay -clock tpe4_rxdi_clki 0.01	[get_ports $tpe4_func_rxdi]
	set_input_delay -clock tpe4_rxdi_clki 0.01	[get_ports $tpe4_func_rxdi] -clock_fall -add_delay

	set_input_delay -clock tpe5_rxdi_clki 0.01	[get_ports $tpe5_func_rxdi]
	set_input_delay -clock tpe5_rxdi_clki 0.01	[get_ports $tpe5_func_rxdi] -clock_fall -add_delay

	set_input_delay -clock tpe6_rxdi_clki 0.01	[get_ports $tpe6_func_rxdi]
	set_input_delay -clock tpe6_rxdi_clki 0.01	[get_ports $tpe6_func_rxdi] -clock_fall -add_delay

	set_input_delay -clock tpe7_rxdi_clki 0.01	[get_ports $tpe7_func_rxdi]
	set_input_delay -clock tpe7_rxdi_clki 0.01	[get_ports $tpe7_func_rxdi] -clock_fall -add_delay
####################################
	set	tpe0_func_txdo	[get_ports tpem_link_*_out*[0] -filter {NAME !~ "*fclk*" && NAME !~ "*rstn*" && NAME !~ "*tune*" }]	
	set	tpe1_func_txdo	[get_ports tpem_link_*_out*[1] -filter {NAME !~ "*fclk*" && NAME !~ "*rstn*" && NAME !~ "*tune*" }]	
	set	tpe2_func_txdo	[get_ports tpem_link_*_out*[2] -filter {NAME !~ "*fclk*" && NAME !~ "*rstn*" && NAME !~ "*tune*" }]	
	set	tpe3_func_txdo	[get_ports tpem_link_*_out*[3] -filter {NAME !~ "*fclk*" && NAME !~ "*rstn*" && NAME !~ "*tune*" }]	
	set	tpe4_func_txdo	[get_ports tpem_link_*_out*[4] -filter {NAME !~ "*fclk*" && NAME !~ "*rstn*" && NAME !~ "*tune*" }]	
	set	tpe5_func_txdo	[get_ports tpem_link_*_out*[5] -filter {NAME !~ "*fclk*" && NAME !~ "*rstn*" && NAME !~ "*tune*" }]	
	set	tpe6_func_txdo	[get_ports tpem_link_*_out*[6] -filter {NAME !~ "*fclk*" && NAME !~ "*rstn*" && NAME !~ "*tune*" }]	
	set	tpe7_func_txdo	[get_ports tpem_link_*_out*[7] -filter {NAME !~ "*fclk*" && NAME !~ "*rstn*" && NAME !~ "*tune*" }]	

	set_output_delay -clock tpe0_txdo_clko 0.01	[get_ports $tpe0_func_txdo]
	set_output_delay -clock tpe0_txdo_clko 0.01	[get_ports $tpe0_func_txdo] -clock_fall -add_delay
	
	set_output_delay -clock tpe1_txdo_clko 0.01	[get_ports $tpe1_func_txdo]
	set_output_delay -clock tpe1_txdo_clko 0.01	[get_ports $tpe1_func_txdo] -clock_fall -add_delay
	
	set_output_delay -clock tpe2_txdo_clko 0.01	[get_ports $tpe2_func_txdo]
	set_output_delay -clock tpe2_txdo_clko 0.01	[get_ports $tpe2_func_txdo] -clock_fall -add_delay
	
	set_output_delay -clock tpe3_txdo_clko 0.01	[get_ports $tpe3_func_txdo]
	set_output_delay -clock tpe3_txdo_clko 0.01	[get_ports $tpe3_func_txdo] -clock_fall -add_delay
	
	set_output_delay -clock tpe4_txdo_clko 0.01	[get_ports $tpe4_func_txdo]
	set_output_delay -clock tpe4_txdo_clko 0.01	[get_ports $tpe4_func_txdo] -clock_fall -add_delay
	
	set_output_delay -clock tpe5_txdo_clko 0.01	[get_ports $tpe5_func_txdo]
	set_output_delay -clock tpe5_txdo_clko 0.01	[get_ports $tpe5_func_txdo] -clock_fall -add_delay
	
	set_output_delay -clock tpe6_txdo_clko 0.01	[get_ports $tpe6_func_txdo]
	set_output_delay -clock tpe6_txdo_clko 0.01	[get_ports $tpe6_func_txdo] -clock_fall -add_delay
	
	set_output_delay -clock tpe7_txdo_clko 0.01	[get_ports $tpe7_func_txdo]
	set_output_delay -clock tpe7_txdo_clko 0.01	[get_ports $tpe7_func_txdo] -clock_fall -add_delay
####################################
	set_input_delay 	-clock link_sclk 	3  		[get_ports tpem_scfg_*_inpp[*] ]
	set_output_delay 	-clock link_sclk 	3  		[get_ports tpem_scfg_*_outp[*] ]
#####################################################################################################################################
####	Timing Constraint Exception
#####################################################################################################################################
	set ddrs_uclk	[get_clocks -of	[get_pins u_ku60_fpga_core/u_lpddr3_256m/inst/u_ddr_infrastructure/u_bufg_divClk/O							 ]]
	set	pcie_aclk	[get_clocks -of	[get_pins u_pcie_exp8_ctrl/inst/pcie3_ip_i/inst/pcie_xdma_ctrl_pcie3_ip_gt_top_i/phy_clk_i/bufg_gt_userclk/O ]]
	set	mgt1_uclk	[get_clocks -of	[get_pins u_ku60_mgt1_sdes/u_mgt1_isde_quad/inst/clock_module_i/ultrascale_tx_userclk_1/gen_gtwiz_userclk_tx_main.bufg_gt_usrclk2_inst/O ]]
	set	mgt2_uclk	[get_clocks -of	[get_pins u_ku60_mgt2_sdes/u_mgt2_isde_quad/inst/clock_module_i/ultrascale_tx_userclk_1/gen_gtwiz_userclk_tx_main.bufg_gt_usrclk2_inst/O ]]
	set	mgt3_uclk	[get_clocks -of	[get_pins u_ku60_mgt3_sdes/u_mgt3_isde_quad/inst/clock_module_i/ultrascale_tx_userclk_1/gen_gtwiz_userclk_tx_main.bufg_gt_usrclk2_inst/O ]]

	set_multicycle_path 4 -setup 	-from [get_clocks link_cclk ] 	-to 	[get_clocks 	$pcie_aclk ] 
	set_multicycle_path 3 -hold 	-from [get_clocks link_cclk ] 	-to 	[get_clocks 	$pcie_aclk ] 

	set_clock_groups -name link_asyn_pcie_bclk -asynchronous  	-group	[get_clocks	link_sclk ] 	-group 	[get_clocks pcie_base_clki	]
	set_clock_groups -name link_asyn_tpxl_rcki -asynchronous 	-group	[get_clocks	link_sclk ] 	-group  [get_clocks tp*_rxdi_clki	]
	set_clock_groups -name link_asyn_tpxl_rcki -asynchronous 	-group	[get_clocks	link_sclk ] 	-group  [get_clocks lane_sclk*		]
	
	set_clock_groups -name init_asyn_pcie_bclk -asynchronous  	-group	[get_clocks	link_cclk ] 	-group 	[get_clocks $pcie_aclk	]
	set_clock_groups -name link_asyn_ddrs_sclk -asynchronous  	-group	[get_clocks	link_sclk ]		-group 	[get_clocks $ddrs_uclk		]


	set_clock_groups -name mgt1_asyn_link_cclk -asynchronous	-group 	[get_clocks	$mgt1_uclk ]	-group	[get_clocks link_cclk 	]		
	set_clock_groups -name mgt1_asyn_link_sclk -asynchronous 	-group 	[get_clocks $mgt1_uclk ]	-group 	[get_clocks link_sclk 	]
	set_clock_groups -name mgt1_asyn_ddrs_uclk -asynchronous 	-group 	[get_clocks $mgt1_uclk ]	-group 	[get_clocks $ddrs_uclk 	]

	set_clock_groups -name mgt2_asyn_link_cclk -asynchronous	-group 	[get_clocks	$mgt2_uclk ]	-group	[get_clocks link_cclk 	]		
	set_clock_groups -name mgt2_asyn_link_sclk -asynchronous 	-group 	[get_clocks $mgt2_uclk ]	-group 	[get_clocks link_sclk 	]
	set_clock_groups -name mgt2_asyn_ddrs_uclk -asynchronous 	-group 	[get_clocks $mgt2_uclk ]	-group 	[get_clocks $ddrs_uclk 	]

	set_clock_groups -name mgt3_asyn_link_cclk -asynchronous	-group 	[get_clocks	$mgt3_uclk ]	-group	[get_clocks link_cclk 	]		
	set_clock_groups -name mgt3_asyn_link_sclk -asynchronous	-group 	[get_clocks $mgt3_uclk ]	-group 	[get_clocks link_sclk 	]
	set_clock_groups -name mgt3_asyn_ddrs_uclk -asynchronous	-group 	[get_clocks $mgt3_uclk ]	-group 	[get_clocks $ddrs_uclk 	]


	set_clock_groups -name pcie_asyn_link_sclk -asynchronous  	-group	[get_clocks $pcie_aclk ]	-group 	[get_clocks link_sclk ]
	set_clock_groups -name pcie_asyn_lane_sclk -asynchronous	-group	[get_clocks $pcie_aclk ]	-group	[get_clocks lane_sclk*] 
	set_clock_groups -name pcie_asyn_ddrs_uclk -asynchronous 	-group	[get_clocks $pcie_aclk ]	-group 	[get_clocks $ddrs_uclk]
	
	set_clock_groups -name chip_asyn_pcie_bclk -asynchronous 	-group	chip_clki					-group 	pcie_base_clki
	set_clock_groups -name chip_asyn_pcie_bclk -asynchronous 	-group	chip_clki					-group 	link_fclk
	set_clock_groups -name chip_asyn_pcie_bclk -asynchronous 	-group	chip_clki					-group 	[get_clocks $ddrs_uclk 	]
	
	set_clock_groups -name init_asyn_link_sclk -asynchronous 	-group 	link_sclk					-group	link_cclk 
	
#	set_clock_groups -name chip_asyn_link_sclk -asynchronous 	-group 	chip_100m					-group	[get_clocks link_sclk ]

 	set_false_path	-from	[get_ports pcie_rstn_io]
#####################################################################################################################################
	set_property IODELAY_GROUP "dlygrp_x1y0" [get_cells u_ku60_fpga_core/u_ku60_dlys_ctrl/u_dlys_ctrl_x1y0]
	set_property IODELAY_GROUP "dlygrp_x1y0" [get_cells u_ku60_fpga_core/gens_tpem_link_port[7].u_tpem_link_rxdi_pmau/gens_rdxi_idly_cell[0].u_RXDI_IDLY_CELL ]
	set_property IODELAY_GROUP "dlygrp_x1y0" [get_cells u_ku60_fpga_core/gens_tpem_link_port[7].u_tpem_link_rxdi_pmau/gens_rdxi_idly_cell[1].u_RXDI_IDLY_CELL ]

	set_property IODELAY_GROUP "dlygrp_x1y1" [get_cells u_ku60_fpga_core/u_ku60_dlys_ctrl/u_dlys_ctrl_x1y1]
	set_property IODELAY_GROUP "dlygrp_x1y1" [get_cells u_ku60_fpga_core/gens_tpem_link_port[7].u_tpem_link_rxdi_pmau/gens_rdxi_idly_cell[2].u_RXDI_IDLY_CELL ]
	set_property IODELAY_GROUP "dlygrp_x1y1" [get_cells u_ku60_fpga_core/gens_tpem_link_port[7].u_tpem_link_rxdi_pmau/gens_rdxi_idly_cell[3].u_RXDI_IDLY_CELL ]
	set_property IODELAY_GROUP "dlygrp_x1y1" [get_cells u_ku60_fpga_core/gens_tpem_link_port[7].u_tpem_link_rxdi_pmau/gens_rdxi_idly_cell[4].u_RXDI_IDLY_CELL ]

	set_property IODELAY_GROUP "dlygrp_x1y6" [get_cells u_ku60_fpga_core/u_ku60_dlys_ctrl/u_dlys_ctrl_x1y6]
	set_property IODELAY_GROUP "dlygrp_x1y6" [get_cells u_ku60_fpga_core/gens_tpem_link_port[3].u_tpem_link_rxdi_pmau/gens_rdxi_idly_cell[1].u_RXDI_IDLY_CELL ]
	set_property IODELAY_GROUP "dlygrp_x1y6" [get_cells u_ku60_fpga_core/gens_tpem_link_port[3].u_tpem_link_rxdi_pmau/gens_rdxi_idly_cell[2].u_RXDI_IDLY_CELL ]

	set_property IODELAY_GROUP "dlygrp_x1y7" [get_cells u_ku60_fpga_core/u_ku60_dlys_ctrl/u_dlys_ctrl_x1y7]
	set_property IODELAY_GROUP "dlygrp_x1y7" [get_cells u_ku60_fpga_core/gens_tpem_link_port[3].u_tpem_link_rxdi_pmau/gens_rdxi_idly_cell[0].u_RXDI_IDLY_CELL ]
	set_property IODELAY_GROUP "dlygrp_x1y7" [get_cells u_ku60_fpga_core/gens_tpem_link_port[3].u_tpem_link_rxdi_pmau/gens_rdxi_idly_cell[3].u_RXDI_IDLY_CELL ]
	set_property IODELAY_GROUP "dlygrp_x1y7" [get_cells u_ku60_fpga_core/gens_tpem_link_port[3].u_tpem_link_rxdi_pmau/gens_rdxi_idly_cell[4].u_RXDI_IDLY_CELL ]

	set_property IODELAY_GROUP "dlygrp_x1y8" [get_cells u_ku60_fpga_core/u_ku60_dlys_ctrl/u_dlys_ctrl_x1y8]
	set_property IODELAY_GROUP "dlygrp_x1y8" [get_cells u_ku60_fpga_core/gens_tpem_link_port[1].u_tpem_link_rxdi_pmau/gens_rdxi_idly_cell[1].u_RXDI_IDLY_CELL ]
	set_property IODELAY_GROUP "dlygrp_x1y8" [get_cells u_ku60_fpga_core/gens_tpem_link_port[1].u_tpem_link_rxdi_pmau/gens_rdxi_idly_cell[2].u_RXDI_IDLY_CELL ]
	set_property IODELAY_GROUP "dlygrp_x1y8" [get_cells u_ku60_fpga_core/gens_tpem_link_port[1].u_tpem_link_rxdi_pmau/gens_rdxi_idly_cell[3].u_RXDI_IDLY_CELL ]

	set_property IODELAY_GROUP "dlygrp_x1y9" [get_cells u_ku60_fpga_core/u_ku60_dlys_ctrl/u_dlys_ctrl_x1y9]
	set_property IODELAY_GROUP "dlygrp_x1y9" [get_cells u_ku60_fpga_core/gens_tpem_link_port[1].u_tpem_link_rxdi_pmau/gens_rdxi_idly_cell[0].u_RXDI_IDLY_CELL ]
	set_property IODELAY_GROUP "dlygrp_x1y9" [get_cells u_ku60_fpga_core/gens_tpem_link_port[1].u_tpem_link_rxdi_pmau/gens_rdxi_idly_cell[4].u_RXDI_IDLY_CELL ]

	set_property IODELAY_GROUP "dlygrp_x1y14" [get_cells u_ku60_fpga_core/u_ku60_dlys_ctrl/u_dlys_ctrl_x1y14]
	set_property IODELAY_GROUP "dlygrp_x1y14" [get_cells u_ku60_fpga_core/gens_tpem_link_port[6].u_tpem_link_rxdi_pmau/gens_rdxi_idly_cell[0].u_RXDI_IDLY_CELL ]
	set_property IODELAY_GROUP "dlygrp_x1y14" [get_cells u_ku60_fpga_core/gens_tpem_link_port[6].u_tpem_link_rxdi_pmau/gens_rdxi_idly_cell[2].u_RXDI_IDLY_CELL ]
	
	set_property IODELAY_GROUP "dlygrp_x1y15" [get_cells u_ku60_fpga_core/u_ku60_dlys_ctrl/u_dlys_ctrl_x1y15]
	set_property IODELAY_GROUP "dlygrp_x1y15" [get_cells u_ku60_fpga_core/gens_tpem_link_port[6].u_tpem_link_rxdi_pmau/gens_rdxi_idly_cell[1].u_RXDI_IDLY_CELL ]
	set_property IODELAY_GROUP "dlygrp_x1y15" [get_cells u_ku60_fpga_core/gens_tpem_link_port[6].u_tpem_link_rxdi_pmau/gens_rdxi_idly_cell[3].u_RXDI_IDLY_CELL ]
	set_property IODELAY_GROUP "dlygrp_x1y15" [get_cells u_ku60_fpga_core/gens_tpem_link_port[6].u_tpem_link_rxdi_pmau/gens_rdxi_idly_cell[4].u_RXDI_IDLY_CELL ]
	
	set_property IODELAY_GROUP "dlygrp_x1y16" [get_cells u_ku60_fpga_core/u_ku60_dlys_ctrl/u_dlys_ctrl_x1y16]
	set_property IODELAY_GROUP "dlygrp_x1y16" [get_cells u_ku60_fpga_core/gens_tpem_link_port[2].u_tpem_link_rxdi_pmau/gens_rdxi_idly_cell[0].u_RXDI_IDLY_CELL ]
	set_property IODELAY_GROUP "dlygrp_x1y16" [get_cells u_ku60_fpga_core/gens_tpem_link_port[2].u_tpem_link_rxdi_pmau/gens_rdxi_idly_cell[3].u_RXDI_IDLY_CELL ]

	set_property IODELAY_GROUP "dlygrp_x1y17" [get_cells u_ku60_fpga_core/u_ku60_dlys_ctrl/u_dlys_ctrl_x1y17]
	set_property IODELAY_GROUP "dlygrp_x1y17" [get_cells u_ku60_fpga_core/gens_tpem_link_port[2].u_tpem_link_rxdi_pmau/gens_rdxi_idly_cell[1].u_RXDI_IDLY_CELL ]
	set_property IODELAY_GROUP "dlygrp_x1y17" [get_cells u_ku60_fpga_core/gens_tpem_link_port[2].u_tpem_link_rxdi_pmau/gens_rdxi_idly_cell[2].u_RXDI_IDLY_CELL ]
	set_property IODELAY_GROUP "dlygrp_x1y17" [get_cells u_ku60_fpga_core/gens_tpem_link_port[2].u_tpem_link_rxdi_pmau/gens_rdxi_idly_cell[4].u_RXDI_IDLY_CELL ]

	set_property IODELAY_GROUP "dlygrp_x1y22" [get_cells u_ku60_fpga_core/u_ku60_dlys_ctrl/u_dlys_ctrl_x1y22]
	set_property IODELAY_GROUP "dlygrp_x1y22" [get_cells u_ku60_fpga_core/gens_tpem_link_port[0].u_tpem_link_rxdi_pmau/gens_rdxi_idly_cell[0].u_RXDI_IDLY_CELL ]
	set_property IODELAY_GROUP "dlygrp_x1y22" [get_cells u_ku60_fpga_core/gens_tpem_link_port[0].u_tpem_link_rxdi_pmau/gens_rdxi_idly_cell[3].u_RXDI_IDLY_CELL ]

	set_property IODELAY_GROUP "dlygrp_x1y23" [get_cells u_ku60_fpga_core/u_ku60_dlys_ctrl/u_dlys_ctrl_x1y23]
	set_property IODELAY_GROUP "dlygrp_x1y23" [get_cells u_ku60_fpga_core/gens_tpem_link_port[0].u_tpem_link_rxdi_pmau/gens_rdxi_idly_cell[1].u_RXDI_IDLY_CELL ]
	set_property IODELAY_GROUP "dlygrp_x1y23" [get_cells u_ku60_fpga_core/gens_tpem_link_port[0].u_tpem_link_rxdi_pmau/gens_rdxi_idly_cell[2].u_RXDI_IDLY_CELL ]
	set_property IODELAY_GROUP "dlygrp_x1y23" [get_cells u_ku60_fpga_core/gens_tpem_link_port[0].u_tpem_link_rxdi_pmau/gens_rdxi_idly_cell[4].u_RXDI_IDLY_CELL ]

	set_property IODELAY_GROUP "dlygrp_x1y24" [get_cells u_ku60_fpga_core/u_ku60_dlys_ctrl/u_dlys_ctrl_x1y24]
	set_property IODELAY_GROUP "dlygrp_x1y24" [get_cells u_ku60_fpga_core/gens_tpem_link_port[4].u_tpem_link_rxdi_pmau/gens_rdxi_idly_cell[0].u_RXDI_IDLY_CELL ]
	set_property IODELAY_GROUP "dlygrp_x1y24" [get_cells u_ku60_fpga_core/gens_tpem_link_port[4].u_tpem_link_rxdi_pmau/gens_rdxi_idly_cell[3].u_RXDI_IDLY_CELL ]
	set_property IODELAY_GROUP "dlygrp_x1y24" [get_cells u_ku60_fpga_core/gens_tpem_link_port[4].u_tpem_link_rxdi_pmau/gens_rdxi_idly_cell[4].u_RXDI_IDLY_CELL ]

	set_property IODELAY_GROUP "dlygrp_x1y25" [get_cells u_ku60_fpga_core/u_ku60_dlys_ctrl/u_dlys_ctrl_x1y25]
	set_property IODELAY_GROUP "dlygrp_x1y25" [get_cells u_ku60_fpga_core/gens_tpem_link_port[4].u_tpem_link_rxdi_pmau/gens_rdxi_idly_cell[1].u_RXDI_IDLY_CELL ]
	set_property IODELAY_GROUP "dlygrp_x1y25" [get_cells u_ku60_fpga_core/gens_tpem_link_port[4].u_tpem_link_rxdi_pmau/gens_rdxi_idly_cell[2].u_RXDI_IDLY_CELL ]

	set_property IODELAY_GROUP "dlygrp_x1y30" [get_cells u_ku60_fpga_core/u_ku60_dlys_ctrl/u_dlys_ctrl_x1y30]
	set_property IODELAY_GROUP "dlygrp_x1y30" [get_cells u_ku60_fpga_core/gens_tpem_link_port[5].u_tpem_link_rxdi_pmau/gens_rdxi_idly_cell[0].u_RXDI_IDLY_CELL ]
	set_property IODELAY_GROUP "dlygrp_x1y30" [get_cells u_ku60_fpga_core/gens_tpem_link_port[5].u_tpem_link_rxdi_pmau/gens_rdxi_idly_cell[2].u_RXDI_IDLY_CELL ]

	set_property IODELAY_GROUP "dlygrp_x1y31" [get_cells u_ku60_fpga_core/u_ku60_dlys_ctrl/u_dlys_ctrl_x1y31]
	set_property IODELAY_GROUP "dlygrp_x1y31" [get_cells u_ku60_fpga_core/gens_tpem_link_port[5].u_tpem_link_rxdi_pmau/gens_rdxi_idly_cell[1].u_RXDI_IDLY_CELL ]
	set_property IODELAY_GROUP "dlygrp_x1y31" [get_cells u_ku60_fpga_core/gens_tpem_link_port[5].u_tpem_link_rxdi_pmau/gens_rdxi_idly_cell[3].u_RXDI_IDLY_CELL ]
	set_property IODELAY_GROUP "dlygrp_x1y31" [get_cells u_ku60_fpga_core/gens_tpem_link_port[5].u_tpem_link_rxdi_pmau/gens_rdxi_idly_cell[4].u_RXDI_IDLY_CELL ]

	set_property IODELAY_GROUP "dlygrp_x1y32" [get_cells u_ku60_fpga_core/u_ku60_dlys_ctrl/u_dlys_ctrl_x1y32]
	set_property IODELAY_GROUP "dlygrp_x1y32" [get_cells u_ku60_fpga_core/gens_tpgm_link_port[3].u_tpgm_link_rxdi_pmau/gens_rdxi_idly_cell[0].u_RXDI_IDLY_CELL ]
	set_property IODELAY_GROUP "dlygrp_x1y32" [get_cells u_ku60_fpga_core/gens_tpgm_link_port[3].u_tpgm_link_rxdi_pmau/gens_rdxi_idly_cell[3].u_RXDI_IDLY_CELL ]
	set_property IODELAY_GROUP "dlygrp_x1y32" [get_cells u_ku60_fpga_core/gens_tpgm_link_port[3].u_tpgm_link_rxdi_pmau/gens_rdxi_idly_cell[4].u_RXDI_IDLY_CELL ]


	set_property IODELAY_GROUP "dlygrp_x1y33" [get_cells u_ku60_fpga_core/u_ku60_dlys_ctrl/u_dlys_ctrl_x1y33]
	set_property IODELAY_GROUP "dlygrp_x1y33" [get_cells u_ku60_fpga_core/gens_tpgm_link_port[3].u_tpgm_link_rxdi_pmau/gens_rdxi_idly_cell[1].u_RXDI_IDLY_CELL ]
	set_property IODELAY_GROUP "dlygrp_x1y33" [get_cells u_ku60_fpga_core/gens_tpgm_link_port[3].u_tpgm_link_rxdi_pmau/gens_rdxi_idly_cell[2].u_RXDI_IDLY_CELL ]


	set_property IODELAY_GROUP "dlygrp_x1y38" [get_cells u_ku60_fpga_core/u_ku60_dlys_ctrl/u_dlys_ctrl_x1y38]
	set_property IODELAY_GROUP "dlygrp_x1y38" [get_cells u_ku60_fpga_core/gens_tpgm_link_port[2].u_tpgm_link_rxdi_pmau/gens_rdxi_idly_cell[0].u_RXDI_IDLY_CELL ]
	set_property IODELAY_GROUP "dlygrp_x1y38" [get_cells u_ku60_fpga_core/gens_tpgm_link_port[2].u_tpgm_link_rxdi_pmau/gens_rdxi_idly_cell[2].u_RXDI_IDLY_CELL ]
	set_property IODELAY_GROUP "dlygrp_x1y38" [get_cells u_ku60_fpga_core/gens_tpgm_link_port[2].u_tpgm_link_rxdi_pmau/gens_rdxi_idly_cell[4].u_RXDI_IDLY_CELL ]

	set_property IODELAY_GROUP "dlygrp_x1y39" [get_cells u_ku60_fpga_core/u_ku60_dlys_ctrl/u_dlys_ctrl_x1y39]
	set_property IODELAY_GROUP "dlygrp_x1y39" [get_cells u_ku60_fpga_core/gens_tpgm_link_port[2].u_tpgm_link_rxdi_pmau/gens_rdxi_idly_cell[1].u_RXDI_IDLY_CELL ]
	set_property IODELAY_GROUP "dlygrp_x1y39" [get_cells u_ku60_fpga_core/gens_tpgm_link_port[2].u_tpgm_link_rxdi_pmau/gens_rdxi_idly_cell[3].u_RXDI_IDLY_CELL ]

	set_property IODELAY_GROUP "dlygrp_x2y16" [get_cells u_ku60_fpga_core/u_ku60_dlys_ctrl/u_dlys_ctrl_x2y16]
	set_property IODELAY_GROUP "dlygrp_x2y16" [get_cells u_ku60_fpga_core/gens_tpgm_link_port[1].u_tpgm_link_rxdi_pmau/gens_rdxi_idly_cell[0].u_RXDI_IDLY_CELL ]
	set_property IODELAY_GROUP "dlygrp_x2y16" [get_cells u_ku60_fpga_core/gens_tpgm_link_port[1].u_tpgm_link_rxdi_pmau/gens_rdxi_idly_cell[1].u_RXDI_IDLY_CELL ]
	set_property IODELAY_GROUP "dlygrp_x2y16" [get_cells u_ku60_fpga_core/gens_tpgm_link_port[1].u_tpgm_link_rxdi_pmau/gens_rdxi_idly_cell[2].u_RXDI_IDLY_CELL ]

	set_property IODELAY_GROUP "dlygrp_x2y17" [get_cells u_ku60_fpga_core/u_ku60_dlys_ctrl/u_dlys_ctrl_x2y17]
	set_property IODELAY_GROUP "dlygrp_x2y17" [get_cells u_ku60_fpga_core/gens_tpgm_link_port[1].u_tpgm_link_rxdi_pmau/gens_rdxi_idly_cell[3].u_RXDI_IDLY_CELL ]
	set_property IODELAY_GROUP "dlygrp_x2y17" [get_cells u_ku60_fpga_core/gens_tpgm_link_port[1].u_tpgm_link_rxdi_pmau/gens_rdxi_idly_cell[4].u_RXDI_IDLY_CELL ]

	set_property IODELAY_GROUP "dlygrp_x1y35" [get_cells u_ku60_fpga_core/u_ku60_dlys_ctrl/u_dlys_ctrl_x1y35]
	set_property IODELAY_GROUP "dlygrp_x1y35" [get_cells u_ku60_fpga_core/gens_tpgm_link_port[3].u_tpgm_link_txdo_pmau/u_FCLK_ODLY_CELL ]

	set_property IODELAY_GROUP "dlygrp_x1y36" [get_cells u_ku60_fpga_core/u_ku60_dlys_ctrl/u_dlys_ctrl_x1y36]
	set_property IODELAY_GROUP "dlygrp_x1y36" [get_cells u_ku60_fpga_core/gens_tpgm_link_port[2].u_tpgm_link_txdo_pmau/u_FCLK_ODLY_CELL ]

	set_property IODELAY_GROUP "dlygrp_x2y19" [get_cells u_ku60_fpga_core/u_ku60_dlys_ctrl/u_dlys_ctrl_x2y19]
	set_property IODELAY_GROUP "dlygrp_x2y19" [get_cells u_ku60_fpga_core/gens_tpgm_link_port[1].u_tpgm_link_txdo_pmau/u_FCLK_ODLY_CELL ]

	set_property UNAVAILABLE_DURING_CALIBRATION TRUE [get_ports tpgm_link_dat0_outp[3]]
	set_property UNAVAILABLE_DURING_CALIBRATION TRUE [get_ports tpgm_link_dat1_outp[1]]
	set_property UNAVAILABLE_DURING_CALIBRATION TRUE [get_ports tpgm_link_fram_outp[2]]
#####################################################################################################################################
#------------------------------------------------------------
	set_property CONFIG_MODE SPIx4 [current_design]
	set_property BITSTREAM.CONFIG.CONFIGRATE 110 [current_design]
	set_property CONFIG_VOLTAGE 1.8 [current_design]
	set_property CFGBVS GND [current_design]
	set_property BITSTREAM.CONFIG.SPI_BUSWIDTH 4 [current_design]
	set_property BITSTREAM.CONFIG.SPI_FALL_EDGE YES [current_design]
	set_property BITSTREAM.CONFIG.CONFIGFALLBACK DISABLE [current_design]
	set_property BITSTREAM.GENERAL.COMPRESS TRUE [current_design]
#####################################################################################################################################
#####################################################################################################################################























######################################################################################################################################
#	create_clock -period 10.000 -name chip_100m 	[get_ports chip_clki_inpp]
######################################################################################################################################
#	set    mmcm_clki					[get_pins u_ku60_fpga_core/u_xcku_clks_gens/CHIP_MMCM/CLKIN1]
#	set    mmcm_clko					[get_pins u_ku60_fpga_core/u_xcku_clks_gens/CHIP_MMCM/CLKOUT0]

#	create_generated_clock 				-name 			mmcm_320m				[get_pins $mmcm_clko]	\
#	                       				-source    			           			[get_pins $mmcm_clki]   \
#	                       				-mul    		16          	                               	\ 
#	                       				-div    		5               	                           	\
#	                       				-master_clock 	chip_100m		  		-add
######################################################################################################################################
#	set	chip_clki_bufg	BUFG_CHIP_CLKI
#	set	link_fclk_bufg	u_ku60_fpga_core/u_xcku_clks_gens/BUFG_320M
#	set	link_sclk_bufg	u_ku60_fpga_core/u_xcku_clks_gens/BUFG_080M
#	set	link_cclk_bufg	u_ku60_fpga_core/u_xcku_clks_gens/BUFG_040M

#	set_property CLOCK_REGION X4Y2 		[get_cells 	$chip_clki_bufg]
#	set_property CLOCK_REGION X4Y2 		[get_cells 	$link_fclk_bufg]
#	set_property CLOCK_REGION X4Y2 		[get_cells 	$link_sclk_bufg]
#	set_property CLOCK_REGION X4Y2 		[get_cells 	$link_cclk_bufg]

#	create_generated_clock	-name	link_fclk	[get_pins $link_fclk_bufg/O]	-source	[get_pins $link_fclk_bufg/I]	-div 1	-master_clock	mmcm_320m	-add
#	create_generated_clock	-name	link_sclk	[get_pins $link_sclk_bufg/O]	-source	[get_pins $link_sclk_bufg/I]	-div 4	-master_clock	mmcm_320m	-add
#	create_generated_clock	-name	link_cclk	[get_pins $link_cclk_bufg/O]	-source	[get_pins $link_cclk_bufg/I]	-div 8	-master_clock	mmcm_320m	-add
######################################################################################################################################
#	create_generated_clock -name tpg1_txdo_clko  [get_ports tpgm_link_fclk_outp[1] ] -source [get_pins $link_fclk_bufg/O] -div 1 -master_clock link_fclk -add
#	create_generated_clock -name tpg2_txdo_clko  [get_ports tpgm_link_fclk_outp[2] ] -source [get_pins $link_fclk_bufg/O] -div 1 -master_clock link_fclk -add
#	create_generated_clock -name tpg3_txdo_clko  [get_ports tpgm_link_fclk_outp[3] ] -source [get_pins $link_fclk_bufg/O] -div 1 -master_clock link_fclk -add
#	create_generated_clock -name tpe0_txdo_clko  [get_ports tpem_link_fclk_outp[0] ] -source [get_pins $link_fclk_bufg/O] -div 1 -master_clock link_fclk -add
#	create_generated_clock -name tpe1_txdo_clko  [get_ports tpem_link_fclk_outp[1] ] -source [get_pins $link_fclk_bufg/O] -div 1 -master_clock link_fclk -add
#	create_generated_clock -name tpe2_txdo_clko  [get_ports tpem_link_fclk_outp[2] ] -source [get_pins $link_fclk_bufg/O] -div 1 -master_clock link_fclk -add
#	create_generated_clock -name tpe3_txdo_clko  [get_ports tpem_link_fclk_outp[3] ] -source [get_pins $link_fclk_bufg/O] -div 1 -master_clock link_fclk -add
#	create_generated_clock -name tpe4_txdo_clko  [get_ports tpem_link_fclk_outp[4] ] -source [get_pins $link_fclk_bufg/O] -div 1 -master_clock link_fclk -add
#	create_generated_clock -name tpe5_txdo_clko  [get_ports tpem_link_fclk_outp[5] ] -source [get_pins $link_fclk_bufg/O] -div 1 -master_clock link_fclk -add
#	create_generated_clock -name tpe6_txdo_clko  [get_ports tpem_link_fclk_outp[6] ] -source [get_pins $link_fclk_bufg/O] -div 1 -master_clock link_fclk -add
#	create_generated_clock -name tpe7_txdo_clko  [get_ports tpem_link_fclk_outp[7] ] -source [get_pins $link_fclk_bufg/O] -div 1 -master_clock link_fclk -add
######################################################################################################################################
#	create_clock -period 10.000 -name pcie_base_clki 	[get_ports pcie_clkp_io]
#	create_clock -period 10.000 -name mgt1_base_clki   	[get_ports mgt1_rclk_p]
#	create_clock -period 10.000 -name mgt2_base_clki   	[get_ports mgt2_rclk_p]
#	create_clock -period 10.000 -name mgt3_base_clki  	[get_ports mgt3_rclk_p]

#	create_clock -period  3.125	-name tpg1_rxdi_clki 	[get_ports tpgs_link_fclk_inpp[1] ]
#	create_clock -period  3.125	-name tpg2_rxdi_clki 	[get_ports tpgs_link_fclk_inpp[2] ]
#	create_clock -period  3.125	-name tpg3_rxdi_clki 	[get_ports tpgs_link_fclk_inpp[3] ]
	
#	create_clock -period  6.25 	-name tpe0_rxdi_clki 	[get_ports tpes_link_fclk_inpp[0] ]
#	create_clock -period  6.25 	-name tpe1_rxdi_clki 	[get_ports tpes_link_fclk_inpp[1] ]
#	create_clock -period  6.25 	-name tpe2_rxdi_clki 	[get_ports tpes_link_fclk_inpp[2] ]
#	create_clock -period  6.25 	-name tpe3_rxdi_clki 	[get_ports tpes_link_fclk_inpp[3] ]
#	create_clock -period  6.25 	-name tpe4_rxdi_clki 	[get_ports tpes_link_fclk_inpp[4] ]
#	create_clock -period  6.25 	-name tpe5_rxdi_clki 	[get_ports tpes_link_fclk_inpp[5] ]
#	create_clock -period  6.25 	-name tpe6_rxdi_clki 	[get_ports tpes_link_fclk_inpp[6] ]
#	create_clock -period  6.25 	-name tpe7_rxdi_clki 	[get_ports tpes_link_fclk_inpp[7] ]
######################################################################################################################################
#	set	tpg1_fcki_bufg	u_ku60_fpga_core/gens_tpgm_link_port[1].u_tpgm_link_rxdi_pmau/LVDS_FCLK_BUFG
#	set	tpg2_fcki_bufg	u_ku60_fpga_core/gens_tpgm_link_port[2].u_tpgm_link_rxdi_pmau/LVDS_FCLK_BUFG
#	set	tpg3_fcki_bufg	u_ku60_fpga_core/gens_tpgm_link_port[3].u_tpgm_link_rxdi_pmau/LVDS_FCLK_BUFG
#	set	tpe0_fcki_bufg	u_ku60_fpga_core/gens_tpem_link_por*[0].u_tpem_link_rxdi_pmau/LVDS_FCLK_BUFG
#	set	tpe1_fcki_bufg	u_ku60_fpga_core/gens_tpem_link_port[1].u_tpem_link_rxdi_pmau/LVDS_FCLK_BUFG
#	set	tpe2_fcki_bufg	u_ku60_fpga_core/gens_tpem_link_port[2].u_tpem_link_rxdi_pmau/LVDS_FCLK_BUFG
#	set	tpe3_fcki_bufg	u_ku60_fpga_core/gens_tpem_link_port[3].u_tpem_link_rxdi_pmau/LVDS_FCLK_BUFG
#	set	tpe4_fcki_bufg	u_ku60_fpga_core/gens_tpem_link_port[4].u_tpem_link_rxdi_pmau/LVDS_FCLK_BUFG
#	set	tpe5_fcki_bufg	u_ku60_fpga_core/gens_tpem_link_port[5].u_tpem_link_rxdi_pmau/LVDS_FCLK_BUFG
#	set	tpe6_fcki_bufg	u_ku60_fpga_core/gens_tpem_link_port[6].u_tpem_link_rxdi_pmau/LVDS_FCLK_BUFG
#	set	tpe7_fcki_bufg	u_ku60_fpga_core/gens_tpem_link_port[7].u_tpem_link_rxdi_pmau/LVDS_FCLK_BUFG

#	set	tpg1_scki_bufg	u_ku60_fpga_core/gens_tpgm_link_port[1].u_tpgm_link_rxdi_pmau/LVDS_SCLK_BUFG
#	set	tpg2_scki_bufg	u_ku60_fpga_core/gens_tpgm_link_port[2].u_tpgm_link_rxdi_pmau/LVDS_SCLK_BUFG
#	set	tpg3_scki_bufg	u_ku60_fpga_core/gens_tpgm_link_port[3].u_tpgm_link_rxdi_pmau/LVDS_SCLK_BUFG
#	set	tpe0_scki_bufg	u_ku60_fpga_core/gens_tpem_link_por*[0].u_tpem_link_rxdi_pmau/LVDS_SCLK_BUFG
#	set	tpe1_scki_bufg	u_ku60_fpga_core/gens_tpem_link_port[1].u_tpem_link_rxdi_pmau/LVDS_SCLK_BUFG
#	set	tpe2_scki_bufg	u_ku60_fpga_core/gens_tpem_link_port[2].u_tpem_link_rxdi_pmau/LVDS_SCLK_BUFG
#	set	tpe3_scki_bufg	u_ku60_fpga_core/gens_tpem_link_port[3].u_tpem_link_rxdi_pmau/LVDS_SCLK_BUFG
#	set	tpe4_scki_bufg	u_ku60_fpga_core/gens_tpem_link_port[4].u_tpem_link_rxdi_pmau/LVDS_SCLK_BUFG
#	set	tpe5_scki_bufg	u_ku60_fpga_core/gens_tpem_link_port[5].u_tpem_link_rxdi_pmau/LVDS_SCLK_BUFG
#	set	tpe6_scki_bufg	u_ku60_fpga_core/gens_tpem_link_port[6].u_tpem_link_rxdi_pmau/LVDS_SCLK_BUFG
#	set	tpe7_scki_bufg	u_ku60_fpga_core/gens_tpem_link_port[7].u_tpem_link_rxdi_pmau/LVDS_SCLK_BUFG
##20251120
#	set_property CLOCK_REGION X4Y2 [get_cells 	$tpg1_fcki_bufg]
#	set_property CLOCK_REGION X2Y4 [get_cells 	$tpg2_fcki_bufg]
#	set_property CLOCK_REGION X2Y4 [get_cells 	$tpg3_fcki_bufg]
#	set_property CLOCK_REGION X2Y2 [get_cells 	$tpe0_fcki_bufg]
#	set_property CLOCK_REGION X2Y1 [get_cells 	$tpe1_fcki_bufg]
#	set_property CLOCK_REGION X2Y2 [get_cells 	$tpe2_fcki_bufg]
#	set_property CLOCK_REGION X2Y0 [get_cells 	$tpe3_fcki_bufg]
#	set_property CLOCK_REGION X2Y3 [get_cells 	$tpe4_fcki_bufg]
#	set_property CLOCK_REGION X2Y3 [get_cells 	$tpe5_fcki_bufg]
#	set_property CLOCK_REGION X2Y1 [get_cells 	$tpe6_fcki_bufg]
#	set_property CLOCK_REGION X2Y0 [get_cells 	$tpe7_fcki_bufg]

#	set_property CLOCK_REGION X4Y2 [get_cells 	$tpg1_scki_bufg]
#	set_property CLOCK_REGION X2Y4 [get_cells 	$tpg2_scki_bufg]
#	set_property CLOCK_REGION X2Y4 [get_cells 	$tpg3_scki_bufg]
#	set_property CLOCK_REGION X2Y2 [get_cells 	$tpe0_scki_bufg]
#	set_property CLOCK_REGION X2Y1 [get_cells 	$tpe1_scki_bufg]
#	set_property CLOCK_REGION X2Y2 [get_cells 	$tpe2_scki_bufg]
#	set_property CLOCK_REGION X2Y0 [get_cells 	$tpe3_scki_bufg]
#	set_property CLOCK_REGION X2Y3 [get_cells 	$tpe4_scki_bufg]
#	set_property CLOCK_REGION X2Y3 [get_cells 	$tpe5_scki_bufg]
#	set_property CLOCK_REGION X2Y1 [get_cells 	$tpe6_scki_bufg]
#	set_property CLOCK_REGION X2Y0 [get_cells 	$tpe7_scki_bufg]
#################################################################################################################################
#	set_property CLOCK_DEDICATED_ROUTE BACKBONE [get_nets chip_clki]

#	set_property CLOCK_DEDICATED_ROUTE FALSE [get_nets u_ku60_fpga_core/gens_tpgm_link_port[1].u_tpgm_link_rxdi_pmau/LVDS_FCLK_PAD/O ]
#	set_property CLOCK_DEDICATED_ROUTE FALSE [get_nets u_ku60_fpga_core/gens_tpgm_link_port[2].u_tpgm_link_rxdi_pmau/LVDS_FCLK_PAD/O ]
#	set_property CLOCK_DEDICATED_ROUTE FALSE [get_nets u_ku60_fpga_core/gens_tpgm_link_port[3].u_tpgm_link_rxdi_pmau/LVDS_FCLK_PAD/O ]

#	set_property CLOCK_DEDICATED_ROUTE FALSE [get_nets u_ku60_fpga_core/gens_tpem_link_port[0].u_tpem_link_rxdi_pmau/LVDS_FCLK_PAD/O ]
#	set_property CLOCK_DEDICATED_ROUTE FALSE [get_nets u_ku60_fpga_core/gens_tpem_link_port[1].u_tpem_link_rxdi_pmau/LVDS_FCLK_PAD/O ]
#	set_property CLOCK_DEDICATED_ROUTE FALSE [get_nets u_ku60_fpga_core/gens_tpem_link_port[2].u_tpem_link_rxdi_pmau/LVDS_FCLK_PAD/O ]
#	set_property CLOCK_DEDICATED_ROUTE FALSE [get_nets u_ku60_fpga_core/gens_tpem_link_port[3].u_tpem_link_rxdi_pmau/LVDS_FCLK_PAD/O ]
#	set_property CLOCK_DEDICATED_ROUTE FALSE [get_nets u_ku60_fpga_core/gens_tpem_link_port[4].u_tpem_link_rxdi_pmau/LVDS_FCLK_PAD/O ]
#	set_property CLOCK_DEDICATED_ROUTE FALSE [get_nets u_ku60_fpga_core/gens_tpem_link_port[5].u_tpem_link_rxdi_pmau/LVDS_FCLK_PAD/O ]
#	set_property CLOCK_DEDICATED_ROUTE FALSE [get_nets u_ku60_fpga_core/gens_tpem_link_port[6].u_tpem_link_rxdi_pmau/LVDS_FCLK_PAD/O ]
#	set_property CLOCK_DEDICATED_ROUTE FALSE [get_nets u_ku60_fpga_core/gens_tpem_link_port[7].u_tpem_link_rxdi_pmau/LVDS_FCLK_PAD/O ]
#########################################################################################################################################
#	set_input_delay   -clock pcie_base_clki 1	[get_ports pcie_rstn_io    ]
#########################################################################################################################################
################# TPGL iodelay####################
#	set	tpg1_func_rxdi	[get_ports tpgs_link_*_inp*[1] 	-filter {NAME !~ "*fclk*" }]		
#	set	tpg2_func_rxdi	[get_ports tpgs_link_*_inp*[2] 	-filter {NAME !~ "*fclk*" }]	
#	set	tpg3_func_rxdi	[get_ports tpgs_link_*_inp*[3] 	-filter {NAME !~ "*fclk*" }]	

#	set_input_delay 	-clock tpg1_rxdi_clki 	0.01	[get_ports $tpg1_func_rxdi]
#	set_input_delay 	-clock tpg1_rxdi_clki 	0.01	[get_ports $tpg1_func_rxdi] -clock_fall -add_delay

#	set_input_delay 	-clock tpg2_rxdi_clki 	0.01	[get_ports $tpg2_func_rxdi]
#	set_input_delay 	-clock tpg2_rxdi_clki 	0.01	[get_ports $tpg2_func_rxdi] -clock_fall -add_delay

#	set_input_delay 	-clock tpg3_rxdi_clki 	0.01	[get_ports $tpg3_func_rxdi]
#	set_input_delay 	-clock tpg3_rxdi_clki 	0.01	[get_ports $tpg3_func_rxdi] -clock_fall -add_delay
#########################################
#	set	tpg1_func_txdo	[get_ports tpgm_link_*_out*[1] -filter {NAME !~ "*fclk*" && NAME !~ "*rstn*" && NAME !~ "*tune*" }]	
#	set	tpg2_func_txdo	[get_ports tpgm_link_*_out*[2] -filter {NAME !~ "*fclk*" && NAME !~ "*rstn*" && NAME !~ "*tune*" }]	
#	set	tpg3_func_txdo	[get_ports tpgm_link_*_out*[3] -filter {NAME !~ "*fclk*" && NAME !~ "*rstn*" && NAME !~ "*tune*" }]	

#	set_output_delay -clock tpg1_txdo_clko 0.01	[get_ports $tpg1_func_txdo]
#	set_output_delay -clock tpg1_txdo_clko 0.01	[get_ports $tpg1_func_txdo] -clock_fall -add_delay

#	set_output_delay -clock tpg2_txdo_clko 0.01	[get_ports $tpg2_func_txdo]
#	set_output_delay -clock tpg2_txdo_clko 0.01	[get_ports $tpg2_func_txdo] -clock_fall -add_delay

#	set_output_delay -clock tpg3_txdo_clko 0.01	[get_ports $tpg3_func_txdo]
#	set_output_delay -clock tpg3_txdo_clko 0.01	[get_ports $tpg3_func_txdo] -clock_fall -add_delay
#########################################
#	set	tpgl_ctrl_txdo	[get_ports tpgm_link_*_out*[*] 	-filter {NAME =~ "*rstn*" || NAME =~ "*tune*" }]	
#	set	tpel_ctrl_txdo	[get_ports tpem_link_*[*] 		-filter {NAME =~ "*rstn*" || NAME =~ "*tune*" }]	
	
#	set_output_delay 	-clock link_sclk 	1.0		[get_ports $tpgl_ctrl_txdo]
#	set_output_delay 	-clock link_sclk 	1.0		[get_ports $tpel_ctrl_txdo]
#########################################################################################################################################
################# TPEL iodelay####################
#	set	tpe0_func_rxdi	[get_ports tpes_link_*_inp*[0] -filter {NAME !~ "*fclk*" }]	
#	set	tpe1_func_rxdi	[get_ports tpes_link_*_inp*[1] -filter {NAME !~ "*fclk*" }]	
#	set	tpe2_func_rxdi	[get_ports tpes_link_*_inp*[2] -filter {NAME !~ "*fclk*" }]	
#	set	tpe3_func_rxdi	[get_ports tpes_link_*_inp*[3] -filter {NAME !~ "*fclk*" }]	
#	set	tpe4_func_rxdi	[get_ports tpes_link_*_inp*[4] -filter {NAME !~ "*fclk*" }]	
#	set	tpe5_func_rxdi	[get_ports tpes_link_*_inp*[5] -filter {NAME !~ "*fclk*" }]	
#	set	tpe6_func_rxdi	[get_ports tpes_link_*_inp*[6] -filter {NAME !~ "*fclk*" }]	
#	set	tpe7_func_rxdi	[get_ports tpes_link_*_inp*[7] -filter {NAME !~ "*fclk*" }]	

#	set_input_delay -clock tpe0_rxdi_clki 0.01	[get_ports $tpe0_func_rxdi]
#	set_input_delay -clock tpe0_rxdi_clki 0.01	[get_ports $tpe0_func_rxdi] -clock_fall -add_delay

#	set_input_delay -clock tpe1_rxdi_clki 0.01	[get_ports $tpe1_func_rxdi]
#	set_input_delay -clock tpe1_rxdi_clki 0.01	[get_ports $tpe1_func_rxdi] -clock_fall -add_delay

#	set_input_delay -clock tpe2_rxdi_clki 0.01	[get_ports $tpe2_func_rxdi]
#	set_input_delay -clock tpe2_rxdi_clki 0.01	[get_ports $tpe2_func_rxdi] -clock_fall -add_delay

#	set_input_delay -clock tpe3_rxdi_clki 0.01	[get_ports $tpe3_func_rxdi]
#	set_input_delay -clock tpe3_rxdi_clki 0.01	[get_ports $tpe3_func_rxdi] -clock_fall -add_delay

#	set_input_delay -clock tpe4_rxdi_clki 0.01	[get_ports $tpe4_func_rxdi]
#	set_input_delay -clock tpe4_rxdi_clki 0.01	[get_ports $tpe4_func_rxdi] -clock_fall -add_delay

#	set_input_delay -clock tpe5_rxdi_clki 0.01	[get_ports $tpe5_func_rxdi]
#	set_input_delay -clock tpe5_rxdi_clki 0.01	[get_ports $tpe5_func_rxdi] -clock_fall -add_delay

#	set_input_delay -clock tpe6_rxdi_clki 0.01	[get_ports $tpe6_func_rxdi]
#	set_input_delay -clock tpe6_rxdi_clki 0.01	[get_ports $tpe6_func_rxdi] -clock_fall -add_delay

#	set_input_delay -clock tpe7_rxdi_clki 0.01	[get_ports $tpe7_func_rxdi]
#	set_input_delay -clock tpe7_rxdi_clki 0.01	[get_ports $tpe7_func_rxdi] -clock_fall -add_delay
#####################################
#	set	tpe0_func_txdo	[get_ports tpem_link_*_out*[0] -filter {NAME !~ "*fclk*" && NAME !~ "*rstn*" && NAME !~ "*tune*" }]	
#	set	tpe1_func_txdo	[get_ports tpem_link_*_out*[1] -filter {NAME !~ "*fclk*" && NAME !~ "*rstn*" && NAME !~ "*tune*" }]	
#	set	tpe2_func_txdo	[get_ports tpem_link_*_out*[2] -filter {NAME !~ "*fclk*" && NAME !~ "*rstn*" && NAME !~ "*tune*" }]	
#	set	tpe3_func_txdo	[get_ports tpem_link_*_out*[3] -filter {NAME !~ "*fclk*" && NAME !~ "*rstn*" && NAME !~ "*tune*" }]	
#	set	tpe4_func_txdo	[get_ports tpem_link_*_out*[4] -filter {NAME !~ "*fclk*" && NAME !~ "*rstn*" && NAME !~ "*tune*" }]	
#	set	tpe5_func_txdo	[get_ports tpem_link_*_out*[5] -filter {NAME !~ "*fclk*" && NAME !~ "*rstn*" && NAME !~ "*tune*" }]	
#	set	tpe6_func_txdo	[get_ports tpem_link_*_out*[6] -filter {NAME !~ "*fclk*" && NAME !~ "*rstn*" && NAME !~ "*tune*" }]	
#	set	tpe7_func_txdo	[get_ports tpem_link_*_out*[7] -filter {NAME !~ "*fclk*" && NAME !~ "*rstn*" && NAME !~ "*tune*" }]	

#	set_output_delay -clock tpe0_txdo_clko 0.01	[get_ports $tpe0_func_txdo]
#	set_output_delay -clock tpe0_txdo_clko 0.01	[get_ports $tpe0_func_txdo] -clock_fall -add_delay
	
#	set_output_delay -clock tpe1_txdo_clko 0.01	[get_ports $tpe1_func_txdo]
#	set_output_delay -clock tpe1_txdo_clko 0.01	[get_ports $tpe1_func_txdo] -clock_fall -add_delay
	
#	set_output_delay -clock tpe2_txdo_clko 0.01	[get_ports $tpe2_func_txdo]
#	set_output_delay -clock tpe2_txdo_clko 0.01	[get_ports $tpe2_func_txdo] -clock_fall -add_delay
	
#	set_output_delay -clock tpe3_txdo_clko 0.01	[get_ports $tpe3_func_txdo]
#	set_output_delay -clock tpe3_txdo_clko 0.01	[get_ports $tpe3_func_txdo] -clock_fall -add_delay
	
#	set_output_delay -clock tpe4_txdo_clko 0.01	[get_ports $tpe4_func_txdo]
#	set_output_delay -clock tpe4_txdo_clko 0.01	[get_ports $tpe4_func_txdo] -clock_fall -add_delay
	
#	set_output_delay -clock tpe5_txdo_clko 0.01	[get_ports $tpe5_func_txdo]
#	set_output_delay -clock tpe5_txdo_clko 0.01	[get_ports $tpe5_func_txdo] -clock_fall -add_delay
	
#	set_output_delay -clock tpe6_txdo_clko 0.01	[get_ports $tpe6_func_txdo]
#	set_output_delay -clock tpe6_txdo_clko 0.01	[get_ports $tpe6_func_txdo] -clock_fall -add_delay
	
#	set_output_delay -clock tpe7_txdo_clko 0.01	[get_ports $tpe7_func_txdo]
#	set_output_delay -clock tpe7_txdo_clko 0.01	[get_ports $tpe7_func_txdo] -clock_fall -add_delay
#####################################
#	set_input_delay 	-clock link_sclk 	3  		[get_ports tpem_scfg_*_inpp[*] ]
#	set_output_delay 	-clock link_sclk 	3  		[get_ports tpem_scfg_*_outp[*] ]
######################################################################################################################################
#####	Timing Constraint Exception
######################################################################################################################################
#	set ddrs_uclk	[get_clocks -of	[get_pins u_ku60_fpga_core/u_lpddr3_256m/inst/u_ddr_infrastructure/u_bufg_divClk/O							 ]]
#	set	pcie_aclk	[get_clocks -of	[get_pins u_pcie_exp8_ctrl/inst/pcie3_ip_i/inst/pcie_xdma_ctrl_pcie3_ip_gt_top_i/phy_clk_i/bufg_gt_userclk/O ]]
#	set	mgt1_uclk	[get_clocks -of	[get_pins u_ku60_mgt1_sdes/u_mgt1_isde_quad/inst/clock_module_i/ultrascale_tx_userclk_1/gen_gtwiz_userclk_tx_main.bufg_gt_usrclk2_inst/O ]]
#	set	mgt2_uclk	[get_clocks -of	[get_pins u_ku60_mgt2_sdes/u_mgt2_isde_quad/inst/clock_module_i/ultrascale_tx_userclk_1/gen_gtwiz_userclk_tx_main.bufg_gt_usrclk2_inst/O ]]
#	set	mgt3_uclk	[get_clocks -of	[get_pins u_ku60_mgt3_sdes/u_mgt3_isde_quad/inst/clock_module_i/ultrascale_tx_userclk_1/gen_gtwiz_userclk_tx_main.bufg_gt_usrclk2_inst/O ]]

#	set_multicycle_path 4 -setup 	-from [get_clocks link_cclk ] 	-to 	[get_clocks 	$pcie_aclk ] 
#	set_multicycle_path 3 -hold 	-from [get_clocks link_cclk ] 	-to 	[get_clocks 	$pcie_aclk ] 

#	set_clock_groups -name link_asyn_pcie_bclk -asynchronous  	-group	[get_clocks	link_sclk ] 	-group 	[get_clocks pcie_base_clki	]
#	set_clock_groups -name link_asyn_tpxl_rcki -asynchronous 	-group	[get_clocks	link_sclk ] 	-group  [get_clocks tp*_rxdi_clki	]
#	set_clock_groups -name link_asyn_tpxl_rcki -asynchronous 	-group	[get_clocks	link_sclk ] 	-group  [get_clocks lane_sclk*		]
	
#	set_clock_groups -name init_asyn_pcie_bclk -asynchronous  	-group	[get_clocks	link_cclk ] 	-group 	[get_clocks $pcie_aclk	]
#	set_clock_groups -name link_asyn_ddrs_sclk -asynchronous  	-group	[get_clocks	link_sclk ]		-group 	[get_clocks $ddrs_uclk		]


#	set_clock_groups -name mgt1_asyn_link_cclk -asynchronous	-group 	[get_clocks	$mgt1_uclk ]	-group	[get_clocks link_cclk 	]		
#	set_clock_groups -name mgt1_asyn_link_sclk -asynchronous 	-group 	[get_clocks $mgt1_uclk ]	-group 	[get_clocks link_sclk 	]
#	set_clock_groups -name mgt1_asyn_ddrs_uclk -asynchronous 	-group 	[get_clocks $mgt1_uclk ]	-group 	[get_clocks $ddrs_uclk 	]

#	set_clock_groups -name mgt2_asyn_link_cclk -asynchronous	-group 	[get_clocks	$mgt2_uclk ]	-group	[get_clocks link_cclk 	]		
#	set_clock_groups -name mgt2_asyn_link_sclk -asynchronous 	-group 	[get_clocks $mgt2_uclk ]	-group 	[get_clocks link_sclk 	]
#	set_clock_groups -name mgt2_asyn_ddrs_uclk -asynchronous 	-group 	[get_clocks $mgt2_uclk ]	-group 	[get_clocks $ddrs_uclk 	]

#	set_clock_groups -name mgt3_asyn_link_cclk -asynchronous	-group 	[get_clocks	$mgt3_uclk ]	-group	[get_clocks link_cclk 	]		
#	set_clock_groups -name mgt3_asyn_link_sclk -asynchronous	-group 	[get_clocks $mgt3_uclk ]	-group 	[get_clocks link_sclk 	]
#	set_clock_groups -name mgt3_asyn_ddrs_uclk -asynchronous	-group 	[get_clocks $mgt3_uclk ]	-group 	[get_clocks $ddrs_uclk 	]


#	set_clock_groups -name pcie_asyn_link_sclk -asynchronous  	-group	[get_clocks $pcie_aclk ]	-group 	[get_clocks link_sclk ]
#	set_clock_groups -name pcie_asyn_lane_sclk -asynchronous	-group	[get_clocks $pcie_aclk ]	-group	[get_clocks lane_sclk*] 
#	set_clock_groups -name pcie_asyn_ddrs_uclk -asynchronous 	-group	[get_clocks $pcie_aclk ]	-group 	[get_clocks $ddrs_uclk]
	
#	set_clock_groups -name chip_asyn_pcie_bclk -asynchronous 	-group	chip_100m					-group 	pcie_base_clki	
##	set_clock_groups -name chip_asyn_link_fclk -asynchronous 	-group 	chip_100m					-group	[get_clocks link_fclk ]
##	set_clock_groups -name chip_asyn_link_sclk -asynchronous 	-group 	chip_100m					-group	[get_clocks link_sclk ]

# 	set_false_path	-from	[get_ports pcie_rstn_io]
######################################################################################################################################
#	set_property IODELAY_GROUP "dlygrp_x1y0" [get_cells u_ku60_fpga_core/u_ku60_dlys_ctrl/u_dlys_ctrl_x1y0]
#	set_property IODELAY_GROUP "dlygrp_x1y0" [get_cells u_ku60_fpga_core/gens_tpem_link_port[7].u_tpem_link_rxdi_pmau/gens_rdxi_idly_cell[0].u_RXDI_IDLY_CELL ]
#	set_property IODELAY_GROUP "dlygrp_x1y0" [get_cells u_ku60_fpga_core/gens_tpem_link_port[7].u_tpem_link_rxdi_pmau/gens_rdxi_idly_cell[1].u_RXDI_IDLY_CELL ]

#	set_property IODELAY_GROUP "dlygrp_x1y1" [get_cells u_ku60_fpga_core/u_ku60_dlys_ctrl/u_dlys_ctrl_x1y1]
#	set_property IODELAY_GROUP "dlygrp_x1y1" [get_cells u_ku60_fpga_core/gens_tpem_link_port[7].u_tpem_link_rxdi_pmau/gens_rdxi_idly_cell[2].u_RXDI_IDLY_CELL ]
#	set_property IODELAY_GROUP "dlygrp_x1y1" [get_cells u_ku60_fpga_core/gens_tpem_link_port[7].u_tpem_link_rxdi_pmau/gens_rdxi_idly_cell[3].u_RXDI_IDLY_CELL ]
#	set_property IODELAY_GROUP "dlygrp_x1y1" [get_cells u_ku60_fpga_core/gens_tpem_link_port[7].u_tpem_link_rxdi_pmau/gens_rdxi_idly_cell[4].u_RXDI_IDLY_CELL ]

#	set_property IODELAY_GROUP "dlygrp_x1y6" [get_cells u_ku60_fpga_core/u_ku60_dlys_ctrl/u_dlys_ctrl_x1y6]
#	set_property IODELAY_GROUP "dlygrp_x1y6" [get_cells u_ku60_fpga_core/gens_tpem_link_port[3].u_tpem_link_rxdi_pmau/gens_rdxi_idly_cell[1].u_RXDI_IDLY_CELL ]
#	set_property IODELAY_GROUP "dlygrp_x1y6" [get_cells u_ku60_fpga_core/gens_tpem_link_port[3].u_tpem_link_rxdi_pmau/gens_rdxi_idly_cell[2].u_RXDI_IDLY_CELL ]

#	set_property IODELAY_GROUP "dlygrp_x1y7" [get_cells u_ku60_fpga_core/u_ku60_dlys_ctrl/u_dlys_ctrl_x1y7]
#	set_property IODELAY_GROUP "dlygrp_x1y7" [get_cells u_ku60_fpga_core/gens_tpem_link_port[3].u_tpem_link_rxdi_pmau/gens_rdxi_idly_cell[0].u_RXDI_IDLY_CELL ]
#	set_property IODELAY_GROUP "dlygrp_x1y7" [get_cells u_ku60_fpga_core/gens_tpem_link_port[3].u_tpem_link_rxdi_pmau/gens_rdxi_idly_cell[3].u_RXDI_IDLY_CELL ]
#	set_property IODELAY_GROUP "dlygrp_x1y7" [get_cells u_ku60_fpga_core/gens_tpem_link_port[3].u_tpem_link_rxdi_pmau/gens_rdxi_idly_cell[4].u_RXDI_IDLY_CELL ]

#	set_property IODELAY_GROUP "dlygrp_x1y8" [get_cells u_ku60_fpga_core/u_ku60_dlys_ctrl/u_dlys_ctrl_x1y8]
#	set_property IODELAY_GROUP "dlygrp_x1y8" [get_cells u_ku60_fpga_core/gens_tpem_link_port[1].u_tpem_link_rxdi_pmau/gens_rdxi_idly_cell[1].u_RXDI_IDLY_CELL ]
#	set_property IODELAY_GROUP "dlygrp_x1y8" [get_cells u_ku60_fpga_core/gens_tpem_link_port[1].u_tpem_link_rxdi_pmau/gens_rdxi_idly_cell[2].u_RXDI_IDLY_CELL ]
#	set_property IODELAY_GROUP "dlygrp_x1y8" [get_cells u_ku60_fpga_core/gens_tpem_link_port[1].u_tpem_link_rxdi_pmau/gens_rdxi_idly_cell[3].u_RXDI_IDLY_CELL ]

#	set_property IODELAY_GROUP "dlygrp_x1y9" [get_cells u_ku60_fpga_core/u_ku60_dlys_ctrl/u_dlys_ctrl_x1y9]
#	set_property IODELAY_GROUP "dlygrp_x1y9" [get_cells u_ku60_fpga_core/gens_tpem_link_port[1].u_tpem_link_rxdi_pmau/gens_rdxi_idly_cell[0].u_RXDI_IDLY_CELL ]
#	set_property IODELAY_GROUP "dlygrp_x1y9" [get_cells u_ku60_fpga_core/gens_tpem_link_port[1].u_tpem_link_rxdi_pmau/gens_rdxi_idly_cell[4].u_RXDI_IDLY_CELL ]

#	set_property IODELAY_GROUP "dlygrp_x1y14" [get_cells u_ku60_fpga_core/u_ku60_dlys_ctrl/u_dlys_ctrl_x1y14]
#	set_property IODELAY_GROUP "dlygrp_x1y14" [get_cells u_ku60_fpga_core/gens_tpem_link_port[6].u_tpem_link_rxdi_pmau/gens_rdxi_idly_cell[0].u_RXDI_IDLY_CELL ]
#	set_property IODELAY_GROUP "dlygrp_x1y14" [get_cells u_ku60_fpga_core/gens_tpem_link_port[6].u_tpem_link_rxdi_pmau/gens_rdxi_idly_cell[2].u_RXDI_IDLY_CELL ]
	
#	set_property IODELAY_GROUP "dlygrp_x1y15" [get_cells u_ku60_fpga_core/u_ku60_dlys_ctrl/u_dlys_ctrl_x1y15]
#	set_property IODELAY_GROUP "dlygrp_x1y15" [get_cells u_ku60_fpga_core/gens_tpem_link_port[6].u_tpem_link_rxdi_pmau/gens_rdxi_idly_cell[1].u_RXDI_IDLY_CELL ]
#	set_property IODELAY_GROUP "dlygrp_x1y15" [get_cells u_ku60_fpga_core/gens_tpem_link_port[6].u_tpem_link_rxdi_pmau/gens_rdxi_idly_cell[3].u_RXDI_IDLY_CELL ]
#	set_property IODELAY_GROUP "dlygrp_x1y15" [get_cells u_ku60_fpga_core/gens_tpem_link_port[6].u_tpem_link_rxdi_pmau/gens_rdxi_idly_cell[4].u_RXDI_IDLY_CELL ]
	
#	set_property IODELAY_GROUP "dlygrp_x1y16" [get_cells u_ku60_fpga_core/u_ku60_dlys_ctrl/u_dlys_ctrl_x1y16]
#	set_property IODELAY_GROUP "dlygrp_x1y16" [get_cells u_ku60_fpga_core/gens_tpem_link_port[2].u_tpem_link_rxdi_pmau/gens_rdxi_idly_cell[0].u_RXDI_IDLY_CELL ]
#	set_property IODELAY_GROUP "dlygrp_x1y16" [get_cells u_ku60_fpga_core/gens_tpem_link_port[2].u_tpem_link_rxdi_pmau/gens_rdxi_idly_cell[3].u_RXDI_IDLY_CELL ]

#	set_property IODELAY_GROUP "dlygrp_x1y17" [get_cells u_ku60_fpga_core/u_ku60_dlys_ctrl/u_dlys_ctrl_x1y17]
#	set_property IODELAY_GROUP "dlygrp_x1y17" [get_cells u_ku60_fpga_core/gens_tpem_link_port[2].u_tpem_link_rxdi_pmau/gens_rdxi_idly_cell[1].u_RXDI_IDLY_CELL ]
#	set_property IODELAY_GROUP "dlygrp_x1y17" [get_cells u_ku60_fpga_core/gens_tpem_link_port[2].u_tpem_link_rxdi_pmau/gens_rdxi_idly_cell[2].u_RXDI_IDLY_CELL ]
#	set_property IODELAY_GROUP "dlygrp_x1y17" [get_cells u_ku60_fpga_core/gens_tpem_link_port[2].u_tpem_link_rxdi_pmau/gens_rdxi_idly_cell[4].u_RXDI_IDLY_CELL ]

#	set_property IODELAY_GROUP "dlygrp_x1y22" [get_cells u_ku60_fpga_core/u_ku60_dlys_ctrl/u_dlys_ctrl_x1y22]
#	set_property IODELAY_GROUP "dlygrp_x1y22" [get_cells u_ku60_fpga_core/gens_tpem_link_port[0].u_tpem_link_rxdi_pmau/gens_rdxi_idly_cell[0].u_RXDI_IDLY_CELL ]
#	set_property IODELAY_GROUP "dlygrp_x1y22" [get_cells u_ku60_fpga_core/gens_tpem_link_port[0].u_tpem_link_rxdi_pmau/gens_rdxi_idly_cell[3].u_RXDI_IDLY_CELL ]

#	set_property IODELAY_GROUP "dlygrp_x1y23" [get_cells u_ku60_fpga_core/u_ku60_dlys_ctrl/u_dlys_ctrl_x1y23]
#	set_property IODELAY_GROUP "dlygrp_x1y23" [get_cells u_ku60_fpga_core/gens_tpem_link_port[0].u_tpem_link_rxdi_pmau/gens_rdxi_idly_cell[1].u_RXDI_IDLY_CELL ]
#	set_property IODELAY_GROUP "dlygrp_x1y23" [get_cells u_ku60_fpga_core/gens_tpem_link_port[0].u_tpem_link_rxdi_pmau/gens_rdxi_idly_cell[2].u_RXDI_IDLY_CELL ]
#	set_property IODELAY_GROUP "dlygrp_x1y23" [get_cells u_ku60_fpga_core/gens_tpem_link_port[0].u_tpem_link_rxdi_pmau/gens_rdxi_idly_cell[4].u_RXDI_IDLY_CELL ]

#	set_property IODELAY_GROUP "dlygrp_x1y24" [get_cells u_ku60_fpga_core/u_ku60_dlys_ctrl/u_dlys_ctrl_x1y24]
#	set_property IODELAY_GROUP "dlygrp_x1y24" [get_cells u_ku60_fpga_core/gens_tpem_link_port[4].u_tpem_link_rxdi_pmau/gens_rdxi_idly_cell[0].u_RXDI_IDLY_CELL ]
#	set_property IODELAY_GROUP "dlygrp_x1y24" [get_cells u_ku60_fpga_core/gens_tpem_link_port[4].u_tpem_link_rxdi_pmau/gens_rdxi_idly_cell[3].u_RXDI_IDLY_CELL ]
#	set_property IODELAY_GROUP "dlygrp_x1y24" [get_cells u_ku60_fpga_core/gens_tpem_link_port[4].u_tpem_link_rxdi_pmau/gens_rdxi_idly_cell[4].u_RXDI_IDLY_CELL ]

#	set_property IODELAY_GROUP "dlygrp_x1y25" [get_cells u_ku60_fpga_core/u_ku60_dlys_ctrl/u_dlys_ctrl_x1y25]
#	set_property IODELAY_GROUP "dlygrp_x1y25" [get_cells u_ku60_fpga_core/gens_tpem_link_port[4].u_tpem_link_rxdi_pmau/gens_rdxi_idly_cell[1].u_RXDI_IDLY_CELL ]
#	set_property IODELAY_GROUP "dlygrp_x1y25" [get_cells u_ku60_fpga_core/gens_tpem_link_port[4].u_tpem_link_rxdi_pmau/gens_rdxi_idly_cell[2].u_RXDI_IDLY_CELL ]

#	set_property IODELAY_GROUP "dlygrp_x1y30" [get_cells u_ku60_fpga_core/u_ku60_dlys_ctrl/u_dlys_ctrl_x1y30]
#	set_property IODELAY_GROUP "dlygrp_x1y30" [get_cells u_ku60_fpga_core/gens_tpem_link_port[5].u_tpem_link_rxdi_pmau/gens_rdxi_idly_cell[0].u_RXDI_IDLY_CELL ]
#	set_property IODELAY_GROUP "dlygrp_x1y30" [get_cells u_ku60_fpga_core/gens_tpem_link_port[5].u_tpem_link_rxdi_pmau/gens_rdxi_idly_cell[2].u_RXDI_IDLY_CELL ]

#	set_property IODELAY_GROUP "dlygrp_x1y31" [get_cells u_ku60_fpga_core/u_ku60_dlys_ctrl/u_dlys_ctrl_x1y31]
#	set_property IODELAY_GROUP "dlygrp_x1y31" [get_cells u_ku60_fpga_core/gens_tpem_link_port[5].u_tpem_link_rxdi_pmau/gens_rdxi_idly_cell[1].u_RXDI_IDLY_CELL ]
#	set_property IODELAY_GROUP "dlygrp_x1y31" [get_cells u_ku60_fpga_core/gens_tpem_link_port[5].u_tpem_link_rxdi_pmau/gens_rdxi_idly_cell[3].u_RXDI_IDLY_CELL ]
#	set_property IODELAY_GROUP "dlygrp_x1y31" [get_cells u_ku60_fpga_core/gens_tpem_link_port[5].u_tpem_link_rxdi_pmau/gens_rdxi_idly_cell[4].u_RXDI_IDLY_CELL ]

#	set_property IODELAY_GROUP "dlygrp_x1y32" [get_cells u_ku60_fpga_core/u_ku60_dlys_ctrl/u_dlys_ctrl_x1y32]
#	set_property IODELAY_GROUP "dlygrp_x1y32" [get_cells u_ku60_fpga_core/gens_tpgm_link_port[3].u_tpgm_link_rxdi_pmau/gens_rdxi_idly_cell[0].u_RXDI_IDLY_CELL ]
#	set_property IODELAY_GROUP "dlygrp_x1y32" [get_cells u_ku60_fpga_core/gens_tpgm_link_port[3].u_tpgm_link_rxdi_pmau/gens_rdxi_idly_cell[3].u_RXDI_IDLY_CELL ]
#	set_property IODELAY_GROUP "dlygrp_x1y32" [get_cells u_ku60_fpga_core/gens_tpgm_link_port[3].u_tpgm_link_rxdi_pmau/gens_rdxi_idly_cell[4].u_RXDI_IDLY_CELL ]


#	set_property IODELAY_GROUP "dlygrp_x1y33" [get_cells u_ku60_fpga_core/u_ku60_dlys_ctrl/u_dlys_ctrl_x1y33]
#	set_property IODELAY_GROUP "dlygrp_x1y33" [get_cells u_ku60_fpga_core/gens_tpgm_link_port[3].u_tpgm_link_rxdi_pmau/gens_rdxi_idly_cell[1].u_RXDI_IDLY_CELL ]
#	set_property IODELAY_GROUP "dlygrp_x1y33" [get_cells u_ku60_fpga_core/gens_tpgm_link_port[3].u_tpgm_link_rxdi_pmau/gens_rdxi_idly_cell[2].u_RXDI_IDLY_CELL ]


#	set_property IODELAY_GROUP "dlygrp_x1y38" [get_cells u_ku60_fpga_core/u_ku60_dlys_ctrl/u_dlys_ctrl_x1y38]
#	set_property IODELAY_GROUP "dlygrp_x1y38" [get_cells u_ku60_fpga_core/gens_tpgm_link_port[2].u_tpgm_link_rxdi_pmau/gens_rdxi_idly_cell[0].u_RXDI_IDLY_CELL ]
#	set_property IODELAY_GROUP "dlygrp_x1y38" [get_cells u_ku60_fpga_core/gens_tpgm_link_port[2].u_tpgm_link_rxdi_pmau/gens_rdxi_idly_cell[2].u_RXDI_IDLY_CELL ]
#	set_property IODELAY_GROUP "dlygrp_x1y38" [get_cells u_ku60_fpga_core/gens_tpgm_link_port[2].u_tpgm_link_rxdi_pmau/gens_rdxi_idly_cell[4].u_RXDI_IDLY_CELL ]

#	set_property IODELAY_GROUP "dlygrp_x1y39" [get_cells u_ku60_fpga_core/u_ku60_dlys_ctrl/u_dlys_ctrl_x1y39]
#	set_property IODELAY_GROUP "dlygrp_x1y39" [get_cells u_ku60_fpga_core/gens_tpgm_link_port[2].u_tpgm_link_rxdi_pmau/gens_rdxi_idly_cell[1].u_RXDI_IDLY_CELL ]
#	set_property IODELAY_GROUP "dlygrp_x1y39" [get_cells u_ku60_fpga_core/gens_tpgm_link_port[2].u_tpgm_link_rxdi_pmau/gens_rdxi_idly_cell[3].u_RXDI_IDLY_CELL ]

#	set_property IODELAY_GROUP "dlygrp_x2y16" [get_cells u_ku60_fpga_core/u_ku60_dlys_ctrl/u_dlys_ctrl_x2y16]
#	set_property IODELAY_GROUP "dlygrp_x2y16" [get_cells u_ku60_fpga_core/gens_tpgm_link_port[1].u_tpgm_link_rxdi_pmau/gens_rdxi_idly_cell[0].u_RXDI_IDLY_CELL ]
#	set_property IODELAY_GROUP "dlygrp_x2y16" [get_cells u_ku60_fpga_core/gens_tpgm_link_port[1].u_tpgm_link_rxdi_pmau/gens_rdxi_idly_cell[1].u_RXDI_IDLY_CELL ]
#	set_property IODELAY_GROUP "dlygrp_x2y16" [get_cells u_ku60_fpga_core/gens_tpgm_link_port[1].u_tpgm_link_rxdi_pmau/gens_rdxi_idly_cell[2].u_RXDI_IDLY_CELL ]

#	set_property IODELAY_GROUP "dlygrp_x2y17" [get_cells u_ku60_fpga_core/u_ku60_dlys_ctrl/u_dlys_ctrl_x2y17]
#	set_property IODELAY_GROUP "dlygrp_x2y17" [get_cells u_ku60_fpga_core/gens_tpgm_link_port[1].u_tpgm_link_rxdi_pmau/gens_rdxi_idly_cell[3].u_RXDI_IDLY_CELL ]
#	set_property IODELAY_GROUP "dlygrp_x2y17" [get_cells u_ku60_fpga_core/gens_tpgm_link_port[1].u_tpgm_link_rxdi_pmau/gens_rdxi_idly_cell[4].u_RXDI_IDLY_CELL ]

#	set_property IODELAY_GROUP "dlygrp_x1y35" [get_cells u_ku60_fpga_core/u_ku60_dlys_ctrl/u_dlys_ctrl_x1y35]
#	set_property IODELAY_GROUP "dlygrp_x1y35" [get_cells u_ku60_fpga_core/gens_tpgm_link_port[3].u_tpgm_link_txdo_pmau/u_FCLK_ODLY_CELL ]

#	set_property IODELAY_GROUP "dlygrp_x1y36" [get_cells u_ku60_fpga_core/u_ku60_dlys_ctrl/u_dlys_ctrl_x1y36]
#	set_property IODELAY_GROUP "dlygrp_x1y36" [get_cells u_ku60_fpga_core/gens_tpgm_link_port[2].u_tpgm_link_txdo_pmau/u_FCLK_ODLY_CELL ]

#	set_property IODELAY_GROUP "dlygrp_x2y19" [get_cells u_ku60_fpga_core/u_ku60_dlys_ctrl/u_dlys_ctrl_x2y19]
#	set_property IODELAY_GROUP "dlygrp_x2y19" [get_cells u_ku60_fpga_core/gens_tpgm_link_port[1].u_tpgm_link_txdo_pmau/u_FCLK_ODLY_CELL ]




## 	set_property IODELAY_GROUP "dlygrp_x1y12" [get_cells u_ku60_fpga_core/u_ku60_dlys_ctrl/u_dlys_ctrl_x1y12]
## 	set_property IODELAY_GROUP "dlygrp_x1y12" [get_cells u_ku60_fpga_core/gens_tpem_link_port[0].u_tpem_link_txdo_pmau/u_FCLK_ODLY_CELL ]
## 
## 	set_property IODELAY_GROUP "dlygrp_x1y4" 	[get_cells u_ku60_fpga_core/u_ku60_dlys_ctrl/u_dlys_ctrl_x1y4]
## 	set_property IODELAY_GROUP "dlygrp_x1y4" 	[get_cells u_ku60_fpga_core/gens_tpem_link_port[1].u_tpem_link_txdo_pmau/u_FCLK_ODLY_CELL ]
## 
## 	set_property IODELAY_GROUP "dlygrp_x1y11" 	[get_cells u_ku60_fpga_core/u_ku60_dlys_ctrl/u_dlys_ctrl_x1y11]
## 	set_property IODELAY_GROUP "dlygrp_x1y11" 	[get_cells u_ku60_fpga_core/gens_tpem_link_port[2].u_tpem_link_txdo_pmau/u_FCLK_ODLY_CELL ]
## 
## 	set_property IODELAY_GROUP "dlygrp_x1y19" 	[get_cells u_ku60_fpga_core/u_ku60_dlys_ctrl/u_dlys_ctrl_x1y19]
## 	set_property IODELAY_GROUP "dlygrp_x1y19" 	[get_cells u_ku60_fpga_core/gens_tpem_link_port[3].u_tpem_link_txdo_pmau/u_FCLK_ODLY_CELL ]
## 
## 	set_property IODELAY_GROUP "dlygrp_x1y28" 	[get_cells u_ku60_fpga_core/u_ku60_dlys_ctrl/u_dlys_ctrl_x1y28]
## 	set_property IODELAY_GROUP "dlygrp_x1y28" 	[get_cells u_ku60_fpga_core/gens_tpem_link_port[4].u_tpem_link_txdo_pmau/u_FCLK_ODLY_CELL ]
## 
## 	set_property IODELAY_GROUP "dlygrp_x1y20" 	[get_cells u_ku60_fpga_core/u_ku60_dlys_ctrl/u_dlys_ctrl_x1y20]
## 	set_property IODELAY_GROUP "dlygrp_x1y20" 	[get_cells u_ku60_fpga_core/gens_tpem_link_port[5].u_tpem_link_txdo_pmau/u_FCLK_ODLY_CELL ]
## 
## 	set_property IODELAY_GROUP "dlygrp_x1y27" 	[get_cells u_ku60_fpga_core/u_ku60_dlys_ctrl/u_dlys_ctrl_x1y27]
## 	set_property IODELAY_GROUP "dlygrp_x1y27" 	[get_cells u_ku60_fpga_core/gens_tpem_link_port[6].u_tpem_link_txdo_pmau/u_FCLK_ODLY_CELL ]
## 
## 	set_property IODELAY_GROUP "dlygrp_x1y3" 	[get_cells u_ku60_fpga_core/u_ku60_dlys_ctrl/u_dlys_ctrl_x1y3]
## 	set_property IODELAY_GROUP "dlygrp_x1y3" 	[get_cells u_ku60_fpga_core/gens_tpem_link_port[7].u_tpem_link_txdo_pmau/u_FCLK_ODLY_CELL ]
##
## 	set_property UNAVAILABLE_DURING_CALIBRATION TRUE [get_ports tpem_link_dat1_outp[3]]
## 	set_property UNAVAILABLE_DURING_CALIBRATION TRUE [get_ports tpem_link_dat1_outp[5]]
## 	set_property UNAVAILABLE_DURING_CALIBRATION TRUE [get_ports tpem_link_dat1_outp[7]]
## 	set_property UNAVAILABLE_DURING_CALIBRATION TRUE [get_ports tpem_link_dat3_outp[6]]
## 	set_property UNAVAILABLE_DURING_CALIBRATION TRUE [get_ports tpem_link_fram_outp[2]]
##

#	set_property UNAVAILABLE_DURING_CALIBRATION TRUE [get_ports tpgm_link_dat0_outp[3]]
#	set_property UNAVAILABLE_DURING_CALIBRATION TRUE [get_ports tpgm_link_dat1_outp[1]]
#	set_property UNAVAILABLE_DURING_CALIBRATION TRUE [get_ports tpgm_link_fram_outp[2]]
######################################################################################################################################
##------------------------------------------------------------
#	set_property CONFIG_MODE SPIx4 [current_design]
#	set_property BITSTREAM.CONFIG.CONFIGRATE 110 [current_design]
#	set_property CONFIG_VOLTAGE 1.8 [current_design]
#	set_property CFGBVS GND [current_design]
#	set_property BITSTREAM.CONFIG.SPI_BUSWIDTH 4 [current_design]
#	set_property BITSTREAM.CONFIG.SPI_FALL_EDGE YES [current_design]
#	set_property BITSTREAM.CONFIG.CONFIGFALLBACK DISABLE [current_design]
#	set_property BITSTREAM.GENERAL.COMPRESS TRUE [current_design]

##	set_property C_CLK_INPUT_FREQ_HZ 300000000 [get_debug_cores dbg_hub]
##	set_property C_ENABLE_CLK_DIVIDER false [get_debug_cores dbg_hub]
##	set_property C_USER_SCAN_CHAIN 1 [get_debug_cores dbg_hub]
##	connect_debug_port dbg_hub/clk [get_nets clk ]

######################################################################################################################################
######################################################################################################################################
##write_cfgmem -format bin -size 256 -interface SPIx4 -loadbit "up 0x0 ./ku35_fpga_tops/ku35_fpga_tops.runs/impl_1/ku35_fpga_tops.bit" -checksum -force -file "./ku35_fpga_tops_20260329.bin"
##write_cfgmem -format mcs -size 256 -interface SPIx4 -loadbit "up 0x0 ./ku35_fpga_tops/ku35_fpga_tops.runs/impl_1/ku35_fpga_tops.bit" -checksum -force -file "./ku35_fpga_tops_20260329.mcs"
##write_cfgmem -format bin -size 256 -interface SPIx4 -loadbit "up 0x0 ./ku60_fpga_tops/ku60_fpga_tops.runs/impl_1/ku60_fpga_tops.bit" -checksum -force -file "./ku60_fpga_tops_20260329.bin"
##write_cfgmem -format mcs -size 256 -interface SPIx4 -loadbit "up 0x0 ./ku60_fpga_tops/ku60_fpga_tops.runs/impl_1/ku60_fpga_tops.bit" -checksum -force -file "./ku60_fpga_tops_20260329.mcs"