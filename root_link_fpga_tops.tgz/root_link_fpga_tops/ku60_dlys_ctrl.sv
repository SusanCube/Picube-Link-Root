module	ku60_dlys_ctrl(
	output		reg						dlys_brst			,
	output								dlys_drdy			,
	input								dlys_fclk			,
	input								dlys_sclk			,
	input								dlys_rstn			);
/***********************************************************************************************************************/
	reg			[ 4: 0]					dlys_drdy_samp	=	5'H00	;
	reg									dlys_ctrl_drdy	=	1'b0	;
	reg			[ 0:24]					dlys_ctrl_sreg	=	0		;
	wire		[ 0:24]					dlys_ctrl_stat	;

	assign	dlys_drdy		=		 	dlys_ctrl_drdy	;

	always@(posedge dlys_sclk or negedge dlys_rstn)
	if(~dlys_rstn)						dlys_ctrl_sreg	<=	0	;
	else 								dlys_ctrl_sreg	<= 	dlys_ctrl_stat	;

	always@(posedge dlys_sclk or negedge dlys_rstn)
	if(~dlys_rstn)						dlys_ctrl_drdy	<=	0	;
	else 								dlys_ctrl_drdy	<= &dlys_ctrl_sreg	;

	always@(posedge dlys_sclk or negedge dlys_rstn)
	if(~dlys_rstn)						dlys_drdy_samp	<= 	5'H00	;
	else 								dlys_drdy_samp	<= 	{dlys_ctrl_drdy	,	dlys_drdy_samp[4:1]};

	always@(posedge dlys_sclk or negedge dlys_rstn)
	if(~dlys_rstn)						dlys_brst		<=	1'B0	;
	else 								dlys_brst		<= 	dlys_drdy_samp[2:0]	== 3'B100		;
/***********************************************************************************************************************/
	reg									dlys_ctrl_disa	=	1'B1	;
	reg			[15: 0]					dlys_ctrl_time	=	16'H0000;
	reg			[24: 0]					dlys_ctrl_prst	=	25'H1FFFFFF;

	wire								dlys_ctrl_init	;				

`ifdef 	FAST_SIMU
	assign	dlys_ctrl_init	=			dlys_ctrl_time	<= 	16'H00F0;
`else
	assign	dlys_ctrl_init	=			dlys_ctrl_time	<= 	16'HFFF0;
`endif	
//------------------------------------------------------------------------------
	always@(posedge dlys_sclk or negedge dlys_rstn)
	if(~dlys_rstn)						dlys_ctrl_time	<=	16'H0	;
	else if( dlys_ctrl_init)			dlys_ctrl_time	<=	16'H1	+	dlys_ctrl_time	;
//------------------------------------------------------------------------------
	always@(posedge dlys_sclk or negedge dlys_rstn)	
	if(~dlys_rstn)						dlys_ctrl_disa	<=	1'H1	;
	else 								dlys_ctrl_disa	<=	dlys_ctrl_init	;
//------------------------------------------------------------------------------
	always@(posedge dlys_sclk or negedge dlys_rstn)
	if(~dlys_rstn)						dlys_ctrl_prst	<=	25'H1FFFFFF;
	else 								dlys_ctrl_prst	<= {25{dlys_ctrl_disa}	};
/***********************************************************************************************************************/
// Y0 group
(* DONT_TOUCH = "TRUE" *) (* LOC = "BITSLICE_CONTROL_X1Y0" *) (* BEL = "BITSLICE_CONTROL_X1Y0" *)
IDELAYCTRL #( .SIM_DEVICE("ULTRASCALE") ) u_dlys_ctrl_x1y0 (.RDY(dlys_ctrl_stat[ 0]), .REFCLK(dlys_fclk), .RST(dlys_ctrl_prst[ 0]));
// Y1 group
(* DONT_TOUCH = "TRUE" *) (* LOC = "BITSLICE_CONTROL_X1Y1" *) (* BEL = "BITSLICE_CONTROL_X1Y1" *)
IDELAYCTRL #( .SIM_DEVICE("ULTRASCALE") ) u_dlys_ctrl_x1y1 (.RDY(dlys_ctrl_stat[ 1]), .REFCLK(dlys_fclk), .RST(dlys_ctrl_prst[ 1]));

// Y6 group
(* DONT_TOUCH = "TRUE" *) (* LOC = "BITSLICE_CONTROL_X1Y6" *) (* BEL = "BITSLICE_CONTROL_X1Y6" *)
IDELAYCTRL #( .SIM_DEVICE("ULTRASCALE") ) u_dlys_ctrl_x1y6 (.RDY(dlys_ctrl_stat[ 2]), .REFCLK(dlys_fclk), .RST(dlys_ctrl_prst[ 2]));

// Y7 group
(* DONT_TOUCH = "TRUE" *) (* LOC = "BITSLICE_CONTROL_X1Y7" *) (* BEL = "BITSLICE_CONTROL_X1Y7" *)
IDELAYCTRL #( .SIM_DEVICE("ULTRASCALE") ) u_dlys_ctrl_x1y7 (.RDY(dlys_ctrl_stat[ 3]), .REFCLK(dlys_fclk), .RST(dlys_ctrl_prst[ 3]));

// Y8 group
(* DONT_TOUCH = "TRUE" *) (* LOC = "BITSLICE_CONTROL_X1Y8" *) (* BEL = "BITSLICE_CONTROL_X1Y8" *)
IDELAYCTRL #( .SIM_DEVICE("ULTRASCALE") ) u_dlys_ctrl_x1y8 (.RDY(dlys_ctrl_stat[ 4]), .REFCLK(dlys_fclk), .RST(dlys_ctrl_prst[ 4]));

// Y9 group
(* DONT_TOUCH = "TRUE" *) (* LOC = "BITSLICE_CONTROL_X1Y9" *) (* BEL = "BITSLICE_CONTROL_X1Y9" *)
IDELAYCTRL #( .SIM_DEVICE("ULTRASCALE") ) u_dlys_ctrl_x1y9 (.RDY(dlys_ctrl_stat[ 5]), .REFCLK(dlys_fclk), .RST(dlys_ctrl_prst[ 5]));

// Y14 group
(* DONT_TOUCH = "TRUE" *) (* LOC = "BITSLICE_CONTROL_X1Y14" *) (* BEL = "BITSLICE_CONTROL_X1Y14" *)
IDELAYCTRL #( .SIM_DEVICE("ULTRASCALE") ) u_dlys_ctrl_x1y14 (.RDY(dlys_ctrl_stat[ 6]), .REFCLK(dlys_fclk), .RST(dlys_ctrl_prst[ 6]));

// Y15 group
(* DONT_TOUCH = "TRUE" *) (* LOC = "BITSLICE_CONTROL_X1Y15" *) (* BEL = "BITSLICE_CONTROL_X1Y15" *)
IDELAYCTRL #( .SIM_DEVICE("ULTRASCALE") ) u_dlys_ctrl_x1y15 (.RDY(dlys_ctrl_stat[ 7]), .REFCLK(dlys_fclk), .RST(dlys_ctrl_prst[ 7]));

// Y16 group
(* DONT_TOUCH = "TRUE" *) (* LOC = "BITSLICE_CONTROL_X1Y16" *) (* BEL = "BITSLICE_CONTROL_X1Y16" *)
IDELAYCTRL #( .SIM_DEVICE("ULTRASCALE") ) u_dlys_ctrl_x1y16 (.RDY(dlys_ctrl_stat[ 8]), .REFCLK(dlys_fclk), .RST(dlys_ctrl_prst[ 8]));

// Y17 group
(* DONT_TOUCH = "TRUE" *) (* LOC = "BITSLICE_CONTROL_X1Y17" *) (* BEL = "BITSLICE_CONTROL_X1Y17" *)
IDELAYCTRL #( .SIM_DEVICE("ULTRASCALE") ) u_dlys_ctrl_x1y17 (.RDY(dlys_ctrl_stat[ 9]), .REFCLK(dlys_fclk), .RST(dlys_ctrl_prst[ 9]));

// Y22 group
(* DONT_TOUCH = "TRUE" *) (* LOC = "BITSLICE_CONTROL_X1Y22" *) (* BEL = "BITSLICE_CONTROL_X1Y22" *)
IDELAYCTRL #( .SIM_DEVICE("ULTRASCALE") ) u_dlys_ctrl_x1y22 (.RDY(dlys_ctrl_stat[10]), .REFCLK(dlys_fclk), .RST(dlys_ctrl_prst[10]));

// Y23 group
(* DONT_TOUCH = "TRUE" *) (* LOC = "BITSLICE_CONTROL_X1Y23" *) (* BEL = "BITSLICE_CONTROL_X1Y23" *)
IDELAYCTRL #( .SIM_DEVICE("ULTRASCALE") ) u_dlys_ctrl_x1y23 (.RDY(dlys_ctrl_stat[11]), .REFCLK(dlys_fclk), .RST(dlys_ctrl_prst[11]));

// Y24 group
(* DONT_TOUCH = "TRUE" *) (* LOC = "BITSLICE_CONTROL_X1Y24" *) (* BEL = "BITSLICE_CONTROL_X1Y24" *)
IDELAYCTRL #( .SIM_DEVICE("ULTRASCALE") ) u_dlys_ctrl_x1y24 (.RDY(dlys_ctrl_stat[12]), .REFCLK(dlys_fclk), .RST(dlys_ctrl_prst[12]));

// Y25 group
(* DONT_TOUCH = "TRUE" *) (* LOC = "BITSLICE_CONTROL_X1Y25" *) (* BEL = "BITSLICE_CONTROL_X1Y25" *)
IDELAYCTRL #( .SIM_DEVICE("ULTRASCALE") ) u_dlys_ctrl_x1y25 (.RDY(dlys_ctrl_stat[13]), .REFCLK(dlys_fclk), .RST(dlys_ctrl_prst[13]));

// Y30 group
(* DONT_TOUCH = "TRUE" *) (* LOC = "BITSLICE_CONTROL_X1Y30" *) (* BEL = "BITSLICE_CONTROL_X1Y30" *)
IDELAYCTRL #( .SIM_DEVICE("ULTRASCALE") ) u_dlys_ctrl_x1y30 (.RDY(dlys_ctrl_stat[14]), .REFCLK(dlys_fclk), .RST(dlys_ctrl_prst[14]));

// Y31 group
(* DONT_TOUCH = "TRUE" *) (* LOC = "BITSLICE_CONTROL_X1Y31" *) (* BEL = "BITSLICE_CONTROL_X1Y31" *)
IDELAYCTRL #( .SIM_DEVICE("ULTRASCALE") ) u_dlys_ctrl_x1y31 (.RDY(dlys_ctrl_stat[15]), .REFCLK(dlys_fclk), .RST(dlys_ctrl_prst[15]));

// Y32 group
(* DONT_TOUCH = "TRUE" *) (* LOC = "BITSLICE_CONTROL_X1Y32" *) (* BEL = "BITSLICE_CONTROL_X1Y32" *)
IDELAYCTRL #( .SIM_DEVICE("ULTRASCALE") ) u_dlys_ctrl_x1y32 (.RDY(dlys_ctrl_stat[16]), .REFCLK(dlys_fclk), .RST(dlys_ctrl_prst[16]));

// Y33 group
(* DONT_TOUCH = "TRUE" *) (* LOC = "BITSLICE_CONTROL_X1Y33" *) (* BEL = "BITSLICE_CONTROL_X1Y33" *)
IDELAYCTRL #( .SIM_DEVICE("ULTRASCALE") ) u_dlys_ctrl_x1y33 (.RDY(dlys_ctrl_stat[17]), .REFCLK(dlys_fclk), .RST(dlys_ctrl_prst[17]));

// Y35 group
(* DONT_TOUCH = "TRUE" *) (* LOC = "BITSLICE_CONTROL_X1Y35" *) (* BEL = "BITSLICE_CONTROL_X1Y35" *)
IDELAYCTRL #( .SIM_DEVICE("ULTRASCALE") ) u_dlys_ctrl_x1y35 (.RDY(dlys_ctrl_stat[18]), .REFCLK(dlys_fclk), .RST(dlys_ctrl_prst[18]));

// Y36 group
(* DONT_TOUCH = "TRUE" *) (* LOC = "BITSLICE_CONTROL_X1Y36" *) (* BEL = "BITSLICE_CONTROL_X1Y36" *)
IDELAYCTRL #( .SIM_DEVICE("ULTRASCALE") ) u_dlys_ctrl_x1y36 (.RDY(dlys_ctrl_stat[19]), .REFCLK(dlys_fclk), .RST(dlys_ctrl_prst[19]));

// Y38 group
(* DONT_TOUCH = "TRUE" *) (* LOC = "BITSLICE_CONTROL_X1Y38" *) (* BEL = "BITSLICE_CONTROL_X1Y38" *)
IDELAYCTRL #( .SIM_DEVICE("ULTRASCALE") ) u_dlys_ctrl_x1y38 (.RDY(dlys_ctrl_stat[20]), .REFCLK(dlys_fclk), .RST(dlys_ctrl_prst[20]));

// Y39 group
(* DONT_TOUCH = "TRUE" *) (* LOC = "BITSLICE_CONTROL_X1Y39" *) (* BEL = "BITSLICE_CONTROL_X1Y39" *)
IDELAYCTRL #( .SIM_DEVICE("ULTRASCALE") ) u_dlys_ctrl_x1y39 (.RDY(dlys_ctrl_stat[21]), .REFCLK(dlys_fclk), .RST(dlys_ctrl_prst[21]));

// X2Y16 group
(* DONT_TOUCH = "TRUE" *) (* LOC = "BITSLICE_CONTROL_X2Y16" *) (* BEL = "BITSLICE_CONTROL_X2Y16" *)
IDELAYCTRL #( .SIM_DEVICE("ULTRASCALE") ) u_dlys_ctrl_x2y16 (.RDY(dlys_ctrl_stat[22]), .REFCLK(dlys_fclk), .RST(dlys_ctrl_prst[22]));

// X2Y17 group
(* DONT_TOUCH = "TRUE" *) (* LOC = "BITSLICE_CONTROL_X2Y17" *) (* BEL = "BITSLICE_CONTROL_X2Y17" *)
IDELAYCTRL #( .SIM_DEVICE("ULTRASCALE") ) u_dlys_ctrl_x2y17 (.RDY(dlys_ctrl_stat[23]), .REFCLK(dlys_fclk), .RST(dlys_ctrl_prst[23]));

// X2Y19 group
(* DONT_TOUCH = "TRUE" *) (* LOC = "BITSLICE_CONTROL_X2Y19" *) (* BEL = "BITSLICE_CONTROL_X2Y19" *)
IDELAYCTRL #( .SIM_DEVICE("ULTRASCALE") ) u_dlys_ctrl_x2y19 (.RDY(dlys_ctrl_stat[24]), .REFCLK(dlys_fclk), .RST(dlys_ctrl_prst[24]));



//
//// X1Y12 group
//(* DONT_TOUCH = "TRUE" *) (* LOC = "BITSLICE_CONTROL_X1Y12" *) (* BEL = "BITSLICE_CONTROL_X1Y12" *)
//IDELAYCTRL #( .SIM_DEVICE("ULTRASCALE") ) u_dlys_ctrl_x1y12 (.RDY(dlys_ctrl_stat[25]), .REFCLK(dlys_fclk), .RST(dlys_ctrl_prst[25]));
//// X1Y4 group
//(* DONT_TOUCH = "TRUE" *) (* LOC = "BITSLICE_CONTROL_X1Y4" *) (* BEL = "BITSLICE_CONTROL_X1Y4" *)
//IDELAYCTRL #( .SIM_DEVICE("ULTRASCALE") ) u_dlys_ctrl_x1y4 (.RDY(dlys_ctrl_stat[26]), .REFCLK(dlys_fclk), .RST(dlys_ctrl_prst[26]));
//// X1Y11 group
//(* DONT_TOUCH = "TRUE" *) (* LOC = "BITSLICE_CONTROL_X1Y11" *) (* BEL = "BITSLICE_CONTROL_X1Y11" *)
//IDELAYCTRL #( .SIM_DEVICE("ULTRASCALE") ) u_dlys_ctrl_x1y11 (.RDY(dlys_ctrl_stat[27]), .REFCLK(dlys_fclk), .RST(dlys_ctrl_prst[27]));
//// X1Y19 group
//(* DONT_TOUCH = "TRUE" *) (* LOC = "BITSLICE_CONTROL_X1Y19" *) (* BEL = "BITSLICE_CONTROL_X1Y19" *)
//IDELAYCTRL #( .SIM_DEVICE("ULTRASCALE") ) u_dlys_ctrl_x1y19 (.RDY(dlys_ctrl_stat[28]), .REFCLK(dlys_fclk), .RST(dlys_ctrl_prst[28]));
//// X1Y28 group
//(* DONT_TOUCH = "TRUE" *) (* LOC = "BITSLICE_CONTROL_X1Y28" *) (* BEL = "BITSLICE_CONTROL_X1Y28" *)
//IDELAYCTRL #( .SIM_DEVICE("ULTRASCALE") ) u_dlys_ctrl_x1y28 (.RDY(dlys_ctrl_stat[29]), .REFCLK(dlys_fclk), .RST(dlys_ctrl_prst[29]));
//// X1Y20 group
//(* DONT_TOUCH = "TRUE" *) (* LOC = "BITSLICE_CONTROL_X1Y20" *) (* BEL = "BITSLICE_CONTROL_X1Y20" *)
//IDELAYCTRL #( .SIM_DEVICE("ULTRASCALE") ) u_dlys_ctrl_x1y20 (.RDY(dlys_ctrl_stat[30]), .REFCLK(dlys_fclk), .RST(dlys_ctrl_prst[30]));
//// X1Y27 group
//(* DONT_TOUCH = "TRUE" *) (* LOC = "BITSLICE_CONTROL_X1Y27" *) (* BEL = "BITSLICE_CONTROL_X1Y27" *)
//IDELAYCTRL #( .SIM_DEVICE("ULTRASCALE") ) u_dlys_ctrl_x1y27 (.RDY(dlys_ctrl_stat[31]), .REFCLK(dlys_fclk), .RST(dlys_ctrl_prst[31]));
//// X1Y3 group
//(* DONT_TOUCH = "TRUE" *) (* LOC = "BITSLICE_CONTROL_X1Y3" *) (* BEL = "BITSLICE_CONTROL_X1Y3" *)
//IDELAYCTRL #( .SIM_DEVICE("ULTRASCALE") ) u_dlys_ctrl_x1y3 (.RDY(dlys_ctrl_stat[32]), .REFCLK(dlys_fclk), .RST(dlys_ctrl_prst[32]));
//
 
endmodule	


