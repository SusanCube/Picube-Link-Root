//--MGT1::ku60_aurora_64b66b_x1y2_rxo
//--MGT2::ku60_aurora_64b66b_x1y3_rxo
//--MGT3::ku60_aurora_64b66b_x1y4_rxo

module	ku60_mgt3_sdes_rxo(
	input	[ 0: 3]						mgt3_rxp_io			,
	input	[ 0: 3]						mgt3_rxn_io			,
	input								mgt3_rclk_p			,
	input								mgt3_rclk_n			,
	
	output								mgt3_intf_link_stat	,
	input								mgt3_pmau_init_ctrl	,
	input								mgt3_rstb_push_ctrl	,
	output	[255:0]						mgt3_isde_wdma_data	, 	 
    output								mgt3_isde_wdma_drdy	,
	
	output								mgt3_clki			,
	input								link_cclk			);
/**********************************************************************************************************/
	wire  	[0:3]     					mgt3_lane_up		;
	wire 	[3:0]      					mgt3_powr_up		;
	wire            					mgt3_chnl_up		;
	wire            					mgt3_qpll_up		;
	
	wire            					mgt3_dnot_lock		;
	wire								mgt3_link_rsto		;
	wire            					mgt3_txrx_rsto		;
	wire            					mgt3_msys_rsto		;
		
	wire								mgt3_hard_errs		;
	wire								mgt3_soft_errs		;
	
	assign	mgt3_intf_link_stat	=	&{	mgt3_lane_up		,//15:12
										mgt3_powr_up		,//11: 8
										mgt3_chnl_up		,//7
										mgt3_qpll_up		,//6
								 	 ~	mgt3_hard_errs		,//5
								 	 ~	mgt3_soft_errs		,//4
								 	 ~	mgt3_dnot_lock		,//5
								 	 ~	mgt3_link_rsto		,//2
								 	 ~	mgt3_txrx_rsto		,//1
								 	 ~	mgt3_msys_rsto		};//0
/*********************************************************************************************************/

/*********************************************************************************************************/
	ku60_mgth_x1y4_rxo				u_mgt3_isde_quad(
		.m_axi_rx_tdata					(mgt3_isde_wdma_data	),
		.m_axi_rx_tvalid				(mgt3_isde_wdma_drdy	),

		.rxp							(mgt3_rxp_io			),
		.rxn							(mgt3_rxn_io			),

		.gt_refclk1_p					(mgt3_rclk_p			),
		.gt_refclk1_n					(mgt3_rclk_n			),
		.gt_refclk1_out					(						),

		.rx_hard_err					(mgt3_hard_errs			),
		.rx_soft_err					(mgt3_soft_errs			),

		.rx_channel_up  				(mgt3_chnl_up			),
		.rx_lane_up     				(mgt3_lane_up			),

		.init_clk						(link_cclk				),
		.user_clk_out          			(mgt3_clki				),
        .tx_out_clk                 	(						),//Keep Not Connect


        .gt_rxcdrovrden_in				(1'B0					),
		.mmcm_not_locked_out			(mgt3_dnot_lock			),
        .gt_pll_lock					(mgt3_qpll_up			),

		.reset2fc						(						),
        .reset_pb						(mgt3_rstb_push_ctrl	),
		.pma_init						(mgt3_pmau_init_ctrl	),


		.gt_powergood					(mgt3_powr_up			),
		.power_down						(1'B0					),

        .link_reset_out					(mgt3_link_rsto			),
		.sys_reset_out					(mgt3_msys_rsto			),
		.gt_reset_out					(mgt3_txrx_rsto			),

		.gt0_drpaddr					(9'H0					),//    input   [8:0]     
		.gt0_drpdi						(16'H0000				),//    input   [15:0]  
		.gt0_drpen						(1'H0					),//    input            
		.gt0_drpwe						(1'H0					),//    input            
		.gt0_drpdo						(),//    output  [15:0]   
		.gt0_drprdy						(),//    output            

		.gt1_drpaddr					(9'H0					),
		.gt1_drpdi						(16'H0000				),
		.gt1_drpen						(1'H0					), 
		.gt1_drpwe						(1'H0					), 
		.gt1_drpdo						(), 
		.gt1_drprdy						(), 

		.gt2_drpaddr					(9'H0					),
		.gt2_drpdi						(16'H0000				),
		.gt2_drpen						(1'H0					), 
		.gt2_drpwe						(1'H0					), 
		.gt2_drpdo						(), 
		.gt2_drprdy						(), 

		.gt3_drpaddr					(9'H0					),
		.gt3_drpdi						(16'H0000				),
		.gt3_drpen						(1'H0					), 
		.gt3_drpwe						(1'H0					), 
		.gt3_drpdo						(), 
		.gt3_drprdy						() 

        );
 

endmodule
	
