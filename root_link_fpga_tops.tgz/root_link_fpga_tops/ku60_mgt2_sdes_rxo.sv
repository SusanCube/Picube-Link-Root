//--MGT1::ku60_aurora_64b66b_x1y2_rxo
//--MGT2::ku60_aurora_64b66b_x1y3_rxo
//--MGT3::ku60_aurora_64b66b_x1y4_rxo

module	ku60_mgt2_sdes_rxo(
	input	[ 0: 3]						mgt2_rxp_io			,
	input	[ 0: 3]						mgt2_rxn_io			,
	input								mgt2_rclk_p			,
	input								mgt2_rclk_n			,
	
	output								mgt2_intf_link_stat	,
	input								mgt2_pmau_init_ctrl	,
	input								mgt2_rstb_push_ctrl	,
	output	[255:0]						mgt2_isde_wdma_data	, 	 
    output								mgt2_isde_wdma_drdy	,
	
	output								mgt2_clki			,
	input								link_cclk			);
/**********************************************************************************************************/
	wire  	[0:3]     					mgt2_lane_up		;
	wire 	[3:0]      					mgt2_powr_up		;
	wire            					mgt2_chnl_up		;
	wire            					mgt2_qpll_up		;
	
	wire            					mgt2_dnot_lock		;
	wire								mgt2_link_rsto		;
	wire            					mgt2_txrx_rsto		;
	wire            					mgt2_msys_rsto		;
		
	wire								mgt2_hard_errs		;
	wire								mgt2_soft_errs		;
	
	assign	mgt2_intf_link_stat	=	&{	mgt2_lane_up		,//15:12
										mgt2_powr_up		,//11: 8
										mgt2_chnl_up		,//7
										mgt2_qpll_up		,//6
								 	 ~	mgt2_hard_errs		,//5
								 	 ~	mgt2_soft_errs		,//4
								 	 ~	mgt2_dnot_lock		,//5
								 	 ~	mgt2_link_rsto		,//2
								 	 ~	mgt2_txrx_rsto		,//1
								 	 ~	mgt2_msys_rsto		};//0
/*********************************************************************************************************/

/*********************************************************************************************************/
	ku60_mgth_x1y3_rxo				u_mgt2_isde_quad(
		.m_axi_rx_tdata					(mgt2_isde_wdma_data	),
		.m_axi_rx_tvalid				(mgt2_isde_wdma_drdy	),

		.rxp							(mgt2_rxp_io			),
		.rxn							(mgt2_rxn_io			),

		.gt_refclk1_p					(mgt2_rclk_p			),
		.gt_refclk1_n					(mgt2_rclk_n			),
		.gt_refclk1_out					(						),

		.rx_hard_err					(mgt2_hard_errs			),
		.rx_soft_err					(mgt2_soft_errs			),

		.rx_channel_up  				(mgt2_chnl_up			),
		.rx_lane_up     				(mgt2_lane_up			),

		.init_clk						(link_cclk				),
		.user_clk_out          			(mgt2_clki				),
        .tx_out_clk                 	(						),//Keep Not Connect


        .gt_rxcdrovrden_in				(1'B0					),
		.mmcm_not_locked_out			(mgt2_dnot_lock			),
        .gt_pll_lock					(mgt2_qpll_up			),

		.reset2fc						(						),
        .reset_pb						(mgt2_rstb_push_ctrl	),
		.pma_init						(mgt2_pmau_init_ctrl	),


		.gt_powergood					(mgt2_powr_up			),
		.power_down						(1'B0					),

        .link_reset_out					(mgt2_link_rsto			),
		.sys_reset_out					(mgt2_msys_rsto			),
		.gt_reset_out					(mgt2_txrx_rsto			),

		.gt0_drpaddr					(9'H0					),//    input   [8:0]     
		.gt0_drpdi						(16'H0000				),//    input   [15:0]  
		.gt0_drpen						(1'H0					),//    input            
		.gt0_drpwe						(1'H0					),//    input            
		.gt0_drpdo						(),//    output  [15:0]   
		.gt0_drprdy						(),//    output            

		.gt1_drpaddr					(9'H0					),
		.gt1_drpdi						(16'H0000				),
		.gt1_drpen						(1'H0					), 
		.gt1_drpwe						(1'H0					), 
		.gt1_drpdo						(), 
		.gt1_drprdy						(), 

		.gt2_drpaddr					(9'H0					),
		.gt2_drpdi						(16'H0000				),
		.gt2_drpen						(1'H0					), 
		.gt2_drpwe						(1'H0					), 
		.gt2_drpdo						(), 
		.gt2_drprdy						(), 

		.gt3_drpaddr					(9'H0					),
		.gt3_drpdi						(16'H0000				),
		.gt3_drpen						(1'H0					), 
		.gt3_drpwe						(1'H0					), 
		.gt3_drpdo						(), 
		.gt3_drprdy						() 

        );
 

endmodule
	
