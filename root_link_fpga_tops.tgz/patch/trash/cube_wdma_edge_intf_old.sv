/*----author edward------
//	wire							cube_idat_wdma_enab	;
//	assign	cube_idat_wdma_enab	= 	cube_idat_wdma_samp[2:0] ==	3'B111	;
*/

module	cube_wdma_edge_intf(
	input								this_tpgs_pile_lead	,
	input		[ 4: 0]					this_tpgs_edge_base	,
	input		[ 3: 0]					ecos_omni_pile_numb	,

	input		[24 : 0]				llmb_mast_ddrs_base	,
	input		[19 : 0]				llmb_mast_imag_cols	,

	input		[24 : 0]				llmb_edge_imag_size	,
	input		[19 : 0]				llmb_edge_imag_cols	,
	input								llmb_edge_imag_even	,//0:ODD 1: EVEN
	input								llmb_edge_imag_row2	,//0:
	
	input								cube_edge_wdma_enab	,//write enable
	input								cube_edge_wdma_mode	,//0:VECT 1: MTRX
	input								cube_edge_idat_lead	,
	input								cube_edge_idat_wrcs	,
	input		[ 31: 0]				cube_edge_idat_data	,

	input								link_clki			,
	input								link_rstn			,
//------------------------------------------------------------------------------
	input								cube_edge_wdma_init	,	
	input								cube_edge_wdma_pick	,	
	input								cube_edge_wdma_reqs	,	
	input		[ 3: 0]					cube_edge_wdma_size	,

	output								cube_edge_wdma_ov08	,
	output								cube_edge_wdma_ov04	,
	output								cube_edge_wdma_ov02	,
	output								cube_edge_wdma_ov01	,

	output		[255: 0]				ubus_edge_wdma_data	,
	output		[ 24: 0]				ubus_edge_wdma_addr	,
	output	reg							ubus_edge_wdma_drdy	,				

	input								ubus_clki			,
	input								ubus_rstn			);
/**********************************************************************************************************/
	wire		[ 7: 0]					edge_push_page_dptr	;
	wire		[24: 0]					edge_push_page_addr	;
	wire		[255:0]					edge_push_page_data	;
	wire								edge_push_page_drdy	;

	cube_wdma_edge_push				u_cube_wdma_edge_push(
		.this_tpgs_pile_lead			(this_tpgs_pile_lead	),//input				
		.this_tpgs_edge_base			(this_tpgs_edge_base	),//input		[ 4: 0]	
		.ecos_omni_pile_numb			(ecos_omni_pile_numb	),//input		[ 3: 0]	
		
		.llmb_mast_ddrs_base			(llmb_mast_ddrs_base	),//input		[24 : 0]
		.llmb_mast_imag_cols			(llmb_mast_imag_cols	),//input		[19 : 0]

		.llmb_edge_imag_size			(llmb_edge_imag_size	),//input		[24 : 0]
		.llmb_edge_imag_cols			(llmb_edge_imag_cols	),//input		[19 : 0]
		.llmb_edge_imag_even			(llmb_edge_imag_even	),	//input				
		.llmb_edge_imag_row2			(llmb_edge_imag_row2	),	//input				

		.cube_edge_wdma_enab			(cube_edge_wdma_enab	),	//input				
		.cube_edge_wdma_mode			(cube_edge_wdma_mode	),	//input				
		.cube_edge_idat_lead			(cube_edge_idat_lead	),	//input				
		.cube_edge_idat_wrcs			(cube_edge_idat_wrcs	),	//input				
		.cube_edge_idat_data			(cube_edge_idat_data	),	//input		[ 31: 0]
		
		.edge_push_page_dptr			(edge_push_page_dptr	),	//output	reg	[ 6: 0]	
		.edge_push_page_addr			(edge_push_page_addr	),	//output	reg	[24: 0]	
		.edge_push_page_data			(edge_push_page_data	),	//output	reg	[255:0]	
		.edge_push_page_drdy			(edge_push_page_drdy	),	//output	reg			
		.link_clki						(link_clki				),//input				
		.link_rstn						(link_rstn				));//input				

	cube_wdma_ubus_pops				u_cube_wdma_ubus_pops(
		.llmb_edge_imag_cols			(llmb_edge_imag_cols[11:4]),	
		.edge_push_page_lead			(cube_edge_idat_lead	),//input				
		.edge_push_page_dptr			(edge_push_page_dptr	),//input		[ 6: 0]	
		.edge_push_page_addr			(edge_push_page_addr	),//input		[24: 0]	
		.edge_push_page_data			(edge_push_page_data	),//input		[255:0]	
		.edge_push_page_drdy			(edge_push_page_drdy	),//input				
		.edge_clki						(link_clki				),//input				
		.edge_rstn						(link_rstn				),//input				
				
		.ubus_pops_page_init			(cube_edge_wdma_init	),//input				
		.ubus_pops_page_pick			(cube_edge_wdma_pick	),//input				
		.ubus_pops_page_reqs			(cube_edge_wdma_reqs	),//input				
		.ubus_pops_page_size			(cube_edge_wdma_size	),//input		[ 3: 0]	

		.ubus_pops_resv_ov08			(cube_edge_wdma_ov08	),//output	
		.ubus_pops_resv_ov04			(cube_edge_wdma_ov04	),//output	
		.ubus_pops_resv_ov02			(cube_edge_wdma_ov02	),//output	
		.ubus_pops_resv_ov01			(cube_edge_wdma_ov01	),//output	
	
		.ubus_pops_page_addr			(ubus_edge_wdma_addr	),//output		[ 24: 0]
		.ubus_pops_page_data			(ubus_edge_wdma_data	),//output		[255: 0]
		.ubus_pops_page_drdy			(ubus_edge_wdma_drdy	),//output	reg			
	
		.ubus_clki						(ubus_clki				),//input	
		.ubus_rstn						(ubus_rstn				));//input	


endmodule 
 
