/*----author edward------
//	wire							cube_idat_wdma_enab	;
//	assign	cube_idat_wdma_enab	= 	cube_idat_wdma_samp[2:0] ==	3'B111	;
*/

module	cube_edge_wdma_dmau(
	input								this_tpgs_pile_lead	,
	input		[ 4: 0]					this_tpgs_edge_base	,

	input		[24 : 0]				llmb_hubs_ddrs_base	,
	input		[19 : 0]				llmb_hubs_imag_cols	,
	input		[19 : 0]				llmb_mtrx_imag_cols	,
	
	input								llmb_edge_imag_even	,//0:ODD 1: EVEN
	input		[24 : 0]				llmb_edge_imag_size	,
	input		[19 : 0]				llmb_edge_imag_cols	,
	input								llmb_edge_imag_row2	,
	
	input								cube_edge_wdma_enab	,//write enable
	input								cube_edge_wdma_mode	,//0:VECT 1: MTRX
	input								cube_edge_idat_lead	,
	input								cube_edge_idat_wrcs	,
	input		[ 31: 0]				cube_edge_idat_data	,

	input								link_clki			,
	input								link_rstn			,
//------------------------------------------------------------------------------
	input								edge_wdma_taps_pick	,	
	output								edge_wdma_tapx_issu	,
	output								edge_wdma_tap4_issu	,
	input								edge_wdma_tapx_reqs	,	//0:TAP4_POPS 1:TAPX_POPS 
	input								edge_wdma_tap4_reqs	,	

	output		[255: 0]				edge_wdma_page_data	,
	output		[ 24: 0]				edge_wdma_page_addr	,
	output								edge_wdma_page_drdy	,				

	input								ubus_clki			,
	input								ubus_rstn			);
/**********************************************************************************************************/
	wire		[ 7: 0]					edge_push_page_dptr	;
	wire		[24: 0]					edge_push_page_addr	;
	wire		[255:0]					edge_push_page_data	;
	wire								edge_push_page_drdy	;

	cube_edge_wdma_push				u_cube_edge_wdma_push(
		.this_tpgs_pile_lead			(this_tpgs_pile_lead	),//input				
		.this_tpgs_edge_base			(this_tpgs_edge_base	),//input		[ 4: 0]	
		
		.llmb_hubs_ddrs_base			(llmb_hubs_ddrs_base	),//input		[24 : 0]
		.llmb_hubs_imag_cols			(llmb_hubs_imag_cols	),//input		[19 : 0]
		.llmb_mtrx_imag_cols			(llmb_mtrx_imag_cols	),
		
		.llmb_edge_imag_size			(llmb_edge_imag_size	),//input		[24 : 0]
		.llmb_edge_imag_cols			(llmb_edge_imag_cols	),//input		[19 : 0]
		.llmb_edge_imag_even			(llmb_edge_imag_even	),	//input				
		.llmb_edge_imag_row2			(llmb_edge_imag_row2	),	//input				

		.cube_edge_wdma_enab			(cube_edge_wdma_enab	),	//input				
		.cube_edge_wdma_mode			(cube_edge_wdma_mode	),	//input				
		.cube_edge_idat_lead			(cube_edge_idat_lead	),	//input				
		.cube_edge_idat_wrcs			(cube_edge_idat_wrcs	),	//input				
		.cube_edge_idat_data			(cube_edge_idat_data	),	//input		[ 31: 0]
		
//		.edge_push_page_dptr			(edge_push_page_dptr	),	//output	reg	[ 6: 0]	
		.edge_push_page_addr			(edge_push_page_addr	),	//output	reg	[24: 0]	
		.edge_push_page_data			(edge_push_page_data	),	//output	reg	[255:0]	
		.edge_push_page_drdy			(edge_push_page_drdy	),	//output	reg			
		.link_clki						(link_clki				),//input				
		.link_rstn						(link_rstn				));//input				

	cube_edge_wdma_pops				u_cube_edge_wdma_pops(
		.edge_push_ddrs_enab			(cube_edge_wdma_enab	),	
		.edge_push_rows_page			(llmb_edge_imag_cols[11:4]),	
		.edge_push_page_lead			(cube_edge_idat_lead	),//input				
		.edge_push_page_addr			(edge_push_page_addr	),//input		[24: 0]	
		.edge_push_page_data			(edge_push_page_data	),//input		[255:0]	
		.edge_push_page_drdy			(edge_push_page_drdy	),//input				
		.edge_clki						(link_clki				),//input				
		.edge_rstn						(link_rstn				),//input				
				
		.ubus_pops_taps_pick			(edge_wdma_taps_pick	),
		.ubus_pops_tapx_issu			(edge_wdma_tapx_issu	),
		.ubus_pops_tap4_issu			(edge_wdma_tap4_issu	),
		.ubus_pops_tap4_reqs			(edge_wdma_tap4_reqs	),
		.ubus_pops_tapx_reqs			(edge_wdma_tapx_reqs	),
		.ubus_pops_page_addr			(edge_wdma_page_addr	),//output		[ 24: 0]
		.ubus_pops_page_data			(edge_wdma_page_data	),//output		[255: 0]
		.ubus_pops_page_drdy			(edge_wdma_page_drdy	),//output	reg			
	
		.ubus_clki						(ubus_clki				),//input	
		.ubus_rstn						(ubus_rstn				));//input	


endmodule 
 
