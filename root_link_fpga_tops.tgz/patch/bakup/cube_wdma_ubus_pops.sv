/*----author edward------
//	wire							cube_idat_wdma_enab	;
//	assign	cube_idat_wdma_enab	= 	cube_idat_wdma_samp[2:0] ==	3'B111	;
*/

module	cube_wdma_ubus_pops(
	input		[ 7: 0]					llmb_edge_imag_cols	,
	input								edge_push_page_lead	,	//from edge_rxdi_pmau
	input		[ 7: 0]					edge_push_page_dptr	,	//from edge_rxdi_pmau
	input		[24: 0]					edge_push_page_addr	,	//from edge_rxdi_pmau
	input		[255:0]					edge_push_page_data	,	//from edge_rxdi_pmau
	input								edge_push_page_drdy	,	//from edge_rxdi_pmau
	input								edge_clki			,
	input								edge_rstn			,
				
	input								ubus_pops_page_init	,	
	input								ubus_pops_page_pick	,	
	input								ubus_pops_page_reqs	,	
	input		[ 3: 0]					ubus_pops_page_size	,

	output								ubus_pops_resv_ov08	,
	output								ubus_pops_resv_ov04	,
	output								ubus_pops_resv_ov02	,
	output								ubus_pops_resv_ov01	,
	
	output		[ 24: 0]				ubus_pops_page_addr	,
	output		[255: 0]				ubus_pops_page_data	,
	output	reg							ubus_pops_page_drdy	,				
	
	input								ubus_clki			,
	input								ubus_rstn			);
/**********************************************************************************************************************/
	wire								ubus_push_page_drdy	;
	wire								ubus_push_page_lead	;
//SYNC FROM EDGE TO UBUS
	gens_edge_slow_fast 			u_edge_ubus_lead_edge(	
		.fast_edge						(ubus_push_page_lead	),//output	
		.fast_clki						(ubus_clki				),//input	
		.fast_rstn						(ubus_rstn				),//input	

		.slow_sign						(edge_push_page_lead	),//input
		.slow_clki						(edge_clki				),//input
		.slow_rstn						(edge_rstn				));//input

	gens_edge_slow_fast 			u_edge_ubus_drdy_edge(	
		.fast_edge						(ubus_push_page_drdy	),//output	
		.fast_clki						(ubus_clki				),//input	
		.fast_rstn						(ubus_rstn				),//input	

		.slow_sign						(edge_push_page_drdy	),//input
		.slow_clki						(edge_clki				),//input
		.slow_rstn						(edge_rstn				));//input
/**********************************************************************************************************************/
	reg			[ 7: 0]					ubus_push_page_cnts	;
	reg			[ 7: 0]					ubus_pops_page_cnts	;			
	reg			[ 6: 0]					ubus_pops_page_resv	;
	reg			[ 3: 0]					ubus_pops_page_taps	;
	reg			[ 3: 0]					ubus_pops_page_leng	;


//	reg			[ 3: 0]					ubus_pops_tap8_numb	;
	reg			[ 5: 0]					ubus_pops_tap4_numb	;
	reg									ubus_pops_tap2_numb	;
	reg									ubus_pops_tap1_numb	;
//great or equal than x
	wire	ubus_pops_resv_get8	=	|	ubus_pops_page_resv[6:3]	;
	wire	ubus_pops_resv_get4	=	|	ubus_pops_page_resv[6:2]	;
	wire	ubus_pops_resv_get2	=	|	ubus_pops_page_resv[6:1]	;
	wire	ubus_pops_resv_get1	=	|	ubus_pops_page_resv[6:0]	;

	wire	ubus_pops_page_last	=	&{	ubus_pops_page_drdy	,	ubus_pops_page_taps + 1 ==	ubus_pops_page_leng	};

	always@(posedge ubus_clki or negedge  ubus_rstn)
	if(~ubus_rstn)						ubus_pops_page_leng	<=	0	;
	else if( ubus_pops_page_reqs)		ubus_pops_page_leng	<=	ubus_pops_page_size	;
//------------------------------------------------------------------------------
	always@(posedge ubus_clki or negedge  ubus_rstn)
	if(~ubus_rstn)						ubus_push_page_cnts	<=	0	;
	else if(ubus_push_page_lead)		ubus_push_page_cnts	<=	0	;
	else if(ubus_push_page_drdy)		ubus_push_page_cnts	<=	1 + ubus_push_page_cnts ;
//------------------------------------------------------------------------------
	always@(posedge ubus_clki or negedge  ubus_rstn)
	if(~ubus_rstn)						ubus_pops_page_resv	<=	0	;
	else if(ubus_pops_page_pick)		ubus_pops_page_resv	<=	ubus_push_page_cnts - ubus_pops_page_cnts	;
//------------------------------------------------------------------------------
	always@(posedge ubus_clki or negedge  ubus_rstn)
	if(~ubus_rstn)						ubus_pops_page_drdy	<=	0	;
	else if(ubus_pops_page_init)		ubus_pops_page_drdy	<=	0	;
	else if(ubus_pops_page_reqs)		ubus_pops_page_drdy	<=	1	;
	else if(ubus_pops_page_last)		ubus_pops_page_drdy	<=	0	;
	
	always@(posedge ubus_clki or negedge  ubus_rstn)
	if(~ubus_rstn)						ubus_pops_page_cnts	<=	0	;
	else if(ubus_push_page_lead)		ubus_pops_page_cnts	<=	0	;
	else if(ubus_pops_page_drdy)		ubus_pops_page_cnts	<=	1 + ubus_pops_page_cnts ;

	always@(posedge ubus_clki or negedge  ubus_rstn)
	if(~ubus_rstn)						ubus_pops_page_taps	<=	0	;
	else if(ubus_pops_page_init)		ubus_pops_page_taps	<=	0	;
	else if(ubus_pops_page_reqs)		ubus_pops_page_taps	<=	0	;
	else if(ubus_pops_page_last)		ubus_pops_page_taps	<=	0	;
	else if(ubus_pops_page_drdy)		ubus_pops_page_taps	<=	1 + ubus_pops_page_taps	;
//------------------------------------------------------------------------------
	always@(posedge ubus_clki or negedge  ubus_rstn)
	if(~ubus_rstn)						begin
//		ubus_pops_tap8_numb		<=	4'H0	;
		ubus_pops_tap4_numb		<=	6'H0	;
		ubus_pops_tap2_numb		<=	1'H0	;
		ubus_pops_tap1_numb		<=	1'H0	;
	end else if(ubus_pops_page_init)	begin
//		ubus_pops_tap8_numb		<=	4'H0	;
		ubus_pops_tap4_numb		<=	llmb_edge_imag_cols[ 7:2]	;
		ubus_pops_tap2_numb		<=	llmb_edge_imag_cols[   1]	;
		ubus_pops_tap1_numb		<=	llmb_edge_imag_cols[   0]	;
	end
/**********************************************************************************************************************/
//	reg			[ 3: 0]					ubus_pops_tap8_cnts	;

//	always@(posedge ubus_clki or negedge  ubus_rstn)
//	if(~ubus_rstn)						ubus_pops_tap8_cnts	<=	0	;
//	else if(ubus_push_page_lead)		ubus_pops_tap8_cnts	<=	0	;
//	else if(ubus_pops_page_req8)		ubus_pops_tap8_cnts	<=	0	;//	ubus_pops_tap8_cnts + 1	;

	reg			[ 5: 0]					ubus_pops_tap4_cnts	;
	reg									ubus_pops_tap2_cnts	;
	reg									ubus_pops_tap1_cnts	;

//	wire	ubus_pops_page_req8	=	&{	ubus_pops_page_reqs	,	ubus_pops_page_size == 4'H8	};
	wire	ubus_pops_page_req4	=	&{	ubus_pops_page_reqs	,	ubus_pops_page_size == 4'H4	};
	wire	ubus_pops_page_req2	=	&{	ubus_pops_page_reqs	,	ubus_pops_page_size == 4'H2	};
	wire	ubus_pops_page_req1	=	&{	ubus_pops_page_reqs	,	ubus_pops_page_size == 4'H1	};

	always@(posedge ubus_clki or negedge  ubus_rstn)
	if(~ubus_rstn)						ubus_pops_tap4_cnts	<=	0	;
	else if(ubus_push_page_lead)		ubus_pops_tap4_cnts	<=	0	;
	else if(ubus_pops_page_req4)		ubus_pops_tap4_cnts	<=	1	+ ubus_pops_tap4_cnts	;

	always@(posedge ubus_clki or negedge  ubus_rstn)
	if(~ubus_rstn)						ubus_pops_tap2_cnts	<=	0	;
	else if(ubus_push_page_lead)		ubus_pops_tap2_cnts	<=	0	;
	else if(ubus_pops_page_req2)		ubus_pops_tap2_cnts	<=	1	;

	always@(posedge ubus_clki or negedge  ubus_rstn)
	if(~ubus_rstn)						ubus_pops_tap1_cnts	<=	0	;
	else if(ubus_push_page_lead)		ubus_pops_tap1_cnts	<=	0	;
	else if(ubus_pops_page_req1)		ubus_pops_tap1_cnts	<=	1	;
/**********************************************************************************************************************/
//	wire								ubus_pops_tap8_case	;
	wire								ubus_pops_tap4_case	;
	wire								ubus_pops_tap2_case	;
	wire								ubus_pops_tap1_case	;

	wire								ubus_pops_tap8_over	;
	wire								ubus_pops_tap4_over	;
	wire								ubus_pops_tap2_over	;
	wire								ubus_pops_tap1_over	;

//	assign	ubus_pops_tap8_case	= 	|	ubus_pops_tap8_numb	;
//	assign	ubus_pops_tap8_over	=		ubus_pops_tap8_case	?	ubus_pops_tap8_cnts	==	ubus_pops_tap8_numb	:	1'B1	;

//	assign	ubus_pops_tap4_case	=	&{ |ubus_pops_tap4_numb	,	ubus_pops_tap8_over	};

	assign	ubus_pops_tap4_case	=	|	ubus_pops_tap4_numb	;
	assign	ubus_pops_tap4_over	=		ubus_pops_tap4_case	?	ubus_pops_tap4_cnts	==	ubus_pops_tap4_numb	:	1'B1	;

	assign	ubus_pops_tap2_case	=	&{	ubus_pops_tap2_numb	,	ubus_pops_tap4_over	};
	assign	ubus_pops_tap2_over	=		ubus_pops_tap2_case	?	ubus_pops_tap2_cnts	:	1'B1	;

	assign	ubus_pops_tap1_case	=	&{	ubus_pops_tap1_numb	,	ubus_pops_tap2_over	};
	assign	ubus_pops_tap1_over	=	 	ubus_pops_tap1_case	?	ubus_pops_tap1_cnts	:	1'B1	;
	
//	assign	ubus_pops_resv_ov08	=	&{	ubus_pops_tap8_case	,	ubus_pops_resv_get8	, ~	ubus_pops_tap8_over	};
	assign	ubus_pops_resv_ov08	=		1'B0	;
	assign	ubus_pops_resv_ov04	=	&{	ubus_pops_tap4_case	,	ubus_pops_resv_get4	, ~	ubus_pops_tap4_over	};
	assign	ubus_pops_resv_ov02	=	&{	ubus_pops_tap2_case	,	ubus_pops_resv_get2	, ~	ubus_pops_tap2_over	};
	assign	ubus_pops_resv_ov01	=	&{	ubus_pops_tap1_case	,	ubus_pops_resv_get1	, ~	ubus_pops_tap1_over	};
/**********************************************************************************************************/
	wire		[ 7: 0]					ubus_pops_page_next	;
	wire		[ 7: 0]					ubus_pops_page_dptr	;

	assign	ubus_pops_page_next	=		ubus_pops_page_cnts + 1	;
	assign	ubus_pops_page_dptr	=		ubus_pops_page_drdy	?	ubus_pops_page_next	:	ubus_pops_page_cnts	;
//------------------------------------------------------------------------------
	dual_port_bram	#(	
		.ADDR_BITS	( 8 	),	
		.DATA_BITS	( 256 	))	
									u_idat_wdma_beat_data (
		.wport_csen						(edge_push_page_drdy	),//input  				 		
		.wport_addr						(edge_push_page_dptr	),//input		[ADDR_BITS-1:0]
		.wport_data						(edge_push_page_data	),//input		[DATA_BITS-1:0]
		.wport_clki						(edge_clki				),//input						

		.rport_addr						(ubus_pops_page_dptr	),//input		[ADDR_BITS-1:0]
		.rport_data						(ubus_pops_page_data	),//output	reg	[DATA_BITS-1:0]
		.rport_clki						(ubus_clki				));//input						


	dual_port_bram	#(	
		.ADDR_BITS	( 8 	),	
		.DATA_BITS	( 25 	))	
									u_idat_wdma_beat_addr (
		.wport_csen						(edge_push_page_drdy	),//input  				 		
		.wport_addr						(edge_push_page_dptr	),//input		[DATA_BITS-1:0]
		.wport_data						(edge_push_page_addr	),//input		[ADDR_BITS-1:0]
		.wport_clki						(edge_clki				),//input						

		.rport_addr						(ubus_pops_page_dptr	),//input		[ADDR_BITS-1:0]
		.rport_data						(ubus_pops_page_addr	),//output	reg	[DATA_BITS-1:0]
		.rport_clki						(ubus_clki				));//input						

endmodule 
 