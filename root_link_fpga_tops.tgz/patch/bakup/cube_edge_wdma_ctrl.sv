//	input	[ 4: 0]					cube_idat_gnpu_numb	,
//	output	reg						cube_idat_wdma_done	,

module	cube_edge_wdma_ctrl(
//add @20250119
	input		[ 7: 0]					cube_edge_link_enab	,
	input		[24: 0]					cube_edge_imag_size	,
	output								cube_edge_wdma_done	,
	input								cube_edge_wdma_enab	,
	input								link_clki			,
	input								link_rstn			,

	input		[ 0: 7]					cube_edge_fifo_ov08	,
	input		[ 0: 7]					cube_edge_fifo_ov04	,
	input		[ 0: 7]					cube_edge_fifo_ov02	,
	input		[ 0: 7]					cube_edge_fifo_ov01	,

	output								cube_edge_wdma_init	,
	output								cube_edge_wdma_pick	,
	output		[ 0: 7]					cube_edge_wdma_reqs	,
	output		[ 3: 0]					cube_edge_wdma_size	,

	input		[ 0: 7][255: 0]			cube_edge_wdma_data	,
	input		[ 0: 7][ 24: 0]			cube_edge_wdma_addr	,
	input		[ 0: 7]					cube_edge_wdma_drdy	,				

	output								ubus_wdma_ddrs_csen	,
	output		[ 24: 0]				ubus_wdma_ddrs_addr	,
	output		[255: 0]				ubus_wdma_ddrs_data	,
	input								ubus_wdma_ddrs_trdy	,
	input								ubus_wdma_ddrs_wrdy	,

	input								ubus_clki			,
	input								ubus_rstn			);

/**********************************************************************************************************************/
	wire								ubus_wdma_ddrs_enab	;
	
	cube_edge_wdma_mfsm				u_cube_edge_wdma_mfsm(
		.cube_edge_wdma_port			(cube_edge_link_enab	),//input		[ 7: 0]	
		.cube_edge_wdma_imag			(cube_edge_imag_size	),//input		[24: 0]	
		.cube_edge_wdma_done			(cube_edge_wdma_done	),//input				
		.cube_edge_wdma_enab			(cube_edge_wdma_enab	),//output				
		.link_clki						(link_clki				),//input				
		.link_rstn						(link_rstn				),//input				
//------------------------------------------------------------------------------	
		.cube_edge_wdma_ov08			(cube_edge_fifo_ov08	),//input		[ 0: 7]		
		.cube_edge_wdma_ov04			(cube_edge_fifo_ov04	),//input		[ 0: 7]		
		.cube_edge_wdma_ov02			(cube_edge_fifo_ov02	),//input		[ 0: 7]		
		.cube_edge_wdma_ov01			(cube_edge_fifo_ov01	),//input		[ 0: 7]		

		.cube_edge_wdma_init			(cube_edge_wdma_init	),//output					
		.cube_edge_wdma_pick			(cube_edge_wdma_pick	),//output					
		.cube_edge_wdma_reqs			(cube_edge_wdma_reqs	),//output		[ 0: 7]		
		.cube_edge_wdma_size			(cube_edge_wdma_size	),//output	reg	[ 3: 0]		

		.ubus_wdma_ddrs_enab			(ubus_wdma_ddrs_enab	),
		.ubus_wdma_ddrs_init			(ubus_wdma_ddrs_init	),//output	
		.ubus_wdma_ddrs_done			(ubus_wdma_ddrs_done	),//input	
		.ubus_clki						(ubus_clki				),//input				
		.ubus_rstn						(ubus_rstn				));//input		
/***********************************************************************************************************************/
	cube_edge_wdma_ddrs 			u_cube_edge_wdma_ddrs(
		.ubus_wdma_ddrs_csen			(ubus_wdma_ddrs_csen	),//output				
		.ubus_wdma_ddrs_addr			(ubus_wdma_ddrs_addr	),//output		[ 24: 0]
		.ubus_wdma_ddrs_data			(ubus_wdma_ddrs_data	),//output		[255: 0]
		.ubus_wdma_ddrs_trdy			(ubus_wdma_ddrs_trdy	),//input				
		.ubus_wdma_ddrs_wrdy			(ubus_wdma_ddrs_wrdy	),//input				

		.cube_edge_wdma_data			(cube_edge_wdma_data	),//input	[ 0: 7]	[255: 0]
		.cube_edge_wdma_addr			(cube_edge_wdma_addr	),//input	[ 0: 7]	[ 24: 0]
		.cube_edge_wdma_drdy			(cube_edge_wdma_drdy	),//input	[ 0: 7]			

		.ubus_wdma_ddrs_enab			(ubus_wdma_ddrs_enab	),
		.ubus_wdma_ddrs_init			(ubus_wdma_ddrs_init	),//input	
		.ubus_wdma_ddrs_reqs			(cube_edge_wdma_reqs	),//input	
		.ubus_wdma_ddrs_size			(cube_edge_wdma_size	),
		.ubus_wdma_ddrs_done			(ubus_wdma_ddrs_done	),//output	
		.ubus_clki						(ubus_clki				),//input				
		.ubus_rstn						(ubus_rstn				));//input		
 	

endmodule
 