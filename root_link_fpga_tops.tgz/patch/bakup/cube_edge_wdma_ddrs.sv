module	cube_edge_wdma_ddrs (
	output								ubus_wdma_ddrs_csen	,
	output		[ 24: 0]				ubus_wdma_ddrs_addr	,
	output		[255: 0]				ubus_wdma_ddrs_data	,
	input								ubus_wdma_ddrs_trdy	,
	input								ubus_wdma_ddrs_wrdy	,

	input		[ 0: 7]	[255: 0]		cube_edge_wdma_data	,
	input		[ 0: 7]	[ 24: 0]		cube_edge_wdma_addr	,
	input		[ 0: 7]					cube_edge_wdma_drdy	,				

	input								ubus_wdma_ddrs_enab	,	
	input								ubus_wdma_ddrs_init	,
	input		[ 0: 7]					ubus_wdma_ddrs_reqs	,
	input		[ 3: 0]					ubus_wdma_ddrs_size	,	
	output								ubus_wdma_ddrs_done	,	

	input								ubus_clki			,
	input								ubus_rstn			);
/***********************************************************************************************************************/
	reg			[ 3: 0]					ubus_wdma_ddrs_leng	;

	always@(posedge ubus_clki or negedge ubus_rstn)
	if(!ubus_rstn)						ubus_wdma_ddrs_leng	<=	0	;
	else if(|ubus_wdma_ddrs_reqs)		ubus_wdma_ddrs_leng	<=	ubus_wdma_ddrs_size	;
/***********************************************************************************************************************/
	reg			[255: 0]				muxs_edge_idat_data	;
	reg			[ 24: 0]				muxs_edge_idat_addr	;
	reg									muxs_edge_idat_drdy	;
	reg									muxs_edge_idat_ddry	;

	reg			[ 0: 7][ 24: 0]			ubus_wdma_addr_memo	;
	reg			[ 0: 7][255: 0]			ubus_wdma_data_memo	;

	wire								ubus_wdma_ddrs_wreq	;

	assign	ubus_wdma_ddrs_wreq	= 	&{	muxs_edge_idat_drdy	, ~	muxs_edge_idat_ddry	};
//MUX_EDGE_IDAT_MISC------------------------------------------------------------
	always@(posedge ubus_clki or negedge ubus_rstn)
	if(!ubus_rstn)						muxs_edge_idat_data	<=	0	;
	else if(cube_edge_wdma_drdy[0])		muxs_edge_idat_data	<=	cube_edge_wdma_data[0]	;
	else if(cube_edge_wdma_drdy[1])		muxs_edge_idat_data	<=	cube_edge_wdma_data[1]	;
	else if(cube_edge_wdma_drdy[2])		muxs_edge_idat_data	<=	cube_edge_wdma_data[2]	;
	else if(cube_edge_wdma_drdy[3])		muxs_edge_idat_data	<=	cube_edge_wdma_data[3]	;
	else if(cube_edge_wdma_drdy[4])		muxs_edge_idat_data	<=	cube_edge_wdma_data[4]	;
	else if(cube_edge_wdma_drdy[5])		muxs_edge_idat_data	<=	cube_edge_wdma_data[5]	;
	else if(cube_edge_wdma_drdy[6])		muxs_edge_idat_data	<=	cube_edge_wdma_data[6]	;
	else if(cube_edge_wdma_drdy[7])		muxs_edge_idat_data	<=	cube_edge_wdma_data[7]	;
	else 								muxs_edge_idat_data	<=	256'H0					;

	always@(posedge ubus_clki or negedge ubus_rstn)
	if(!ubus_rstn)						muxs_edge_idat_addr	<=	0	;
	else if(cube_edge_wdma_drdy[0])		muxs_edge_idat_addr	<=	cube_edge_wdma_addr[0]	;
	else if(cube_edge_wdma_drdy[1])		muxs_edge_idat_addr	<=	cube_edge_wdma_addr[1]	;
	else if(cube_edge_wdma_drdy[2])		muxs_edge_idat_addr	<=	cube_edge_wdma_addr[2]	;
	else if(cube_edge_wdma_drdy[3])		muxs_edge_idat_addr	<=	cube_edge_wdma_addr[3]	;
	else if(cube_edge_wdma_drdy[4])		muxs_edge_idat_addr	<=	cube_edge_wdma_addr[4]	;
	else if(cube_edge_wdma_drdy[5])		muxs_edge_idat_addr	<=	cube_edge_wdma_addr[5]	;
	else if(cube_edge_wdma_drdy[6])		muxs_edge_idat_addr	<=	cube_edge_wdma_addr[6]	;
	else if(cube_edge_wdma_drdy[7])		muxs_edge_idat_addr	<=	cube_edge_wdma_addr[7]	;
	else 								muxs_edge_idat_addr	<=	25'H0					;

	always@(posedge ubus_clki or negedge ubus_rstn)
	if(!ubus_rstn)						muxs_edge_idat_drdy	<=	0	;
	else if(~ubus_wdma_ddrs_enab)		muxs_edge_idat_drdy	<=	0	;
	else if( ubus_wdma_ddrs_init)		muxs_edge_idat_drdy	<=	0	;
	else 								muxs_edge_idat_drdy	<= |cube_edge_wdma_drdy[0:7];

	always@(posedge ubus_clki or negedge ubus_rstn)
	if(!ubus_rstn)						muxs_edge_idat_ddry	<=	0	;
	else if(~ubus_wdma_ddrs_enab)		muxs_edge_idat_ddry	<=	0	;
	else if( ubus_wdma_ddrs_init)		muxs_edge_idat_ddry	<=	0	;
	else 								muxs_edge_idat_ddry	<= 	muxs_edge_idat_drdy		;
//UBUS_WDMA_DDRS_MEMO------------------------------------------------------------------------------
	reg			[ 2: 0]					ubus_wdma_memo_indx	;
	wire		[ 0: 7]					ubus_wdma_memo_wrcs	;

	always@(posedge ubus_clki or negedge ubus_rstn)
	if(~ubus_rstn)						ubus_wdma_memo_indx	<=	0	;
	else if(ubus_wdma_ddrs_init)		ubus_wdma_memo_indx	<=	0	;
	else if(muxs_edge_idat_drdy)		ubus_wdma_memo_indx	<=	1 +	ubus_wdma_memo_indx	;

	for(genvar i = 0 ; i < 8 ; i = i +  1)	begin:gens_rimt_wrcs_memo
	
		assign	ubus_wdma_memo_wrcs[i]	= &{	muxs_edge_idat_drdy	,	ubus_wdma_memo_indx	==	i	};

		always@(posedge ubus_clki or negedge ubus_rstn)
		if(~ubus_rstn)						begin
			ubus_wdma_addr_memo[i]		<=	0	;
			ubus_wdma_data_memo[i]		<=	0	;
		end	else if(ubus_wdma_memo_wrcs[i])	begin
			ubus_wdma_addr_memo[i]		<=	muxs_edge_idat_addr	;
			ubus_wdma_data_memo[i]		<=	muxs_edge_idat_data	;
		end

	end
/***********************************************************************************************************************/
	reg									ubus_wdma_beat_csen	;
	reg		[ 3: 0]						ubus_wdma_beat_cnts	;
	wire	[ 3: 0]						ubus_wdma_beat_inc1	;

	assign	ubus_wdma_beat_inc1	=		ubus_wdma_beat_cnts + 1	;
	assign	ubus_wdma_ddrs_csen	= 	&{	ubus_wdma_beat_csen	,	ubus_wdma_ddrs_wrdy	,	ubus_wdma_ddrs_trdy	};
//	assign	ubus_wdma_ddrs_done	=	&{	ubus_wdma_ddrs_csen	,	ubus_wdma_beat_inc1	==	ubus_wdma_ddrs_size	};									
	assign	ubus_wdma_ddrs_done	=	&{	ubus_wdma_ddrs_csen	,	ubus_wdma_beat_inc1	==	ubus_wdma_ddrs_leng	};									
									
	always@(posedge ubus_clki or negedge ubus_rstn)
	if(!ubus_rstn)						ubus_wdma_beat_csen	<=	0	;
	else if(ubus_wdma_ddrs_wreq)		ubus_wdma_beat_csen	<=	1	;	
	else if(ubus_wdma_ddrs_done)		ubus_wdma_beat_csen	<=	0	;	

	always@(posedge ubus_clki or negedge ubus_rstn)
	if(!ubus_rstn)						ubus_wdma_beat_cnts	<=	0	;
	else if(ubus_wdma_ddrs_init)		ubus_wdma_beat_cnts	<=	0	;
	else if(ubus_wdma_ddrs_csen)		ubus_wdma_beat_cnts	<=	ubus_wdma_beat_inc1	;
//----------------------------------------------------------------------------------------------------------------------
	wire		[ 0 : 7]				ubus_wdma_ddrs_csid	;	

	for	(genvar j = 0 ; j < 8 ; j = j + 1)	begin:gens_ubus_read_memo
		assign	ubus_wdma_ddrs_csid[j]	= &{ubus_wdma_beat_csen	,	ubus_wdma_beat_cnts	== j	};

	end
	
	assign	ubus_wdma_ddrs_addr	=		ubus_wdma_ddrs_csid[0]	?	ubus_wdma_addr_memo[0]	:
										ubus_wdma_ddrs_csid[1]	?	ubus_wdma_addr_memo[1]	:	
										ubus_wdma_ddrs_csid[2]	?	ubus_wdma_addr_memo[2]	:
										ubus_wdma_ddrs_csid[3]	?	ubus_wdma_addr_memo[3]	:	
										ubus_wdma_ddrs_csid[4]	?	ubus_wdma_addr_memo[4]	:
										ubus_wdma_ddrs_csid[5]	?	ubus_wdma_addr_memo[5]	:	
										ubus_wdma_ddrs_csid[6]	?	ubus_wdma_addr_memo[6]	:
										ubus_wdma_ddrs_csid[7]	?	ubus_wdma_addr_memo[7]	:	25'H0	;

	assign	ubus_wdma_ddrs_data	=		ubus_wdma_ddrs_csid[0]	?	ubus_wdma_data_memo[0]	:
										ubus_wdma_ddrs_csid[1]	?	ubus_wdma_data_memo[1]	:	
										ubus_wdma_ddrs_csid[2]	?	ubus_wdma_data_memo[2]	:
										ubus_wdma_ddrs_csid[3]	?	ubus_wdma_data_memo[3]	:	
										ubus_wdma_ddrs_csid[4]	?	ubus_wdma_data_memo[4]	:
										ubus_wdma_ddrs_csid[5]	?	ubus_wdma_data_memo[5]	:	
										ubus_wdma_ddrs_csid[6]	?	ubus_wdma_data_memo[6]	:
										ubus_wdma_ddrs_csid[7]	?	ubus_wdma_data_memo[7]	:	256'H0	;


//----------------------------------------------------------------------------------------------------------------------
//	ila_302							u_ila_edge_rimt(
//		.clk							(ubus_clki				),
//		.probe0							({
//										cube_edge_wdma_drdy	,	//BIT302
//										muxs_edge_idat_drdy	,	//BIT294
//										ubus_wdma_ddrs_dst0	,	//BIT293
//										ubus_wdma_ddrs_dst1	,	//BIT292
//										ubus_wdma_ddrs_reqs	,	//BIT291
//										ubus_wdma_ddrs_csen	,	//BIT290
//										ubus_wdma_ddrs_cs00	,	//BIT289
//										ubus_wdma_ddrs_cs01	,	//BIT288
//										ubus_wdma_ddrs_trdy	,	//BIT287
//										ubus_wdma_ddrs_wok0	,	//BIT286
//										ubus_wdma_ddrs_wok1	,	//BIT285
//
//										ubus_wdma_ddrs_csen	,	//BIT284
//										ubus_wdma_ddrs_wrdy	,	//BIT283
//										ubus_wdma_ddrs_trdy	,	//BIT282
//										ubus_wdma_ddrs_addr	,	//BIT281
//										ubus_wdma_ddrs_data	}));//BIT256


endmodule