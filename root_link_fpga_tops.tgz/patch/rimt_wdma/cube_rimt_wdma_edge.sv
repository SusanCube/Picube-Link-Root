/*----author edward------
//	wire							cube_idat_wdma_enab	;
//	assign	cube_idat_wdma_enab	= 	edge_data_wdma_samp[2:0] ==	3'B111	;
*/

module	cube_rimt_wdma_edge(
	input								this_hubs_root_lead	,
	input		[ 4: 0]					this_hubs_edge_indx	,
	
	input		[24 : 0]				llmb_meta_ddrs_base	,
	input		[19 : 0]				llmb_meta_hubs_cols	,
	input		[19 : 0]				llmb_meta_root_cols	,
	
	input								llmb_edge_imag_even	,	//0:ODD 1: EVEN
	input		[19 : 0]				llmb_edge_imag_rows	,
	input		[19 : 0]				llmb_edge_imag_cols	,

	input								cube_edge_rimt_enab	,	//write enable
	input								cube_edge_rimt_acks	,
	output	reg							cube_edge_rimt_reqs	,
	output		[25: 0]					cube_edge_rimt_tags	,

	input								cube_edge_idat_lead	,
	input								cube_edge_idat_wrcs	,
	input		[ 31: 0]				cube_edge_idat_data	,

	output	reg							cube_edge_rimt_rank	,
	output	reg							cube_edge_rimt_csen	,
	output	reg	[ 5: 0]					cube_edge_rimt_addr	,
	output	reg	[255:0]					cube_edge_rimt_data	,
	
	input								link_clki			,
	input								link_rstn			);
/***********************************************************************************************************************/
	reg			[ 3: 0]					cube_edge_rimt_mfsm	;
	
	parameter	CUBE_EDGE_RIMT_IDLE	=	3'H0	;
	parameter	CUBE_EDGE_RIMT_LEAD	=	3'H1	;
	parameter	CUBE_EDGE_RIMT_DATA	=	3'H2	;
	parameter	CUBE_EDGE_RIMT_REQS	=	3'H3	;
	parameter	CUBE_EDGE_RIMT_ACKS	=	3'H4	;
	parameter	CUBE_EDGE_RIMT_LOOP	=	3'H5	;
	parameter	CUBE_EDGE_RIMT_DONE	=	3'H6	;
//------------------------------------------------------------------------------
	wire								edge_rxdi_rows_done	;
	wire								edge_rxdi_imag_done	;

	wire		edge_rimt_hits_idle	=	cube_edge_rimt_mfsm	==	CUBE_EDGE_RIMT_IDLE	;						
	wire		edge_rimt_hits_lead	=	cube_edge_rimt_mfsm	==	CUBE_EDGE_RIMT_LEAD	;						
	wire		edge_rimt_hits_data	=	cube_edge_rimt_mfsm	==	CUBE_EDGE_RIMT_DATA	;						
	wire		edge_rimt_hits_reqs	=	cube_edge_rimt_mfsm	==	CUBE_EDGE_RIMT_REQS	;						
	wire		edge_rimt_hits_acks	=	cube_edge_rimt_mfsm	==	CUBE_EDGE_RIMT_ACKS	;						
	wire		edge_rimt_hits_loop	=	cube_edge_rimt_mfsm	==	CUBE_EDGE_RIMT_LOOP	;	

	always@(posedge link_clki or negedge link_rstn)	
	if(~link_rstn)						cube_edge_rimt_mfsm	<=	CUBE_EDGE_RIMT_IDLE	;
	else if(~cube_edge_rimt_enab)		cube_edge_rimt_mfsm	<=	CUBE_EDGE_RIMT_IDLE	;
	else begin	
		case(cube_edge_rimt_mfsm)		
			CUBE_EDGE_RIMT_IDLE	:		cube_edge_rimt_mfsm	<=													CUBE_EDGE_RIMT_LEAD	;
			CUBE_EDGE_RIMT_LEAD	:		cube_edge_rimt_mfsm	<=	cube_edge_idat_lead	?	CUBE_EDGE_RIMT_DATA	:	CUBE_EDGE_RIMT_LEAD	;	
			CUBE_EDGE_RIMT_DATA	:		cube_edge_rimt_mfsm	<=	edge_rxdi_rows_done	?	CUBE_EDGE_RIMT_REQS	:	CUBE_EDGE_RIMT_DATA	;
			CUBE_EDGE_RIMT_REQS	:		cube_edge_rimt_mfsm	<=													CUBE_EDGE_RIMT_ACKS	;
			CUBE_EDGE_RIMT_ACKS	:		cube_edge_rimt_mfsm	<=	cube_edge_rimt_acks	?	CUBE_EDGE_RIMT_LOOP	:	CUBE_EDGE_RIMT_ACKS	;
			CUBE_EDGE_RIMT_LOOP	:		cube_edge_rimt_mfsm	<=	edge_rxdi_imag_done	?	CUBE_EDGE_RIMT_DONE	:	CUBE_EDGE_RIMT_LEAD	;
			CUBE_EDGE_RIMT_DONE	:		cube_edge_rimt_mfsm	<=	cube_edge_rimt_enab	?	CUBE_EDGE_RIMT_DONE	:	CUBE_EDGE_RIMT_IDLE	;
			default	:					cube_edge_rimt_mfsm	<=													CUBE_EDGE_RIMT_IDLE	;
		endcase
	end
/***********************************************************************************************************************/
	wire		cube_edge_rimt_lead	= &{edge_rimt_hits_lead	,	cube_edge_idat_lead	};
	wire		cube_edge_rimt_next	= &{edge_rimt_hits_acks	,	cube_edge_rimt_acks	};

	always@(posedge link_clki or negedge link_rstn)
	if(~link_rstn) 						cube_edge_rimt_reqs	<=	0	;
	else if(~cube_edge_rimt_enab)		cube_edge_rimt_reqs	<=	0	;
	else if( edge_rimt_hits_reqs)		cube_edge_rimt_reqs	<=	1	;
	else if( cube_edge_rimt_next)		cube_edge_rimt_reqs	<=	0	;
//------------------------------------------------------------------------------
	always@(posedge link_clki or negedge link_rstn)
	if(~link_rstn) 						cube_edge_rimt_rank	<=	0	;
	else if(~cube_edge_rimt_enab)		cube_edge_rimt_rank	<=	0	;
	else if( cube_edge_rimt_next)		cube_edge_rimt_rank	<= ~cube_edge_rimt_rank	;
//------------------------------------------------------------------------------
	reg			[ 2: 0]					cube_rxdi_word_cnts	;
	reg			[ 5: 0]					cube_rxdi_page_cnts	;
	reg			[11: 0]					cube_rxdi_rows_cnts	;
	
	wire		[ 5: 0]					cube_edge_rows_page	;
	wire		[11: 0]					cube_edge_rows_numb	;
	
	assign		cube_edge_rows_page	=	llmb_edge_imag_cols[ 9: 4]	;
	assign		cube_edge_rows_numb	=	llmb_edge_imag_rows[11: 0]	;
	
	wire		edge_rxdi_word_drdy	= &{edge_rimt_hits_data	,	cube_edge_idat_wrcs	};
	wire		edge_rxdi_page_drdy	= &{edge_rxdi_word_drdy	,	cube_rxdi_word_cnts	==	3'H7				};
	assign		edge_rxdi_rows_done	=&{							cube_rxdi_page_cnts	==	cube_edge_rows_page	};	
	assign		edge_rxdi_imag_done	= &{						cube_rxdi_rows_cnts	==	cube_edge_rows_numb	};

	always@(posedge link_clki or negedge link_rstn)
	if(~link_rstn) 						cube_rxdi_rows_cnts	<=	0	;
	else if(~cube_edge_rimt_enab)		cube_rxdi_rows_cnts	<=	0	;
	else if( edge_rimt_hits_reqs)		cube_rxdi_rows_cnts	<=	cube_rxdi_rows_cnts + 1	;	

	always@(posedge link_clki or negedge link_rstn)
	if(~link_rstn) 						cube_rxdi_word_cnts	<=	0	;
	else if( edge_rimt_hits_lead)		cube_rxdi_word_cnts	<=	0	;	
	else if( edge_rimt_hits_reqs)		cube_rxdi_word_cnts	<=	0	;	
	else if( edge_rxdi_word_drdy)		cube_rxdi_word_cnts	<=	cube_rxdi_word_cnts + 1	;	

	always@(posedge link_clki or negedge link_rstn)
	if(~link_rstn) 						cube_rxdi_page_cnts	<=	0	;
	else if( edge_rimt_hits_lead)		cube_rxdi_page_cnts	<=	0	;	
	else if( edge_rimt_hits_reqs)		cube_rxdi_page_cnts	<=	0	;	
	else if( edge_rxdi_page_drdy)		cube_rxdi_page_cnts	<=	cube_rxdi_page_cnts + 1	;	

	always@(posedge link_clki or negedge link_rstn)
	if(~link_rstn) 						cube_edge_rimt_data	<=	0	;
	else if(~cube_edge_rimt_enab)		cube_edge_rimt_data	<=	0	;
	else if( cube_edge_idat_wrcs)		cube_edge_rimt_data	<= {cube_edge_idat_data	,	cube_edge_rimt_data[255:32]	};	

	always@(posedge link_clki or negedge link_rstn)
	if(~link_rstn) 						cube_edge_rimt_csen	<=	0	;
	else if(~cube_edge_rimt_enab)		cube_edge_rimt_csen	<=	0	;
	else 								cube_edge_rimt_csen	<= 	edge_rxdi_page_drdy	;	

	always@(posedge link_clki or negedge link_rstn)
	if(~link_rstn) 						cube_edge_rimt_addr	<=	0	;
	else if(~cube_edge_rimt_enab)		cube_edge_rimt_addr	<=	0	;
	else if( edge_rxdi_page_drdy)		cube_edge_rimt_addr	<= 	cube_rxdi_page_cnts	;	

//	else if( cube_edge_idat_wrcs)		cube_edge_rimt_csen	<= 	edge_rxdi_page_drdy	;	
/***********************************************************************************************************************/
	reg			[ 4: 0]					this_hubs_gnpu_indx	;

	always@(posedge link_clki or negedge  link_rstn)
	if(~link_rstn)						this_hubs_gnpu_indx	<=	0	;
	else if(~cube_edge_rimt_enab)		this_hubs_gnpu_indx	<=	this_hubs_edge_indx	+ llmb_edge_imag_even	;
/***********************************************************************************************************************/
	reg			[24: 0]					mtrx_data_wdma_base	;
	reg			[24: 0]					mtrx_data_wdma_ofst	;
//------------------------------------------------------------------------------
	wire		[19: 0]					mtrx_hubs_rows_dims	=	this_hubs_root_lead	?	llmb_meta_root_cols	:	llmb_meta_hubs_cols	;
	wire		[19: 0]					mtrx_gnpu_bias_cols	=	this_hubs_gnpu_indx	*	llmb_edge_imag_cols	;
	wire		[15: 0]					mtrx_hubs_rows_page	=	mtrx_hubs_rows_dims[19: 4];
	wire		[15: 0]					mtrx_gnpu_bias_page	=	mtrx_gnpu_bias_cols[19: 4];
	
	always@(posedge link_clki or negedge link_rstn )
	if(~link_rstn)						mtrx_data_wdma_base	<=	0	;
	else if(~cube_edge_rimt_enab)		mtrx_data_wdma_base	<=	llmb_meta_ddrs_base	+ mtrx_gnpu_bias_page	;
	
	always@(posedge link_clki or negedge link_rstn )
	if(~link_rstn)						mtrx_data_wdma_ofst	<=	0	;
	else if(~cube_edge_rimt_enab)		mtrx_data_wdma_ofst	<=	0	;
	else if( edge_rimt_hits_loop) 		mtrx_data_wdma_ofst	<=	cube_rxdi_rows_cnts	* mtrx_hubs_rows_page	;
/**********************************************************************************************************/
	reg			[24: 0]					cube_edge_rimt_ddrs	;

	always@(posedge link_clki or negedge link_rstn )
	if(~link_rstn)						cube_edge_rimt_ddrs	<=	0	;
	else if(~cube_edge_rimt_enab)		cube_edge_rimt_ddrs	<=	0	;
	else if( cube_edge_rimt_lead)		cube_edge_rimt_ddrs	<=	mtrx_data_wdma_base + mtrx_data_wdma_ofst	;
/***********************************************************************************************************************/
	assign		cube_edge_rimt_tags	=  {cube_edge_rimt_rank	,	cube_edge_rimt_ddrs	};

endmodule 

 