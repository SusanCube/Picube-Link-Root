/*----author edward------
//	wire							ubus_idat_wdma_enab	;
//	assign	ubus_idat_wdma_enab	= 	edge_data_wdma_samp[2:0] ==	3'B111	;
*/

module	cube_rimt_wdma_ubus(
	input								cube_rimt_wdma_enab	,
	input		[19: 0]					cube_rimt_wdma_cols	,

	input		[ 0: 7]					cube_edge_rimt_rank	,
	input		[ 0: 7]					cube_edge_rimt_csen	,
	input		[ 0: 7][  5:0]			cube_edge_rimt_addr	,
	input		[ 0: 7][255:0]			cube_edge_rimt_data	,
	input								link_clki			,
	input								link_rstn			,
	
	input								ubus_rimt_wdma_reqs	,
	input		[ 2: 0]					ubus_rimt_wdma_edge	,
	input		[25: 0]					ubus_rimt_wdma_tags	,
	output								ubus_rimt_wdma_wrdy	,

	output								ubus_wdma_ddrs_csen	,
	output	reg	[ 24: 0]				ubus_wdma_ddrs_addr	,
	output		[255: 0]				ubus_wdma_ddrs_data	,
	input								ubus_wdma_ddrs_trdy	,
	input								ubus_wdma_ddrs_wrdy	,
	input								ubus_clki			,
	input								ubus_rstn			);
/***********************************************************************************************************************/
	wire		[15: 0]					rimt_rows_page_numb	=	cube_rimt_wdma_cols[19: 4]	;
	wire		[12: 0]					rimt_pack_page_numb	=	rimt_rows_page_numb[15: 3]	;
	wire		[ 2: 0]					rimt_frag_page_numb	=	rimt_rows_page_numb[ 2: 0]	;
	wire								rimt_wdma_pack_case	= |	rimt_pack_page_numb	;
	wire								rimt_wdma_frag_case	= |	rimt_frag_page_numb	;

	wire		[17: 0]					rimt_wdma_ubus_cfig	;
	wire		[17: 0]					rimt_wdma_link_cfig	= {	rimt_wdma_pack_case	,	rimt_wdma_frag_case	,
																rimt_pack_page_numb	,	rimt_frag_page_numb	};
//------------------------------------------------------------------------------
	gens_sync_gray 		#(.MSB (17))	
									u_gens_ubus_rimt_cfig(
		.data_asyn						(rimt_wdma_link_cfig	),//input	[MSB: 0]	
		.scki							(link_clki				),//input				
		.data_sync						(rimt_wdma_ubus_cfig	),//output	reg [MSB: 0]
		.clki							(ubus_clki				),//input				
		.rstn							(ubus_rstn				));//input				
//------------------------------------------------------------------------------
	gens_sign_slow_fast  #(.EXTN( 1)) 
									u_gens_ubus_rimt_enab(	
		.slow_sign						(cube_rimt_wdma_enab	),//input	
		.slow_clki						(link_clki				),//input	
		.slow_rstn						(link_rstn				),//input	

		.fast_sign						(ubus_rimt_wdma_enab	),//output	
		.fast_clki						(ubus_clki				),//input	
		.fast_rstn						(ubus_rstn				));//input	
//------------------------------------------------------------------------------
//	gens_sync_gray 		#(.MSB (15))	
//									u_gens_ubus_rimt_dims(
//		.data_asyn						(rimt_rows_page_numb	),//input	[MSB: 0]	
//		.scki							(link_clki				),//input				
//
//		.data_sync						(ubus_rimt_wdma_dims	),//output	reg [MSB: 0]
//		.clki							(ubus_clki				),//input				
//		.rstn							(ubus_rstn				));//input				
//------------------------------------------------------------------------------
	reg									ubus_rimt_pack_case	;
	reg									ubus_rimt_frag_case	;
	reg			[12: 0]					ubus_rimt_pack_numb	;
	reg			[ 3: 0]					ubus_rimt_frag_numb	;

	always@(posedge ubus_clki or negedge ubus_rstn)	
	if(~ubus_rstn)						begin
		ubus_rimt_pack_case	<=	0	;
		ubus_rimt_frag_case	<=	0	;
		ubus_rimt_pack_numb	<=	0	;
		ubus_rimt_frag_numb	<=	0	;
	end else if(~ubus_rimt_wdma_enab)	begin
		ubus_rimt_pack_case	<=		rimt_wdma_ubus_cfig[17  ]	;
		ubus_rimt_frag_case	<=		rimt_wdma_ubus_cfig[16  ]	;
		ubus_rimt_pack_numb	<=		rimt_wdma_ubus_cfig[15:3]	;
		ubus_rimt_frag_numb	<={1'B0,rimt_wdma_ubus_cfig[ 2:0]	};
	end
/***********************************************************************************************************************/
	reg			[ 3: 0]					ubus_rimt_wdma_mfsm	;

	parameter	UBUS_RIMT_WDMA_IDLE	=	4'H0	;	
	parameter	UBUS_RIMT_WDMA_SEEK	=	4'H1	;	

	parameter	UBUS_RIMT_PACK_REQS	=	4'H2	;
	parameter	UBUS_RIMT_PACK_READ	=	4'H3	;
	parameter	UBUS_RIMT_PACK_RRDY	=	4'H4	;
	parameter	UBUS_RIMT_PACK_BEAT	=	4'H5	;
	parameter	UBUS_RIMT_PACK_LOOP	=	4'H6	;

	parameter	UBUS_RIMT_FRAG_REQS	=	4'H7	;
	parameter	UBUS_RIMT_FRAG_READ	=	4'H8	;
	parameter	UBUS_RIMT_FRAG_RRDY	=	4'H9	;
	parameter	UBUS_RIMT_FRAG_BEAT	=	4'HA	;
	parameter	UBUS_RIMT_WDMA_WRDY	=	4'HB	;

	wire								ubus_wdma_frag_done	;
	wire								ubus_wdma_pack_done	;
	wire								ubus_wdma_pack_over	;
//------------------------------------------------------------------------------
	wire	ubus_rimt_wdma_idle	=		ubus_rimt_wdma_mfsm	==	UBUS_RIMT_WDMA_IDLE	;	
	wire	ubus_rimt_wdma_seek	=		ubus_rimt_wdma_mfsm	==	UBUS_RIMT_WDMA_SEEK	;	
	assign	ubus_rimt_wdma_wrdy	=		ubus_rimt_wdma_mfsm	==	UBUS_RIMT_WDMA_WRDY	;

	wire	ubus_rimt_pack_reqs	=		ubus_rimt_wdma_mfsm	==	UBUS_RIMT_PACK_REQS	;
	wire	ubus_rimt_pack_read	=		ubus_rimt_wdma_mfsm	==	UBUS_RIMT_PACK_READ	;
	wire	ubus_rimt_pack_rrdy	=		ubus_rimt_wdma_mfsm	==	UBUS_RIMT_PACK_RRDY	;
	wire	ubus_rimt_pack_beat	=		ubus_rimt_wdma_mfsm	==	UBUS_RIMT_PACK_BEAT	;
	wire	ubus_rimt_pack_loop	=		ubus_rimt_wdma_mfsm	==	UBUS_RIMT_PACK_LOOP	;

	wire	ubus_rimt_frag_reqs	=		ubus_rimt_wdma_mfsm	==	UBUS_RIMT_FRAG_REQS	;
	wire	ubus_rimt_frag_read	=		ubus_rimt_wdma_mfsm	==	UBUS_RIMT_FRAG_READ	;
	wire	ubus_rimt_frag_rrdy	=		ubus_rimt_wdma_mfsm	==	UBUS_RIMT_FRAG_RRDY	;
	wire	ubus_rimt_frag_beat	=		ubus_rimt_wdma_mfsm	==	UBUS_RIMT_FRAG_BEAT	;
//------------------------------------------------------------------------------

	always@(posedge ubus_clki or negedge ubus_rstn)	
	if(~ubus_rstn)						ubus_rimt_wdma_mfsm	<=	UBUS_RIMT_WDMA_IDLE	;
	else if(~ubus_rimt_wdma_enab)		ubus_rimt_wdma_mfsm	<=	UBUS_RIMT_WDMA_IDLE	;
	else begin	
		case(ubus_rimt_wdma_mfsm)		
			UBUS_RIMT_WDMA_IDLE	:		ubus_rimt_wdma_mfsm	<=													UBUS_RIMT_WDMA_SEEK	;
			UBUS_RIMT_WDMA_SEEK	:		ubus_rimt_wdma_mfsm	<= ~ubus_rimt_wdma_reqs	?	UBUS_RIMT_WDMA_SEEK	:
																ubus_rimt_pack_case	?	UBUS_RIMT_PACK_REQS	:	UBUS_RIMT_FRAG_REQS	;

			UBUS_RIMT_PACK_REQS	:		ubus_rimt_wdma_mfsm	<=													UBUS_RIMT_PACK_READ	;
			UBUS_RIMT_PACK_READ	:		ubus_rimt_wdma_mfsm	<=													UBUS_RIMT_PACK_RRDY	;
			UBUS_RIMT_PACK_RRDY	:		ubus_rimt_wdma_mfsm	<=													UBUS_RIMT_PACK_BEAT	;
			UBUS_RIMT_PACK_BEAT	:		ubus_rimt_wdma_mfsm	<=	ubus_wdma_pack_done	?	UBUS_RIMT_PACK_LOOP	:	UBUS_RIMT_PACK_BEAT	;
			UBUS_RIMT_PACK_LOOP	:		ubus_rimt_wdma_mfsm	<= ~ubus_wdma_pack_over	?	UBUS_RIMT_PACK_REQS	:	
																ubus_rimt_frag_case	?	UBUS_RIMT_FRAG_REQS	:	UBUS_RIMT_WDMA_WRDY	;

			UBUS_RIMT_FRAG_REQS	:		ubus_rimt_wdma_mfsm	<=													UBUS_RIMT_FRAG_READ	;
			UBUS_RIMT_FRAG_READ	:		ubus_rimt_wdma_mfsm	<=													UBUS_RIMT_FRAG_RRDY		;
			UBUS_RIMT_FRAG_RRDY	:		ubus_rimt_wdma_mfsm	<=													UBUS_RIMT_FRAG_BEAT	;
			UBUS_RIMT_FRAG_BEAT	:		ubus_rimt_wdma_mfsm	<=	ubus_wdma_frag_done	?	UBUS_RIMT_WDMA_WRDY	:	UBUS_RIMT_FRAG_BEAT	;

			UBUS_RIMT_WDMA_WRDY	:		ubus_rimt_wdma_mfsm	<=													UBUS_RIMT_WDMA_SEEK	;
			default				:		ubus_rimt_wdma_mfsm	<=													UBUS_RIMT_WDMA_IDLE	;
		endcase
	end
/***********************************************************************************************************************/
	reg			[ 2: 0]					ubus_rimt_read_bank	;
	reg									ubus_rimt_read_rank	;
	reg			[ 5: 0]					ubus_rimt_read_addr	;
	reg									ubus_rimt_read_drdy	;
	reg			[ 3: 0]					ubus_rimt_read_dcnt	;

	reg									ubus_rimt_frag_rdcs	;
	reg									ubus_rimt_pack_rdcs	;
	reg			[12: 0]					ubus_rimt_pack_cnts	;

	wire								ubus_rimt_wdma_issu	;
	wire								ubus_rimt_read_init	;
	wire								ubus_rimt_read_csen	;
	wire								ubus_rimt_frag_rdok	;
	wire								ubus_rimt_pack_rdok	;
	wire		[ 3: 0]					ubus_rimt_dcnt_inc1	;

	assign		ubus_rimt_wdma_issu	= &{ubus_rimt_wdma_seek	,	ubus_rimt_wdma_reqs	};
	assign		ubus_rimt_read_init	=	ubus_rimt_frag_reqs |	ubus_rimt_pack_reqs	;
	assign		ubus_rimt_read_csen	=	ubus_rimt_frag_rdcs |	ubus_rimt_pack_rdcs	;

	assign		ubus_rimt_dcnt_inc1	=	ubus_rimt_read_dcnt + 1	;	
	assign		ubus_rimt_frag_rdok	= &{ubus_rimt_frag_rdcs	,	ubus_rimt_dcnt_inc1	==	ubus_rimt_frag_numb	};
	assign		ubus_rimt_pack_rdok	= &{ubus_rimt_pack_rdcs	,	ubus_rimt_dcnt_inc1	==	4'H8				};
	assign		ubus_wdma_pack_over	=	ubus_rimt_pack_cnts	==	ubus_rimt_pack_numb	;

//------------------------------------------------------------------------------
	always@(posedge ubus_clki or negedge ubus_rstn)	
	if(~ubus_rstn)						ubus_rimt_read_bank	<=	0	;
	else if(ubus_rimt_wdma_issu)		ubus_rimt_read_bank	<=	ubus_rimt_wdma_edge	;

	always@(posedge ubus_clki or negedge ubus_rstn)	
	if(~ubus_rstn)						ubus_rimt_read_rank	<=	0	;
	else if(ubus_rimt_wdma_issu)		ubus_rimt_read_rank	<=	ubus_rimt_wdma_tags[25]	;

	always@(posedge ubus_clki or negedge ubus_rstn)	
	if(~ubus_rstn)						ubus_rimt_frag_rdcs	<=	0	;
	else if(ubus_rimt_frag_reqs)		ubus_rimt_frag_rdcs	<=	1	;
	else if(ubus_rimt_frag_rdok)		ubus_rimt_frag_rdcs	<=	0	;	

	always@(posedge ubus_clki or negedge ubus_rstn)	
	if(~ubus_rstn)						ubus_rimt_pack_rdcs	<=	0	;
	else if(ubus_rimt_pack_reqs)		ubus_rimt_pack_rdcs	<=	1	;
	else if(ubus_rimt_pack_rdok)		ubus_rimt_pack_rdcs	<=	0	;	

	always@(posedge ubus_clki or negedge ubus_rstn)	
	if(~ubus_rstn)						ubus_rimt_read_dcnt	<=	0	;
	else if(~ubus_rimt_wdma_enab)		ubus_rimt_read_dcnt	<=	0	;
	else if( ubus_rimt_read_init)		ubus_rimt_read_dcnt	<=	0	;
	else if( ubus_rimt_read_csen)		ubus_rimt_read_dcnt	<=	ubus_rimt_dcnt_inc1	;	

	always@(posedge ubus_clki or negedge ubus_rstn)	
	if(~ubus_rstn)						ubus_rimt_read_drdy	<=	0	;
	else if(~ubus_rimt_wdma_enab)		ubus_rimt_read_drdy	<=	0	;
	else								ubus_rimt_read_drdy	<=	ubus_rimt_read_csen	;
	
	always@(posedge ubus_clki or negedge ubus_rstn)	
	if(~ubus_rstn)						ubus_rimt_read_addr	<=	0	;
	else if(~ubus_rimt_wdma_enab)		ubus_rimt_read_addr	<=	0	;
	else if( ubus_rimt_wdma_issu)		ubus_rimt_read_addr	<=	0	;
	else if( ubus_rimt_read_csen)		ubus_rimt_read_addr	<=	ubus_rimt_read_addr + 1	;

	always@(posedge ubus_clki or negedge ubus_rstn)	
	if(~ubus_rstn)						ubus_rimt_pack_cnts	<=	0	;
	else if(~ubus_rimt_wdma_enab)		ubus_rimt_pack_cnts	<=	0	;
	else if( ubus_rimt_wdma_issu)		ubus_rimt_pack_cnts	<=	0	;
	else if( ubus_wdma_pack_done)		ubus_rimt_pack_cnts	<=	ubus_rimt_pack_cnts + 1	;
/***********************************************************************************************************************/
	reg			[ 3: 0]					ubus_page_pops_cnts	;
	reg			[ 0: 7][255: 0]			ubus_page_pops_memo	;

	wire		[ 0: 7]					ubus_page_pops_drdy	;
	wire		[ 0: 7][255:0]			ubus_rimt_read_data	;
	wire		       [255:0]			ubus_rimt_bank_data	;

	assign		ubus_rimt_bank_data	=	ubus_rimt_read_bank == 3'H7	?	ubus_rimt_read_data[7]	:
										ubus_rimt_read_bank == 3'H6	?	ubus_rimt_read_data[6]	:
										ubus_rimt_read_bank == 3'H5	?	ubus_rimt_read_data[5]	:
										ubus_rimt_read_bank == 3'H4	?	ubus_rimt_read_data[4]	:
										ubus_rimt_read_bank == 3'H3	?	ubus_rimt_read_data[3]	:
										ubus_rimt_read_bank == 3'H2	?	ubus_rimt_read_data[2]	:
										ubus_rimt_read_bank == 3'H1	?	ubus_rimt_read_data[1]	:	ubus_rimt_read_data[0]	;

	always@(posedge ubus_clki or negedge ubus_rstn)	
	if(~ubus_rstn)						ubus_page_pops_cnts	<=	0	;
	else if(~ubus_rimt_wdma_enab)		ubus_page_pops_cnts	<=	0	;
	else if( ubus_rimt_read_init)		ubus_page_pops_cnts	<=	0	;
	else if( ubus_rimt_read_drdy)		ubus_page_pops_cnts	<=	ubus_page_pops_cnts + 1	;

	for(genvar i = 0 ;  i < 8 ; i++)	begin:gens_rimt_wdma_memo

		assign	ubus_page_pops_drdy[i]=	ubus_rimt_read_drdy &(ubus_page_pops_cnts==i)	;

		always@(posedge ubus_clki or negedge ubus_rstn)	
		if(~ubus_rstn)					ubus_page_pops_memo[i]	<=	0	;
		else if(~ubus_rimt_wdma_enab)	ubus_page_pops_memo[i]	<=	0	;
		else if(ubus_page_pops_drdy[i])	ubus_page_pops_memo[i]	<=	ubus_rimt_bank_data	;

		ping_pang_rimt_bram			u_edge_rimt_wdma_bram(
			.wport_rank					(cube_edge_rimt_rank[i]	),//input					
			.wport_csen					(cube_edge_rimt_csen[i]	),//input  				 	
			.wport_addr					(cube_edge_rimt_addr[i]	),//input		[ 6:0]		
			.wport_data					(cube_edge_rimt_data[i]	),//input		[255:0]		
			.wport_clki					(link_clki				),//input					

			.rport_rank					(ubus_rimt_read_rank	),//input				
			.rport_addr					(ubus_rimt_read_addr	),//input		[ 6 :0]	
			.rport_data					(ubus_rimt_read_data[i]	),//output		[255:0]	
			.rport_clki					(ubus_clki				));//input				
	end
/***********************************************************************************************************************/
	reg									ubus_wdma_beat_csen	;
	reg		[ 3: 0]						ubus_wdma_beat_cnts	;

	wire								ubus_wdma_frag_csen	;
	wire								ubus_wdma_pack_csen	;
	wire	[ 3: 0]						ubus_wdma_beat_inc1	;
	
	assign	ubus_wdma_beat_inc1	=		ubus_wdma_beat_cnts + 1	;
	assign	ubus_wdma_ddrs_csen	= 	&{	ubus_wdma_beat_csen	,	ubus_wdma_ddrs_wrdy	,	ubus_wdma_ddrs_trdy	};
	assign	ubus_wdma_frag_csen	=	&{	ubus_wdma_ddrs_csen	,	ubus_rimt_frag_beat	};
	assign	ubus_wdma_pack_csen	=	&{	ubus_wdma_ddrs_csen	,	ubus_rimt_pack_beat	};

	assign	ubus_wdma_frag_done	=	&{	ubus_wdma_frag_csen	,	ubus_wdma_beat_inc1	==	ubus_rimt_frag_numb	};										
	assign	ubus_wdma_pack_done	=	&{	ubus_wdma_pack_csen	,	ubus_wdma_beat_inc1	==	4'H8				};										

	assign	ubus_wdma_beat_wreq	=	|{	ubus_rimt_frag_rrdy	,	ubus_rimt_pack_rrdy	};
	assign	ubus_wdma_beat_wrdy	=	|{	ubus_wdma_frag_done	,	ubus_wdma_pack_done	};
									
	always@(posedge ubus_clki or negedge ubus_rstn)
	if(!ubus_rstn)						ubus_wdma_beat_csen	<=	0	;
	else if(ubus_wdma_beat_wreq)		ubus_wdma_beat_csen	<=	1	;	
	else if(ubus_wdma_beat_wrdy)		ubus_wdma_beat_csen	<=	0	;	

	always@(posedge ubus_clki or negedge ubus_rstn)
	if(!ubus_rstn)						ubus_wdma_beat_cnts	<=	0	;
	else if(ubus_wdma_beat_wreq)		ubus_wdma_beat_cnts	<=	0	;
	else if(ubus_wdma_ddrs_csen)		ubus_wdma_beat_cnts	<=	ubus_wdma_beat_inc1	;

	always@(posedge ubus_clki or negedge ubus_rstn)
	if(!ubus_rstn)						ubus_wdma_ddrs_addr	<=	0	;
	else if(~ubus_rimt_wdma_enab)		ubus_wdma_ddrs_addr	<=	0	;
	else if( ubus_rimt_wdma_issu)		ubus_wdma_ddrs_addr	<=	ubus_rimt_wdma_tags[24:0]	;
	else if( ubus_wdma_ddrs_csen)		ubus_wdma_ddrs_addr	<=	ubus_wdma_ddrs_addr + 1		;
//----------------------------------------------------------------------------------------------------------------------
	assign	ubus_wdma_ddrs_data	=		ubus_wdma_beat_cnts	== 4'H0	?	ubus_page_pops_memo[0]	:
										ubus_wdma_beat_cnts	== 4'H1	?	ubus_page_pops_memo[1]	:
										ubus_wdma_beat_cnts	== 4'H2	?	ubus_page_pops_memo[2]	:
										ubus_wdma_beat_cnts	== 4'H3	?	ubus_page_pops_memo[3]	:
										ubus_wdma_beat_cnts	== 4'H4	?	ubus_page_pops_memo[4]	:
										ubus_wdma_beat_cnts	== 4'H5	?	ubus_page_pops_memo[5]	:
										ubus_wdma_beat_cnts	== 4'H6	?	ubus_page_pops_memo[6]	:
										ubus_wdma_beat_cnts	== 4'H7	?	ubus_page_pops_memo[7]	:	256'H0	;
/***********************************************************************************************************************/
endmodule 
//	reg			[ 6: 0]					ubus_rimt_read_addr	;
//	reg			[ 3: 0]					ubus_rimt_dmem_rcnt	;
//	reg									ubus_rimt_read_drdy	;
//
//	wire		[ 3: 0]					ubus_rimt_rcnt_inc1	;
//
//	assign		ubus_rimt_rcnt_inc1	=	ubus_rimt_dmem_rcnt + 1 ;
//	assign		ubus_rdma_frag_done	= &{ubus_rimt_frag_read	,	ubus_rimt_rcnt_inc1	==	ubus_rimt_frag_numb	};
//	assign		ubus_rdma_pack_done	= &{ubus_rimt_pack_read	,	ubus_rimt_rcnt_inc1	==	4'H8				};
//
//	wire		ubus_rimt_read_init	=	ubus_rimt_frag_reqs	|	ubus_rimt_pack_reqs	;
//	wire		ubus_rimt_read_csen	=	ubus_rimt_frag_read	|	ubus_rimt_pack_read	;
//	wire		ubus_rimt_read_last	= 	ubus_rdma_frag_done	|	ubus_rdma_pack_done	;
//
//	always@(posedge ubus_clki or negedge ubus_rstn)	
//	if(~ubus_rstn)						ubus_rimt_dmem_rcnt	<=	0	;
//	else if(~ubus_rimt_wdma_enab)		ubus_rimt_dmem_rcnt	<=	0	;
//	else if( ubus_rimt_read_init)		ubus_rimt_dmem_rcnt	<=	0	;
//	else if( ubus_rimt_read_last)		ubus_rimt_dmem_rcnt	<=	0	;
//	else if( ubus_rimt_read_csen)		ubus_rimt_dmem_rcnt	<=	ubus_rimt_rcnt_inc1	;
//
//------------------------------------------------------------------------------

