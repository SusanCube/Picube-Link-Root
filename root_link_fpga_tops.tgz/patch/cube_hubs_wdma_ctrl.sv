/*----author edward------*/

module	cube_hubs_wdma_ctrl(
	input								hubs_rxdi_wdma_enab	,//write enable
	output								hubs_rxdi_wdma_done	,

	input		[24 : 0]				hubs_rxdi_ddrs_base	,	
	input		[19 : 0]				hubs_rxdi_rows_numb	,
	input		[15 : 0]				hubs_rxdi_cols_numb	,

	input								hubs_rxdi_data_lead	,
	input								hubs_rxdi_data_wrcs	,
	input		[ 31: 0]				hubs_rxdi_data_word	,

	input								link_clki			,
	input								link_rstn			,

	output								ubus_hubs_wdma_csen	,
	output		[ 24: 0]				ubus_hubs_wdma_addr	,
	output		[255: 0]				ubus_hubs_wdma_data	,
	input								ubus_hubs_wdma_trdy	,
	input								ubus_hubs_wdma_wrdy	,

	input								ubus_clki			,
	input								ubus_rstn			);
/**********************************************************************************************************************/
	reg			[  2: 0]				ubus_wdma_ddrs_samp	;	
	reg			[  1: 0]				ubus_wdma_done_samp	;	
	wire								ubus_wdma_ddrs_done	;

	wire								ubus_hubs_wdma_disa	;
	wire								ubus_hubs_wdma_init	;
	wire								ubus_hubs_wdma_enab	;
	
	assign	ubus_hubs_wdma_disa	=		ubus_wdma_ddrs_samp[1:0]==2'B00	;
	assign	ubus_hubs_wdma_init	=		ubus_wdma_ddrs_samp[1:0]==2'B10	;
	assign	ubus_hubs_wdma_enab	=		ubus_wdma_ddrs_samp[1:0]==2'B11	;
	assign	hubs_rxdi_wdma_done	=		ubus_wdma_done_samp[0]			;

	always@(posedge ubus_clki or negedge ubus_rstn)
	if(~ubus_rstn)						ubus_wdma_ddrs_samp	<=	0	;
	else								ubus_wdma_ddrs_samp	<={	hubs_rxdi_wdma_enab	, ubus_wdma_ddrs_samp[2:1]	};	

	always@(posedge link_clki or negedge link_rstn)
	if(~link_rstn)						ubus_wdma_done_samp	<=	0	;
	else								ubus_wdma_done_samp	<={	ubus_wdma_ddrs_done	, ubus_wdma_done_samp[ 1 ]	};	
/**********************************************************************************************************************/
	reg			[  2: 0]				hubs_rxdi_word_cnts	;
	reg			[ 24: 0]				hubs_rxdi_page_cnts	;	
	reg			[ 24: 0]				hubs_rxdi_page_addr	;	
	reg			[255: 0]				hubs_rxdi_page_data	;
	reg									hubs_rxdi_page_wrcs	;

	wire								last_word_each_page	;
	wire		[  8: 0]				hubs_rxdi_push_dptr	;

	assign	last_word_each_page	= 	&{	hubs_rxdi_data_wrcs	,	hubs_rxdi_word_cnts	};
	assign	hubs_rxdi_push_dptr	=		hubs_rxdi_page_cnts[ 8: 0]	;

	always@(posedge link_clki or negedge link_rstn)
	if(!link_rstn) 						hubs_rxdi_word_cnts	<=	0	;
	else if(~hubs_rxdi_wdma_enab)		hubs_rxdi_word_cnts	<=	0	;
	else if( hubs_rxdi_data_lead)		hubs_rxdi_word_cnts	<=	0	;
	else 								hubs_rxdi_word_cnts	<=	hubs_rxdi_word_cnts	+	hubs_rxdi_data_wrcs	;

	always@(posedge link_clki or negedge link_rstn)
	if(!link_rstn) 						hubs_rxdi_page_data	<=	0	;
	else if(~hubs_rxdi_wdma_enab)		hubs_rxdi_page_data	<=	0	;
	else if( hubs_rxdi_data_lead)		hubs_rxdi_page_data	<=	0	;
	else if( hubs_rxdi_data_wrcs)		hubs_rxdi_page_data	<={	hubs_rxdi_data_word	,	hubs_rxdi_page_data[255:32]	};

	always@(posedge link_clki or negedge link_rstn)
	if(!link_rstn) 						hubs_rxdi_page_addr	<=	0	;
	else if(~hubs_rxdi_wdma_enab)		hubs_rxdi_page_addr	<=	hubs_rxdi_ddrs_base	;
	else if( hubs_rxdi_page_wrcs)		hubs_rxdi_page_addr	<=	hubs_rxdi_page_addr + 1	;

	always@(posedge link_clki or negedge link_rstn)
	if(!link_rstn) 						hubs_rxdi_page_cnts	<=	0	;
	else if(~hubs_rxdi_wdma_enab)		hubs_rxdi_page_cnts	<=	0	;
	else if( hubs_rxdi_page_wrcs)		hubs_rxdi_page_cnts	<=	hubs_rxdi_page_cnts + 1	;

	always@(posedge link_clki or negedge link_rstn)
	if(!link_rstn) 						hubs_rxdi_page_wrcs	<=	0	;
	else								hubs_rxdi_page_wrcs	<=	last_word_each_page	;
/**********************************************************************************************************************/
	wire								ubus_hubs_wdma_reqs		;

	gens_edge_slow_fast 			u_hubs_wdma_beat_gens(	
		.fast_edge 						(ubus_hubs_wdma_reqs	),
		.fast_clki						(ubus_clki				),
		.fast_rstn						(ubus_rstn				),

		.slow_sign						(hubs_rxdi_page_wrcs	),
		.slow_clki						(link_clki				),
		.slow_rstn						(link_rstn				));
/**********************************************************************************************************************/
	parameter	UBUS_WDMA_DDRS_IDLE	=	3'H0	;	
	parameter	UBUS_WDMA_DDRS_SEEK	=	3'H1	;
	parameter	UBUS_WDMA_DDRS_TAPS	=	3'H2	;
	parameter	UBUS_WDMA_DDRS_LOOP	=	3'H3	;
	parameter	UBUS_WDMA_DDRS_DONE	=	3'H4	;

	reg		[ 2: 0]						ubus_hubs_wdma_mfsm	;

	wire								ubus_hubs_wdma_wreq	;
	wire								ubus_hubs_wdma_wrok	;
	wire								ubus_hubs_wdma_last	;

	wire								ubus_hubs_mfsm_taps	;
	wire								ubus_hubs_mfsm_loop	;

	always@(posedge ubus_clki or negedge ubus_rstn )
	if(!ubus_rstn)						ubus_hubs_wdma_mfsm	<=	UBUS_WDMA_DDRS_IDLE	;	
	else if(~ubus_hubs_wdma_enab)		ubus_hubs_wdma_mfsm	<=	UBUS_WDMA_DDRS_IDLE	;	
	else begin
		case(ubus_hubs_wdma_mfsm)
			UBUS_WDMA_DDRS_IDLE	:		ubus_hubs_wdma_mfsm	<=													UBUS_WDMA_DDRS_SEEK	;	
			UBUS_WDMA_DDRS_SEEK	:		ubus_hubs_wdma_mfsm	<=	ubus_hubs_wdma_wreq	?	UBUS_WDMA_DDRS_TAPS	:	UBUS_WDMA_DDRS_SEEK	;	
			UBUS_WDMA_DDRS_TAPS	:		ubus_hubs_wdma_mfsm	<=	ubus_hubs_wdma_wrok	?	UBUS_WDMA_DDRS_LOOP	:	UBUS_WDMA_DDRS_TAPS	;	
			UBUS_WDMA_DDRS_LOOP	:		ubus_hubs_wdma_mfsm	<=	ubus_hubs_wdma_last	?	UBUS_WDMA_DDRS_DONE	:	UBUS_WDMA_DDRS_SEEK	;		
			UBUS_WDMA_DDRS_DONE	:		ubus_hubs_wdma_mfsm	<=	ubus_hubs_wdma_enab	?	UBUS_WDMA_DDRS_DONE	:	UBUS_WDMA_DDRS_IDLE	;	
		endcase
	end
//------------------------------------------------------------------------------
	reg		[24: 0]						ubus_hubs_wdma_size	;
	reg		[24: 0]						ubus_hubs_wdma_cnts	;
	reg		[24: 0]						ubus_hubs_wdma_numb	;
	reg									ubus_hubs_wdma_time	;

	wire	[ 1: 0]						ubus_hubs_wdma_taps	;

	wire								ubus_hubs_wdma_drdy	;
	wire	[  8: 0]					ubus_hubs_wdma_lsba	;
	wire	[  8: 0]					ubus_hubs_wdma_nxta	;	
	wire	[  8: 0]					ubus_wdma_pops_dptr	;


	assign	ubus_hubs_mfsm_taps	=		ubus_hubs_wdma_mfsm	==	UBUS_WDMA_DDRS_TAPS	;
	assign	ubus_hubs_mfsm_loop	=		ubus_hubs_wdma_mfsm	==	UBUS_WDMA_DDRS_LOOP	;
	assign	ubus_wdma_ddrs_done	=		ubus_hubs_wdma_mfsm	==	UBUS_WDMA_DDRS_DONE	;

	assign	ubus_hubs_wdma_taps	=		ubus_hubs_wdma_cnts[ 1: 0]	;

	assign	ubus_hubs_wdma_drdy	=	&{	ubus_hubs_wdma_trdy	,	ubus_hubs_wdma_wrdy		};
	assign	ubus_hubs_wdma_csen	=	&{	ubus_hubs_wdma_time	,	ubus_hubs_wdma_drdy		};

	assign	ubus_hubs_wdma_wreq	=		ubus_hubs_wdma_numb	>=	ubus_hubs_wdma_cnts + 4	;
	assign	ubus_hubs_wdma_wrok	=	&{	ubus_hubs_wdma_csen	,	ubus_hubs_wdma_taps		};
	assign	ubus_hubs_wdma_last	=		ubus_hubs_wdma_cnts	==	ubus_hubs_wdma_size		;

	assign	ubus_hubs_wdma_lsba	=		ubus_hubs_wdma_cnts[ 8: 0]	;
	assign	ubus_hubs_wdma_nxta	=		ubus_hubs_wdma_lsba +  1	;
	assign	ubus_wdma_pops_dptr	=		ubus_hubs_wdma_csen	?	ubus_hubs_wdma_nxta	:	ubus_hubs_wdma_lsba	;
//------------------------------------------------------------------------------	
	always@(posedge ubus_clki or negedge ubus_rstn )
	if(!ubus_rstn)						ubus_hubs_wdma_size	<=	0	;	
	else if( ubus_hubs_wdma_disa)		ubus_hubs_wdma_size	<=	0	;	
	else if( ubus_hubs_wdma_init)		ubus_hubs_wdma_size	<=	hubs_rxdi_rows_numb	* 	hubs_rxdi_cols_numb	;	

	always@(posedge ubus_clki or negedge ubus_rstn )
	if(!ubus_rstn)						ubus_hubs_wdma_numb	<=	0	;	
	else if( ubus_hubs_wdma_disa)		ubus_hubs_wdma_numb	<=	0	;	
	else if( ubus_hubs_wdma_init)		ubus_hubs_wdma_numb	<=	0	;	
	else								ubus_hubs_wdma_numb	<=	ubus_hubs_wdma_numb +	ubus_hubs_wdma_reqs	;	

	always@(posedge ubus_clki or negedge ubus_rstn )
	if(!ubus_rstn)						ubus_hubs_wdma_cnts	<=	0	;	
	else if( ubus_hubs_wdma_disa)		ubus_hubs_wdma_cnts	<=	0	;	
	else if( ubus_hubs_wdma_init)		ubus_hubs_wdma_cnts	<=	0	;	
	else if( ubus_hubs_mfsm_taps)		ubus_hubs_wdma_cnts	<=	ubus_hubs_wdma_cnts +	ubus_hubs_wdma_csen	;	

	always@(posedge ubus_clki or negedge ubus_rstn )
	if(!ubus_rstn)						ubus_hubs_wdma_time	<=	0	;	
	else if( ubus_hubs_wdma_disa)		ubus_hubs_wdma_time	<=	0	;	
	else if( ubus_hubs_wdma_init)		ubus_hubs_wdma_time	<=	0	;	
	else if( ubus_hubs_wdma_wreq)		ubus_hubs_wdma_time	<=	1	;	
	else if( ubus_hubs_wdma_wrok)		ubus_hubs_wdma_time	<=	0	;	
/**********************************************************************************************************************/
	dual_port_bram	#(	
		.ADDR_BITS	( 9 ),	.DATA_BITS	( 256 ))	
								u_hubs_wdma_ddrs_data (
		.wport_csen					(hubs_rxdi_page_wrcs	),//input  				 		
		.wport_addr					(hubs_rxdi_push_dptr	),//input		[ADDR_BITS-1:0]
		.wport_data					(hubs_rxdi_page_data	),//input		[DATA_BITS-1:0]
		.wport_clki					(link_clki				),//input						

		.rport_addr					(ubus_wdma_pops_dptr	),//input		[ADDR_BITS-1:0]
		.rport_data					(ubus_hubs_wdma_data	),//output	reg	[DATA_BITS-1:0]
		.rport_clki					(ubus_clki				));//input						

	dual_port_bram	#(	
		.ADDR_BITS	( 9 ),	.DATA_BITS	( 25 ))	
								u_hubs_wdma_ddrs_addr (
		.wport_csen					(hubs_rxdi_page_wrcs	),//input  				 		
		.wport_addr					(hubs_rxdi_push_dptr	),//input		[ADDR_BITS-1:0]
		.wport_data					(hubs_rxdi_page_addr	),//input		[DATA_BITS-1:0]
		.wport_clki					(link_clki				),//input						
		
		.rport_addr					(ubus_wdma_pops_dptr	),//input		[ADDR_BITS-1:0]
		.rport_data					(ubus_hubs_wdma_addr	),//output	reg	[DATA_BITS-1:0]
		.rport_clki					(ubus_clki				));//input						

endmodule 
  