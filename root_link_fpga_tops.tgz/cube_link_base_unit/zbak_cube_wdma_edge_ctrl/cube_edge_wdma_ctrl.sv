//	input	[ 4: 0]					cube_idat_gnpu_numb	,
//	output	reg						cube_idat_wdma_done	,

module	cube_edge_wdma_ctrl(
//add @20250119
	input		[ 7: 0]				cube_edge_link_enab	,
	input		[24: 0]				cube_edge_imag_size	,
	output							cube_edge_wdma_done	,
	input							cube_edge_wdma_enab	,

	input							link_clki			,
	input							link_rstn			,

	input		[ 0: 7]				cube_edge_fifo_ov16	,
	input		[ 0: 7]				cube_edge_fifo_ov08	,
	input		[ 0: 7]				cube_edge_fifo_ov04	,
	input		[ 0: 7]				cube_edge_fifo_ov02	,
	

	output							cube_edge_wdma_init	,
	output		[ 0: 7]				cube_edge_wdma_reqs	,
	output	reg	[ 3: 0]				cube_edge_wdma_size	,

	input		[ 0: 7][255: 0]		cube_edge_wdma_data	,
	input		[ 0: 7][ 24: 0]		cube_edge_wdma_addr	,
	input		[ 0: 7]				cube_edge_wdma_drdy	,				
	
	output							ubus_wdma_ddrs_csen	,
	output		[ 24: 0]			ubus_wdma_ddrs_addr	,
	output		[255: 0]			ubus_wdma_ddrs_data	,
	input							ubus_wdma_ddrs_trdy	,
	input							ubus_wdma_ddrs_wrdy	,
	
	input							ubus_clki			,
	input							ubus_rstn			);
/**********************************************************************/
	wire		[255: 0]			cube_mono_wdma_data	;
	wire		[ 24: 0]			cube_mono_wdma_addr	;
	wire							cube_mono_wdma_drdy	;

	cube_edge_wdma_muxs 		u_tpem_idat_wdma_mx10(
		.cube_wdma_mtrx_data		(cube_edge_wdma_data	),//input	[ 0: 9]	[255: 0]
		.cube_wdma_mtrx_addr		(cube_edge_wdma_addr	),//input	[ 0: 9]	[ 24: 0]
		.cube_wdma_mtrx_drdy		(cube_edge_wdma_drdy	),//input	[ 0: 9]			

		.cube_wdma_mono_data		(cube_mono_wdma_data	),//output	reg	[255: 0]	
		.cube_wdma_mono_addr		(cube_mono_wdma_addr	),//output	reg	[ 24: 0]	
		.cube_wdma_mono_drdy		(cube_mono_wdma_drdy	),//output	reg		
		.cube_clki					(ubus_clki				),//input				
		.cube_rstn					(ubus_rstn				));//input				
/**********************************************************************/
	wire							edge_wdma_pack_done	;
	
	reg		[ 1: 0]					edge_wdma_enab_samp	;
	wire							edge_wdma_mfsm_enab	;
	assign	edge_wdma_mfsm_enab	=	edge_wdma_enab_samp[0]	;
	
	always@(posedge ubus_clki or negedge ubus_rstn)
	if(!ubus_rstn)					edge_wdma_enab_samp	<=	0	;
	else							edge_wdma_enab_samp	<={	cube_edge_wdma_enab	,	edge_wdma_enab_samp[1]	};			

	cube_edge_wdma_mfsm			u_cube_idat_wdma_mfsm(
		.edge_wdma_mfsm_enab		(edge_wdma_mfsm_enab	),//input			
		.edge_wdma_pack_done		(edge_wdma_pack_done	),//input				
		
		.cube_edge_fifo_ov16		(cube_edge_fifo_ov16	),//input		[ 0: 7]	
		.cube_edge_fifo_ov08		(cube_edge_fifo_ov08	),//input		[ 0: 7]	
		.cube_edge_fifo_ov04		(cube_edge_fifo_ov04	),//input		[ 0: 7]	
		.cube_edge_fifo_ov02		(cube_edge_fifo_ov02	),//input		[ 0: 7]	
		

		.cube_edge_wdma_init		(cube_edge_wdma_init	),//output				
		.cube_edge_wdma_reqs		(cube_edge_wdma_reqs	),//output		[ 0: 1]	
		.cube_edge_wdma_size		(cube_edge_wdma_size	),//output	reg	[ 3: 0]	

		.ubus_clki					(ubus_clki				),//input				
		.ubus_rstn					(ubus_rstn				));//input		

/**********************************************************************/
	reg			[24: 0]				cube_wdma_page_size	;
	reg								cube_edge_wdma_wrok	;
	
	reg			[ 1: 0]				cube_edge_wdma_samp	;


	wire		[3: 0]				cube_edge_link_numb	;
	wire							cube_edge_wdma_last	;


	port_link_numb_accu			u_port_link_numb_accu(	
		.port_link_csen				(cube_edge_link_enab		),//input		[ 7: 0]
		.port_link_numb				(cube_edge_link_numb		));//input		[ 3: 0]

	always@(posedge ubus_clki or negedge ubus_rstn)	
	if(~ubus_rstn)					cube_wdma_page_size	<=	0	;
	else if(~edge_wdma_mfsm_enab)	cube_wdma_page_size	<=	25'H1FFFFFF	;
	else 							cube_wdma_page_size	<=	cube_edge_link_numb *	cube_edge_imag_size	;

	always@(posedge ubus_clki or negedge ubus_rstn)	
	if(~ubus_rstn)					cube_edge_wdma_wrok	<=	0	;
	else if(~edge_wdma_mfsm_enab)	cube_edge_wdma_wrok	<=	0	;
	else if( cube_edge_wdma_last)	cube_edge_wdma_wrok	<=	1	;

	always@(posedge link_clki or negedge link_rstn)	
	if(~link_rstn)					cube_edge_wdma_samp	<=	0	;
	else							cube_edge_wdma_samp	<= {cube_edge_wdma_wrok	,	cube_edge_wdma_samp[1]	};

	assign	cube_edge_wdma_done	=	cube_edge_wdma_samp[0]	;

/***********************************************************************/
	reg		[ 3: 0]					cube_idat_load_numb	;
	reg		[ 3: 0]					cube_idat_load_cnts	;

	assign	edge_wdma_pack_done	= &{cube_mono_wdma_drdy	,	cube_idat_load_numb	==	cube_idat_load_cnts};

	always@(posedge ubus_clki or negedge ubus_rstn)	
	if(!ubus_rstn)					cube_idat_load_numb	<=	0	;
	else if(cube_edge_wdma_reqs)	cube_idat_load_numb	<=	cube_edge_wdma_size	;
	else if(edge_wdma_pack_done)	cube_idat_load_numb	<=	0	;

	always@(posedge ubus_clki or negedge ubus_rstn)	
	if(!ubus_rstn)					cube_idat_load_cnts	<=	0	;
	else if(cube_edge_wdma_reqs)	cube_idat_load_cnts	<=	0	;
	else if(edge_wdma_pack_done)	cube_idat_load_cnts	<=	0	;
	else if(cube_mono_wdma_drdy)	cube_idat_load_cnts	<=	cube_idat_load_cnts+1;

/**********************************************************************************************************/
	reg			[24: 0]				cube_wdma_fifo_wcnt	;
	wire		[24: 0]				cube_rdma_fifo_rcnt	;

	cube_edge_wdma_ddrs			u_cube_edge_wdma_ddrs(
		.ubus_wdma_fifo_enab		(edge_wdma_mfsm_enab	),//input				
		.cube_wdma_fifo_wcnt		(cube_wdma_fifo_wcnt	),//input		[24: 0]	
	
		.ubus_rdma_ddrs_rcnt		(cube_rdma_fifo_rcnt	),//output	reg	[24: 0]	
		.ubus_rdma_ddrs_rreq		(cube_rdma_fifo_rreq	),//output				
		.ubus_rdma_ddrs_rrdy		(ubus_wdma_ddrs_csen	),//input				
	
		.ubus_clki					(ubus_clki				),//input	
		.ubus_rstn					(ubus_rstn				));//input	

	
	wire		[  8: 0]			cube_wdma_fifo_wptr	;
	wire		[  8: 0]			cube_rdma_fifo_rptr	;
	wire		[  8: 0]			cube_idat_fifo_lsba	;
	wire		[  8: 0]			cube_idat_fifo_nxta	;

	assign	cube_idat_fifo_lsba	=	cube_rdma_fifo_rcnt[8:0];
	assign	cube_idat_fifo_nxta	=	cube_idat_fifo_lsba + 1 ;
	assign	cube_rdma_fifo_rptr	=	ubus_wdma_ddrs_csen	?	cube_idat_fifo_nxta	:	cube_idat_fifo_lsba	;
	assign	cube_wdma_fifo_wptr	=	cube_wdma_fifo_wcnt[8:0];
	
	assign	cube_edge_wdma_last	=	cube_rdma_fifo_rcnt	==	cube_wdma_page_size	;


	assign	ubus_wdma_ddrs_csen	= &{ubus_wdma_ddrs_trdy	,	ubus_wdma_ddrs_wrdy	,	
									cube_rdma_fifo_rreq	,	edge_wdma_mfsm_enab	};
									
	always@(posedge ubus_clki or negedge ubus_rstn)	
	if(!ubus_rstn)					cube_wdma_fifo_wcnt	<=	0	;
	else if(~edge_wdma_mfsm_enab)	cube_wdma_fifo_wcnt	<=	0	;
	else if( cube_edge_wdma_init)	cube_wdma_fifo_wcnt	<=	0	;
	else 							cube_wdma_fifo_wcnt	<=	cube_wdma_fifo_wcnt + 	cube_mono_wdma_drdy	;
/**********************************************************************************************************/

	dual_port_bram	#(	
		.ADDR_BITS	( 9 ),	.DATA_BITS	( 256 ))	
	u_ubus_wdma_data_fifo (
		.wport_csen					(cube_mono_wdma_drdy	),//input  				 		
		.wport_data					(cube_mono_wdma_data	),//input		[DATA_BITS-1:0]
		.wport_addr					(cube_wdma_fifo_wptr	),//input		[ADDR_BITS-1:0]
		.wport_clki					(ubus_clki				),//input						

		.rport_addr					(cube_rdma_fifo_rptr	),//input		[ADDR_BITS-1:0]
		.rport_data					(ubus_wdma_ddrs_data	),//output	reg	[DATA_BITS-1:0]
		.rport_clki					(ubus_clki				));//input						

	dual_port_bram	#(	
		.ADDR_BITS	( 9 ),	.DATA_BITS	( 25 ))	
	u_ubus_wdma_addr_fifo (
		.wport_csen					(cube_mono_wdma_drdy	),//input  				 		
		.wport_data					(cube_mono_wdma_addr	),//input		[DATA_BITS-1:0]
		.wport_addr					(cube_wdma_fifo_wptr	),//input		[ADDR_BITS-1:0]
		.wport_clki					(ubus_clki				),//input						
		
		.rport_addr					(cube_rdma_fifo_rptr	),//input		[ADDR_BITS-1:0]
		.rport_data					(ubus_wdma_ddrs_addr	),//output	reg	[DATA_BITS-1:0]
		.rport_clki					(ubus_clki				));//input						

endmodule
 