/*		lvds_rxdi_intf
	fram_sdi---->lvds_rxdi_line		
					|----IDLY----IDDR----SHFT----lane_trim_cell---->lvds_fram_mbo0

*/

`include	"agile_card_vars.vh"

module	tpgs_link_rxdi_dmau(
	input							link_rxdi_port_init	,
	
	input	[7:0]					link_rxdi_fram_mbdi	,
	input	[7:0]					link_rxdi_dat0_mbdi	,
	input	[7:0]					link_rxdi_dat1_mbdi	,
	input	[7:0]					link_rxdi_dat2_mbdi	,
	input	[7:0]					link_rxdi_dat3_mbdi	,

	output							link_rxdi_trim_mark	,
	output							link_rxdi_icfg_mark	,
	output							link_rxdi_ocfg_mark	,
	output							link_rxdi_nnex_mark	,
	output							link_rxdi_ivct_mark	,
	output							link_rxdi_ovct_mark	,
	output							link_rxdi_imtx_mark	,
	output							link_rxdi_omtx_mark	,
	output							link_rxdi_rivt_mark	,
	output							link_rxdi_rovt_mark	,
	output							link_rxdi_rimt_mark	,
	output							link_rxdi_romt_mark	,
	output							link_rxdi_risv_mark	,
	output							link_rxdi_rosv_mark	,
	output							link_rxdi_rism_mark	,
	output							link_rxdi_rosm_mark	,
	output							link_rxdi_aset_mark	,
	output							link_rxdi_dnld_mark	,
	output							link_rxdi_boot_mark	,
	output							link_rxdi_auxi_mark	,
	
	output	reg						link_rxdi_cmnd_lead	,
	output	reg						link_rxdi_cmnd_wrcs	,
	output	reg						link_rxdi_cmnd_coda	,
	
	output	reg						link_rxdi_data_lead	,
	output	reg						link_rxdi_data_wrcs	,
	output	reg	[31: 0]				link_rxdi_data_word	,

	input							link_clki			,
	input							link_rstn			);
/**********************************************************************************************************/
	reg		[7:0]					link_rxdi_fram_samp	;
	reg		[7:0]					link_rxdi_fram_samx	;
	reg		[7:0]					link_rxdi_dat0_samx	;
	reg		[7:0]					link_rxdi_dat1_samx	;
	reg		[7:0]					link_rxdi_dat2_samx	;
	reg		[7:0]					link_rxdi_dat3_samx	;

	always@(posedge link_clki or negedge link_rstn)	
	if(~link_rstn)	begin
		link_rxdi_fram_samp	<=	0	;
		link_rxdi_fram_samx	<=	0	;
		link_rxdi_dat0_samx	<=	0	;
		link_rxdi_dat1_samx	<=	0	;
		link_rxdi_dat2_samx	<=	0	;
		link_rxdi_dat3_samx	<=	0	;
	end 	else	begin
		link_rxdi_fram_samp	<=	link_rxdi_fram_mbdi	;
		link_rxdi_fram_samx	<=	link_rxdi_fram_samp	;
		link_rxdi_dat0_samx	<=	link_rxdi_dat0_mbdi		;
		link_rxdi_dat1_samx	<=	link_rxdi_dat1_mbdi		;
		link_rxdi_dat2_samx	<=	link_rxdi_dat2_mbdi		;
		link_rxdi_dat3_samx	<=	link_rxdi_dat3_mbdi		;
	end
		
	wire	[ 15: 0]				link_rxdi_fram_buff	;
	wire	[ 31: 0]				link_rxdi_data_buff	;
		
	wire	link_rxdi_fram_rise	=	link_rxdi_fram_buff	==	16'HFF00	;	
	wire	link_rxdi_fram_fall	=	link_rxdi_fram_buff	==	16'H00FF	;	
	wire	link_rxdi_fram_high	=	link_rxdi_fram_buff	==	16'HFFFF	;	
	
	assign	link_rxdi_fram_buff	={	link_rxdi_fram_samp	,	link_rxdi_fram_samx	};
	assign	link_rxdi_data_buff	={	link_rxdi_dat3_samx	,	link_rxdi_dat2_samx	,	link_rxdi_dat1_samx	,	link_rxdi_dat0_samx	};
//----------------------------------------------------------------------------------------------------------	
	assign	link_rxdi_trim_mark	= &{link_rxdi_data_buff	==	`CUBE_LINK_TRIM_LEAD , link_rxdi_fram_rise	};
	assign	link_rxdi_icfg_mark	= &{link_rxdi_data_buff	==	`CUBE_LINK_ICFG_LEAD , link_rxdi_fram_rise	};
	assign	link_rxdi_ocfg_mark	= &{link_rxdi_data_buff	==	`CUBE_LINK_OCFG_LEAD , link_rxdi_fram_rise	};
	assign	link_rxdi_nnex_mark	= &{link_rxdi_data_buff	==	`CUBE_LINK_NNEX_LEAD , link_rxdi_fram_rise	};
	assign	link_rxdi_ivct_mark	= &{link_rxdi_data_buff	==	`CUBE_LINK_IVCT_LEAD , link_rxdi_fram_rise	};
	assign	link_rxdi_ovct_mark	= &{link_rxdi_data_buff	==	`CUBE_LINK_OVCT_LEAD , link_rxdi_fram_rise	};
	assign	link_rxdi_imtx_mark	= &{link_rxdi_data_buff	==	`CUBE_LINK_IMTX_LEAD , link_rxdi_fram_rise	};
	assign	link_rxdi_omtx_mark	= &{link_rxdi_data_buff	==	`CUBE_LINK_OMTX_LEAD , link_rxdi_fram_rise	};
	assign	link_rxdi_rivt_mark	= &{link_rxdi_data_buff	==	`CUBE_LINK_RIVT_LEAD , link_rxdi_fram_rise	};
	assign	link_rxdi_rovt_mark	= &{link_rxdi_data_buff	==	`CUBE_LINK_ROVT_LEAD , link_rxdi_fram_rise	};
	assign	link_rxdi_rimt_mark	= &{link_rxdi_data_buff	==	`CUBE_LINK_RIMT_LEAD , link_rxdi_fram_rise	};
	assign	link_rxdi_romt_mark	= &{link_rxdi_data_buff	==	`CUBE_LINK_ROMT_LEAD , link_rxdi_fram_rise	};
	assign	link_rxdi_risv_mark	= &{link_rxdi_data_buff	==	`CUBE_LINK_RISV_LEAD , link_rxdi_fram_rise	};
	assign	link_rxdi_rosv_mark	= &{link_rxdi_data_buff	==	`CUBE_LINK_ROSV_LEAD , link_rxdi_fram_rise	};
	assign	link_rxdi_rism_mark	= &{link_rxdi_data_buff	==	`CUBE_LINK_RISM_LEAD , link_rxdi_fram_rise	};
	assign	link_rxdi_rosm_mark	= &{link_rxdi_data_buff	==	`CUBE_LINK_ROSM_LEAD , link_rxdi_fram_rise	};
	assign	link_rxdi_aset_mark	= &{link_rxdi_data_buff	==	`CUBE_LINK_ASET_LEAD , link_rxdi_fram_rise	};
	assign	link_rxdi_dnld_mark	= &{link_rxdi_data_buff	==	`CUBE_LINK_DNLD_LEAD , link_rxdi_fram_rise	};
	assign	link_rxdi_boot_mark	= &{link_rxdi_data_buff	==	`CUBE_LINK_BOOT_LEAD , link_rxdi_fram_rise	};
	assign	link_rxdi_auxi_mark	= &{link_rxdi_data_buff	==	`CUBE_LINK_ACMD_LEAD , link_rxdi_fram_rise	};
	wire	link_rxdi_data_mark	= &{link_rxdi_data_buff	==	`CUBE_LINK_DATA_LEAD , link_rxdi_fram_rise	};

	wire	link_rxdi_cmnd_mark	= |{link_rxdi_auxi_mark , link_rxdi_icfg_mark , link_rxdi_ocfg_mark , link_rxdi_nnex_mark , 
									link_rxdi_ivct_mark , link_rxdi_ovct_mark , link_rxdi_imtx_mark , link_rxdi_omtx_mark , 
									link_rxdi_rivt_mark , link_rxdi_rovt_mark , link_rxdi_rimt_mark , link_rxdi_romt_mark , 
									link_rxdi_risv_mark , link_rxdi_rosv_mark , link_rxdi_rism_mark , link_rxdi_rosm_mark , 
									link_rxdi_aset_mark , link_rxdi_dnld_mark , link_rxdi_boot_mark , link_rxdi_trim_mark };

/**********************************************************************************************************/	
	always@(posedge link_clki or negedge link_rstn)	
	if(!link_rstn)					link_rxdi_cmnd_lead	<=	0	;
	else							link_rxdi_cmnd_lead	<=	link_rxdi_cmnd_mark	;

	always@(posedge link_clki or negedge link_rstn)	
	if(!link_rstn)					link_rxdi_cmnd_wrcs	<=	0	;
	else if( link_rxdi_cmnd_lead)	link_rxdi_cmnd_wrcs	<=	1	;
	else if( link_rxdi_fram_fall)	link_rxdi_cmnd_wrcs	<=	0	;
	else							link_rxdi_cmnd_wrcs	<=	link_rxdi_cmnd_wrcs	;

	always@(posedge link_clki or negedge link_rstn)	
	if(!link_rstn)					link_rxdi_cmnd_coda	<=	0	;
	else if( link_rxdi_cmnd_wrcs)	link_rxdi_cmnd_coda	<=	link_rxdi_fram_fall	;
	else							link_rxdi_cmnd_coda	<=	0	;
//----------------------------------
	always@(posedge link_clki or negedge link_rstn)	
	if(!link_rstn)					link_rxdi_data_lead	<=	0	;
	else							link_rxdi_data_lead	<=	link_rxdi_data_mark	;

	always@(posedge link_clki or negedge link_rstn)	
	if(!link_rstn)					link_rxdi_data_wrcs	<=	0	;
	else if( link_rxdi_data_lead)	link_rxdi_data_wrcs	<=	1	;
	else if( link_rxdi_fram_fall)	link_rxdi_data_wrcs	<=	0	;
	else							link_rxdi_data_wrcs	<=	link_rxdi_data_wrcs	;
//----------------------------------
	always@(posedge link_clki or negedge link_rstn)	
	if(!link_rstn)					link_rxdi_data_word	<=	0	;
	else if( link_rxdi_fram_high)	link_rxdi_data_word	<=	link_rxdi_data_buff	;
	else							link_rxdi_data_word	<=	0	;
//----------------------------------------------------------------------	
 
endmodule
