
module	tpgs_link_txdo_pmau(
	input								tune_txdo_inpp	,		
	input								tune_txdo_inpn	,		
		
	output								link_fclk_outp	,
	output								link_fclk_outn	,
	output								link_fram_outp	,
	output								link_fram_outn	,
	output								link_dat0_outp	,
	output								link_dat0_outn	,
	output								link_dat1_outp	,
	output								link_dat1_outn	,
	output								link_dat2_outp	,
	output								link_dat2_outn	,
	output								link_dat3_outp	,
	output								link_dat3_outn	,
		
	input	[ 7: 0]						link_fram_mbdi	,
	input	[ 7: 0]						link_dat0_mbdi	,
	input	[ 7: 0]						link_dat1_mbdi	,
	input	[ 7: 0]						link_dat2_mbdi	,
	input	[ 7: 0]						link_dat3_mbdi	,
		
	input								link_fclk		,
	input								link_strb		,
	input								link_rstn		);
/**********************************************************************************************************************/
	reg		[3: 0]						tune_txdo_samp	;
	wire								tune_txdo_mode	;
	wire								tune_txdo_enab	;

	assign	tune_txdo_enab	=		&	tune_txdo_samp[1:0]	;

	always@(posedge  link_fclk or negedge link_rstn)
	if(~link_rstn)						tune_txdo_samp	<=	0	;
	else								tune_txdo_samp	<={	tune_txdo_mode	, tune_txdo_samp[3:1]	};

	IBUFDS							u_TPGS_TUNE_IPAD (
		.O								(tune_txdo_mode		), 
		.I								(tune_txdo_inpp		),
		.IB								(tune_txdo_inpn		));	
/**********************************************************************************************************************/
	reg		[ 7: 0]						tune_txdo_patn	;

	always@(posedge link_fclk or negedge link_rstn)
	if(!link_rstn) 						tune_txdo_patn	<=	0		;
	else if(~tune_txdo_enab)			tune_txdo_patn	<=  0		;
	else if(link_strb)					tune_txdo_patn	<=  8'H9A	;
	else 								tune_txdo_patn	<= {tune_txdo_patn[5:0]	,tune_txdo_patn[7:6]	};
/**********************************************************************************************************************/
	reg		[ 7: 0]						link_fram_shft	;	
	reg		[ 7: 0]						link_dat0_shft	;	
	reg		[ 7: 0]						link_dat1_shft	;	
	reg		[ 7: 0]						link_dat2_shft	;	
	reg		[ 7: 0]						link_dat3_shft	;	

	always@(posedge link_fclk or negedge link_rstn)
	if(!link_rstn) begin
		link_fram_shft					<=	0	;
		link_dat0_shft					<=	0	;
		link_dat1_shft					<=	0	;
		link_dat2_shft					<=	0	;
		link_dat3_shft					<=	0	;
	end else if(tune_txdo_enab)	begin
		link_fram_shft					<=	0	;
		link_dat0_shft					<=	0	;
		link_dat1_shft					<=	0	;
		link_dat2_shft					<=	0	;
		link_dat3_shft					<=	0	;
	end else if(link_strb)	begin
		link_fram_shft					<=	link_fram_mbdi	;
		link_dat0_shft					<=	link_dat0_mbdi	;
		link_dat1_shft					<=	link_dat1_mbdi	;
		link_dat2_shft					<=	link_dat2_mbdi	;
		link_dat3_shft					<=	link_dat3_mbdi	;
	end else begin
		link_fram_shft					<={	link_fram_shft[5:0]	,2'B00	};
		link_dat0_shft					<={	link_dat0_shft[5:0]	,2'B00	};
		link_dat1_shft					<={	link_dat1_shft[5:0]	,2'B00	};
		link_dat2_shft					<={	link_dat2_shft[5:0]	,2'B00	};
		link_dat3_shft					<={	link_dat3_shft[5:0]	,2'B00	};
	end
/**********************************************************************************************************************/
	wire								link_fram_d0	;
	wire								link_dat0_d0	;
	wire								link_dat1_d0	;
	wire								link_dat2_d0	;
	wire								link_dat3_d0	;

	wire								link_fram_d1	;
	wire								link_dat0_d1	;
	wire								link_dat1_d1	;
	wire								link_dat2_d1	;
	wire								link_dat3_d1	;

	assign		link_fram_d0	=		link_fram_shft[7]	| tune_txdo_patn[7]	;
	assign		link_fram_d1	=		link_fram_shft[6]	| tune_txdo_patn[6]	;

	assign		link_dat0_d0	=		link_dat0_shft[7]	| tune_txdo_patn[7]	;
	assign		link_dat0_d1	=		link_dat0_shft[6]	| tune_txdo_patn[6]	;

	assign		link_dat1_d0	=		link_dat1_shft[7]	| tune_txdo_patn[7]	;
	assign		link_dat1_d1	=		link_dat1_shft[6]	| tune_txdo_patn[6]	;

	assign		link_dat2_d0	=		link_dat2_shft[7]	| tune_txdo_patn[7]	;
	assign		link_dat2_d1	=		link_dat2_shft[6]	| tune_txdo_patn[6]	;

	assign		link_dat3_d0	=		link_dat3_shft[7]	| tune_txdo_patn[7]	;
	assign		link_dat3_d1	=		link_dat3_shft[6]	| tune_txdo_patn[6]	;
/***link_fclk_txdo*******************************************************************************************************************/
  	ODDRE1 #(
		.IS_C_INVERTED					(1'b0				),	// Optional inversion for C
		.IS_D1_INVERTED					(1'b0				),  // Unsupported, do not use
		.IS_D2_INVERTED					(1'b0				),  // Unsupported, do not use
		.SIM_DEVICE						("ULTRASCALE"		), 	// Set the device version for simulation functionality (ULTRASCALE)
		.SRVAL							(1'b0				))	// Initializes the ODDRE1 Flip-Flops to the specified value (1'b0, 1'b1)
	ODDRE1_FCLK (
		.Q								(link_fclk_txdo		),	// 1-bit output: Data output to IOB
		.D1								(1'B0				),	// 1-bit input: Parallel data input 1
		.D2								(1'B1				),	// 1-bit input: Parallel data input 2
		.C								(link_fclk			),	// 1-bit input: High-speed clock input
		.SR								(1'B0				)); // 1-bit input: Active-High Async Reset

	OBUFDS							LVDS_FCLK_OUTP	(
		.I								(link_fclk_txdo		),
		.O								(link_fclk_outp		),
		.OB								(link_fclk_outn		));
/***link_fram_txdo*******************************************************************************************************************/
  	ODDRE1 #(
		.IS_C_INVERTED					(1'b0				),	// Optional inversion for C
		.IS_D1_INVERTED					(1'b0				),  // Unsupported, do not use
		.IS_D2_INVERTED					(1'b0				),  // Unsupported, do not use
		.SIM_DEVICE						("ULTRASCALE"		), 	// Set the device version for simulation functionality (ULTRASCALE)
		.SRVAL							(1'b0				))	// Initializes the ODDRE1 Flip-Flops to the specified value (1'b0, 1'b1)
	ODDRE1_FRAM (	
		.Q								(link_fram_txdo		),// 1-bit output: Data output to IOB
		.D1								(link_fram_d0		),// 1-bit input: Parallel data input 1
		.D2								(link_fram_d1		),// 1-bit input: Parallel data input 2
		.C								(link_fclk			),// 1-bit input: High-speed clock input
		.SR								(1'B0				));  // 1-bit input: Active-High Async Reset

	OBUFDS							LVDS_FRAM_OUTP	(
		.I								(link_fram_txdo		),
		.O								(link_fram_outp		),
		.OB								(link_fram_outn		));
/***link_dat0_txdo*******************************************************************************************************************/
  	ODDRE1 #(					
		.IS_C_INVERTED					(1'b0				),	// Optional inversion for C
		.IS_D1_INVERTED					(1'b0				),  // Unsupported, do not use
		.IS_D2_INVERTED					(1'b0				),  // Unsupported, do not use
		.SIM_DEVICE						("ULTRASCALE"		), 	// Set the device version for simulation functionality (ULTRASCALE)
		.SRVAL							(1'b0				))	// Initializes the ODDRE1 Flip-Flops to the specified value (1'b0, 1'b1)
	ODDRE1_DAT0 (	
		.Q								(link_dat0_txdo		),// 1-bit output: Data output to IOB
		.D1								(link_dat0_d0		),// 1-bit input: Parallel data input 1
		.D2								(link_dat0_d1		),// 1-bit input: Parallel data input 2
		.C								(link_fclk			),// 1-bit input: High-speed clock input
		.SR								(1'B0				));  // 1-bit input: Active-High Async Reset

	OBUFDS							LVDS_DAT0_OUTP	(
		.I								(link_dat0_txdo		),
		.O								(link_dat0_outp		),
		.OB								(link_dat0_outn		));
/***link_dat1_txdo*******************************************************************************************************************/
 	ODDRE1 #(
		.IS_C_INVERTED					(1'b0				),	// Optional inversion for C
		.IS_D1_INVERTED					(1'b0				),  // Unsupported, do not use
		.IS_D2_INVERTED					(1'b0				),  // Unsupported, do not use
		.SIM_DEVICE						("ULTRASCALE"		), 	// Set the device version for simulation functionality (ULTRASCALE)
		.SRVAL							(1'b0				))	// Initializes the ODDRE1 Flip-Flops to the specified value (1'b0, 1'b1)
	ODDRE1_DAT1 (	
		.Q								(link_dat1_txdo		),// 1-bit output: Data output to IOB
		.D1								(link_dat1_d0		),// 1-bit input: Parallel data input 1
		.D2								(link_dat1_d1		),// 1-bit input: Parallel data input 2
		.C								(link_fclk			),// 1-bit input: High-speed clock input
		.SR								(1'B0				));  // 1-bit input: Active-High Async Reset

	OBUFDS							LVDS_DAT1_OUTP	(
		.I								(link_dat1_txdo		),
		.O								(link_dat1_outp		),
		.OB								(link_dat1_outn		));
/***link_dat2_txdo*******************************************************************************************************************/
 	ODDRE1 #(					
		.IS_C_INVERTED					(1'b0				),	// Optional inversion for C
		.IS_D1_INVERTED					(1'b0				),  // Unsupported, do not use
		.IS_D2_INVERTED					(1'b0				),  // Unsupported, do not use
		.SIM_DEVICE						("ULTRASCALE"		), 	// Set the device version for simulation functionality (ULTRASCALE)
		.SRVAL							(1'b0				))	// Initializes the ODDRE1 Flip-Flops to the specified value (1'b0, 1'b1)
	ODDRE1_DAT2 (	
		.Q								(link_dat2_txdo		),// 1-bit output: Data output to IOB
		.D1								(link_dat2_d0		),// 1-bit input: Parallel data input 1
		.D2								(link_dat2_d1		),// 1-bit input: Parallel data input 2
		.C								(link_fclk			),// 1-bit input: High-speed clock input
		.SR								(1'B0				));  // 1-bit input: Active-High Async Reset

	OBUFDS							LVDS_DAT2_OUTP	(
		.I								(link_dat2_txdo		),
		.O								(link_dat2_outp		),
		.OB								(link_dat2_outn		));
/***link_dat3_txdo*******************************************************************************************************************/
 	ODDRE1 #(					
		.IS_C_INVERTED					(1'b0				),	// Optional inversion for C
		.IS_D1_INVERTED					(1'b0				),  // Unsupported, do not use
		.IS_D2_INVERTED					(1'b0				),  // Unsupported, do not use
		.SIM_DEVICE						("ULTRASCALE"		), 	// Set the device version for simulation functionality (ULTRASCALE)
		.SRVAL							(1'b0				))	// Initializes the ODDRE1 Flip-Flops to the specified value (1'b0, 1'b1)
	ODDRE1_DAT3 (
		.Q								(link_dat3_txdo		),// 1-bit output: Data output to IOB
		.D1								(link_dat3_d0		),// 1-bit input: Parallel data input 1
		.D2								(link_dat3_d1		),// 1-bit input: Parallel data input 2
		.C								(link_fclk			),// 1-bit input: High-speed clock input
		.SR								(1'B0				));  // 1-bit input: Active-High Async Reset

	OBUFDS							LVDS_DAT3_OUTP	(
		.I								(link_dat3_txdo		),
		.O								(link_dat3_outp		),
		.OB								(link_dat3_outn		));

endmodule

 