/*----------------------------------------------------------------------
AUTHOR	: EDWARD YANG
----------------------------------------------------------------------*/
module	tpgs_link_misc_ctrl(
	output							tpgs_link_port_idle	,	
	input							tpgs_link_resp_reqs	,
	input							tpgs_link_acks_reqs	,
	output							tpgs_link_acks_done	,	
	output							tpgs_link_resp_done	,
//-MISC SIGNAL
	output		[ 7: 0]				tpgs_link_fram_mbdo	,
	output		[ 7: 0]				tpgs_link_dat3_mbdo	,
	output		[ 7: 0]				tpgs_link_dat2_mbdo	,
	output		[ 7: 0]				tpgs_link_dat1_mbdo	,
	output		[ 7: 0]				tpgs_link_dat0_mbdo	,

	output		[ 3: 0]				tpgs_link_acks_indx	,
	input		[31: 0]				tpgs_link_acks_data	,
	output		[ 3: 0]				tpgs_link_resp_indx	,
//	input		[31: 0]				tpgs_link_resp_data	,

	input							tpgs_sclk			,
	input							tpgs_rstn			);	
/**********************************************************************/
//------CFIG
	wire		[ 7: 0]				tpgs_acks_fram_mbdo	;
	wire		[ 7: 0]				tpgs_acks_dat3_mbdo	;
	wire		[ 7: 0]				tpgs_acks_dat2_mbdo	;
	wire		[ 7: 0]				tpgs_acks_dat1_mbdo	;
	wire		[ 7: 0]				tpgs_acks_dat0_mbdo	;
//------RESP
	wire		[ 7: 0]				tpgs_resp_fram_mbdo	;
	wire		[ 7: 0]				tpgs_resp_dat3_mbdo	;
	wire		[ 7: 0]				tpgs_resp_dat2_mbdo	;
	wire		[ 7: 0]				tpgs_resp_dat0_mbdo	;
	wire		[ 7: 0]				tpgs_resp_dat1_mbdo	;
//------	
	wire							tpgs_link_acks_idle	;	
	wire							tpgs_link_resp_idle	;
	assign	tpgs_link_port_idle	=&{	tpgs_link_acks_idle	,	tpgs_link_resp_idle};	
/**********************************************************************/
//------COMBO FUNCTION MIX
	assign	tpgs_link_fram_mbdo	= 	tpgs_acks_fram_mbdo	|	tpgs_resp_fram_mbdo	;
	assign	tpgs_link_dat3_mbdo	= 	tpgs_acks_dat3_mbdo	|	tpgs_resp_dat3_mbdo	;
	assign	tpgs_link_dat2_mbdo	= 	tpgs_acks_dat2_mbdo	|	tpgs_resp_dat2_mbdo	;
	assign	tpgs_link_dat1_mbdo	= 	tpgs_acks_dat1_mbdo	|	tpgs_resp_dat1_mbdo	;
	assign	tpgs_link_dat0_mbdo	= 	tpgs_acks_dat0_mbdo	|	tpgs_resp_dat0_mbdo	;
/**********************************************************************/
	cube_link_acks_misc	#	
		(  .LINK_MODE	("TPGM")	)	
								u_tpgs_acks_misc_ctrl(
		.cube_link_acks_reqs		(tpgs_link_acks_reqs	),//input							
		.cube_link_acks_idle		(tpgs_link_acks_idle	),//output							
		.cube_link_acks_done		(tpgs_link_acks_done	),//output							
		.cube_acks_fram_mbdo		(tpgs_acks_fram_mbdo	),//output	reg				
		.cube_acks_dat3_mbdo		(tpgs_acks_dat3_mbdo	),//output	reg		[ 7: 0]	
		.cube_acks_dat2_mbdo		(tpgs_acks_dat2_mbdo	),//output	reg		[ 7: 0]	
		.cube_acks_dat1_mbdo		(tpgs_acks_dat1_mbdo	),//output	reg		[ 7: 0]	
		.cube_acks_dat0_mbdo		(tpgs_acks_dat0_mbdo	),//output	reg		[ 7: 0]	
		.cube_link_acks_indx		(tpgs_link_acks_indx	),//output	reg		[ 3: 0]
		.cube_link_acks_data		(tpgs_link_acks_data	),//input			[31: 0]
		.cube_sclk					(tpgs_sclk				),//input	
		.cube_rstn					(tpgs_rstn				));//input	
 
	cube_link_resp_misc	#	
		(	.LINK_MODE	("TPGM" )	)
								u_tpgs_resp_ctrl(
		.cube_link_resp_reqs		(tpgs_link_resp_reqs	),//input							
		.cube_link_resp_idle		(tpgs_link_resp_idle	),//output							
		.cube_link_resp_done		(tpgs_link_resp_done	),//output							
		.cube_resp_fram_mbdo		(tpgs_resp_fram_mbdo	),//output	reg						
		.cube_resp_dat3_mbdo		(tpgs_resp_dat3_mbdo	),//output	reg		[ 7: 0]			
		.cube_resp_dat2_mbdo		(tpgs_resp_dat2_mbdo	),//output	reg		[ 7: 0]			
		.cube_resp_dat1_mbdo		(tpgs_resp_dat1_mbdo	),//output	reg		[ 7: 0]			
		.cube_resp_dat0_mbdo		(tpgs_resp_dat0_mbdo	),//output	reg		[ 7: 0]			
		.cube_sclk					(tpgs_sclk				),//input	
		.cube_rstn					(tpgs_rstn				));//input	

	assign	tpgs_link_resp_indx	=	0	;


endmodule
 