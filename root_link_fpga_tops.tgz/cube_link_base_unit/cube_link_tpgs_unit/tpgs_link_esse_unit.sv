/*----------------------------------------------------------------------
AUTHOR	: EDWARD YANG
----------------------------------------------------------------------*/
module	tpgs_link_esse_unit(
//FABRIC CONTROL
	output							tpgs_link_port_idle	,	
	input							tpgs_link_port_init	,
//------TPGM TPGS PORT
	output		[ 7: 0]				tpgs_port_txdo_fram	,
	output		[ 7: 0]				tpgs_port_txdo_dat0	,
	output		[ 7: 0]				tpgs_port_txdo_dat1	,
	output		[ 7: 0]				tpgs_port_txdo_dat2	,
	output		[ 7: 0]				tpgs_port_txdo_dat3	,
//RXDI CONTROL
	input		[ 7: 0]				tpgs_port_rxdi_fram	,
	input		[ 7: 0]				tpgs_port_rxdi_dat0	,
	input		[ 7: 0]				tpgs_port_rxdi_dat1	,
	input		[ 7: 0]				tpgs_port_rxdi_dat2	,
	input		[ 7: 0]				tpgs_port_rxdi_dat3	,

	input							tpgs_txdo_acks_reqs	,
	input							tpgs_txdo_resp_reqs	,
	output							tpgs_txdo_acks_done	,	
	output							tpgs_txdo_resp_done	,
	
	output		[ 3: 0]				tpgs_txdo_acks_indx	,
	input		[31: 0]				tpgs_txdo_acks_data	,
	output		[ 3: 0]				tpgs_txdo_resp_indx	,
	input		[31: 0]				tpgs_txdo_resp_data	,

	output							tpgs_rxdi_cmnd_lead	,
	output							tpgs_rxdi_cmnd_wrcs	,
	output							tpgs_rxdi_cmnd_coda	,
	output		[31: 0]				tpgs_rxdi_data_word	,

	output							tpgs_rxdi_trim_mark	,
	output							tpgs_rxdi_icfg_mark	,
	output							tpgs_rxdi_ocfg_mark	,
	output							tpgs_rxdi_nnex_mark	,
	output							tpgs_rxdi_ivct_mark	,
	output							tpgs_rxdi_ovct_mark	,
	output							tpgs_rxdi_imtx_mark	,
	output							tpgs_rxdi_omtx_mark	,
	output							tpgs_rxdi_rivt_mark	,
	output							tpgs_rxdi_rovt_mark	,
	output							tpgs_rxdi_rimt_mark	,
	output							tpgs_rxdi_romt_mark	,
	output							tpgs_rxdi_risv_mark	,
	output							tpgs_rxdi_rosv_mark	,
	output							tpgs_rxdi_rism_mark	,
	output							tpgs_rxdi_rosm_mark	,
	output							tpgs_rxdi_aset_mark	,
	output							tpgs_rxdi_dnld_mark	,
	output							tpgs_rxdi_boot_mark	,
	output							tpgs_rxdi_auxi_mark	,
//------
	input		[24: 0]				llmb_devs_ddrs_base	,
	input		[19: 0]				llmb_meta_imag_rows	,
	input		[19: 0]				llmb_meta_imag_cols	,
	input		[19: 0]				llmb_edge_imag_rows	,
	input		[19: 0]				llmb_edge_imag_cols	,

//	input							tpgs_xdat_meta_mode	,//1:MTRX
	input							tpgs_idat_wdma_enab	,
	output							tpgs_idat_wdma_done	,
	input							tpgs_odat_rdma_enab	,
	output							tpgs_odat_rdma_done	,
//------SHORT CUT MISC CONTROL
	input							tpgs_link_scut_enab	,

	input		[ 7: 0]				tpem_scut_tpgs_fram	,
	input		[ 7: 0]				tpem_scut_tpgs_dat3	,
	input		[ 7: 0]				tpem_scut_tpgs_dat2	,
	input		[ 7: 0]				tpem_scut_tpgs_dat1	,
	input		[ 7: 0]				tpem_scut_tpgs_dat0	,

	output		[ 7: 0]				tpgs_scut_tpem_fram	,
	output		[ 7: 0]				tpgs_scut_tpem_dat3	,
	output		[ 7: 0]				tpgs_scut_tpem_dat2	,
	output		[ 7: 0]				tpgs_scut_tpem_dat1	,
	output		[ 7: 0]				tpgs_scut_tpem_dat0	,
//----DDRS INTERFACE
	output							ubus_tpgs_wdma_csen	,
	output		[ 24: 0]			ubus_tpgs_wdma_addr	,
	output		[255: 0]			ubus_tpgs_wdma_data	,
	input							ubus_tpgs_wdma_trdy	,
	input							ubus_tpgs_wdma_wrdy	,

	output	reg						ubus_tpgs_rdma_csen	,
	output	reg	[ 24: 0]			ubus_tpgs_rdma_addr	,
	input							ubus_tpgs_rdma_trdy	,
	input		[255: 0]			ubus_tpgs_rdma_data	,
	input							ubus_tpgs_rdma_drdy	,

	input							ubus_clki			,
	input							ubus_rstn			,	
	input							tpgs_sclk			,
	input							tpgs_rstn			);	
/**********************************************************************************************************/
	wire		[ 7: 0]				tpgs_clnk_fram_mbdo		;
	wire		[ 7: 0]				tpgs_clnk_dat3_mbdo		;
	wire		[ 7: 0]				tpgs_clnk_dat2_mbdo		;
	wire		[ 7: 0]				tpgs_clnk_dat1_mbdo		;
	wire		[ 7: 0]				tpgs_clnk_dat0_mbdo		;

	wire		[ 7: 0]				tpgs_dlnk_fram_mbdo		;
	wire		[ 7: 0]				tpgs_dlnk_dat3_mbdo		;
	wire		[ 7: 0]				tpgs_dlnk_dat2_mbdo		;
	wire		[ 7: 0]				tpgs_dlnk_dat1_mbdo		;
	wire		[ 7: 0]				tpgs_dlnk_dat0_mbdo		;

	wire		[ 7: 0]				tpgs_core_txdo_fram		;
	wire		[ 7: 0]				tpgs_core_txdo_dat3		;
	wire		[ 7: 0]				tpgs_core_txdo_dat2		;
	wire		[ 7: 0]				tpgs_core_txdo_dat1		;
	wire		[ 7: 0]				tpgs_core_txdo_dat0		;

	assign	tpgs_core_txdo_fram	=	tpgs_clnk_fram_mbdo	|	tpgs_dlnk_fram_mbdo	|	tpem_scut_tpgs_fram	;
	assign	tpgs_core_txdo_dat3	=	tpgs_clnk_dat3_mbdo	|	tpgs_dlnk_dat3_mbdo	|	tpem_scut_tpgs_dat3	;
	assign	tpgs_core_txdo_dat2	=	tpgs_clnk_dat2_mbdo	|	tpgs_dlnk_dat2_mbdo	|	tpem_scut_tpgs_dat2	;
	assign	tpgs_core_txdo_dat1	=	tpgs_clnk_dat1_mbdo	|	tpgs_dlnk_dat1_mbdo	|	tpem_scut_tpgs_dat1	;
	assign	tpgs_core_txdo_dat0	=	tpgs_clnk_dat0_mbdo	|	tpgs_dlnk_dat0_mbdo	|	tpem_scut_tpgs_dat0	;
/**********************************************************************************************************/
//TPGS LINK MISC
	tpgs_link_misc_ctrl			u_tpgs_link_misc_ctrl(
		.tpgs_link_port_idle		(tpgs_link_port_idle	),//output	

		.tpgs_link_acks_reqs		(tpgs_txdo_acks_reqs	),//input				
		.tpgs_link_resp_reqs		(tpgs_txdo_resp_reqs	),//input				
		.tpgs_link_acks_done		(tpgs_txdo_acks_done	),	//output				
		.tpgs_link_resp_done		(tpgs_txdo_resp_done	),//output				
		.tpgs_link_acks_indx		(tpgs_txdo_acks_indx	),//output		[ 3: 0]	
		.tpgs_link_acks_data		(tpgs_txdo_acks_data	),//input		[31: 0]	
		.tpgs_link_resp_indx		(tpgs_txdo_resp_indx	),//output		[ 3: 0]	
//		.tpgs_link_resp_data		(tpgs_txdo_resp_data	),//input		[31: 0]	

		.tpgs_link_fram_mbdo		(tpgs_clnk_fram_mbdo	),//output		[ 7: 0]	
		.tpgs_link_dat3_mbdo		(tpgs_clnk_dat3_mbdo	),//output		[ 7: 0]	
		.tpgs_link_dat2_mbdo		(tpgs_clnk_dat2_mbdo	),//output		[ 7: 0]	
		.tpgs_link_dat1_mbdo		(tpgs_clnk_dat1_mbdo	),//output		[ 7: 0]	
		.tpgs_link_dat0_mbdo		(tpgs_clnk_dat0_mbdo	),//output		[ 7: 0]	

		.tpgs_sclk					(tpgs_sclk				),//input				
		.tpgs_rstn					(tpgs_rstn				));	//input				
/**********************************************************************************************************/
//TPGS LINK PORT	
	tpgs_link_port_ctrl			u_tpgs_link_port_ctrl(
		.tpgs_core_txdo_fram		(tpgs_core_txdo_fram	),//input		[ 7: 0]
		.tpgs_core_txdo_dat0		(tpgs_core_txdo_dat0	),//input		[ 7: 0]
		.tpgs_core_txdo_dat1		(tpgs_core_txdo_dat1	),//input		[ 7: 0]
		.tpgs_core_txdo_dat2		(tpgs_core_txdo_dat2	),//input		[ 7: 0]
		.tpgs_core_txdo_dat3		(tpgs_core_txdo_dat3	),//input		[ 7: 0]

		.tpgs_port_txdo_fram		(tpgs_port_txdo_fram	),//output		[ 7: 0]
		.tpgs_port_txdo_dat0		(tpgs_port_txdo_dat0	),//output		[ 7: 0]
		.tpgs_port_txdo_dat1		(tpgs_port_txdo_dat1	),//output		[ 7: 0]
		.tpgs_port_txdo_dat2		(tpgs_port_txdo_dat2	),//output		[ 7: 0]
		.tpgs_port_txdo_dat3		(tpgs_port_txdo_dat3	),//output		[ 7: 0]
		
		.tpgs_link_port_init		(tpgs_link_port_init	),//	(tpgs_link_cmnd_init	),
		.tpgs_port_rxdi_fram		(tpgs_port_rxdi_fram	),//input	[ 7: 0]	
		.tpgs_port_rxdi_dat0		(tpgs_port_rxdi_dat0	),//input	[ 7: 0]	
		.tpgs_port_rxdi_dat1		(tpgs_port_rxdi_dat1	),//input	[ 7: 0]	
		.tpgs_port_rxdi_dat2		(tpgs_port_rxdi_dat2	),//input	[ 7: 0]	
		.tpgs_port_rxdi_dat3		(tpgs_port_rxdi_dat3	),//input	[ 7: 0]	
		
		.tpgs_rxdi_trim_mark		(tpgs_rxdi_trim_mark	),//	(tpgm_link_icfg_mark	),//output				
		.tpgs_rxdi_icfg_mark		(tpgs_rxdi_icfg_mark	),//	(tpgm_link_icfg_mark	),//output				
		.tpgs_rxdi_ocfg_mark		(tpgs_rxdi_ocfg_mark	),//	(tpgm_link_ocfg_mark	),//output				
		.tpgs_rxdi_nnex_mark		(tpgs_rxdi_nnex_mark	),//	(tpgm_link_nnex_mark	),//output				
		.tpgs_rxdi_ivct_mark		(tpgs_rxdi_ivct_mark	),//	(tpgm_link_ivct_mark	),//output				
		.tpgs_rxdi_ovct_mark		(tpgs_rxdi_ovct_mark	),//	(tpgm_link_ovct_mark	),//output				
		.tpgs_rxdi_imtx_mark		(tpgs_rxdi_imtx_mark	),//	(tpgm_link_imtx_mark	),//output				
		.tpgs_rxdi_omtx_mark		(tpgs_rxdi_omtx_mark	),//	(tpgm_link_omtx_mark	),//output				
		.tpgs_rxdi_rivt_mark		(tpgs_rxdi_rivt_mark	),//	(tpgm_link_rivt_mark	),//output				
		.tpgs_rxdi_rovt_mark		(tpgs_rxdi_rovt_mark	),//	(tpgm_link_rovt_mark	),//output				
		.tpgs_rxdi_rimt_mark		(tpgs_rxdi_rimt_mark	),//	(tpgm_link_rimt_mark	),//output				
		.tpgs_rxdi_romt_mark		(tpgs_rxdi_romt_mark	),//	(tpgm_link_romt_mark	),//output				
		.tpgs_rxdi_risv_mark		(tpgs_rxdi_risv_mark	),//	(tpgm_link_risv_mark	),//output				
		.tpgs_rxdi_rosv_mark		(tpgs_rxdi_rosv_mark	),//	(tpgm_link_rosv_mark	),//output				
		.tpgs_rxdi_rism_mark		(tpgs_rxdi_rism_mark	),//	(tpgm_link_rism_mark	),//output				
		.tpgs_rxdi_rosm_mark		(tpgs_rxdi_rosm_mark	),//	(tpgm_link_rosm_mark	),//output				
		.tpgs_rxdi_aset_mark		(tpgs_rxdi_aset_mark	),//	(tpgm_link_aset_mark	),//output				
		.tpgs_rxdi_dnld_mark		(tpgs_rxdi_dnld_mark	),//	(tpgm_link_dnld_mark	),//output				
		.tpgs_rxdi_boot_mark		(tpgs_rxdi_boot_mark	),//	(tpgm_link_boot_mark	),//output				
		.tpgs_rxdi_auxi_mark		(tpgs_rxdi_auxi_mark	),//	(tpgm_link_auxi_mark	),//output				
		
		.tpgs_rxdi_cmnd_lead		(tpgs_rxdi_cmnd_lead	),//	(tpgs_link_cmnd_lead	),//output				
		.tpgs_rxdi_cmnd_wrcs		(tpgs_rxdi_cmnd_wrcs	),//	(tpgs_link_cmnd_wrcs	),//output				
		.tpgs_rxdi_cmnd_coda		(tpgs_rxdi_cmnd_coda	),//	(tpgs_link_cmnd_coda	),//output				
		
		.tpgs_rxdi_data_lead		(tpgs_rxdi_data_lead	),//	(tpgs_link_idat_lead	),//output				
		.tpgs_rxdi_data_wrcs		(tpgs_rxdi_data_wrcs	),//	(tpgs_link_idat_wrcs	),//output				
		.tpgs_rxdi_data_word		(tpgs_rxdi_data_word	),//	(tpgs_link_idat_data	),//output	[31: 0]	

//		.tpgs_fclk					(tpgs_fclk				),//input				
		.tpgs_sclk					(tpgs_sclk				),//input				
		.tpgs_rstn					(tpgs_rstn				));	//input		
/**********************************************************************************************************/
//------TPGS IDAT WDMA CONTROL
//	dlnk_mono_wdma_ctrl			u_tpgs_dlnk_wdma_ctrl(
//		.dlnk_idat_wdma_enab		(tpgs_idat_wdma_enab	),//input	write enable
//		.dlnk_idat_wdma_done		(tpgs_idat_wdma_done	),//output				
//		.dlnk_idat_ddrs_base		(llmb_devs_ddrs_base	),//input	[24 : 0]
//		.dlnk_idat_rows_numb		(llmb_meta_imag_rows	),//input	[19 : 0]
//		.dlnk_idat_cols_numb		(llmb_meta_imag_cols[19:4]	),//input	[15 : 0]
//		.dlnk_mono_idat_lead		(tpgs_rxdi_data_lead	),//input				
//		.dlnk_mono_idat_wrcs		(tpgs_rxdi_data_wrcs	),//input				
//		.dlnk_mono_idat_data		(tpgs_rxdi_data_word	),//input	[ 31: 0]
//		.link_clki					(tpgs_sclk				),//input				
//		.link_rstn					(tpgs_rstn				),//input				
//
//		.ubus_dlnk_wdma_csen		(ubus_tpgs_wdma_csen	),//output				
//		.ubus_dlnk_wdma_addr		(ubus_tpgs_wdma_addr	),//output	[ 24: 0]
//		.ubus_dlnk_wdma_data		(ubus_tpgs_wdma_data	),//output	[255: 0]
//		.ubus_dlnk_wdma_trdy		(ubus_tpgs_wdma_trdy	),//input				
//		.ubus_dlnk_wdma_wrdy		(ubus_tpgs_wdma_wrdy	),//input				
//		.ubus_clki					(ubus_clki				),//input				
//		.ubus_rstn					(ubus_rstn				));//input	

	cube_hubs_wdma_ctrl				u_tpgs_dlnk_wdma_ctrl(
		.hubs_rxdi_wdma_enab			(tpgs_idat_wdma_enab	),//input						
		.hubs_rxdi_wdma_done			(tpgs_idat_wdma_done	),//output						
		.hubs_rxdi_ddrs_base			(llmb_devs_ddrs_base	),//input		[24 : 0]		
		.hubs_rxdi_rows_numb			(llmb_meta_imag_rows	),//input		[19 : 0]		
		.hubs_rxdi_cols_numb			(llmb_meta_imag_cols[19:4]	),//input		[15 : 0]		
		.hubs_rxdi_data_lead			(tpgs_rxdi_data_lead	),//input						
		.hubs_rxdi_data_wrcs			(tpgs_rxdi_data_wrcs	),//input						
		.hubs_rxdi_data_word			(tpgs_rxdi_data_word	),//input		[ 31: 0]		
		.link_clki						(tpgs_sclk				),//input						
		.link_rstn						(tpgs_rstn				),//input						

		.ubus_hubs_wdma_csen			(ubus_tpgs_wdma_csen	),//output						
		.ubus_hubs_wdma_addr			(ubus_tpgs_wdma_addr	),//output		[ 24: 0]		
		.ubus_hubs_wdma_data			(ubus_tpgs_wdma_data	),//output		[255: 0]		
		.ubus_hubs_wdma_trdy			(ubus_tpgs_wdma_trdy	),//input						
		.ubus_hubs_wdma_wrdy			(ubus_tpgs_wdma_wrdy	),//input						
		.ubus_clki						(ubus_clki				),//input						
		.ubus_rstn						(ubus_rstn				));//input						


/**********************************************************************************************************/
//------TPGS ODAT RDMA CONTROL
	dlnk_mono_rdma_ctrl			u_tpgs_dlnk_rdma_ctrl(
		.dlnk_odat_fram_mbdo		(tpgs_dlnk_fram_mbdo	),//output		[ 7: 0]	
		.dlnk_odat_dat3_mbdo		(tpgs_dlnk_dat3_mbdo	),//output		[ 7: 0]	
		.dlnk_odat_dat2_mbdo		(tpgs_dlnk_dat2_mbdo	),//output		[ 7: 0]	
		.dlnk_odat_dat1_mbdo		(tpgs_dlnk_dat1_mbdo	),//output		[ 7: 0]	
		.dlnk_odat_dat0_mbdo		(tpgs_dlnk_dat0_mbdo	),//output		[ 7: 0]	

		.dlnk_odat_ddrs_done		(tpgs_odat_rdma_done	),//output	
		.dlnk_odat_ddrs_enab		(tpgs_odat_rdma_enab	),//input	
		.dlnk_odat_ddrs_mode		(1'B0					),//input	
		
		.llmb_mast_ddrs_base		(llmb_devs_ddrs_base	),//input		[24: 0]		
		.llmb_meta_imag_rows		(llmb_meta_imag_rows	),//input		[19: 0]		
		.llmb_meta_imag_cols		(llmb_meta_imag_cols	),//input		[19: 0]		
		.llmb_edge_imag_rows		(llmb_edge_imag_rows	),//input		[19: 0]		
		.llmb_edge_imag_cols		(llmb_edge_imag_cols	),//input		[19: 0]		

		.link_clki					(tpgs_sclk				),//input				
		.link_rstn					(tpgs_rstn				),//input				

		.ubus_dlnk_rdma_csen		(ubus_tpgs_rdma_csen	),//output	reg			
		.ubus_dlnk_rdma_addr		(ubus_tpgs_rdma_addr	),//output	reg	[ 24: 0]
		.ubus_dlnk_rdma_trdy		(ubus_tpgs_rdma_trdy	),//input				
		.ubus_dlnk_rdma_data		(ubus_tpgs_rdma_data	),//input		[255: 0]
		.ubus_dlnk_rdma_drdy		(ubus_tpgs_rdma_drdy	),//input				
		.ubus_clki					(ubus_clki				),//input				
		.ubus_rstn					(ubus_rstn				));//input	

/**********************************************************************************************************/
//SHORTCUT BETWEEN TPGS AND TPEM
	reg		[31: 0]				tpgs_scut_cnts_patn	;

	scut_root_edge_ctrl 		u_scut_tpgs_tpem_ctrl(
		.cube_link_scut_enab		(tpgs_link_scut_enab	),//input				
		
		.root_rxdi_data_lead		(tpgs_rxdi_data_lead	),//input				
		.root_rxdi_data_wrcs		(tpgs_rxdi_data_wrcs	),//input				
		.root_rxdi_data_word		(tpgs_rxdi_data_word	),//input		[ 31: 0]
//		.root_rxdi_data_word		(tpgs_scut_cnts_patn	),//input		[ 31: 0]
	
		.root_scut_edge_fram		(tpgs_scut_tpem_fram	),//output	reg	[  7: 0]
		.root_scut_edge_dat3		(tpgs_scut_tpem_dat3	),//output		[  7: 0]
		.root_scut_edge_dat2		(tpgs_scut_tpem_dat2	),//output		[  7: 0]
		.root_scut_edge_dat1		(tpgs_scut_tpem_dat1	),//output		[  7: 0]
		.root_scut_edge_dat0		(tpgs_scut_tpem_dat0	),//output		[  7: 0]
	
		.cube_clki					(tpgs_sclk				),//input	
		.cube_rstn					(tpgs_rstn				));//input	

//
//
//	always@(posedge tpgs_sclk or negedge tpgs_rstn)	
//	if(~tpgs_rstn)					tpgs_scut_cnts_patn	<=	0	;
//	else if(~tpgs_link_scut_enab)	tpgs_scut_cnts_patn	<=	1	;
//	else if( tpgs_rxdi_data_wrcs)	tpgs_scut_cnts_patn	<=	1 + tpgs_scut_cnts_patn	;
//




endmodule

 