module	cube_link_trim_mfsm(
	output	[3:0]					cube_link_trim_mfsm	,
	output							cube_link_trim_idle	,
	output							cube_link_trim_done	,//add @ 20241028
	output							cube_link_trim_lead	,//add @ 20241028
	output							cube_link_trim_cmnd	,
	
	input							cube_link_trim_reqs	,//add @ 20241028
	input							cube_link_trim_coda	,

	input							link_clki			,
	input							link_rstn			);
//********************************************************************************************************//
//	reg		[ 3: 0]					cube_link_trim_mfsm	;

	parameter	CUBE_LINK_TRIM_IDLE	=	4'H0	;
	parameter	CUBE_LINK_TRIM_LEAD	=	4'H1	;
	parameter	CUBE_LINK_TRIM_CMND	=	4'H2	;
	parameter	CUBE_LINK_TRIM_DONE	=	4'H3	;
//********************************************************************************************************//
	assign		cube_link_trim_idle	=	cube_link_trim_mfsm	==	CUBE_LINK_TRIM_IDLE	;
	assign		cube_link_trim_lead	=	cube_link_trim_mfsm	==	CUBE_LINK_TRIM_LEAD	;
	assign		cube_link_trim_cmnd	=	cube_link_trim_mfsm	==	CUBE_LINK_TRIM_CMND	;
	assign		cube_link_trim_done	=	cube_link_trim_mfsm	==	CUBE_LINK_TRIM_DONE	;
/**********************************************************************************************************/
	always@(posedge link_clki or negedge link_rstn)	
	if(~link_rstn)					cube_link_trim_mfsm	<=	CUBE_LINK_TRIM_IDLE	;
	else begin
		case(cube_link_trim_mfsm)
			CUBE_LINK_TRIM_IDLE	:	cube_link_trim_mfsm	<=	cube_link_trim_reqs	?	CUBE_LINK_TRIM_LEAD	:	CUBE_LINK_TRIM_IDLE	;
			CUBE_LINK_TRIM_LEAD	:	cube_link_trim_mfsm	<=							CUBE_LINK_TRIM_CMND	;	
			CUBE_LINK_TRIM_CMND	:	cube_link_trim_mfsm	<=	cube_link_trim_coda	?	CUBE_LINK_TRIM_DONE	:	CUBE_LINK_TRIM_CMND	;
			CUBE_LINK_TRIM_DONE	:	cube_link_trim_mfsm	<=	cube_link_trim_reqs	?	CUBE_LINK_TRIM_DONE	:	CUBE_LINK_TRIM_IDLE	;
			default				:	cube_link_trim_mfsm	<=							CUBE_LINK_TRIM_IDLE	;	
		endcase		
	end
/**********************************************************************************************************/
endmodule
 