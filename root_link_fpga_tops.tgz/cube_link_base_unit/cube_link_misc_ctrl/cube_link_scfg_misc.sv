/*----------------------------------------------------------------------
Reference Document	:	UG380	
	Page 27	:	Serial Configuration Data Timing
	Page 76	:	Clear Configuration Memory
Reference Document	:	UG162
	Page 54	:	Tpl 				4ms
				Tprogram			500ns
				Tcco				12ns
----------------------------------------------------------------------*/
`include	"agile_card_vars.vh"
module	cube_link_scfg_misc(
	output							cube_scfg_misc_idle	,
	output							cube_scfg_aset_done	,
	output							cube_scfg_dnld_done	,
	output							cube_scfg_boot_done	,
	
	input							cube_scfg_aset_reqs	,
	input							cube_scfg_dnld_reqs	,
	input							cube_scfg_boot_reqs	,
	
	output	reg						cube_scfg_prog_sbdo	,
	output	reg						cube_scfg_data_sbdo	,
	output	reg						cube_scfg_cclk_sbdo	,
	input							cube_scfg_init_sbdi	,
	input							cube_scfg_done_sbdi	,		
	
	output		[ 3: 0]				cube_scfg_cmnd_indx	,
	input		[31: 0]				cube_scfg_cmnd_data	,

	input							link_clki			,
	input							link_rstn			);	
//MISC Parameter -------------------------------------------------------------------------------------------
	parameter	TPEM_CCLK_KEEP_TIME=	20'd100	;//18'H003FF	;
	parameter	TPEM_PROG_RISE_TIME=	20'd200	;//18'd150000	;//1.5ms base on 100Mhz	
	
	parameter	TPEM_INIT_RISE_TIME=	20'd150	;//18'd150000	;//1.5ms base on 100Mhz
	parameter	TPEM_SBIT_ISSU_TIME=	3'd7		;
	parameter	TPEM_CCLK_RISE_TIME=	3'd1		;
	parameter	TPEM_CCLK_FALL_TIME=	3'd5		;

`ifdef			FAST_SIMU	
	parameter	TPEM_PROG_ISSU_TIME= 	20'd400		;
`else
	parameter	TPEM_PROG_ISSU_TIME= 	20'd500000	;
`endif
/**********************************************************************************************************/
	reg			[ 3: 0]				cube_scfg_ctrl_mfsm	;

	parameter	TPEM_SCFG_BOOT_IDLE=	4'H0	;	
	
	parameter	TPEM_SCFG_ISSU_PROG=	4'H1	;	
	parameter	TPEM_SCFG_INIT_DONE=	4'H2	;		
	parameter	TPEM_SCFG_INIT_FAIL=	4'H3	;		
	
	parameter	TPEM_SCFG_LOAD_WORD=	4'H4	;		
	parameter	TPEM_SCFG_ISSU_SBIT=	4'H5	;		
	parameter	TPEM_SCFG_WORD_DONE=	4'H6	;		
	parameter	TPEM_SCFG_DNLD_DONE=	4'H7	;		
	
	parameter	TPEM_SCFG_ISSU_BOOT=	4'H8	;	
	parameter	TPEM_SCFG_BOOT_DONE=	4'H9	;		
	parameter	TPEM_SCFG_BOOT_FAIL=	4'HA	;		

	assign							cube_scfg_misc_idle	=	cube_scfg_ctrl_mfsm	==	TPEM_SCFG_BOOT_IDLE		;
	wire							tpes_hits_issu_prog	=	cube_scfg_ctrl_mfsm	==	TPEM_SCFG_ISSU_PROG		;
	wire							tpes_hits_load_word	=	cube_scfg_ctrl_mfsm	==	TPEM_SCFG_LOAD_WORD		;
	wire							tpes_hits_issu_sbit	=	cube_scfg_ctrl_mfsm	==	TPEM_SCFG_ISSU_SBIT		;
	wire							tpes_hits_word_done	=	cube_scfg_ctrl_mfsm	==	TPEM_SCFG_WORD_DONE		;
	wire							tpes_hits_issu_boot	=	cube_scfg_ctrl_mfsm	==	TPEM_SCFG_ISSU_BOOT		;

	wire							scfg_hits_init_done	=	cube_scfg_ctrl_mfsm	==	TPEM_SCFG_INIT_DONE	;
	wire							scfg_hits_boot_done	=	cube_scfg_ctrl_mfsm	==	TPEM_SCFG_BOOT_DONE	;

	wire							cube_scfg_init_fail	=	cube_scfg_ctrl_mfsm	==	TPEM_SCFG_INIT_FAIL	;
	wire							cube_scfg_boot_fail	=	cube_scfg_ctrl_mfsm	==	TPEM_SCFG_BOOT_FAIL	;

	assign							cube_scfg_aset_done	= 	scfg_hits_init_done	|	cube_scfg_init_fail	;
	assign							cube_scfg_boot_done	=	scfg_hits_boot_done	|	cube_scfg_boot_fail	;
	assign							cube_scfg_dnld_done	=	cube_scfg_ctrl_mfsm	==	TPEM_SCFG_DNLD_DONE	;
/**********************************************************************************************************/
	reg			[ 2: 0]				tpes_sbit_cclk_cnts	;
	reg			[ 4: 0]				tpes_word_sbit_cnts	;
	reg			[ 2: 0]				tpes_page_word_cnts	;
	reg			[31: 0]				cube_scfg_sbit_word	;

	assign							cube_scfg_data_sbdo	=	cube_scfg_sbit_word[31]	;
	assign							cube_scfg_cmnd_indx	= {	1'B0					,	
															tpes_page_word_cnts	   };		
//----------------------------------------------------------------------------------------------------------
	reg			[19: 0]				tpes_long_time_cnts	;

	wire							time_prog_actv_reqs= &{	tpes_long_time_cnts	==	20'H1				,	tpes_hits_issu_prog	};
	wire							time_prog_actv_bmax= &{	tpes_long_time_cnts	==	TPEM_PROG_RISE_TIME	,	tpes_hits_issu_prog	};	
	wire							time_prog_cnts_bmax= &{	tpes_long_time_cnts	==	TPEM_PROG_ISSU_TIME	,	tpes_hits_issu_prog	};	
	wire							time_boot_cnts_bmax= &{	tpes_long_time_cnts	==	TPEM_CCLK_KEEP_TIME	,	tpes_hits_issu_boot	};	

	wire							time_long_cnts_bmax= |{	time_prog_cnts_bmax,	time_boot_cnts_bmax	};	
	wire							time_long_cnts_actv= |{	tpes_hits_issu_prog,	tpes_hits_issu_boot	};	
		
	wire							tpes_cclk_rise_reqs=	tpes_sbit_cclk_cnts	==	TPEM_CCLK_RISE_TIME	;	
	wire							tpes_cclk_fall_reqs=	tpes_sbit_cclk_cnts	==	TPEM_CCLK_FALL_TIME	;	

	wire							scfg_sbit_cclk_bmax	=	tpes_sbit_cclk_cnts	==	TPEM_SBIT_ISSU_TIME	;
	wire							scfg_sbit_cclk_actv	=|{	tpes_hits_issu_sbit,	tpes_hits_issu_boot};	

	wire							scfg_word_sbit_bmax	= &{tpes_word_sbit_cnts	,	scfg_sbit_cclk_bmax};	
	wire							scfg_page_word_bmax	= & tpes_page_word_cnts	;

	wire	cube_prog_init_beok	= &{tpes_hits_issu_prog	,	time_prog_cnts_bmax	,	cube_scfg_init_sbdi};
	wire	cube_prog_init_fail	= &{tpes_hits_issu_prog	,	time_prog_cnts_bmax	,  ~cube_scfg_init_sbdi};
	
	wire	cube_boot_done_beok	= &{tpes_hits_issu_boot	,	time_boot_cnts_bmax	,	cube_scfg_init_sbdi	,	cube_scfg_done_sbdi	};	
	wire	cube_boot_done_fail	= &{tpes_hits_issu_boot	,	time_boot_cnts_bmax	, ~(cube_scfg_init_sbdi	&	cube_scfg_done_sbdi)};	
//MFSM CONTROL -------------------------------------------------------------------------------------------
	always@(posedge link_clki or negedge link_rstn)
	if(!link_rstn)					cube_scfg_prog_sbdo	<=	1	;
	else if( time_prog_actv_reqs)	cube_scfg_prog_sbdo	<=	0	;
	else if( time_prog_actv_bmax)	cube_scfg_prog_sbdo	<=	1	;
	
	always@(posedge link_clki or negedge link_rstn)		
	if(!link_rstn)					cube_scfg_cclk_sbdo	<=	0	;
	else if(~scfg_sbit_cclk_actv)	cube_scfg_cclk_sbdo	<=	0	;
	else if( tpes_cclk_fall_reqs)	cube_scfg_cclk_sbdo	<=	0	;
	else if( tpes_cclk_rise_reqs)	cube_scfg_cclk_sbdo	<=	1	;
	else							cube_scfg_cclk_sbdo	<=	cube_scfg_cclk_sbdo	;
//MFSM CONTROL -------------------------------------------------------------------------------------------
	always@(posedge link_clki or negedge link_rstn)
	if(!link_rstn)					tpes_long_time_cnts	<=	0	;
	else if( time_long_cnts_bmax)	tpes_long_time_cnts	<=	0	;
	else if( time_long_cnts_actv)	tpes_long_time_cnts	<=	tpes_long_time_cnts +1 	;
	else							tpes_long_time_cnts	<=	0	;

	always@(posedge link_clki or negedge link_rstn)
	if(!link_rstn)					tpes_sbit_cclk_cnts	<=	0	;
	else if( cube_scfg_misc_idle)	tpes_sbit_cclk_cnts	<=	0	;
	else if( scfg_sbit_cclk_bmax)	tpes_sbit_cclk_cnts	<=	0	;
	else if( scfg_sbit_cclk_actv)	tpes_sbit_cclk_cnts	<=	tpes_sbit_cclk_cnts +1 	;
	else							tpes_sbit_cclk_cnts	<=	0	;

	always@(posedge link_clki or negedge link_rstn)
	if(!link_rstn)					tpes_word_sbit_cnts	<=	0	;
	else if( scfg_word_sbit_bmax)	tpes_word_sbit_cnts	<=	0	;
	else if( tpes_hits_issu_sbit)	tpes_word_sbit_cnts	<=	tpes_word_sbit_cnts +	scfg_sbit_cclk_bmax 	;
	else							tpes_word_sbit_cnts	<=	0	;

	always@(posedge link_clki or negedge link_rstn)
	if(!link_rstn)					tpes_page_word_cnts	<=	0	;
 	else if( cube_scfg_misc_idle)	tpes_page_word_cnts	<=	0	;
	else if( tpes_hits_word_done)	tpes_page_word_cnts	<=	tpes_page_word_cnts +	1 	;
	else							tpes_page_word_cnts	<=	tpes_page_word_cnts	;

	wire							scfg_sbit_word_lsft	= &{tpes_hits_issu_sbit	,	
															scfg_sbit_cclk_bmax	,
														  ~	scfg_word_sbit_bmax};
	
	always@(posedge link_clki or negedge link_rstn)
	if(!link_rstn)					cube_scfg_sbit_word	<=	0	;
	else if(tpes_hits_load_word)	cube_scfg_sbit_word	<=	 {cube_scfg_cmnd_data[ 7:0],cube_scfg_cmnd_data[15:8],cube_scfg_cmnd_data[23:16],cube_scfg_cmnd_data[31:24]}	;
	else if(scfg_sbit_word_lsft)	cube_scfg_sbit_word	<={	cube_scfg_sbit_word[30:0],1'B0};
	else							cube_scfg_sbit_word	<=	cube_scfg_sbit_word	;
//MFSM CONTROL ---------------------------------------------------------------------------------------------
	always@(posedge link_clki or negedge link_rstn)
	if(!link_rstn)					cube_scfg_ctrl_mfsm	<=	TPEM_SCFG_BOOT_IDLE	;
	else begin
		case(cube_scfg_ctrl_mfsm)
			TPEM_SCFG_BOOT_IDLE	:	cube_scfg_ctrl_mfsm	<=	cube_scfg_aset_reqs	?	TPEM_SCFG_ISSU_PROG	:	
															cube_scfg_dnld_reqs	?	TPEM_SCFG_LOAD_WORD	:	
															cube_scfg_boot_reqs	?	TPEM_SCFG_ISSU_BOOT	:	TPEM_SCFG_BOOT_IDLE	;

			TPEM_SCFG_ISSU_PROG	:	cube_scfg_ctrl_mfsm	<=	cube_prog_init_fail	?	TPEM_SCFG_INIT_FAIL	:
															cube_prog_init_beok	?	TPEM_SCFG_INIT_DONE	:	TPEM_SCFG_ISSU_PROG	;

			TPEM_SCFG_LOAD_WORD	:	cube_scfg_ctrl_mfsm	<=							TPEM_SCFG_ISSU_SBIT	;
			TPEM_SCFG_ISSU_SBIT	:	cube_scfg_ctrl_mfsm	<=	scfg_word_sbit_bmax	?	TPEM_SCFG_WORD_DONE	:	TPEM_SCFG_ISSU_SBIT	;
 			TPEM_SCFG_WORD_DONE	:	cube_scfg_ctrl_mfsm	<=	scfg_page_word_bmax	?	TPEM_SCFG_DNLD_DONE	:	TPEM_SCFG_LOAD_WORD	;

			TPEM_SCFG_ISSU_BOOT	:	cube_scfg_ctrl_mfsm	<=	cube_boot_done_fail	?	TPEM_SCFG_BOOT_FAIL	:
															cube_boot_done_beok	?	TPEM_SCFG_BOOT_DONE	:	TPEM_SCFG_ISSU_BOOT	;
			
			TPEM_SCFG_INIT_DONE	:	cube_scfg_ctrl_mfsm	<=	cube_scfg_aset_reqs	?	TPEM_SCFG_INIT_DONE	:	TPEM_SCFG_BOOT_IDLE	;
			TPEM_SCFG_INIT_FAIL	:	cube_scfg_ctrl_mfsm	<=	cube_scfg_aset_reqs	?	TPEM_SCFG_INIT_FAIL	:	TPEM_SCFG_BOOT_IDLE	;
			TPEM_SCFG_DNLD_DONE	:	cube_scfg_ctrl_mfsm	<=	cube_scfg_dnld_reqs	?	TPEM_SCFG_DNLD_DONE	:	TPEM_SCFG_BOOT_IDLE	;
			TPEM_SCFG_BOOT_DONE	:	cube_scfg_ctrl_mfsm	<=	cube_scfg_boot_reqs	?	TPEM_SCFG_BOOT_DONE	:	TPEM_SCFG_BOOT_IDLE	;
			TPEM_SCFG_BOOT_FAIL	:	cube_scfg_ctrl_mfsm	<=	cube_scfg_boot_reqs	?	TPEM_SCFG_BOOT_FAIL	:	TPEM_SCFG_BOOT_IDLE	;
			default				:	cube_scfg_ctrl_mfsm	<=							TPEM_SCFG_BOOT_IDLE	;			
		endcase
	end		
/***********************************************************************************************************/


endmodule

