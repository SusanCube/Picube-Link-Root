
module	cube_link_resp_mfsm(
	output							cube_link_resp_idle	,
	output	reg						cube_link_resp_done	,
	output							cube_link_resp_lead	,
	output							cube_link_resp_post	,
	
	input							cube_link_resp_reqs	,
	input							cube_link_resp_coda	,
	
	input							cube_sclk			,
	input							cube_rstn			);
//********************************************************************************************************//
	reg		[ 1: 0]					cube_resp_mfsm	;
	
	parameter	CUBE_RESP_IDLE	=	2'H0	;
	parameter	CUBE_RESP_LEAD	=	2'H1	;
	parameter	CUBE_RESP_POST	=	2'H2	;
	parameter	CUBE_RESP_DONE	=	2'H3	;
//********************************************************************************************************//
	assign		cube_link_resp_idle	= cube_resp_mfsm ==	CUBE_RESP_IDLE	;
	assign		cube_link_resp_lead	= cube_resp_mfsm ==	CUBE_RESP_LEAD	;
	assign		cube_link_resp_post	= cube_resp_mfsm ==	CUBE_RESP_POST	;
	wire		cube_link_resp_deal	= cube_resp_mfsm ==	CUBE_RESP_DONE	;
//********************************************************************************************************//
	always@(posedge cube_sclk or negedge cube_rstn)	
	if(!cube_rstn)
		cube_resp_mfsm	<=	CUBE_RESP_IDLE	;
	else begin
		case(cube_resp_mfsm)
			CUBE_RESP_IDLE	://0
				cube_resp_mfsm	<=	cube_link_resp_reqs	?	CUBE_RESP_LEAD	:	CUBE_RESP_IDLE	;
			CUBE_RESP_LEAD	://1
				cube_resp_mfsm	<=							CUBE_RESP_POST						;	
			CUBE_RESP_POST	://2
				cube_resp_mfsm	<=	cube_link_resp_coda	?	CUBE_RESP_DONE	:	CUBE_RESP_POST	;
			CUBE_RESP_DONE	://3
				cube_resp_mfsm	<=	cube_link_resp_reqs	?	CUBE_RESP_DONE	:	CUBE_RESP_IDLE	;	
		endcase		
	end
//********************************************************************************************************//
	always@(posedge cube_sclk or negedge cube_rstn)	
	if(~cube_rstn)					cube_link_resp_done	<=	0	;	
	else							cube_link_resp_done	<=	cube_link_resp_deal	;	

endmodule

