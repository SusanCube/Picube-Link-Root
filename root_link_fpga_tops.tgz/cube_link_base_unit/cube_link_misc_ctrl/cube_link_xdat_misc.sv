/*----------------------------------------------------------------------------------------------------------
L	: 	DRIVE LOWS
Z	: 	DRIVE TRIS
P	: 	EXECUTE FUNCTION PROCESS 
W	: 	WAIT	FUNCTION PROCESS 
USDP:	UPSTREAM DATA PACK
DSDP:	DOWNSTREAM DATA PACK

			IDLE					MUTE				ACKS						RESP
TPLM_LVDS|LLLLLLLLLL|ISDE__CMND|ZZZZZZZZZZZZZZZZZZZZZ|ISDE__ACKS|ZZZZZZZZZZZZZZZZZ|ISDE_RESP|
TPLS_LVDS|ZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZ|ISDE__ACKS|LLLLLLLLLLLLLLLLLL|ISDE_RESP|
ISDE_TPLM|WWWWWWWWWWWWWWWWWWWWW|ISDE__ENAB|*************ISDE__USDP__RECV|
ISDE_TPLS|WWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWW|**ISDE__USDP__TRAN|

			IDLE					MUTE				ACKS						RESP
TPLM_LVDS|LLLLLLLLLL|ISDE__CMND|ZZZZZZZZZZZZZZZZZZZZZ|OSDE__ACKS|ZZZZZZZZZZZZZZZZZ|OSDE_RESP|
TPLS_LVDS|ZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZ|OSDE__ACKS|LLLLLLLLLLLLLLLLLLLLLLLLLLLL|ISDE_RESP|
OSDE_TPLM|WWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWW|OSDE__ENAB|OSDE__DSDP__TRAN|
OSDE_TPLS|WWWWWWWWWWWWWWWWWWWWW|OSDE__ENAB|*********************************OSDE__DSDP__TRAN|

----------------------------------------------------------------------------------------------------------*/
`include	"agile_card_vars.vh"
module	cube_link_xdat_misc #
	( parameter LINK_MODE	=	"TPGM" )	(
	output							cube_link_xdat_idle	,
	output							cube_link_ivct_done	,
	output							cube_link_ovct_done	,
	output							cube_link_imtx_done	,
	output							cube_link_omtx_done	,
	
	input							cube_link_xdat_scut	,
	input							cube_link_ivct_reqs	,
	input							cube_link_ovct_reqs	,
	input							cube_link_imtx_reqs	,
	input							cube_link_omtx_reqs	,
//-MISC SIGNAL
	output	reg		[ 7: 0]			cube_clnk_fram_mbdo	,
	output	reg		[ 7: 0]			cube_clnk_dat0_mbdo	,
	output	reg		[ 7: 0]			cube_clnk_dat1_mbdo	,
	output	reg		[ 7: 0]			cube_clnk_dat2_mbdo	,
	output	reg		[ 7: 0]			cube_clnk_dat3_mbdo	,
//-I/O SDES
	output							link_odat_rdma_enab	,
	output							link_odat_rdma_mode	,
	input							link_odat_rdma_done	,

	output							link_idat_wdma_enab	,
	output							link_idat_wdma_mode	,
	input							link_idat_wdma_done	,
//-	cmnd buffer
	output	reg		[ 3: 0]			cube_link_cmnd_indx	,
	input			[31: 0]			cube_link_cmnd_data	,
	input							cube_link_acks_coda	,
	input							cube_link_resp_coda	,
	
	input							link_clki			,
	input							link_rstn			);	
/*****************************************************************************************/
	wire							cube_ivct_cmnd_lead	;	
	wire							cube_imtx_cmnd_lead	;	
	wire							cube_ovct_cmnd_lead	;	
	wire							cube_omtx_cmnd_lead	;	

	wire							cube_idat_cmnd_post	;	
	wire							cube_odat_cmnd_post	;	

	wire							cube_link_cmnd_post	; 
	wire							cube_link_cmnd_lead	; 
	wire							cube_link_cmnd_coda	;

	assign	cube_link_cmnd_lead	= |{cube_ivct_cmnd_lead	,	cube_imtx_cmnd_lead	,
									cube_ovct_cmnd_lead	,	cube_omtx_cmnd_lead};
	assign	cube_link_cmnd_post	= |{cube_idat_cmnd_post	,	cube_odat_cmnd_post};

	if(LINK_MODE == "TPGM")
		assign	cube_link_cmnd_coda	= &{cube_link_cmnd_post	,	cube_link_cmnd_indx == `TPGM_LINK_CMND_LENG};
	else
		assign	cube_link_cmnd_coda	=&{	cube_link_cmnd_post	,	cube_link_cmnd_indx	== `TPEM_LINK_CMND_LENG};
//common signals -------------------------------------------------------------------------------------------
	reg								cube_link_cmnd_done	;

	always@(posedge link_clki or negedge link_rstn)
	if(!link_rstn) 					cube_link_cmnd_done	<=	0	;
	else							cube_link_cmnd_done	<=	cube_link_cmnd_coda	;

	always@(posedge link_clki or negedge link_rstn)
	if(!link_rstn)					cube_link_cmnd_indx	<=	0	;
	else if(cube_link_xdat_idle)	cube_link_cmnd_indx	<=	0	;
	else if(cube_link_cmnd_post)	cube_link_cmnd_indx	<=	cube_link_cmnd_indx + 1	;
	else							cube_link_cmnd_indx	<=	cube_link_cmnd_indx		;	
/*****************************************************************************************/
	wire		[31: 0]				cube_mixs_word_data	;
	wire		[ 7: 0]				word_dat3_lane_mbit	;
	wire		[ 7: 0]				word_dat2_lane_mbit	;
	wire		[ 7: 0]				word_dat1_lane_mbit	;
	wire		[ 7: 0]				word_dat0_lane_mbit	;

	wire		[31: 0]				cube_ivct_lead_code	=	`CUBE_LINK_IVCT_LEAD	;
	wire		[31: 0]				cube_ovct_lead_code	=	`CUBE_LINK_OVCT_LEAD	;
	wire		[31: 0]				cube_imtx_lead_code	=	`CUBE_LINK_IMTX_LEAD	;
	wire		[31: 0]				cube_omtx_lead_code	=	`CUBE_LINK_OMTX_LEAD	;
	
	assign	cube_mixs_word_data	=	cube_ivct_cmnd_lead	?	cube_ivct_lead_code	:
									cube_ovct_cmnd_lead	?	cube_ovct_lead_code	:	
									cube_imtx_cmnd_lead	?	cube_imtx_lead_code	:
									cube_omtx_cmnd_lead	?	cube_omtx_lead_code	:	
									cube_link_cmnd_post	?	cube_link_cmnd_data	:32'H0	;

	assign	word_dat3_lane_mbit	=	cube_mixs_word_data[31:24]	;
	assign	word_dat2_lane_mbit	=	cube_mixs_word_data[23:16]	;
	assign	word_dat1_lane_mbit	=	cube_mixs_word_data[15: 8]	;
	assign	word_dat0_lane_mbit	=	cube_mixs_word_data[ 7: 0]	;

  	always@(posedge link_clki or negedge link_rstn)
  	if(!link_rstn) 	begin	  		cube_clnk_dat3_mbdo	<=	0	;
  									cube_clnk_dat2_mbdo	<=	0	;
									cube_clnk_dat0_mbdo	<=	0	;
  									cube_clnk_dat1_mbdo	<=	0	;
	end 	else 	begin
									cube_clnk_dat3_mbdo	<=	word_dat3_lane_mbit	;
									cube_clnk_dat2_mbdo	<=	word_dat2_lane_mbit	;
									cube_clnk_dat0_mbdo	<=	word_dat0_lane_mbit	;
									cube_clnk_dat1_mbdo	<=	word_dat1_lane_mbit	;
	end

	always@(posedge link_clki or negedge link_rstn)
	if(!link_rstn) 					cube_clnk_fram_mbdo	<=	8'H00	;
	else if(cube_link_xdat_idle)	cube_clnk_fram_mbdo	<=	8'H00	;
	else if(cube_link_cmnd_lead)	cube_clnk_fram_mbdo	<=	8'HFF	;
	else if(cube_link_cmnd_done)	cube_clnk_fram_mbdo	<=	8'H00	;
	else 							cube_clnk_fram_mbdo	<=	cube_clnk_fram_mbdo	;
/*****************************************************************************************/
	cube_link_xdat_mfsm			u_cube_link_xdat_mfsm(
		.cube_link_xdat_idle		(cube_link_xdat_idle	),//output	
		.cube_link_ivct_done		(cube_link_ivct_done	),//output	
		.cube_link_ovct_done		(cube_link_ovct_done	),//output	
		.cube_link_imtx_done		(cube_link_imtx_done	),//output	
		.cube_link_omtx_done		(cube_link_omtx_done	),//output	

		.cube_ivct_cmnd_lead		(cube_ivct_cmnd_lead	),//output		
		.cube_imtx_cmnd_lead		(cube_imtx_cmnd_lead	),//output		
		.cube_ovct_cmnd_lead		(cube_ovct_cmnd_lead	),//output		
		.cube_omtx_cmnd_lead		(cube_omtx_cmnd_lead	),//output		
		.cube_idat_cmnd_post		(cube_idat_cmnd_post	),//output		
		.cube_odat_cmnd_post		(cube_odat_cmnd_post	),//output		

		.link_odat_rdma_enab		(link_odat_rdma_enab	),//output	reg	
		.link_odat_rdma_mode		(link_odat_rdma_mode	),//output	reg	
		.link_odat_rdma_done		(link_odat_rdma_done	),//output	reg	
		
		.link_idat_wdma_enab		(link_idat_wdma_enab	),//output	reg	
		.link_idat_wdma_mode		(link_idat_wdma_mode	),//output	reg	
		.link_idat_wdma_done		(link_idat_wdma_done	),//output	reg	
		
		.cube_link_xdat_scut		(cube_link_xdat_scut	),
		.cube_link_ivct_reqs		(cube_link_ivct_reqs	),//input	
		.cube_link_ovct_reqs		(cube_link_ovct_reqs	),//input	
		.cube_link_imtx_reqs		(cube_link_imtx_reqs	),//input	
		.cube_link_omtx_reqs		(cube_link_omtx_reqs	),//input	
		
		.cube_link_cmnd_coda		(cube_link_cmnd_coda	),//input	
		.cube_link_acks_coda		(cube_link_acks_coda	),//input	
		.cube_link_resp_coda		(cube_link_resp_coda	),//input	
		
		
		.link_clki					(link_clki				),//input	
		.link_rstn					(link_rstn				));//input	
endmodule
//		.cube_idat_data_post		(cube_idat_data_post	),//output		
//		.cube_odat_data_post		(cube_odat_data_post	),//output		
 