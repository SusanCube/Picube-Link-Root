/*----------------------------------------------------------------------------------------------------------
L	: 	DRIVE LOWS
Z	: 	DRIVE TRIS
P	: 	EXECUTE FUNCTION PROCESS 
W	: 	WAIT	FUNCTION PROCESS 
USDP:	UPSTREAM DATA PACK
DSDP:	DOWNSTREAM DATA PACK

			IDLE					MUTE				ACKS						RESP
TPLM_LVDS|LLLLLLLLLL|ISDE__CMND|ZZZZZZZZZZZZZZZZZZZZZ|ISDE__ACKS|ZZZZZZZZZZZZZZZZZ|ISDE_RESP|
TPLS_LVDS|ZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZ|ISDE__ACKS|LLLLLLLLLLLLLLLLLL|ISDE_RESP|
ISDE_TPLM|WWWWWWWWWWWWWWWWWWWWW|ISDE__ENAB|*************ISDE__USDP__RECV|
ISDE_TPLS|WWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWW|**ISDE__USDP__TRAN|

			IDLE					MUTE				ACKS						RESP
TPLM_LVDS|LLLLLLLLLL|ISDE__CMND|ZZZZZZZZZZZZZZZZZZZZZ|OSDE__ACKS|ZZZZZZZZZZZZZZZZZ|OSDE_RESP|
TPLS_LVDS|ZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZ|OSDE__ACKS|LLLLLLLLLLLLLLLLLLLLLLLLLLLL|ISDE_RESP|
OSDE_TPLM|WWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWW|OSDE__ENAB|OSDE__DSDP__TRAN|
OSDE_TPLS|WWWWWWWWWWWWWWWWWWWWW|OSDE__ENAB|*********************************OSDE__DSDP__TRAN|

----------------------------------------------------------------------------------------------------------*/
`include	"agile_card_vars.vh"
module	cube_link_sdes_misc(
	output							cube_link_sdes_idle	,
	input							cube_link_risv_reqs	,
	input							cube_link_rosv_reqs	,
	input							cube_link_rism_reqs	,
	input							cube_link_rosm_reqs	,
	output							cube_link_risv_done	,
	output							cube_link_rosv_done	,
	output							cube_link_rism_done	,
	output							cube_link_rosm_done	,
//-MISC SIGNAL
	output	reg		[ 7: 0]			cube_clnk_fram_mbdo	,
	output	reg		[ 7: 0]			cube_clnk_dat3_mbdo	,
	output	reg		[ 7: 0]			cube_clnk_dat2_mbdo	,
	output	reg		[ 7: 0]			cube_clnk_dat1_mbdo	,
	output	reg		[ 7: 0]			cube_clnk_dat0_mbdo	,
		
	input							cube_link_acks_coda	,
	input							cube_link_resp_coda	,
//-I/O SDES
//	output							link_mast_rdma_enab	,
//	output							link_slav_wdma_enab	,
	//-	cmnd buffer
	output	reg		[ 3: 0]			cube_link_cmnd_indx	,
	input			[31: 0]			cube_link_cmnd_data	,
	output	reg		[ 3: 0]			cube_link_acmd_indx	,
	input			[31: 0]			cube_link_acmd_data	,
	
	input							link_clki			,
	input							link_rstn			);	
/**********************************************************************************************************/
	wire							cube_link_risv_lead	;
	wire							cube_link_rosv_lead	;
	wire							cube_link_rism_lead	;
	wire							cube_link_rosm_lead	;
//	wire							cube_link_xsde_lead	;
	wire							cube_link_acmd_lead	;

	wire							cube_link_cmnd_post	;
	wire							cube_link_acmd_post	;
	wire							cube_link_cmnd_coda	;
	wire							cube_link_acmd_coda	; 

	assign	cube_link_cmnd_coda	=	cube_link_cmnd_indx == `TPGM_LINK_CMND_LENG	;
	assign	cube_link_acmd_coda	=	cube_link_acmd_indx == `TPGM_LINK_ACMD_LENG	;

	always@(posedge link_clki or negedge link_rstn)
	if(!link_rstn)					cube_link_cmnd_indx	<=	0	;
	else if(cube_link_sdes_idle)	cube_link_cmnd_indx	<=	0	;
	else if(cube_link_cmnd_post)	cube_link_cmnd_indx	<=	cube_link_cmnd_indx + 1	;
	else							cube_link_cmnd_indx	<=	cube_link_cmnd_indx		;	

	always@(posedge link_clki or negedge link_rstn)
	if(!link_rstn)					cube_link_acmd_indx	<=	0	;
	else if(cube_link_sdes_idle)	cube_link_acmd_indx	<=	0	;
	else if(cube_link_acmd_post)	cube_link_acmd_indx	<=	cube_link_acmd_indx + 1	;
	else							cube_link_acmd_indx	<=	cube_link_acmd_indx		;	
//MISC Control -------------------------------------------------------------------------------------------
	wire		[31: 0]				cube_risv_lead_code	=  `CUBE_LINK_RISV_LEAD	;
	wire		[31: 0]				cube_rosv_lead_code	=  `CUBE_LINK_ROSV_LEAD	;
	wire		[31: 0]				cube_rism_lead_code	=  `CUBE_LINK_RISM_LEAD	;
	wire		[31: 0]				cube_rosm_lead_code	=  `CUBE_LINK_ROSM_LEAD	;
	wire		[31: 0]				cube_acmd_lead_code	=  `CUBE_LINK_ACMD_LEAD	;
	wire		[31: 0]				cube_link_mixs_word	;

	wire		[ 7: 0]				word_dat3_lane_mbit	;
	wire		[ 7: 0]				word_dat2_lane_mbit	;
	wire		[ 7: 0]				word_dat1_lane_mbit	;
	wire		[ 7: 0]				word_dat0_lane_mbit	;

	assign	cube_link_mixs_word	=	cube_link_risv_lead	?	cube_risv_lead_code	:
									cube_link_rosv_lead	?	cube_rosv_lead_code	:	
									cube_link_rism_lead	?	cube_rism_lead_code	:
									cube_link_rosm_lead	?	cube_rosm_lead_code	:	
									cube_link_acmd_lead	?	cube_acmd_lead_code	:	
									cube_link_cmnd_post	?	cube_link_cmnd_data	:	
									cube_link_acmd_post	?	cube_link_acmd_data	:	32'H0	;

	assign	word_dat3_lane_mbit	=	cube_link_mixs_word[31:24]	;
	assign	word_dat2_lane_mbit	=	cube_link_mixs_word[23:16]	;
	assign	word_dat1_lane_mbit	=	cube_link_mixs_word[15: 8]	;
	assign	word_dat0_lane_mbit	=	cube_link_mixs_word[ 7: 0]	;
//----------------------------------
  	always@(posedge link_clki or negedge link_rstn)
  	if(!link_rstn) 	begin	  		
		  							cube_clnk_dat3_mbdo	<=	0	;
  									cube_clnk_dat2_mbdo	<=	0	;
  									cube_clnk_dat1_mbdo	<=	0	;
  									cube_clnk_dat0_mbdo	<=	0	;
	end else begin			
									cube_clnk_dat3_mbdo	<=	word_dat3_lane_mbit	;
									cube_clnk_dat2_mbdo	<=	word_dat2_lane_mbit	;
  									cube_clnk_dat1_mbdo	<=	word_dat1_lane_mbit	;
									cube_clnk_dat0_mbdo	<=	word_dat0_lane_mbit	;
	end
//----------------------------------
	reg								cube_link_cmnd_done	;
	reg								cube_link_acmd_done	;
	
	wire							cube_link_xcmd_lead	;
	wire							cube_link_xcmd_coda	;

	assign	cube_link_xcmd_lead	= |{cube_link_risv_lead	,	
									cube_link_rosv_lead	,	
									cube_link_rism_lead	,	
									cube_link_rosm_lead	,	
									cube_link_acmd_lead};

	assign	cube_link_xcmd_done	= |{cube_link_cmnd_done	,	cube_link_acmd_done};

	always@(posedge link_clki or negedge link_rstn)
	if(!link_rstn) 					cube_link_cmnd_done	<=	0	;
	else if(cube_link_sdes_idle)	cube_link_cmnd_done	<=	0	;
	else 							cube_link_cmnd_done	<=	cube_link_cmnd_coda	;

	always@(posedge link_clki or negedge link_rstn)
	if(!link_rstn) 					cube_link_acmd_done	<=	0	;
	else if(cube_link_sdes_idle)	cube_link_acmd_done	<=	0	;
	else 							cube_link_acmd_done	<=	cube_link_acmd_coda	;

	always@(posedge link_clki or negedge link_rstn)
	if(!link_rstn) 					cube_clnk_fram_mbdo	<=	8'H00	;
	else if(cube_link_sdes_idle)	cube_clnk_fram_mbdo	<=	8'H00	;
	else if(cube_link_xcmd_lead)	cube_clnk_fram_mbdo	<=	8'HFF	;
	else if(cube_link_xcmd_done)	cube_clnk_fram_mbdo	<=	8'H00	;
	else 							cube_clnk_fram_mbdo	<=	cube_clnk_fram_mbdo	;
//----------------------------------------------------------------------	
	cube_link_sdes_mfsm			u_cube_link_sdes_mfsm(
		.cube_link_sdes_idle		(cube_link_sdes_idle	),//output	
		.cube_link_risv_done		(cube_link_risv_done	),//input	
		.cube_link_rosv_done		(cube_link_rosv_done	),//input	
		.cube_link_rism_done		(cube_link_rism_done	),//input	
		.cube_link_rosm_done		(cube_link_rosm_done	),//input	
//		.cube_link_xsde_done		(cube_link_xsde_done	),//input	
		
		.cube_link_risv_reqs		(cube_link_risv_reqs	),//input	
		.cube_link_rosv_reqs		(cube_link_rosv_reqs	),//input	
		.cube_link_rism_reqs		(cube_link_rism_reqs	),//input	
		.cube_link_rosm_reqs		(cube_link_rosm_reqs	),//input	
//		.cube_link_xsde_reqs		(cube_link_xsde_reqs	),//input	
		
		.cube_link_cmnd_coda		(cube_link_cmnd_coda	),//input	
		.cube_link_acmd_coda		(cube_link_acmd_coda	),//input	
		.cube_link_acks_coda		(cube_link_acks_coda	),//input	
		.cube_link_resp_coda		(cube_link_resp_coda	),//input	
	
		.cube_link_risv_lead		(cube_link_risv_lead	),//output	
		.cube_link_rosv_lead		(cube_link_rosv_lead	),//output	
		.cube_link_rism_lead		(cube_link_rism_lead	),//output	
		.cube_link_rosm_lead		(cube_link_rosm_lead	),//output	
		.cube_link_acmd_lead		(cube_link_acmd_lead	),//output	
//		.cube_link_xsde_lead		(cube_link_xsde_lead	),//output	
		
		.cube_link_cmnd_post		(cube_link_cmnd_post	),//output	
		.cube_link_acmd_post		(cube_link_acmd_post	),//output	
		
//		.cube_mast_rdma_enab		(cube_mast_rdma_enab	),
//		.cube_slav_wdma_enab		(cube_slav_wdma_enab	),

		.link_clki					(link_clki				),//input	
		.link_rstn					(link_rstn				));//input	

endmodule
