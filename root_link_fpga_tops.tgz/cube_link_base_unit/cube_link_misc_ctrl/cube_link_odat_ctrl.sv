/*
	ONE	PIXS	: 16 BITS	
	2	PIXS	: 32 BITS	->	ONE WORD 	
	8 	WORD 	:256 BITS	->	ONE PAGE
	N  	PAGE	:XXX BITS	->	ONE	ROW			
*/
`include	"agile_card_vars.vh"

module	cube_link_odat_ctrl(
	output	reg	[ 7: 0]				cube_link_fram_mbdo	,
	output	reg	[ 7: 0]				cube_link_dat3_mbdo	,
	output	reg	[ 7: 0]				cube_link_dat2_mbdo	,
	output	reg	[ 7: 0]				cube_link_dat1_mbdo	,
	output	reg	[ 7: 0]				cube_link_dat0_mbdo	,
//------------------------------------------------------
	input							ubus_rdma_ddrs_drdy	,
	input		[255:0 ]			ubus_rdma_ddrs_data	,
	output	reg						link_rdma_ubus_trdy	,
//------------------------------------------------------
	input							link_rdma_odat_enab	,	
	output							link_rdma_odat_done	,		
	input		[ 19: 0]			link_odat_rows_numb	,	
	input		[ 15: 0]			link_odat_rows_page	,	
		
	input							link_bclk			,
	input							link_rstn			);
/**********************************************************************************************************/
	reg			[ 2: 0]				link_rdma_odat_mfsm	;
	
	parameter	LINK_RDMA_ODAT_IDLE	=	3'H0	;
	parameter	LINK_RDMA_ODAT_WAIT	=	3'H1	;
	parameter	LINK_RDMA_ODAT_LEAD	=	3'H2	;
	parameter	LINK_RDMA_ODAT_PACK	=	3'H3	;
	parameter	LINK_RDMA_ODAT_MUTE	=	3'H4	;
	parameter	LINK_RDMA_ODAT_DONE	=	3'H5	;
	
	wire	link_odat_hits_idle	=	link_rdma_odat_mfsm	==	LINK_RDMA_ODAT_IDLE	;	
	wire	link_odat_hits_wait	=	link_rdma_odat_mfsm	==	LINK_RDMA_ODAT_WAIT	;	
	wire	link_odat_hits_lead	=	link_rdma_odat_mfsm	==	LINK_RDMA_ODAT_LEAD	;	
	wire	link_odat_hits_pack	=	link_rdma_odat_mfsm	==	LINK_RDMA_ODAT_PACK	;
	wire	link_odat_hits_mute	=	link_rdma_odat_mfsm	==	LINK_RDMA_ODAT_MUTE	;
	assign	link_rdma_odat_done	=	link_rdma_odat_mfsm	==	LINK_RDMA_ODAT_DONE	;
	
	wire	last_word_each_page		;
	wire	last_page_each_pack		;
	wire	last_pack_each_meta		;

	always@(posedge link_bclk or negedge link_rstn)
	if(!link_rstn)					link_rdma_odat_mfsm	<=	LINK_RDMA_ODAT_IDLE	;
	else begin
		case(link_rdma_odat_mfsm) 
			LINK_RDMA_ODAT_IDLE	:	link_rdma_odat_mfsm	<=	link_rdma_odat_enab	? 	LINK_RDMA_ODAT_WAIT	:	LINK_RDMA_ODAT_IDLE	;
			LINK_RDMA_ODAT_WAIT	:	link_rdma_odat_mfsm	<=	ubus_rdma_ddrs_drdy	? 	LINK_RDMA_ODAT_LEAD	:	LINK_RDMA_ODAT_WAIT	;
			LINK_RDMA_ODAT_LEAD	:	link_rdma_odat_mfsm	<=							LINK_RDMA_ODAT_PACK	;
			LINK_RDMA_ODAT_PACK	:	link_rdma_odat_mfsm	<=	last_page_each_pack	?	LINK_RDMA_ODAT_MUTE	:	LINK_RDMA_ODAT_PACK	;
			LINK_RDMA_ODAT_MUTE	:	link_rdma_odat_mfsm	<=	last_pack_each_meta	?	LINK_RDMA_ODAT_DONE	:	LINK_RDMA_ODAT_WAIT	;
			LINK_RDMA_ODAT_DONE	:	link_rdma_odat_mfsm	<=	link_rdma_odat_enab	? 	LINK_RDMA_ODAT_DONE	:	LINK_RDMA_ODAT_IDLE	;
		endcase
	end	
/**********************************************************************************************************/
	reg		[31: 0]					link_odat_pack_numb	;
	reg		[ 2: 0]					odat_page_word_cnts	;
	reg		[ 2: 0]					odat_pack_page_cnts	;
	reg		[31: 0]					odat_meta_pack_cnts	;


	always@(posedge link_bclk or negedge link_rstn)
	if(!link_rstn)					link_odat_pack_numb	<=	0	;
	else if(link_odat_hits_idle)	link_odat_pack_numb	<=	link_odat_rows_numb	*	link_odat_rows_page[15:3]	;
	else							link_odat_pack_numb	<=	link_odat_pack_numb	;

	always@(posedge link_bclk or negedge  link_rstn)
	if(!link_rstn)					odat_page_word_cnts	<=	0	;
	else if(~link_odat_hits_pack)	odat_page_word_cnts	<=	0	;
	else 							odat_page_word_cnts	<=	odat_page_word_cnts + 	1	;

	always@(posedge link_bclk or negedge  link_rstn)
	if(!link_rstn)					odat_pack_page_cnts	<=	0	;
	else if(~link_odat_hits_pack)	odat_pack_page_cnts	<=	0	;
	else 							odat_pack_page_cnts	<=	odat_pack_page_cnts + 	last_word_each_page	;

	always@(posedge link_bclk or negedge  link_rstn)
	if(!link_rstn)					odat_meta_pack_cnts	<=	0	;
	else if( link_odat_hits_idle)	odat_meta_pack_cnts	<=	0	;
	else 							odat_meta_pack_cnts	<=	odat_pack_page_cnts + 	link_odat_hits_mute	;

	assign	last_word_each_page	= &{odat_page_word_cnts	==	3'H7	};
	assign	last_page_each_pack	= &{odat_pack_page_cnts	==	3'H7				,	last_word_each_page	};
	assign	last_pack_each_meta	= &{odat_meta_pack_cnts	==	link_odat_pack_numb	,	last_page_each_pack	};
/**********************************************************************************************************/
	reg		[255:0]					link_rdma_odat_buff	;
	wire	[ 31:0]					link_rdma_odat_word	=	link_rdma_odat_buff[255:224];
	wire	[ 31:0]					link_rdma_odat_lead	=	`CUBE_LINK_DATA_LEAD	;
	
	always@(posedge link_bclk or negedge  link_rstn)
	if(!link_rstn)					link_rdma_odat_buff	<=	0	;
	else if(link_odat_hits_idle)	link_rdma_odat_buff	<=	ubus_rdma_ddrs_data	;
	else if(link_rdma_ubus_trdy)	link_rdma_odat_buff	<=	ubus_rdma_ddrs_data	;
	else if(link_odat_hits_pack)	link_rdma_odat_buff	<={	link_rdma_odat_buff[223:0], 32'H0	}	;
	else							link_rdma_odat_buff	<=	link_rdma_odat_buff	;

	always@(posedge link_bclk or negedge  link_rstn)
	if(!link_rstn) begin
		cube_link_dat3_mbdo	<=	0	;
		cube_link_dat2_mbdo	<=	0	;
		cube_link_dat1_mbdo	<=	0	;
		cube_link_dat0_mbdo	<=	0	;
	end else if(link_odat_hits_lead)begin
		cube_link_dat3_mbdo	<=	link_rdma_odat_lead[31:24]	;
		cube_link_dat2_mbdo	<=	link_rdma_odat_lead[23:16]	;
		cube_link_dat1_mbdo	<=	link_rdma_odat_lead[15: 8]	;
		cube_link_dat0_mbdo	<=	link_rdma_odat_lead[ 7: 0]	;
	end else begin
		cube_link_dat3_mbdo	<=	link_rdma_odat_word[31:24]	;
		cube_link_dat2_mbdo	<=	link_rdma_odat_word[23:16]	;
		cube_link_dat1_mbdo	<=	link_rdma_odat_word[15: 8]	;
		cube_link_dat0_mbdo	<=	link_rdma_odat_word[ 7: 0]	;
	end

	always@(posedge link_bclk or negedge  link_rstn)
	if(!link_rstn) 					link_rdma_ubus_trdy	<=	0	;
	else if(link_odat_hits_lead)	link_rdma_ubus_trdy	<=	1	;
	else if(link_odat_hits_pack)	link_rdma_ubus_trdy	<=&{last_word_each_page ,~last_page_each_pack	}	;
	else 							link_rdma_ubus_trdy	<=	0	;

	always@(posedge link_bclk or negedge  link_rstn)
	if(!link_rstn)					cube_link_fram_mbdo	<=	0		;
	else if(link_odat_hits_lead)	cube_link_fram_mbdo	<=	8'HFF	;
	else if(link_odat_hits_pack&last_page_each_pack)	cube_link_fram_mbdo	<= 	0		;


endmodule 
 
/*
	wire	[31:  0]				link_odat_word_data	;
	
	wire	[127: 0]				data_lvl0_selx_128b	;
	wire	[ 63: 0]				data_lvl1_selx_064b	;
	wire	[ 31: 0]				data_lvl2_selx_032b	;
	wire	[ 31: 0]				odat_intf_selx_word	;

	wire	[127: 0]				data_lvl0_high_128b	=	ubus_rdma_ddrs_data[255:128];
	wire	[127: 0]				data_lvl0_lowr_128b	=	ubus_rdma_ddrs_data[127:  0];
	wire	[ 63: 0]				data_lvl1_high_064b	=	data_lvl0_selx_128b[127: 64];
	wire	[ 63: 0]				data_lvl1_lowr_064b	=	data_lvl0_selx_128b[ 63:  0];
	wire	[ 31: 0]				data_lvl2_high_032b	=	data_lvl0_selx_128b[ 63: 32];
	wire	[ 31: 0]				data_lvl2_lowr_032b	=	data_lvl0_selx_128b[ 31:  0];
	
	assign	data_lvl0_selx_128b	=	odat_page_word_cnts[2]	?	data_lvl0_high_128b	:	data_lvl0_lowr_128b	;
	assign	data_lvl1_selx_064b	=	odat_page_word_cnts[1]	?	data_lvl1_high_064b	:	data_lvl1_lowr_064b	;
	assign	data_lvl2_selx_032b	=	odat_page_word_cnts[0]	?	data_lvl2_high_032b	:	data_lvl2_lowr_032b	;
	assign	odat_intf_selx_word	=	link_odat_hits_lead		?  `TPLC_ODAT_LEAD_CODE	:	data_lvl2_selx_032b	;

	always@(posedge link_bclk or negedge  link_rstn)
	if(!link_rstn)					
		link_odat_fram_sbdo	<=	0	;
	else if(link_odat_hits_lead|link_odat_hits_data)	
		link_odat_fram_sbdo	<=	1	;
	else							
		link_odat_fram_sbdo	<=	0	;

	always@(posedge link_bclk or negedge  link_rstn)
	if(!link_rstn) begin
		link_odat_dat3_mbdo	<=	0	;
		link_odat_dat2_mbdo	<=	0	;
		link_odat_dat1_mbdo	<=	0	;
		link_odat_dat0_mbdo	<=	0	;
	end else if(link_odat_hits_lead|link_odat_hits_data)begin
		link_odat_dat3_mbdo	<=	odat_intf_selx_word[31:24]	;
		link_odat_dat2_mbdo	<=	odat_intf_selx_word[23:16]	;
		link_odat_dat1_mbdo	<=	odat_intf_selx_word[15: 8]	;
		link_odat_dat0_mbdo	<=	odat_intf_selx_word[ 7: 0]	;
	end

*/

	

	
