/*----------------------------------------------------------------------

----------------------------------------------------------------------*/
`include	"agile_card_vars.vh"
module	cube_link_resp_misc	#
	( parameter LINK_MODE	=	"TPGM" )	(
	input							cube_link_resp_reqs	,//only used for CMND+RESP+ODAT+RESP
	output							cube_link_resp_idle	,
	output							cube_link_resp_done	,
//-MISC SIGNAL
	output	reg		[ 7: 0]			cube_resp_fram_mbdo	,
	output	reg		[ 7: 0]			cube_resp_dat3_mbdo	,
	output	reg		[ 7: 0]			cube_resp_dat2_mbdo	,
	output	reg		[ 7: 0]			cube_resp_dat1_mbdo	,
	output	reg		[ 7: 0]			cube_resp_dat0_mbdo	,
//-	cmnd buffer
//	output	reg		[ 3: 0]			cube_link_resp_indx	,
//	input			[31: 0]			cube_link_resp_data	,
	
	input							cube_sclk			,
	input							cube_rstn			);	
//MISC Parameter -------------------------------------------------------------------------------------------
	reg		[ 3: 0]					cube_link_resp_indx	;
	wire							cube_link_resp_lead	;
	wire							cube_link_resp_post	;
	wire							cube_link_resp_coda	;

	if(LINK_MODE == "TPGM")
		assign	cube_link_resp_coda	= &{cube_link_resp_post	,	cube_link_resp_indx == `TPGM_LINK_RESP_LENG};
	else
		assign	cube_link_resp_coda	=&{	cube_link_resp_post	,	cube_link_resp_indx	== `TPEM_LINK_RESP_LENG};
//MISC Control -------------------------------------------------------------------------------------------
	always@(posedge cube_sclk or negedge cube_rstn)
	if(!cube_rstn)					cube_link_resp_indx	<=	0	;
	else if(cube_link_resp_idle)	cube_link_resp_indx	<=	0	;
	else if(cube_link_resp_post)	cube_link_resp_indx	<=	cube_link_resp_indx + 1	;
	else							cube_link_resp_indx	<=	cube_link_resp_indx		;	
//----------------------------------
	wire	[31: 0]					cube_mixs_word_data	;
	wire	[ 7: 0]					word_dat3_lane_mbit	;
	wire	[ 7: 0]					word_dat2_lane_mbit	;
	wire	[ 7: 0]					word_dat1_lane_mbit	;
	wire	[ 7: 0]					word_dat0_lane_mbit	;
	
	wire	[31: 0]					cube_resp_lead_code	=	`CUBE_LINK_RESP_LEAD	;
	assign	cube_mixs_word_data	=	cube_link_resp_lead	?	cube_resp_lead_code	:	32'H0	;

	assign	word_dat3_lane_mbit	=	cube_mixs_word_data[31:24]	;
	assign	word_dat2_lane_mbit	=	cube_mixs_word_data[23:16]	;
	assign	word_dat1_lane_mbit	=	cube_mixs_word_data[15: 8]	;
	assign	word_dat0_lane_mbit	=	cube_mixs_word_data[ 7: 0]	;
//----------------------------------
  	always@(posedge cube_sclk or negedge cube_rstn)
  	if(!cube_rstn) begin
  		cube_resp_dat3_mbdo	<=	0	;
  		cube_resp_dat2_mbdo	<=	0	;
  		cube_resp_dat1_mbdo	<=	0	;
  		cube_resp_dat0_mbdo	<=	0	;
	end else begin
  		cube_resp_dat3_mbdo	<=	word_dat3_lane_mbit	;
		cube_resp_dat2_mbdo	<=	word_dat2_lane_mbit	;
  		cube_resp_dat1_mbdo	<=	word_dat1_lane_mbit	;
		cube_resp_dat0_mbdo	<=	word_dat0_lane_mbit	;
	end

	always@(posedge cube_sclk or negedge cube_rstn)
	if(!cube_rstn) 					cube_resp_fram_mbdo	<=	8'H00	;
	else if(cube_link_resp_lead)	cube_resp_fram_mbdo	<=	8'HFF	;
	else if(cube_link_resp_post)	cube_resp_fram_mbdo	<=	8'HFF	;
	else							cube_resp_fram_mbdo	<=	8'H00	;
//	else if(cube_link_resp_idle)	cube_resp_fram_mbdo	<=	8'H00	;
//	else if(cube_link_resp_done)	cube_resp_fram_mbdo	<=	8'H00	;
//	else 							cube_resp_fram_mbdo	<=	cube_resp_fram_mbdo	;
//----------------------------------------------------------------------	
	cube_link_resp_mfsm				u_cube_resp_mfsm(
		.cube_link_resp_idle		(cube_link_resp_idle	),//output
		.cube_link_resp_done		(cube_link_resp_done	),//output
		.cube_link_resp_lead		(cube_link_resp_lead	),//output
		.cube_link_resp_post		(cube_link_resp_post	),//output
		
		.cube_link_resp_reqs		(cube_link_resp_reqs	),//input
		.cube_link_resp_coda		(cube_link_resp_coda	),//input
		
		.cube_sclk					(cube_sclk				),//input
		.cube_rstn					(cube_rstn				));//input

endmodule

	