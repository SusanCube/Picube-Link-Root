/*----------------------------------------------------------------------

----------------------------------------------------------------------*/
`include	"agile_card_vars.vh"
module	cube_link_trim_misc #
	( parameter LINK_MODE	=	"TPGM" )	(
	output	reg		[ 7: 0]			cube_clnk_fram_mbdo	,
	output	reg		[ 7: 0]			cube_clnk_dat0_mbdo	,
	output	reg		[ 7: 0]			cube_clnk_dat1_mbdo	,
	output	reg		[ 7: 0]			cube_clnk_dat2_mbdo	,
	output	reg		[ 7: 0]			cube_clnk_dat3_mbdo	,

	output			[3:0 ]			cube_link_trim_mfsm	,
	output							cube_link_trim_idle	,
	output							cube_link_trim_coda	,
	output							cube_link_trim_done	,
	
	input							cube_link_trim_reqs	,
		
	output	reg		[ 3: 0]			cube_link_cmnd_indx	,
	input			[31: 0]			cube_link_cmnd_data	,
	
	input							link_clki			,
	input							link_rstn			);	
//MISC Parameter -------------------------------------------------------------------------------------------
	wire							cube_link_trim_lead	;
	wire							cube_link_trim_cmnd	; 

	reg								cube_trim_cmnd_done	;
	wire	[3: 0]					cube_trim_cmnd_leng	;	


	if(LINK_MODE == "TPGM")
		assign	cube_trim_cmnd_leng	= 	`TPGM_LINK_CMND_LENG	;
	else
		assign	cube_trim_cmnd_leng	= 	`TPEM_LINK_CMND_LENG	;
	
	
	assign	cube_link_trim_coda	=&{	cube_link_trim_cmnd	,	cube_link_cmnd_indx	== cube_trim_cmnd_leng	};
	
//MISC Control -------------------------------------------------------------------------------------------
	always@(posedge link_clki or negedge link_rstn)
	if(!link_rstn)					cube_link_cmnd_indx	<=	0	;
	else if(cube_link_trim_idle)	cube_link_cmnd_indx	<=	0	;
	else if(cube_link_trim_cmnd)	cube_link_cmnd_indx	<=	cube_link_cmnd_indx + 1	;
	else							cube_link_cmnd_indx	<=	cube_link_cmnd_indx		;	
//----------------------------------
	wire		[31: 0]				cube_link_trim_code	=	`CUBE_LINK_TRIM_LEAD	;
	
	wire		[ 7: 0]				word_dat3_lane_mbit	;
	wire		[ 7: 0]				word_dat2_lane_mbit	;
	wire		[ 7: 0]				word_dat1_lane_mbit	;
	wire		[ 7: 0]				word_dat0_lane_mbit	;
	wire		[31: 0]				cube_link_mixs_data	;

	assign	cube_link_mixs_data	=	cube_link_trim_lead	?	cube_link_trim_code		:
									cube_link_trim_cmnd	?	cube_link_cmnd_data		:	32'H0	;
	
	assign	word_dat3_lane_mbit	=	cube_link_mixs_data[31:24]	;
	assign	word_dat2_lane_mbit	=	cube_link_mixs_data[23:16]	;
	assign	word_dat1_lane_mbit	=	cube_link_mixs_data[15: 8]	;
	assign	word_dat0_lane_mbit	=	cube_link_mixs_data[ 7: 0]	;
//----------------------------------
  	always@(posedge link_clki or negedge link_rstn)
  	if(!link_rstn) 	begin	  		cube_clnk_dat3_mbdo	<=	0	;
  									cube_clnk_dat2_mbdo	<=	0	;
 									cube_clnk_dat1_mbdo	<=	0	;
  									cube_clnk_dat0_mbdo	<=	0	;
	end 	else 	begin
  									cube_clnk_dat3_mbdo	<=	word_dat3_lane_mbit	;
									cube_clnk_dat2_mbdo	<=	word_dat2_lane_mbit	;
									cube_clnk_dat1_mbdo	<=	word_dat1_lane_mbit	;
									cube_clnk_dat0_mbdo	<=	word_dat0_lane_mbit	;
	end

	always@(posedge link_clki or negedge link_rstn)
	if(!link_rstn) 					cube_clnk_fram_mbdo	<=	8'H00	;
	else if(cube_link_trim_idle)	cube_clnk_fram_mbdo	<=	8'H00	;
	else if(cube_link_trim_lead)	cube_clnk_fram_mbdo	<=	8'HFF	;
	else if(cube_trim_cmnd_done)	cube_clnk_fram_mbdo	<=	8'H00	;
	else 							cube_clnk_fram_mbdo	<=	cube_clnk_fram_mbdo	;
//----------------------------------
	always@(posedge link_clki or negedge link_rstn)
	if(!link_rstn) 					cube_trim_cmnd_done	<=	0	;
	else							cube_trim_cmnd_done	<=	cube_link_trim_coda	;
//----------------------------------------------------------------------	
	cube_link_trim_mfsm			u_cube_link_trim_mfsm(
		.cube_link_trim_mfsm		(cube_link_trim_mfsm	),//output
		.cube_link_trim_idle		(cube_link_trim_idle	),//output
		.cube_link_trim_done		(cube_link_trim_done	),//output
		.cube_link_trim_lead		(cube_link_trim_lead	),//output
		.cube_link_trim_cmnd		(cube_link_trim_cmnd	),//output

		.cube_link_trim_reqs		(cube_link_trim_reqs	),//input
		.cube_link_trim_coda		(cube_link_trim_coda	),//input

		.link_clki					(link_clki				),//input
		.link_rstn					(link_rstn				));//input

endmodule
				
	