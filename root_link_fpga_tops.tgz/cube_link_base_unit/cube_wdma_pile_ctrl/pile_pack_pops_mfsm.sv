//----------------------------------------------------------------------------------------------------------
module pile_pack_pops_mfsm(
	input							pile_pack_wdma_enab	,

	input							pile_pack_push_drdy	,
	output		[ 8: 0]				pile_pack_push_dptr	,

	input							pile_pack_pops_reqs	,
	input		[ 3: 0]				pile_pack_pops_size	,
	output		[ 8: 0]				pile_pack_pops_dptr	,
	output							pile_pack_pops_last	,

	output							ubus_wdma_ddrs_csen	,
	input							ubus_wdma_ddrs_trdy	,
	input							ubus_wdma_ddrs_wrdy	,
		 
	input							ubus_clki			,
	input							ubus_rstn			);
/***********************************************************************************************************/
	reg			[24: 0]				pile_pack_push_cnts	;

	assign	pile_pack_push_dptr	=	pile_pack_push_cnts[8:0];

	always@(posedge ubus_clki or negedge ubus_rstn)	
	if(~ubus_rstn)					pile_pack_push_cnts	<=	0	;
	else if(~pile_pack_wdma_enab)	pile_pack_push_cnts	<=	0	;
	else 							pile_pack_push_cnts	<=	pile_pack_push_cnts + pile_pack_push_drdy	;
//	else if( cube_pile_wdma_init)	pile_pack_push_cnts	<=	0	;
/***********************************************************************************************************/
	reg								pile_pack_pops_csen	;
	reg			[ 3: 0]				pile_pack_pops_leng	;
	reg			[ 3: 0]				pile_pack_pops_numb	;
	reg			[24: 0]				pile_pack_pops_cnts	;

	wire		[ 8: 0]				pile_pack_pops_lsba	;
	wire		[ 8: 0]				pile_pack_pops_nxta	;


	assign	pile_pack_pops_lsba	=	pile_pack_pops_cnts[8:0];
	assign	pile_pack_pops_nxta	=	pile_pack_pops_lsba + 1 ;
	assign	pile_pack_pops_dptr	=	ubus_wdma_ddrs_csen	?	pile_pack_pops_nxta	:	pile_pack_pops_lsba	;
	
	assign	ubus_wdma_ddrs_csen	= &{pile_pack_pops_csen	,	ubus_wdma_ddrs_trdy	,	ubus_wdma_ddrs_wrdy	};
	assign	pile_pack_pops_last	= &{ubus_wdma_ddrs_csen	,	pile_pack_pops_numb	==	pile_pack_pops_leng	};	
		
	always@(posedge ubus_clki or negedge ubus_rstn)	
	if(~ubus_rstn)					pile_pack_pops_csen	<=	0	;
	else if(~pile_pack_wdma_enab)	pile_pack_pops_csen	<=	0	;
	else if( pile_pack_pops_reqs)	pile_pack_pops_csen	<=	1	;
	else if( pile_pack_pops_last)	pile_pack_pops_csen	<=	0	;
	
	always@(posedge ubus_clki or negedge ubus_rstn)	
	if(~ubus_rstn)					pile_pack_pops_leng	<=	4'HF	;
	else if(~pile_pack_wdma_enab)	pile_pack_pops_leng	<=	4'HF	;
	else if( pile_pack_pops_reqs)	pile_pack_pops_leng	<=	pile_pack_pops_size	;

	always@(posedge ubus_clki or negedge ubus_rstn)	
	if(~ubus_rstn)					pile_pack_pops_numb	<=	4'H0	;
	else if(~pile_pack_wdma_enab)	pile_pack_pops_numb	<=	4'H0	;
	else if( pile_pack_pops_last)	pile_pack_pops_numb	<=	4'H0	;
	else if( ubus_wdma_ddrs_csen)	pile_pack_pops_numb	<=	pile_pack_pops_numb + 1	;

	always@(posedge ubus_clki or negedge ubus_rstn)	
	if(~ubus_rstn)					pile_pack_pops_cnts	<=	0	;
	else if(~pile_pack_wdma_enab)	pile_pack_pops_cnts	<=	0	;
	else if( ubus_wdma_ddrs_csen)	pile_pack_pops_cnts	<=	pile_pack_pops_cnts + 1	;


endmodule										


//	assign 	mono_pile_load_reqs[4]=&{mono_pile_load_reqx , mono_pile_load_port == 4'H4	};
//	assign 	mono_pile_load_reqs[5]=&{mono_pile_load_reqx , mono_pile_load_port == 4'H5	};
//	assign 	mono_pile_load_reqs[6]=&{mono_pile_load_reqx , mono_pile_load_port == 4'H6	};
//	assign 	mono_pile_load_reqs[7]=&{mono_pile_load_reqx , mono_pile_load_port == 4'H7	};
//	assign 	mono_pile_load_reqs[8]=&{mono_pile_load_reqx , mono_pile_load_port == 4'H8	};
//	assign 	mono_pile_load_reqs[9]=&{mono_pile_load_reqx , mono_pile_load_port == 4'H9	}; 