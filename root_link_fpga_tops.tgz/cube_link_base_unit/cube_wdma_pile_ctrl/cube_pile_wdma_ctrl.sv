//	input	[ 4: 0]					cube_idat_gnpu_numb	,
//	output	reg						cube_idat_wdma_done	,
//	input	[19: 0]					cube_idat_rows_numb	,
//	input	[15: 0]					cube_idat_rows_page	,

//	input	[ 1: 0]					cube_pile_port_enab	,
//	input	[19: 0]					cube_pile_rows_numb	,
//	input	[15: 0]					cube_pile_rows_page	,

module	cube_pile_wdma_ctrl(
	output							pile_pack_wdma_enab	,
//------------------------------------------------------
	input							cube_pile_wdma_enab	,
	input	[ 0: 3]					cube_pile_pack_ov16	,
	input	[ 0: 3]					cube_pile_pack_ov08	,
	input	[ 0: 3]					cube_pile_pack_ov04	,
	input	[ 0: 3]					cube_pile_pack_ov02	,
	
	input	[ 0: 3][ 24: 0]			cube_pile_pack_addr	,
	input	[ 0: 3][255: 0]			cube_pile_pack_data	,
	input	[ 0: 3]					cube_pile_pack_drdy	,

	output							cube_pile_push_init	,
	output							cube_pile_push_updt	,
	output		[ 0: 3]				cube_pile_push_reqs	,
	output	reg	[ 3: 0]				cube_pile_push_size	,

	input							link_clki			,
	input							link_rstn			,
	
	output							ubus_wdma_ddrs_csen	,
	output	[ 24: 0]				ubus_wdma_ddrs_addr	,
	output	[255: 0]				ubus_wdma_ddrs_data	,
	input							ubus_wdma_ddrs_trdy	,
	input							ubus_wdma_ddrs_wrdy	,
	
	input							ubus_clki			,
	input							ubus_rstn			);
/**********************************************************************/
	reg		[ 1: 0]					pile_wdma_enab_samp	;
//	wire							pile_pack_wdma_enab	;
	assign	pile_pack_wdma_enab	= 	pile_wdma_enab_samp[0] 	;
	
	always@(posedge ubus_clki or negedge ubus_rstn)
	if(!ubus_rstn)					pile_wdma_enab_samp	<=	0	;
	else							pile_wdma_enab_samp	<={	cube_pile_wdma_enab	,	pile_wdma_enab_samp[1]};			
/**********************************************************************/
	wire		[255: 0]			pile_pack_push_data	;
	wire		[ 24: 0]			pile_pack_push_addr	;
	wire							pile_pack_push_drdy	;

	wire		[  8: 0]			pile_pack_push_dptr	;
	wire		[  8: 0]			pile_pack_pops_dptr	;
	
	wire		[  3: 0]			pile_pack_pops_size	;
	wire		[  3: 0]			cube_pile_pops_size	;
//----------------------------------------------------------------------	
	pile_pack_mono_muxs 		u_tpgm_idat_wdma_mx02(
		.pile_pack_mono_addr		(cube_pile_pack_addr	),//input	[ 0: 3]	[ 24: 0]
		.pile_pack_mono_data		(cube_pile_pack_data	),//input	[ 0: 3]	[255: 0]
		.pile_pack_mono_drdy		(cube_pile_pack_drdy	),//input	[ 0: 3]			

		.pile_pack_push_addr		(pile_pack_push_addr	),//output	reg	[ 24: 0]	
		.pile_pack_push_data		(pile_pack_push_data	),//output	reg	[255: 0]	
		.pile_pack_push_drdy		(pile_pack_push_drdy	),//output	reg		
		.cube_clki					(ubus_clki				),//input				
		.cube_rstn					(ubus_rstn				));//input				
//----------------------------------------------------------------------
	pile_pack_push_mfsm			u_pile_pack_push_mfsm(
		.pile_pack_wdma_enab		(pile_pack_wdma_enab	),//input		
		.mono_pile_push_drdy		(pile_pack_push_drdy	),//input		

		.mono_pile_pack_ov16		(cube_pile_pack_ov16	),//input		[ 0: 3]	
		.mono_pile_pack_ov08		(cube_pile_pack_ov08	),//input		[ 0: 3]	
		.mono_pile_pack_ov04		(cube_pile_pack_ov04	),//input		[ 0: 3]	
		.mono_pile_pack_ov02		(cube_pile_pack_ov02	),//input		[ 0: 3]	
		
		.mono_pile_push_init		(cube_pile_push_init	),//output				
		.mono_pile_push_updt		(cube_pile_push_updt	),//output				
		.mono_pile_push_reqs		(cube_pile_push_reqs	),//output		[ 0: 1]	
		.mono_pile_push_size		(cube_pile_push_size	),//output	reg	[ 3: 0]	
		
		.mono_pile_pops_reqs		(pile_pack_pops_reqs	),//output	
		.mono_pile_pops_size		(pile_pack_pops_size	),//output	reg	[ 3: 0]	
		.mono_pile_pops_last		(pile_pack_pops_last	),//input		
		
		.ubus_clki					(ubus_clki				),//input				
		.ubus_rstn					(ubus_rstn				));//input				
//----------------------------------------------------------------------
	pile_pack_pops_mfsm			u_pile_pack_pops_mfsm(
		.pile_pack_wdma_enab		(pile_pack_wdma_enab	),//input	

		.pile_pack_push_drdy		(pile_pack_push_drdy	),//input				
		.pile_pack_push_dptr		(pile_pack_push_dptr	),//output		[ 8: 0]	

		.pile_pack_pops_reqs		(pile_pack_pops_reqs	),//input				
		.pile_pack_pops_size		(pile_pack_pops_size	),//input		[ 3: 0]	
		.pile_pack_pops_dptr		(pile_pack_pops_dptr	),//output		[ 8: 0]	
		.pile_pack_pops_last		(pile_pack_pops_last	),

		.ubus_wdma_ddrs_csen		(ubus_wdma_ddrs_csen	),//output				
		.ubus_wdma_ddrs_trdy		(ubus_wdma_ddrs_trdy	),//input				
		.ubus_wdma_ddrs_wrdy		(ubus_wdma_ddrs_wrdy	),//input				
		.ubus_clki					(ubus_clki				),//input				
		.ubus_rstn					(ubus_rstn				));//input				
//----------------------------------------------------------------------
	dual_port_bram	#(	
		.ADDR_BITS	( 9 ),	.DATA_BITS	( 256 ))	
	u_ubus_wdma_data_fifo (
		.wport_addr					(pile_pack_push_dptr	),//input		[ADDR_BITS-1:0]
		.wport_csen					(pile_pack_push_drdy	),//input  				 		
		.wport_data					(pile_pack_push_data	),//input		[DATA_BITS-1:0]
		.wport_clki					(ubus_clki				),//input						

		.rport_addr					(pile_pack_pops_dptr	),//input		[ADDR_BITS-1:0]
		.rport_data					(ubus_wdma_ddrs_data	),//output	reg	[DATA_BITS-1:0]
		.rport_clki					(ubus_clki				));//input						
//----------------------------------------------------------------------
	dual_port_bram	#(	
		.ADDR_BITS	( 9 ),	.DATA_BITS	( 25 ))	
	u_ubus_wdma_addr_fifo (
		.wport_addr					(pile_pack_push_dptr	),//input		[ADDR_BITS-1:0]
		.wport_csen					(pile_pack_push_drdy	),//input  				 		
		.wport_data					(pile_pack_push_addr	),//input		[DATA_BITS-1:0]
		.wport_clki					(ubus_clki				),//input						
		
		.rport_addr					(pile_pack_pops_dptr	),//input		[ADDR_BITS-1:0]
		.rport_data					(ubus_wdma_ddrs_addr	),//output	reg	[DATA_BITS-1:0]
		.rport_clki					(ubus_clki				));//input						


endmodule
 