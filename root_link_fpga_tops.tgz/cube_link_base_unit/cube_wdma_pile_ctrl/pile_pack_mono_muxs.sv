module	pile_pack_mono_muxs (
	input	[ 0: 3]	[255: 0]		pile_pack_mono_data	,
	input	[ 0: 3]	[ 24: 0]		pile_pack_mono_addr	,
	input	[ 0: 3]					pile_pack_mono_drdy	,				
	
	output	reg	[255: 0]			pile_pack_push_data	,
	output	reg	[ 24: 0]			pile_pack_push_addr	,
	output	reg						pile_pack_push_drdy	,				
	input							cube_clki			,
	input							cube_rstn			);
/**********************************************************************/
	always@(posedge cube_clki or negedge cube_rstn)
	if(!cube_rstn)					pile_pack_push_data	<=	0	;
	else if(pile_pack_mono_drdy[0])	pile_pack_push_data	<=	pile_pack_mono_data[0]	;
	else if(pile_pack_mono_drdy[1])	pile_pack_push_data	<=	pile_pack_mono_data[1]	;
	else if(pile_pack_mono_drdy[2])	pile_pack_push_data	<=	pile_pack_mono_data[2]	;
	else 							pile_pack_push_data	<=	pile_pack_mono_data[3]	;

	always@(posedge cube_clki or negedge cube_rstn)
	if(!cube_rstn)					pile_pack_push_addr	<=	0	;
	else if(pile_pack_mono_drdy[0])	pile_pack_push_addr	<=	pile_pack_mono_addr[0]	;
	else if(pile_pack_mono_drdy[1])	pile_pack_push_addr	<=	pile_pack_mono_addr[1]	;
	else if(pile_pack_mono_drdy[2])	pile_pack_push_addr	<=	pile_pack_mono_addr[2]	;
	else 							pile_pack_push_addr	<=	pile_pack_mono_addr[3]	;

	always@(posedge cube_clki or negedge cube_rstn)
	if(!cube_rstn)					pile_pack_push_drdy	<=	0	;
	else 							pile_pack_push_drdy	<= |pile_pack_mono_drdy[0:3];
/**********************************************************************/


endmodule