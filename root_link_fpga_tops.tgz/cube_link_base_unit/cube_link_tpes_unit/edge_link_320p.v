// file: edge_link_320p.v
// (c) Copyright 2009 - 2011 Xilinx, Inc. All rights reserved.
// 
// This file contains confidential and proprietary information
// of Xilinx, Inc. and is protected under U.S. and
// international copyright and other intellectual property
// laws.
// 
// DISCLAIMER
// This disclaimer is not a license and does not grant any
// rights to the materials distributed herewith. Except as
// otherwise provided in a valid license issued to you by
// Xilinx, and to the maximum extent permitted by applicable
// law: (1) THESE MATERIALS ARE MADE AVAILABLE "AS IS" AND
// WITH ALL FAULTS, AND XILINX HEREBY DISCLAIMS ALL WARRANTIES
// AND CONDITIONS, EXPRESS, IMPLIED, OR STATUTORY, INCLUDING
// BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, NON-
// INFRINGEMENT, OR FITNESS FOR ANY PARTICULAR PURPOSE; and
// (2) Xilinx shall not be liable (whether in contract or tort,
// including negligence, or under any other theory of
// liability) for any loss or damage of any kind or nature
// related to, arising under or in connection with these
// materials, including for any direct, or any indirect,
// special, incidental, or consequential loss or damage
// (including loss of data, profits, goodwill, or any type of
// loss or damage suffered as a result of any action brought
// by a third party) even if such damage or loss was
// reasonably foreseeable or Xilinx had been advised of the
// possibility of the same.
// 
// CRITICAL APPLICATIONS
// Xilinx products are not designed or intended to be fail-
// safe, or for use in any application requiring fail-safe
// performance, such as life-support or safety devices or
// systems, Class III medical devices, nuclear facilities,
// applications related to the deployment of airbags, or any
// other applications that could lead to death, personal
// injury, or severe property or environmental damage
// (individually and collectively, "Critical
// Applications"). Customer assumes the sole risk and
// liability of any use of Xilinx products in Critical
// Applications, subject only to applicable laws and
// regulations governing limitations on product liability.
// 
// THIS COPYRIGHT NOTICE AND DISCLAIMER MUST BE RETAINED AS
// PART OF THIS FILE AT ALL TIMES.
//----------------------------------------------------------------------------
// User entered comments
//----------------------------------------------------------------------------
// None
//----------------------------------------------------------------------------

`timescale 1ps/1ps

(* CORE_GENERATION_INFO = "edge_link_320p,selectio_wiz_v4_1,{component_name=edge_link_320p,bus_dir=INPUTS,bus_sig_type=DIFF,bus_io_std=LVDS_33,use_serialization=true,use_phase_detector=false,serialization_factor=8,enable_bitslip=true,enable_train=false,system_data_width=5,bus_in_delay=FIXED,bus_out_delay=NONE,clk_sig_type=DIFF,clk_io_std=LVDS_33,clk_buf=BUFIO2,active_edge=BOTH_RISE_FALL,clk_delay=FIXED,v6_bus_in_delay=NONE,v6_bus_out_delay=NONE,v6_clk_buf=BUFIO,v6_active_edge=NOT_APP,v6_ddr_alignment=SAME_EDGE_PIPELINED,v6_oddr_alignment=SAME_EDGE,ddr_alignment=C0,v6_interface_type=NETWORKING,interface_type=RETIMED,v6_bus_in_tap=0,v6_bus_out_tap=0,v6_clk_io_std=LVCMOS18,v6_clk_sig_type=DIFF}" *)

module edge_link_320p
   // width of the data for the system
 #(parameter sys_w = 5,
   // width of the data for the device
   parameter dev_w = 40)
 (
  // From the system into the device
  input  [sys_w-1:0] DATA_IN_FROM_PINS_P,
  input  [sys_w-1:0] DATA_IN_FROM_PINS_N,
  output [dev_w-1:0] DATA_IN_TO_DEVICE,
  input [1:0] DEBUG_IN, // Tie to "00" if not used
  output [3*sys_w + 5 : 0] DEBUG_OUT,  // leave NC is not required
  input              BITSLIP,
  input              CLK_IN_P,      // Differential clock from IOB
  input              CLK_IN_N,
  output             CLK_DIV_OUT,   // Slow clock output
  output			 tpem_fclk,
  input              IO_RESET);
  localparam         num_serial_bits = dev_w/sys_w;
  // Signal declarations
  ////------------------------------
  wire               clock_enable = 1'b1;
  // After the buffer
  wire   [sys_w-1:0] data_in_from_pins_int;
  // Between the delay and serdes
  wire [sys_w-1:0] data_in_from_pins_delay_m;
  wire [sys_w-1:0] data_in_from_pins_delay_s;
  wire [sys_w-1:0] pd_edge;
  wire pd_clk;
  wire [sys_w-1:0] pd_busy;
  wire [sys_w-1:0] pd_data_inc;
  wire [sys_w-1:0] pd_data_ce;
  wire pd_cal_master;
  wire pd_cal_slave;
  wire pd_cal_rst;
  wire [sys_w-1:0] pd_valid;
  wire [sys_w-1:0] pd_inc_dec;
  // Array to use intermediately from the serdes to the internal
  //  devices. bus "0" is the leftmost bus
  wire [sys_w-1:0]  iserdes_q[0:7];   // fills in starting with 0
  // Create the clock logic
  IBUFGDS_DIFF_OUT
    #(.DIFF_TERM("TRUE"),.IOSTANDARD ("LVDS_33"))
   ibufds_clk_inst
     (.I          (CLK_IN_P),
      .IB         (CLK_IN_N),
      .O          (clk_in_int_p),
      .OB         (clk_in_int_n));

  // delay the input clock
`ifdef	FAST_SIMU  
	IODELAY2X   #(
		.DATA_RATE                  ("DDR"),
		.IDELAY_VALUE               (0),
		.IDELAY_TYPE                ("FIXED"),
		.COUNTER_WRAPAROUND         ("STAY_AT_LIMIT"),
		.DELAY_SRC                  ("IDATAIN"),
		.SERDES_MODE                ("NONE"),
		.SIM_TAPDELAY_VALUE         (75))
	IODELAY2X_clk(
		.IDATAIN                (clk_in_int_p),
		.DATAOUT                (clk_in_int_p_delay),
		.T                      (1'b1),
		.DATAOUT2               (),
		.DOUT                   (),
		.ODATAIN                (1'b0),
		.TOUT                   (),
		.IOCLK0                 (1'b0),                 // No calibration needed
		.IOCLK1                 (1'b0),                 // No calibration needed
		.CLK                    (1'b0),
		.CAL                    (1'b0),
		.INC                    (1'b0),
		.CE                     (1'b0),
		.BUSY                   (),
		.RST                    (1'b0));

	IODELAY2X   #(
		.DATA_RATE                  ("DDR"),
		.IDELAY_VALUE               (0),
		.IDELAY_TYPE                ("FIXED"),
		.COUNTER_WRAPAROUND         ("STAY_AT_LIMIT"),
		.DELAY_SRC                  ("IDATAIN"),
		.SERDES_MODE                ("NONE"),
		.SIM_TAPDELAY_VALUE         (75))
	IODELAY2X_clk_n    (
		.IDATAIN                (clk_in_int_n),
		.DATAOUT                (clk_in_int_n_delay),
		.T                      (1'b1),
		.DATAOUT2               (),
		.DOUT                   (),
		.ODATAIN                (1'b0),
		.TOUT                   (),
		.IOCLK0                 (1'b0),                 // No calibration needed
		.IOCLK1                 (1'b0),                 // No calibration needed
		.CLK                    (1'b0),
		.CAL                    (1'b0),
		.INC                    (1'b0),
		.CE                     (1'b0),
		.BUSY                   (),
		.RST                    (1'b0));
`else
	IODELAY2    #(
		.DATA_RATE                  ("DDR"),
		.IDELAY_VALUE               (0),
		.IDELAY_TYPE                ("FIXED"),
		.COUNTER_WRAPAROUND         ("STAY_AT_LIMIT"),
		.DELAY_SRC                  ("IDATAIN"),
		.SERDES_MODE                ("NONE"),
		.SIM_TAPDELAY_VALUE         (75))
	IODELAY2_clk(
		.IDATAIN                (clk_in_int_p),
		.DATAOUT                (clk_in_int_p_delay),
		.T                      (1'b1),
		.DATAOUT2               (),
		.DOUT                   (),
		.ODATAIN                (1'b0),
		.TOUT                   (),
		.IOCLK0                 (1'b0),                 // No calibration needed
		.IOCLK1                 (1'b0),                 // No calibration needed
		.CLK                    (1'b0),
		.CAL                    (1'b0),
		.INC                    (1'b0),
		.CE                     (1'b0),
		.BUSY                   (),
		.RST                    (1'b0));

	IODELAY2    #(
		.DATA_RATE                  ("DDR"),
		.IDELAY_VALUE               (0),
		.IDELAY_TYPE                ("FIXED"),
		.COUNTER_WRAPAROUND         ("STAY_AT_LIMIT"),
		.DELAY_SRC                  ("IDATAIN"),
		.SERDES_MODE                ("NONE"),
		.SIM_TAPDELAY_VALUE         (75))
	IODELAY2_clk_n    (
		.IDATAIN                (clk_in_int_n),
		.DATAOUT                (clk_in_int_n_delay),
		.T                      (1'b1),
		.DATAOUT2               (),
		.DOUT                   (),
		.ODATAIN                (1'b0),
		.TOUT                   (),
		.IOCLK0                 (1'b0),                 // No calibration needed
		.IOCLK1                 (1'b0),                 // No calibration needed
		.CLK                    (1'b0),
		.CAL                    (1'b0),
		.INC                    (1'b0),
		.CE                     (1'b0),
		.BUSY                   (),
		.RST                    (1'b0));
`endif


 // also generated the inverted clock
  	wire				tpem_fclk_bfio;

`ifdef			FAST_SIMU
  // Set up the clock for use in the serdes
	BUFIO2_2CLKX #(
		.DIVIDE        				(8))
	bufio2_inst
     (.DIVCLK       				(clk_div),
      .IOCLK        				(clk_in_int_buf),
      .SERDESSTROBE 				(serdesstrobe),
      .I            				(clk_in_int_p_delay),
      .IB           				(clk_in_int_n_delay)
   );

	BUFIO2X    #(
		.DIVIDE_BYPASS 				("FALSE"),
		.I_INVERT      				("FALSE"),
		.USE_DOUBLER   				("FALSE"),
		.DIVIDE        				(1))
	bufio2_inv_inst(
		.DIVCLK       				(tpem_fclk_bfio),
		.IOCLK        				(clk_in_int_inv),
		.SERDESSTROBE 				(),
		.I            				(clk_in_int_n_delay));
`else
  // Set up the clock for use in the serdes
	BUFIO2_2CLK #(
		.DIVIDE        				(8))
	bufio2_inst
     (.DIVCLK       				(clk_div),
      .IOCLK        				(clk_in_int_buf),
      .SERDESSTROBE 				(serdesstrobe),
      .I            				(clk_in_int_p_delay),
      .IB           				(clk_in_int_n_delay)
   );

 	BUFIO2    #(
		.DIVIDE_BYPASS 				("FALSE"),
		.I_INVERT      				("FALSE"),
		.USE_DOUBLER   				("FALSE"),
		.DIVIDE        				(1))
	bufio2_inv_inst(
		.DIVCLK       				(tpem_fclk_bfio),
		.IOCLK        				(clk_in_int_inv),
		.SERDESSTROBE 				(),
		.I            				(clk_in_int_n_delay));
`endif



   // Buffer up the divided clock
	BUFG	clkdiv_buf_inst(
		.O 		(CLK_DIV_OUT	),
		.I 		(clk_div		));

	BUFG	tpem_fclk_bufg	(
		.O		(tpem_fclk		),
		.I		(tpem_fclk_bfio	));
  // We have multiple bits- step over every bit, instantiating the required elements
  genvar pin_count;
  genvar slice_count;
  generate for (pin_count = 0; pin_count < sys_w; pin_count = pin_count + 1) begin: pins
    // Instantiate the buffers
    ////------------------------------
    // Instantiate a buffer for every bit of the data bus
    IBUFDS
//      #(.DIFF_TERM  ("FALSE"),             // Differential termination
      #(.DIFF_TERM  ("TRUE"),
        .IOSTANDARD ("LVDS_33"))
     ibufds_inst
       (.I          (DATA_IN_FROM_PINS_P  [pin_count]),
        .IB         (DATA_IN_FROM_PINS_N  [pin_count]),
        .O          (data_in_from_pins_int[pin_count]));

`ifdef			FAST_SIMU
	IODELAY2X #(
		.DATA_RATE      			("DDR"), 		// <SDR>, DDR
		.IDELAY_VALUE  				(0), 			// {0 ... 255}
		.IDELAY_TYPE   				("DIFF_PHASE_DETECTOR"),// "DEFAULT", "DIFF_PHASE_DETECTOR", "FIXED", "VARIABLE_FROM_HALF_MAX", "VARIABLE_FROM_ZERO"
		.COUNTER_WRAPAROUND 		("WRAPAROUND"), 	// <STAY_AT_LIMIT>, WRAPAROUND
		.DELAY_SRC     				("IDATAIN" ), 		// "IO", "IDATAIN", "ODATAIN"
		.SERDES_MODE   				("MASTER"), 		// <NONE>, MASTER, SLAVE
		.SIM_TAPDELAY_VALUE   		(49)) 	//
	iodelay_m (
		.IDATAIN  					(data_in_from_pins_int  [pin_count]), 	// data from primary IOB
		.TOUT     					(), 			// tri-state signal to IOB
		.DOUT     					(), 			// output data to IOB
		.T        					(1'b1), 		// tri-state control from OLOGIC/OSERDES2
		.ODATAIN  					(1'b0), 		// data from OLOGIC/OSERDES2
		.DATAOUT  					(data_in_from_pins_delay_m[pin_count]), 		// Output data 1 to ILOGIC/ISERDES2
		.DATAOUT2 					(),	 		// Output data 2 to ILOGIC/ISERDES2
		.IOCLK0         			(clk_in_int_buf),       // High speed clock for calibration for SDR/DDR
		.IOCLK1         			(clk_in_int_inv),       // High speed clock for calibration for DDR
		.CLK      					(CLK_DIV_OUT), 		// Fabric clock (GCLK) for control signals
		.CAL      					(pd_cal_master),	// Calibrate control signal
		.INC      					(pd_data_inc[pin_count]), 		// Increment counter
		.CE       					(pd_data_ce[pin_count]), 		// Clock Enable
		.RST      					(pd_cal_rst),		// Reset delay line
		.BUSY      					()) ; 			// output signal indicating sync circuit has finished / calibration has finished

	IODELAY2X #(
		.DATA_RATE      			("DDR"), 		// <SDR>, DDR
		.IDELAY_VALUE  				(0), 			// {0 ... 255}
		.IDELAY_TYPE   				("DIFF_PHASE_DETECTOR"),// "DEFAULT", "DIFF_PHASE_DETECTOR", "FIXED", "VARIABLE_FROM_HALF_MAX", "VARIABLE_FROM_ZERO"
		.COUNTER_WRAPAROUND 		("WRAPAROUND"), 	// <STAY_AT_LIMIT>, WRAPAROUND
		.DELAY_SRC     				("IDATAIN" ), 		// "IO", "IDATAIN", "ODATAIN"
		.SERDES_MODE   				("SLAVE"), 		// <NONE>, MASTER, SLAVE
		.SIM_TAPDELAY_VALUE 	  	(49)) 	//
	iodelay_s (
		.IDATAIN 					(data_in_from_pins_int  [pin_count]), 	// data from primary IOB
		.TOUT     					(), 			// tri-state signal to IOB
		.DOUT     					(), 			// output data to IOB
		.T        					(1'b1), 		// tri-state control from OLOGIC/OSERDES2
		.ODATAIN  					(1'b0), 		// data from OLOGIC/OSERDES2
		.DATAOUT  					(data_in_from_pins_delay_s[pin_count]), 		// Output data 1 to ILOGIC/ISERDES2
		.DATAOUT2 					(),	 		// Output data 2 to ILOGIC/ISERDES2
	    .IOCLK0         			(clk_in_int_buf),       // High speed clock for calibration for SDR/DDR
	    .IOCLK1         			(clk_in_int_inv),       // High speed clock for calibration for DDR
	    .CLK      					(CLK_DIV_OUT), 		// Fabric clock (GCLK) for control signals
		.CAL      					(pd_cal_slave),	// Calibrate control signal
		.INC      					(pd_data_inc[pin_count]), 		// Increment counter
		.CE       					(pd_data_ce[pin_count]), 		// Clock Enable
		.RST      					(pd_cal_rst),		// Reset delay line
		.BUSY      					(pd_busy[pin_count])) ;		// output signal indicating sync circuit has finished / calibration has finished
`else
	IODELAY2 #(
		.DATA_RATE      			("DDR"), 		// <SDR>, DDR
		.IDELAY_VALUE  				(0), 			// {0 ... 255}
		.IDELAY_TYPE   				("DIFF_PHASE_DETECTOR"),// "DEFAULT", "DIFF_PHASE_DETECTOR", "FIXED", "VARIABLE_FROM_HALF_MAX", "VARIABLE_FROM_ZERO"
		.COUNTER_WRAPAROUND 		("WRAPAROUND"), 	// <STAY_AT_LIMIT>, WRAPAROUND
		.DELAY_SRC     				("IDATAIN" ), 		// "IO", "IDATAIN", "ODATAIN"
		.SERDES_MODE   				("MASTER"), 		// <NONE>, MASTER, SLAVE
		.SIM_TAPDELAY_VALUE   		(49)) 	//
	iodelay_m (
		.IDATAIN  					(data_in_from_pins_int  [pin_count]), 	// data from primary IOB
		.TOUT     					(), 			// tri-state signal to IOB
		.DOUT     					(), 			// output data to IOB
		.T        					(1'b1), 		// tri-state control from OLOGIC/OSERDES2
		.ODATAIN  					(1'b0), 		// data from OLOGIC/OSERDES2
		.DATAOUT  					(data_in_from_pins_delay_m[pin_count]), 		// Output data 1 to ILOGIC/ISERDES2
		.DATAOUT2 					(),	 		// Output data 2 to ILOGIC/ISERDES2
		.IOCLK0         			(clk_in_int_buf),       // High speed clock for calibration for SDR/DDR
		.IOCLK1         			(clk_in_int_inv),       // High speed clock for calibration for DDR
		.CLK      					(CLK_DIV_OUT), 		// Fabric clock (GCLK) for control signals
		.CAL      					(pd_cal_master),	// Calibrate control signal
		.INC      					(pd_data_inc[pin_count]), 		// Increment counter
		.CE       					(pd_data_ce[pin_count]), 		// Clock Enable
		.RST      					(pd_cal_rst),		// Reset delay line
		.BUSY      					()) ; 			// output signal indicating sync circuit has finished / calibration has finished

	IODELAY2 #(
		.DATA_RATE      			("DDR"), 		// <SDR>, DDR
		.IDELAY_VALUE  				(0), 			// {0 ... 255}
		.IDELAY_TYPE   				("DIFF_PHASE_DETECTOR"),// "DEFAULT", "DIFF_PHASE_DETECTOR", "FIXED", "VARIABLE_FROM_HALF_MAX", "VARIABLE_FROM_ZERO"
		.COUNTER_WRAPAROUND 		("WRAPAROUND"), 	// <STAY_AT_LIMIT>, WRAPAROUND
		.DELAY_SRC     				("IDATAIN" ), 		// "IO", "IDATAIN", "ODATAIN"
		.SERDES_MODE   				("SLAVE"), 		// <NONE>, MASTER, SLAVE
		.SIM_TAPDELAY_VALUE 	  	(49)) 	//
	iodelay_s (
		.IDATAIN 					(data_in_from_pins_int  [pin_count]), 	// data from primary IOB
		.TOUT     					(), 			// tri-state signal to IOB
		.DOUT     					(), 			// output data to IOB
		.T        					(1'b1), 		// tri-state control from OLOGIC/OSERDES2
		.ODATAIN  					(1'b0), 		// data from OLOGIC/OSERDES2
		.DATAOUT  					(data_in_from_pins_delay_s[pin_count]), 		// Output data 1 to ILOGIC/ISERDES2
		.DATAOUT2 					(),	 		// Output data 2 to ILOGIC/ISERDES2
	    .IOCLK0         			(clk_in_int_buf),       // High speed clock for calibration for SDR/DDR
	    .IOCLK1         			(clk_in_int_inv),       // High speed clock for calibration for DDR
	    .CLK      					(CLK_DIV_OUT), 		// Fabric clock (GCLK) for control signals
		.CAL      					(pd_cal_slave),	// Calibrate control signal
		.INC      					(pd_data_inc[pin_count]), 		// Increment counter
		.CE       					(pd_data_ce[pin_count]), 		// Clock Enable
		.RST      					(pd_cal_rst),		// Reset delay line
		.BUSY      					(pd_busy[pin_count])) ;		// output signal indicating sync circuit has finished / calibration has finished
`endif
     // Instantiate the serdes primitive
     ////------------------------------
     // local wire only for use in this generate loop
     wire cascade_shift;
     wire [sys_w-1:0] icascade;
     wire [sys_w-1:0] slave_shiftout;

     // decalare the iserdes
     ISERDES2
       #(.BITSLIP_ENABLE ("TRUE"),
         .DATA_RATE      ("DDR"),
         .DATA_WIDTH     (num_serial_bits),
         .INTERFACE_TYPE ("RETIMED"),
         .SERDES_MODE    ("MASTER"))
      iserdes2_master
       (.Q1         (iserdes_q[3][pin_count]),
        .Q2         (iserdes_q[2][pin_count]),
        .Q3         (iserdes_q[1][pin_count]),
        .Q4         (iserdes_q[0][pin_count]),
        .SHIFTOUT   (icascade[pin_count]), // 1-bit Cascade out signal for Master/Slave IO. In Phase Detector mode used to
                                           // send slave sampled data 
        .INCDEC     (pd_inc_dec[pin_count]), // 1-bit Output of Phase Detector (Dummy in slave)
        .VALID      (pd_valid[pin_count]),   // 1-bit Output of Phase Detector (Dummy in Slave). If the input data contains no
                                             // edges (no info for the phase detector to work with) the VALID signal will go
                                             // LOW to indicate that the fabric should ignore the INCDEC signal.

        .BITSLIP    (BITSLIP),       // 1-bit Invoke Bitslip. This can be used with any DATA_WIDTH, cascaded or not.
                                     // The amount of bitslip is fixed by the DATA_WIDTH selection.
        .CE0        (clock_enable),  // 1-bit Clock enable input
        .CLK0       (clk_in_int_buf),// 1-bit IO Clock network input. Optionally Invertible. This is the primary clock
                                     // input used when the clock doubler circuit is not engaged (see DATA_RATE
                                     // attribute).
        .CLK1       (clk_in_int_inv), // 1-bit Optionally invertible IO Clock network input. Timing note: CLK1 should be
                                      // 180 degrees out of phase with CLK0.
        .CLKDIV     (CLK_DIV_OUT),                        // 1-bit Global clock network input. This is the clock for the fabric domain.
        .D          (data_in_from_pins_delay_m[pin_count]), // 1-bit Input signal from IOB.
        .IOCE       (serdesstrobe),                       // 1-bit Data strobe signal derived from BUFIO CE. Strobes data capture for
                                                          // NETWORKING and NETWORKING_PIPELINES alignment modes.

        .RST        (IO_RESET),        // 1-bit Asynchronous reset only.
        .SHIFTIN    (pd_edge[pin_count]),
        // unused connections
        .FABRICOUT  (),
        .CFB0       (),
        .CFB1       (),
        .DFB        ());

     ISERDES2
       #(.BITSLIP_ENABLE ("TRUE"),
         .DATA_RATE      ("DDR"),
         .DATA_WIDTH     (num_serial_bits),
         .INTERFACE_TYPE ("RETIMED"),
         .SERDES_MODE    ("SLAVE"))

      iserdes2_slave
       (.Q1         (iserdes_q[7][pin_count]),
        .Q2         (iserdes_q[6][pin_count]),
        .Q3         (iserdes_q[5][pin_count]),
        .Q4         (iserdes_q[4][pin_count]),
        .INCDEC     (),   // 1-bit Output of Phase Detector (Dummy in slave)
        .SHIFTOUT   (pd_edge[pin_count]), // 1-bit Cascade out signal for Master/Slave IO. In Phase Detector mode used to
                                      // send slave sampled data.

        .VALID      (),    // 1-bit Output of Phase Detector (Dummy in Slave). If the input data contains no
                                      // edges (no info for the phase detector to work with) the VALID signal will go
                                      // LOW to indicate that the fabric should ignore the INCDEC signal.
        .BITSLIP    (BITSLIP),      // 1-bit Invoke Bitslip. This can be used with any DATA_WIDTH, cascaded or not.
                                    // The amount of bitslip is fixed by the DATA_WIDTH selection.
        .CE0        (clock_enable),   // 1-bit Clock enable input
        .CLK0       (clk_in_int_buf), // 1-bit IO Clock network input. Optionally Invertible. This is the primary clock
                                      // input used when the clock doubler circuit is not engaged (see DATA_RATE
                                      // attribute).
        .CLK1       (clk_in_int_inv), // 1-bit Optionally invertible IO Clock network input. Timing note: CLK1 should be
                                      // 180 degrees out of phase with CLK0.
        .CLKDIV     (CLK_DIV_OUT),    // 1-bit Global clock network input. This is the clock for the fabric domain.
        .D          (data_in_from_pins_delay_s[pin_count]),           // 1-bit Input signal from IOB.
        .IOCE       (serdesstrobe),   // 1-bit Data strobe signal derived from BUFIO CE. Strobes data capture for
                                      // NETWORKING and NETWORKING_PIPELINES alignment modes.

        .RST        (IO_RESET),       // 1-bit Asynchronous reset only.
        .SHIFTIN    (icascade[pin_count]),
        // unused connections
        .FABRICOUT  (),
        .CFB0       (),
        .CFB1       (),
        .DFB        ());



     // Concatenate the serdes outputs together. Keep the timesliced
     //   bits together, and placing the earliest bits on the right
     //   ie, if data comes in 0, 1, 2, 3, 4, 5, 6, 7, ...
     //       the output will be 3210, 7654, ...
     ////---------------------------------------------------------
     //for (slice_count = 0; slice_count < num_serial_bits; slice_count = slice_count + 1) begin: in_slices
     //   // This places the first data in time on the right
     //   assign DATA_IN_TO_DEVICE[slice_count*sys_w+:sys_w] =
     //     iserdes_q[num_serial_bits-slice_count-1];
     //   // To place the first data in time on the left, use the
     //   //   following code, instead
     //   // assign DATA_IN_TO_DEVICE[slice_count*sys_w+:sys_w] =
     //   //   iserdes_q[slice_count];
     //end

        assign  DATA_IN_TO_DEVICE[(pin_count+1)*num_serial_bits-1:pin_count*num_serial_bits] =  
            {   iserdes_q[7][pin_count],
                iserdes_q[6][pin_count],
                iserdes_q[5][pin_count],
                iserdes_q[4][pin_count],
                iserdes_q[3][pin_count],
                iserdes_q[2][pin_count],
                iserdes_q[1][pin_count],
                iserdes_q[0][pin_count]};


  end
  endgenerate

phase_detector
   #(.D(5))
phase_detector_inst
    (.use_phase_detector(1'b1),
     .busy(pd_busy),
     .valid(pd_valid),
     .inc_dec(pd_inc_dec),
     .reset(IO_RESET),
     .gclk(CLK_DIV_OUT),
     .debug_in(DEBUG_IN),
     .debug(DEBUG_OUT),
     .cal_master(pd_cal_master),
     .cal_slave(pd_cal_slave),
     .rst_out(pd_cal_rst),
     .ce(pd_data_ce),
     .inc(pd_data_inc));
endmodule
