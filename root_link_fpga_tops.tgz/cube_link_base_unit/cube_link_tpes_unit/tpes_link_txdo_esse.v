
module	tpes_link_txdo_esse(
	output							tpes_fclk_outp	,
	output							tpes_fclk_outn	,
	output							tpes_fram_outp	,
	output							tpes_fram_outn	,
	output							tpes_dat0_outp	,
	output							tpes_dat0_outn	,
	output							tpes_dat1_outp	,
	output							tpes_dat1_outn	,
	output							tpes_dat2_outp	,
	output							tpes_dat2_outn	,
	output							tpes_dat3_outp	,
	output							tpes_dat3_outn	,

	input							tune_txdo_enab	,		
	input							tune_rxdi_enab	,		

	input	[ 7: 0]					ttxd_fram_mbdi	,
	input	[ 7: 0]					ttxd_dat0_mbdi	,
	input	[ 7: 0]					ttxd_dat1_mbdi	,
	input	[ 7: 0]					ttxd_dat2_mbdi	,
	input	[ 7: 0]					ttxd_dat3_mbdi	,//from sclk domain

	input	[ 7: 0]					scut_fram_mbdi	,
	input	[ 7: 0]					scut_dat0_mbdi	,
	input	[ 7: 0]					scut_dat1_mbdi	,
	input	[ 7: 0]					scut_dat2_mbdi	,
	input	[ 7: 0]					scut_dat3_mbdi	,//from sclk domain

	input	[ 7: 0]					acks_fram_mbdi	,
	input	[ 7: 0]					acks_dat0_mbdi	,
	input	[ 7: 0]					acks_dat1_mbdi	,
	input	[ 7: 0]					acks_dat2_mbdi	,
	input	[ 7: 0]					acks_dat3_mbdi	,//from sclk domain

	input	[ 7: 0]					dlnk_fram_mbdi	,
	input	[ 7: 0]					dlnk_dat0_mbdi	,
	input	[ 7: 0]					dlnk_dat1_mbdi	,
	input	[ 7: 0]					dlnk_dat2_mbdi	,
	input	[ 7: 0]					dlnk_dat3_mbdi	,//from sclk domain

	input							tpes_fclk		,
	input							tpes_sclk		,
	input							tpes_strb		,//40Mhz VS 160Mhz 1/4 
	input							tpes_rstn		);
/**********************************************************************************************************/
	reg	[ 7: 0]						func_fram_mbdi	;
	reg	[ 7: 0]						func_dat0_mbdi	;
	reg	[ 7: 0]						func_dat1_mbdi	;
	reg	[ 7: 0]						func_dat2_mbdi	;
	reg	[ 7: 0]						func_dat3_mbdi	;//from sclk domain

	always@(posedge tpes_sclk or negedge tpes_rstn)
	if(~tpes_rstn)					begin
		func_fram_mbdi	<=	0	;
		func_dat0_mbdi	<=	0	;
		func_dat1_mbdi	<=	0	;
		func_dat2_mbdi	<=	0	;
		func_dat3_mbdi	<=	0	;
	end else 						begin
		func_fram_mbdi	<=	acks_fram_mbdi | dlnk_fram_mbdi | scut_fram_mbdi	;
		func_dat0_mbdi	<=	acks_dat0_mbdi | dlnk_dat0_mbdi | scut_dat0_mbdi	;
		func_dat1_mbdi	<=	acks_dat1_mbdi | dlnk_dat1_mbdi | scut_dat1_mbdi	;
		func_dat2_mbdi	<=	acks_dat2_mbdi | dlnk_dat2_mbdi | scut_dat2_mbdi	;
		func_dat3_mbdi	<=	acks_dat3_mbdi | dlnk_dat3_mbdi | scut_dat3_mbdi	;
	end
/**********************************************************************************************************/
	reg		[ 1: 0]					tune_txdo_sync	;
	reg								tune_txdo_mode	;	

	always@(posedge  tpes_fclk or negedge tpes_rstn)
	if(~tpes_rstn)					tune_txdo_sync	<=	0	;
	else 							tune_txdo_sync	<={	tune_txdo_enab	, tune_txdo_sync[1]	};

	always@(posedge  tpes_fclk or negedge tpes_rstn)
	if(~tpes_rstn)					tune_txdo_mode	<=	0	;
	else if(tpes_strb)				tune_txdo_mode	<=	tune_txdo_sync[0];
//----------------------------------------------------------------------
	reg		[ 1: 0]					tune_rxdi_sync	;
	reg								tune_rxdi_mode	;

	always@(posedge  tpes_fclk or negedge tpes_rstn)
	if(~tpes_rstn)					tune_rxdi_sync	<=	0	;
	else 							tune_rxdi_sync	<={	tune_rxdi_enab	, tune_rxdi_sync[1]	};

	always@(posedge  tpes_fclk or negedge tpes_rstn)
	if(~tpes_rstn)					tune_rxdi_mode	<=	0	;
	else if(tpes_strb)				tune_rxdi_mode	<=	tune_rxdi_sync[0];
/**********************************************************************************************************/
	reg		[ 7: 0]					ttxd_fram_shft	;	
	reg		[ 7: 0]					ttxd_dat0_shft	;	
	reg		[ 7: 0]					ttxd_dat1_shft	;	
	reg		[ 7: 0]					ttxd_dat2_shft	;	
	reg		[ 7: 0]					ttxd_dat3_shft	;	

	always@(posedge tpes_fclk or negedge tpes_rstn)
	if(~tpes_rstn)					begin
		ttxd_fram_shft	<=	0	;
		ttxd_dat0_shft	<=	0	;
		ttxd_dat1_shft	<=	0	;
		ttxd_dat2_shft	<=	0	;
		ttxd_dat3_shft	<=	0	;
	end else if(~tune_txdo_mode)	begin
		ttxd_fram_shft	<=	0	;
		ttxd_dat0_shft	<=	0	;
		ttxd_dat1_shft	<=	0	;
		ttxd_dat2_shft	<=	0	;
		ttxd_dat3_shft	<=	0	;
	end else if( tpes_strb)	begin
		ttxd_fram_shft	<=	ttxd_fram_mbdi	;
		ttxd_dat0_shft	<=	ttxd_dat0_mbdi	;
		ttxd_dat1_shft	<=	ttxd_dat1_mbdi	;
		ttxd_dat2_shft	<=	ttxd_dat2_mbdi	;
		ttxd_dat3_shft	<=	ttxd_dat3_mbdi	;
	end else 						begin
		ttxd_fram_shft	<={	ttxd_fram_shft[5:0]	,2'B00	};
		ttxd_dat0_shft	<={	ttxd_dat0_shft[5:0]	,2'B00	};
		ttxd_dat1_shft	<={	ttxd_dat1_shft[5:0]	,2'B00	};
		ttxd_dat2_shft	<={	ttxd_dat2_shft[5:0]	,2'B00	};
		ttxd_dat3_shft	<={	ttxd_dat3_shft[5:0]	,2'B00	};
	end
/**********************************************************************************************************/
	reg		[ 7: 0]					trxd_patn_shft	;

	always@(posedge tpes_fclk or negedge tpes_rstn)
	if(!tpes_rstn) 					trxd_patn_shft	<=	0			;
	else if(~tune_rxdi_mode)		trxd_patn_shft	<= 8'H00		;
	else if( tpes_strb)				trxd_patn_shft	<= 8'H9A		;
	else 							trxd_patn_shft	<= {trxd_patn_shft[5:0]	,trxd_patn_shft[7:6]	};
/**********************************************************************************************************/
	reg		[ 7: 0]					func_fram_shft	= 0;	
	reg		[ 7: 0]					func_dat0_shft	= 0;	
	reg		[ 7: 0]					func_dat1_shft	= 0;	
	reg		[ 7: 0]					func_dat2_shft	= 0;	
	reg		[ 7: 0]					func_dat3_shft	= 0;	

	always@(posedge tpes_fclk or negedge tpes_rstn)
	if(~tpes_rstn)					begin
		func_fram_shft	<=	0	;
		func_dat0_shft	<=	0	;
		func_dat1_shft	<=	0	;
		func_dat2_shft	<=	0	;
		func_dat3_shft	<=	0	;
	end else  if(tpes_strb)			begin
		func_fram_shft	<=	func_fram_mbdi	;
		func_dat0_shft	<=	func_dat0_mbdi	;
		func_dat1_shft	<=	func_dat1_mbdi	;
		func_dat2_shft	<=	func_dat2_mbdi	;
		func_dat3_shft	<=	func_dat3_mbdi	;
	end else begin
		func_fram_shft	<={	func_fram_shft[5:0]	,2'B00	};
		func_dat0_shft	<={	func_dat0_shft[5:0]	,2'B00	};
		func_dat1_shft	<={	func_dat1_shft[5:0]	,2'B00	};
		func_dat2_shft	<={	func_dat2_shft[5:0]	,2'B00	};
		func_dat3_shft	<={	func_dat3_shft[5:0]	,2'B00	};
	end
/**********************************************************************************************************/
	wire							tpes_fram_d0	;
	wire							tpes_dat0_d0	;
	wire							tpes_dat1_d0	;
	wire							tpes_dat2_d0	;
	wire							tpes_dat3_d0	;

	wire							tpes_fram_d1	;
	wire							tpes_dat0_d1	;
	wire							tpes_dat1_d1	;
	wire							tpes_dat2_d1	;
	wire							tpes_dat3_d1	;

	assign		tpes_fram_d0	= 	trxd_patn_shft[7]	|	ttxd_fram_shft[7]	|	func_fram_shft[7]	;
	assign		tpes_fram_d1	= 	trxd_patn_shft[6]	|	ttxd_fram_shft[6]	|	func_fram_shft[6]	;
	assign		tpes_dat0_d0	= 	trxd_patn_shft[7]	|	ttxd_dat0_shft[7]	|	func_dat0_shft[7]	;
	assign		tpes_dat0_d1	= 	trxd_patn_shft[6]	|	ttxd_dat0_shft[6]	|	func_dat0_shft[6]	;
	assign		tpes_dat1_d0	= 	trxd_patn_shft[7]	|	ttxd_dat1_shft[7]	|	func_dat1_shft[7]	;
	assign		tpes_dat1_d1	= 	trxd_patn_shft[6]	|	ttxd_dat1_shft[6]	|	func_dat1_shft[6]	;
	assign		tpes_dat2_d0	= 	trxd_patn_shft[7]	|	ttxd_dat2_shft[7]	|	func_dat2_shft[7]	;
	assign		tpes_dat2_d1	= 	trxd_patn_shft[6]	|	ttxd_dat2_shft[6]	|	func_dat2_shft[6]	;
	assign		tpes_dat3_d0	= 	trxd_patn_shft[7]	|	ttxd_dat3_shft[7]	|	func_dat3_shft[7]	;
	assign		tpes_dat3_d1	= 	trxd_patn_shft[6]	|	ttxd_dat3_shft[6]	|	func_dat3_shft[6]	;
/**********************************************************************************************************/
 	ODDR2 #(
    .DDR_ALIGNMENT        ("C0"       ),
    .INIT                 (1'b0       ),
    .SRTYPE               ("ASYNC"    ))
	ODDRE1_FCLK (
		.Q							(tpes_fclk_txdo		),	// 1-bit output: Data output to IOB
		.D0							(1'B1				),	// 1-bit input: Parallel data input 1
		.D1							(1'B0				),	// 1-bit input: Parallel data input 2
		.C0							(tpes_fclk			),	// 1-bit input: High-speed clock input
		.C1							(~tpes_fclk			),	// 1-bit input: High-speed clock input
    .CE             (1'b1       ),
    .S              (1'b0       ),
		.R 							(1'B0				)); // 1-bit input: Active-High Async Reset

	OBUFDS						LVDS_FCLK_OUTP	(
		.I							(tpes_fclk_txdo		),
		.O							(tpes_fclk_outp		),
		.OB							(tpes_fclk_outn		));
/**********************************************************************************************************/
  ODDR2 #(
    .DDR_ALIGNMENT        ("C0"       ),
    .INIT                 (1'b0       ),
    .SRTYPE               ("ASYNC"    ))
	ODDRE1_FRAM (
		.Q							(tpes_fram_txdo		),// 1-bit output: Data output to IOB
		.D0							(tpes_fram_d0		),// 1-bit input: Parallel data input 1
		.D1							(tpes_fram_d1		),// 1-bit input: Parallel data input 2
		.C0							(tpes_fclk			),// 1-bit input: High-speed clock input
		.C1							(~tpes_fclk			),// 1-bit input: High-speed clock input
    	.CE             (1'b1       ),
    	.S              (1'b0       ),
		.R							(1'B0				));  // 1-bit input: Active-High Async Reset

	OBUFDS						LVDS_FRAM_OUTP	(
		.I							(tpes_fram_txdo		),
		.O							(tpes_fram_outp		),
		.OB							(tpes_fram_outn		));
//----------------------------------------------------------------------
  ODDR2 #(
    .DDR_ALIGNMENT        ("C0"       ),
    .INIT                 (1'b0       ),
    .SRTYPE               ("ASYNC"    ))
	ODDRE1_DAT0 (
		.Q							(tpes_dat0_txdo		),// 1-bit output: Data output to IOB
		.D0							(tpes_dat0_d0		),// 1-bit input: Parallel data input 1
		.D1							(tpes_dat0_d1		),// 1-bit input: Parallel data input 2
		.C0							(tpes_fclk			),// 1-bit input: High-speed clock input
		.C1							(~tpes_fclk			),// 1-bit input: High-speed clock input
    	.CE             (1'b1       ),
    	.S              (1'b0       ),
		.R							(1'B0				));  // 1-bit input: Active-High Async Reset

	OBUFDS						LVDS_DAT0_OUTP	(
		.I							(tpes_dat0_txdo		),
		.O							(tpes_dat0_outp		),
		.OB							(tpes_dat0_outn		));
//----------------------------------------------------------------------
 	ODDR2 #(
    .DDR_ALIGNMENT        ("C0"       ),
    .INIT                 (1'b0       ),
    .SRTYPE               ("ASYNC"    ))
	ODDRE1_DAT1 (
		.Q							(tpes_dat1_txdo		),// 1-bit output: Data output to IOB
		.D0							(tpes_dat1_d0		),// 1-bit input: Parallel data input 1
		.D1							(tpes_dat1_d1		),// 1-bit input: Parallel data input 2
		.C0							(tpes_fclk			),// 1-bit input: High-speed clock input
		.C1							(~tpes_fclk			),// 1-bit input: High-speed clock input
    	.CE             (1'b1       ),
    	.S              (1'b0       ),
		.R							(1'B0				));  // 1-bit input: Active-High Async Reset

	OBUFDS						LVDS_DAT1_OUTP	(
		.I							(tpes_dat1_txdo		),
		.O							(tpes_dat1_outp		),
		.OB							(tpes_dat1_outn		));
//----------------------------------------------------------------------
 	ODDR2 #(
    .DDR_ALIGNMENT        ("C0"       ),
    .INIT                 (1'b0       ),
    .SRTYPE               ("ASYNC"    ))
	ODDRE1_DAT2 (
		.Q							(tpes_dat2_txdo		),// 1-bit output: Data output to IOB
		.D0							(tpes_dat2_d0		),// 1-bit input: Parallel data input 1
		.D1							(tpes_dat2_d1		),// 1-bit input: Parallel data input 2
		.C0							(tpes_fclk			),// 1-bit input: High-speed clock input
		.C1							(~tpes_fclk			),// 1-bit input: High-speed clock input
    	.CE             (1'b1       ),
    	.S              (1'b0       ),
		.R							(1'B0				));  // 1-bit input: Active-High Async Reset

	OBUFDS						LVDS_DAT2_OUTP	(
		.I							(tpes_dat2_txdo		),
		.O							(tpes_dat2_outp		),
		.OB							(tpes_dat2_outn		));
//----------------------------------------------------------------------
 	ODDR2 #(
    .DDR_ALIGNMENT        ("C0"       ),
    .INIT                 (1'b0       ),
    .SRTYPE               ("ASYNC"    ))
	ODDRE1_DAT3 (
		.Q							(tpes_dat3_txdo		),// 1-bit output: Data output to IOB
		.D0							(~tpes_dat3_d0		),// 1-bit input: Parallel data input 1
		.D1							(~tpes_dat3_d1		),// 1-bit input: Parallel data input 2
		.C0							(tpes_fclk			),// 1-bit input: High-speed clock input
		.C1							(~tpes_fclk			),// 1-bit input: High-speed clock input
    .CE             (1'b1       ),
    .S              (1'b0       ),
		.R							(1'B0				));  // 1-bit input: Active-High Async Reset

	OBUFDS						LVDS_DAT3_OUTP	(
		.I							(tpes_dat3_txdo		),
		.O							(tpes_dat3_outp		),
		.OB							(tpes_dat3_outn		));

endmodule

 
