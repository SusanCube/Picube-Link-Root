
module  tpes_link_rxdi_esse(
    input                           tpem_fclk_inpp      ,
    input                           tpem_fclk_inpn      ,
    input                           tpem_fram_inpp      ,
    input                           tpem_fram_inpn      ,
    input                           tpem_dat0_inpp      ,
    input                           tpem_dat0_inpn      ,
    input                           tpem_dat1_inpp      ,
    input                           tpem_dat1_inpn      ,
    input                           tpem_dat2_inpp      ,
    input                           tpem_dat2_inpn      ,
    input                           tpem_dat3_inpp      ,
    input                           tpem_dat3_inpn      ,

    output      [ 7: 0]             tpem_txdo_fram_mbdi ,
    output      [ 7: 0]             tpem_txdo_dat0_mbdi ,
    output      [ 7: 0]             tpem_txdo_dat1_mbdi ,
    output      [ 7: 0]             tpem_txdo_dat2_mbdi ,
    output      [ 7: 0]             tpem_txdo_dat3_mbdi ,

    input                           tpem_tune_txdo      ,
    output      [39: 0]             tpes_tune_acks_patn ,
    output                          tpem_sclk           ,
    output                          tpem_fclk           ,
    input                           tpem_rstn           ,
    input                           tpes_sclk           ,
    input                           tpes_rstn           ,
    input                           isde_prst           );
/**********************************************************************/
    wire    [39: 0]                 tpem_txdo_fram_pack ;
    wire                            tpem_tune_bslp      ;
    wire    [ 4: 0]                 tpem_txdo_padp	;
    wire    [ 4: 0]                 tpem_txdo_padn	;
    assign  tpem_txdo_padp      ={  tpem_fram_inpp  ,
                                    tpem_dat3_inpp  ,
                                    tpem_dat2_inpp  ,
                                    tpem_dat1_inpp  ,
                                    tpem_dat0_inpp  }   ;

    assign  tpem_txdo_padn      ={  tpem_fram_inpn  ,
                                    tpem_dat3_inpn  ,
                                    tpem_dat2_inpn  ,
                                    tpem_dat1_inpn  ,
                                    tpem_dat0_inpn  }   ;

    assign  tpem_txdo_fram_mbdi =   tpem_txdo_fram_pack[39:32]  ;
    assign  tpem_txdo_dat3_mbdi =   tpem_txdo_fram_pack[31:24]  ;
    assign  tpem_txdo_dat2_mbdi =   tpem_txdo_fram_pack[23:16]  ;
    assign  tpem_txdo_dat1_mbdi =   tpem_txdo_fram_pack[15: 8]  ;
    assign  tpem_txdo_dat0_mbdi =   tpem_txdo_fram_pack[ 7: 0]  ;


    edge_link_320p              u_tpes_rdxi_port    (
        .DATA_IN_FROM_PINS_P        (tpem_txdo_padp         ),//input	[ 4:0]	
        .DATA_IN_FROM_PINS_N        (tpem_txdo_padn         ),//input	[ 4:0]	
        .DATA_IN_TO_DEVICE          (tpem_txdo_fram_pack    ),//output	[39:0]	
    
        .DEBUG_IN                   (2'b0                   ),//input
        .DEBUG_OUT                  (                       ),//output
        .BITSLIP                    (tpem_tune_bslp         ),//input		
        .CLK_IN_P                   (tpem_fclk_inpp         ),//input		
        .CLK_IN_N                   (tpem_fclk_inpn         ),//input		
        .CLK_DIV_OUT                (tpem_sclk              ),//output
        .tpem_fclk                  (tpem_fclk              ),//output
        .IO_RESET                   (isde_prst              ));//input

    tpes_link_rxdi_tune         u_tpes_link_rxdi_tune(
        .tpem_tune_bslp	            (tpem_tune_bslp         ),
    
        .tpem_tune_mode	            (tpem_tune_txdo         ),
        .tpem_txdo_pack	            (tpem_txdo_fram_pack    ),
        .tpem_sclk                  (tpem_sclk              ),
        .tpem_rstn                  (tpem_rstn              ),
    
        .tpes_tune_good             (				        ),
        .tpes_tune_acks             (tpes_tune_acks_patn    ),
        .tpes_sclk                  (tpes_sclk              ),
        .tpes_rstn                  (tpes_rstn              ));	


endmodule