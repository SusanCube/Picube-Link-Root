
module  tpes_link_txrx_esse(
	input							tpem_tune_txdo      ,
	input							tpem_tune_rxdi      ,
	
    input							tpem_fclk_inpp      ,
    input							tpem_fclk_inpn      ,
    input							tpem_fram_inpp      ,
    input							tpem_fram_inpn      ,
    input							tpem_dat0_inpp      ,
    input							tpem_dat0_inpn      ,
    input							tpem_dat1_inpp      ,
    input							tpem_dat1_inpn      ,
    input							tpem_dat2_inpp      ,
    input							tpem_dat2_inpn      ,
    input							tpem_dat3_inpp      ,
    input							tpem_dat3_inpn      ,

	output							tpes_fclk_outp		,
	output							tpes_fclk_outn		,
	output							tpes_fram_outp		,
	output							tpes_fram_outn		,
	output							tpes_dat0_outp		,
	output							tpes_dat0_outn		,
	output							tpes_dat1_outp		,
	output							tpes_dat1_outn		,
	output							tpes_dat2_outp		,
	output							tpes_dat2_outn		,
	output							tpes_dat3_outp		,
	output							tpes_dat3_outn		,

	output		[ 0: 9]				tpem_link_cmnd_mark	,
	output							tpem_link_cmnd_lead	,
	output							tpem_link_cmnd_wrcs	,
	output							tpem_link_cmnd_coda	,
    output		[31: 0]        	    tpem_link_cmnd_word ,

	output							tpem_link_data_lead	,
	output							tpem_link_data_wrcs	,
	output		[31: 0]				tpem_link_data_word	,

	output 							tpem_sclk			,
	output 							tpem_fclk			,
	input  							tpem_rstn			,
	input  							isde_prst			,
//-------------------------------------------------------
	input		[ 7: 0]				tpes_scut_fram_mbdi ,
    input		[ 7: 0]				tpes_scut_dat3_mbdi ,
	input		[ 7: 0]				tpes_scut_dat2_mbdi ,
    input		[ 7: 0]				tpes_scut_dat1_mbdi ,
    input		[ 7: 0]				tpes_scut_dat0_mbdi ,
    
	input		[ 7: 0]				tpes_acks_fram_mbdi ,
    input		[ 7: 0]				tpes_acks_dat3_mbdi ,
	input		[ 7: 0]				tpes_acks_dat2_mbdi ,
    input		[ 7: 0]				tpes_acks_dat1_mbdi ,
    input		[ 7: 0]				tpes_acks_dat0_mbdi ,
    
	input		[ 7: 0]				tpes_dlnk_fram_mbdi ,
    input		[ 7: 0]				tpes_dlnk_dat3_mbdi ,
	input		[ 7: 0]				tpes_dlnk_dat2_mbdi ,
    input		[ 7: 0]				tpes_dlnk_dat1_mbdi ,
    input		[ 7: 0]				tpes_dlnk_dat0_mbdi ,
	
	input  							tpes_fclk			,
	input  							tpes_strb			,
	input  							tpes_sclk			,
	input  							tpes_rstn			);
//----------------------------------------------------------------------------------------------------------
    wire      	[ 7: 0]             tpem_txdo_fram_mbdi ;
    wire      	[ 7: 0]             tpem_txdo_dat0_mbdi ;
    wire      	[ 7: 0]             tpem_txdo_dat1_mbdi ;
    wire      	[ 7: 0]             tpem_txdo_dat2_mbdi ;
    wire      	[ 7: 0]             tpem_txdo_dat3_mbdi ;

	wire      	[39: 0]             tpes_tune_acks_patn ;
	wire      	[ 7: 0]             tpes_ttxd_fram_mbdi =	tpes_tune_acks_patn[39:32]	;
	wire      	[ 7: 0]             tpes_ttxd_dat3_mbdi =	tpes_tune_acks_patn[31:24]	;
	wire      	[ 7: 0]             tpes_ttxd_dat2_mbdi =	tpes_tune_acks_patn[23:16]	;
	wire      	[ 7: 0]             tpes_ttxd_dat1_mbdi =	tpes_tune_acks_patn[15: 8]	;
	wire      	[ 7: 0]             tpes_ttxd_dat0_mbdi =	tpes_tune_acks_patn[ 7: 0]	;
	

	tpes_link_rxdi_esse			u_tpes_link_rxdi_esse(
        .tpem_tune_txdo      		(tpem_tune_txdo				),//input 
        .tpem_fclk_inpp      		(tpem_fclk_inpp				),//input 
        .tpem_fclk_inpn      		(tpem_fclk_inpn				),//input 
        .tpem_fram_inpp      		(tpem_fram_inpp				),//input 
        .tpem_fram_inpn      		(tpem_fram_inpn				),//input 
        .tpem_dat0_inpp      		(tpem_dat0_inpp				),//input 
        .tpem_dat0_inpn      		(tpem_dat0_inpn				),//input 
        .tpem_dat1_inpp      		(tpem_dat1_inpp				),//input 
        .tpem_dat1_inpn      		(tpem_dat1_inpn				),//input 
        .tpem_dat2_inpp      		(tpem_dat2_inpp				),//input 
        .tpem_dat2_inpn      		(tpem_dat2_inpn				),//input 
        .tpem_dat3_inpp      		(tpem_dat3_inpp				),//input 
        .tpem_dat3_inpn      		(tpem_dat3_inpn				),//input 

		.tpem_txdo_fram_mbdi		(tpem_txdo_fram_mbdi		),//output      [ 7: 0] 
		.tpem_txdo_dat0_mbdi		(tpem_txdo_dat0_mbdi		),//output      [ 7: 0] 
		.tpem_txdo_dat1_mbdi		(tpem_txdo_dat1_mbdi		),//output      [ 7: 0] 
		.tpem_txdo_dat2_mbdi		(tpem_txdo_dat2_mbdi		),//output      [ 7: 0] 
		.tpem_txdo_dat3_mbdi		(tpem_txdo_dat3_mbdi		),//output      [ 7: 0] 
		.tpes_tune_acks_patn		(tpes_tune_acks_patn		),//output      [39: 0] 

		.tpem_sclk					(tpem_sclk					),//output 
		.tpem_fclk					(tpem_fclk					),//output 
		.tpem_rstn					(tpem_rstn					),//input  
		.tpes_sclk					(tpes_sclk					),//input  
		.tpes_rstn					(tpes_rstn					),//input  
		.isde_prst					(isde_prst					));//input  

	tpes_link_rxdi_port			u_tpes_link_rxdi_port(
		.link_rxdi_port_init		(1'b0					),//input

		.link_rxdi_fram_mbdi		(tpem_txdo_fram_mbdi	),//input	[7:0]	
		.link_rxdi_dat0_mbdi		(tpem_txdo_dat0_mbdi	),//input	[7:0]	
		.link_rxdi_dat1_mbdi		(tpem_txdo_dat1_mbdi	),//input	[7:0]	
		.link_rxdi_dat2_mbdi		(tpem_txdo_dat2_mbdi	),//input	[7:0]	
		.link_rxdi_dat3_mbdi		(tpem_txdo_dat3_mbdi	),//input	[7:0]	

		.link_rxdi_icfg_mark		(tpem_link_cmnd_mark[0 ]),//output	
		.link_rxdi_ocfg_mark		(tpem_link_cmnd_mark[1 ]),//output	
		.link_rxdi_nnex_mark		(tpem_link_cmnd_mark[2 ]),//output	
		.link_rxdi_ivct_mark		(tpem_link_cmnd_mark[3 ]),//output	
		.link_rxdi_ovct_mark		(tpem_link_cmnd_mark[4 ]),//output	
		.link_rxdi_imtx_mark		(tpem_link_cmnd_mark[5 ]),//output	
		.link_rxdi_omtx_mark		(tpem_link_cmnd_mark[6 ]),//output	
		.link_rxdi_aset_mark		(tpem_link_cmnd_mark[7 ]),//output	
		.link_rxdi_dnld_mark		(tpem_link_cmnd_mark[8 ]),//output	
		.link_rxdi_boot_mark		(tpem_link_cmnd_mark[9 ]),//output	
	
		.link_rxdi_cmnd_lead		(tpem_link_cmnd_lead	),//output	reg			
		.link_rxdi_cmnd_wrcs		(tpem_link_cmnd_wrcs	),//output	reg			
		.link_rxdi_cmnd_coda		(tpem_link_cmnd_coda	),//output	reg			
        .link_rxdi_cmnd_word		(tpem_link_cmnd_word	),//output  reg [31: 0]

		.link_rxdi_data_lead		(tpem_link_data_lead	),//output	reg			
		.link_rxdi_data_wrcs		(tpem_link_data_wrcs	),//output	reg			
		.link_rxdi_data_word		(tpem_link_data_word	),//output	reg	[31: 0]

		.link_clki					(tpem_sclk 				),//input	
		.link_rstn					(tpem_rstn 				));//input	

	tpes_link_txdo_esse			u_tpes_link_txdo_esse(
		.tune_txdo_enab				(tpem_tune_txdo				),//input
		.tune_rxdi_enab				(tpem_tune_rxdi				),//input
		
		.tpes_fclk_outp				(tpes_fclk_outp				),//output
		.tpes_fclk_outn				(tpes_fclk_outn				),//output
		.tpes_fram_outp				(tpes_fram_outp				),//output
		.tpes_fram_outn				(tpes_fram_outn				),//output
		.tpes_dat0_outp				(tpes_dat0_outp				),//output
		.tpes_dat0_outn				(tpes_dat0_outn				),//output
		.tpes_dat1_outp				(tpes_dat1_outp				),//output
		.tpes_dat1_outn				(tpes_dat1_outn				),//output
		.tpes_dat2_outp				(tpes_dat2_outp				),//output
		.tpes_dat2_outn				(tpes_dat2_outn				),//output
		.tpes_dat3_outp				(tpes_dat3_outp				),//output
		.tpes_dat3_outn				(tpes_dat3_outn				),//output


		.ttxd_fram_mbdi				(tpes_ttxd_fram_mbdi		),//input	[ 7: 0]	
		.ttxd_dat3_mbdi				(tpes_ttxd_dat3_mbdi		),//input	[ 7: 0]	
		.ttxd_dat2_mbdi				(tpes_ttxd_dat2_mbdi		),//input	[ 7: 0]	
		.ttxd_dat1_mbdi				(tpes_ttxd_dat1_mbdi		),//input	[ 7: 0]	
		.ttxd_dat0_mbdi				(tpes_ttxd_dat0_mbdi		),//input	[ 7: 0]	
		
		.scut_fram_mbdi				(tpes_scut_fram_mbdi		),//input	[ 7: 0]	
		.scut_dat3_mbdi				(tpes_scut_dat3_mbdi		),//input	[ 7: 0]	
		.scut_dat2_mbdi				(tpes_scut_dat2_mbdi		),//input	[ 7: 0]	
		.scut_dat1_mbdi				(tpes_scut_dat1_mbdi		),//input	[ 7: 0]	
		.scut_dat0_mbdi				(tpes_scut_dat0_mbdi		),//input	[ 7: 0]	
		
		.acks_fram_mbdi				(tpes_acks_fram_mbdi		),//input	[ 7: 0]	
		.acks_dat3_mbdi				(tpes_acks_dat3_mbdi		),//input	[ 7: 0]	
		.acks_dat2_mbdi				(tpes_acks_dat2_mbdi		),//input	[ 7: 0]	
		.acks_dat1_mbdi				(tpes_acks_dat1_mbdi		),//input	[ 7: 0]	
		.acks_dat0_mbdi				(tpes_acks_dat0_mbdi		),//input	[ 7: 0]	
		
		.dlnk_fram_mbdi				(tpes_dlnk_fram_mbdi		),//input	[ 7: 0]	
		.dlnk_dat3_mbdi				(tpes_dlnk_dat3_mbdi		),//input	[ 7: 0]	
		.dlnk_dat2_mbdi				(tpes_dlnk_dat2_mbdi		),//input	[ 7: 0]	
		.dlnk_dat1_mbdi				(tpes_dlnk_dat1_mbdi		),//input	[ 7: 0]	
		.dlnk_dat0_mbdi				(tpes_dlnk_dat0_mbdi		),//input	[ 7: 0]	
		
		.tpes_fclk					(tpes_fclk					),//input	
		.tpes_sclk					(tpes_sclk					),//input	
		.tpes_strb					(tpes_strb					),//input	//40Mhz VS 160Mhz 1/4 
		.tpes_rstn	   				(tpes_rstn					));//input	



endmodule

 