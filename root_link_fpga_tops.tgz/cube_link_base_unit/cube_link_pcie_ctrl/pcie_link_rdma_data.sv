/*----author edward------*/
module	pcie_link_rdma_data(
	input		[19 : 0]				pcie_xdma_rows_numb	,
	input		[31 : 0]				pcie_xdma_cols_numb	,
	input		[24 : 0]				pcie_link_rdma_base	,
	input								pcie_link_rdma_enab	,
	output								pcie_link_rdma_done	,

	input								pcie_axis_rdma_trdy	,
	output								pcie_axis_rdma_drdy	,
	output								pcie_axis_rdma_last	,
	output		[255:0]					pcie_axis_rdma_data	,
	input								pcie_aclk			,
	input								pcie_bclk			,
	input								pcie_rstn			,

	output								ubus_pcie_rdma_csen	,
	output	reg	[ 24: 0]				ubus_pcie_rdma_addr	,
	input								ubus_pcie_rdma_trdy	,
	input		[255: 0]				ubus_pcie_rdma_data	,
	input								ubus_pcie_rdma_drdy	,

	input								ubus_clki			,
	input								ubus_rstn			);
/**********************************************************************************************************/
	reg			[ 23:0]					pcie_rdma_page_size	;
	reg			[ 23:0]					pcie_rdma_page_addr	;

	wire		[ 23:0]					pcie_rdma_page_numb	;
	wire		[ 23:0]					pcie_rdma_page_leng	;
	wire								pcie_rdma_page_tail	;
	
	assign	pcie_rdma_page_leng	=		pcie_xdma_cols_numb[27: 4];
	assign	pcie_rdma_page_tail	= |		pcie_xdma_cols_numb[ 3: 0];
	assign	pcie_rdma_page_numb	=		pcie_rdma_page_leng + pcie_rdma_page_tail	;
	
	always@(posedge pcie_bclk or negedge  pcie_rstn)
	if(~pcie_rstn)						pcie_rdma_page_size	<=	0	;
	else if(~pcie_link_rdma_enab)		pcie_rdma_page_size	<=	pcie_rdma_page_numb	;	

	always@(posedge pcie_bclk or negedge  pcie_rstn)
	if(~pcie_rstn)						pcie_rdma_page_addr	<=	0	;
	else if(~pcie_link_rdma_enab)		pcie_rdma_page_addr	<=	pcie_link_rdma_base	;	
/**********************************************************************************************************/
	reg			[ 2: 0]					ubus_rdma_enab_samp	;
	reg			[ 2: 0]					pcie_axis_rdma_samp	;

	wire								ubus_ddrs_rdma_disa	=	ubus_rdma_enab_samp[1:0] == 2'B00	;
	wire								ubus_ddrs_rdma_init	=	ubus_rdma_enab_samp[1:0] == 2'B10	;

	wire								pcie_axis_rdma_disa	= 	pcie_axis_rdma_samp[1:0] ==	2'b00	;
	wire								pcie_axis_rdma_init	= 	pcie_axis_rdma_samp[1:0] ==	2'b10	;

	always@(posedge ubus_clki or negedge ubus_rstn)
	if(~ubus_rstn)						ubus_rdma_enab_samp	<=	0	;
	else								ubus_rdma_enab_samp	<={	pcie_link_rdma_enab	, ubus_rdma_enab_samp[2:1]	};	
	
	always@(posedge pcie_aclk or negedge  pcie_rstn)
	if(~pcie_rstn)						pcie_axis_rdma_samp	<=	0	;
	else								pcie_axis_rdma_samp	<={	pcie_link_rdma_enab	, pcie_axis_rdma_samp[2:1]	};
//----------------------------------------------------------------------------------------------------------
	reg									pcie_rdma_done_extn	;
	reg			[ 2: 0]					pcie_rdma_done_samp	;

	always@(posedge pcie_aclk or negedge  pcie_rstn)
	if(~pcie_rstn)						pcie_rdma_done_extn	<=	0	;
	else if( pcie_axis_rdma_disa)		pcie_rdma_done_extn	<=	0	;
	else if( pcie_axis_rdma_last)		pcie_rdma_done_extn	<=	1	;

	always@(posedge pcie_bclk or negedge  pcie_rstn)
	if(~pcie_rstn)						pcie_rdma_done_samp	<=	0	;
	else if(~pcie_link_rdma_enab)		pcie_rdma_done_samp	<=	0	;
	else								pcie_rdma_done_samp	<={ pcie_rdma_done_extn	, pcie_rdma_done_samp[2:1]	};

	assign	pcie_link_rdma_done	=		pcie_rdma_done_samp[0]	;
/**********************************************************************************************************/
	reg									ubus_rdma_cmnd_enab	;
	reg									ubus_rdma_data_enab	;
	reg		[23: 0]						ubus_rdma_cmnd_cnts	;
	reg		[23: 0]						ubus_rdma_data_cnts	;

	wire	[23: 0]						ubus_rdma_limt_cnts	;
	wire	[23: 0]						ubus_pcie_pops_cnts	;

	wire	[ 8: 0]						ubus_rdma_push_dptr	;
	
	assign	ubus_rdma_limt_cnts	=		ubus_pcie_pops_cnts + 64	;
	assign	ubus_rdma_push_dptr	=		ubus_rdma_data_cnts[8:0]	;

	wire								ubus_rdma_cmnd_goon	;
	wire								ubus_rdma_data_vlid	;

	wire								ubus_rdma_cmnd_last	;
	wire								ubus_rdma_data_last	;
	
	assign	ubus_rdma_cmnd_goon	= 	&{	ubus_rdma_cmnd_enab	,	ubus_rdma_data_cnts	<=	ubus_rdma_limt_cnts	};
	assign	ubus_pcie_rdma_csen	= 	&{	ubus_rdma_cmnd_enab	,	ubus_pcie_rdma_trdy	,	ubus_rdma_cmnd_goon	};
	assign	ubus_rdma_cmnd_last	= 	&{	ubus_pcie_rdma_csen	,	ubus_rdma_cmnd_cnts +1==pcie_rdma_page_size };

	assign	ubus_rdma_data_vlid	= 	&{	ubus_rdma_data_enab	,	ubus_pcie_rdma_drdy	};	
	assign	ubus_rdma_data_last	= 	&{	ubus_rdma_data_vlid	,	ubus_rdma_data_cnts +1==pcie_rdma_page_size };
		
	always@(posedge ubus_clki or negedge ubus_rstn)
	if(~ubus_rstn)						ubus_rdma_cmnd_enab	<=	0	;
	else if(ubus_ddrs_rdma_disa)		ubus_rdma_cmnd_enab	<=	0	;
	else if(ubus_ddrs_rdma_init)		ubus_rdma_cmnd_enab	<=	1	;
	else if(ubus_rdma_cmnd_last)		ubus_rdma_cmnd_enab	<=	0	;

	always@(posedge ubus_clki or negedge ubus_rstn)
	if(~ubus_rstn)						ubus_rdma_cmnd_cnts	<=	0	;
	else if(ubus_ddrs_rdma_disa)		ubus_rdma_cmnd_cnts	<=	0	;
	else if(ubus_ddrs_rdma_init)		ubus_rdma_cmnd_cnts	<=	0 	;
	else if(ubus_pcie_rdma_csen)		ubus_rdma_cmnd_cnts	<=	ubus_rdma_cmnd_cnts + 1	;

	always@(posedge ubus_clki or negedge ubus_rstn)
	if(~ubus_rstn)						ubus_pcie_rdma_addr	<=	0	;
	else if(ubus_ddrs_rdma_disa)		ubus_pcie_rdma_addr	<=	0	;
	else if(ubus_ddrs_rdma_init)		ubus_pcie_rdma_addr	<=	pcie_rdma_page_addr   	;
	else if(ubus_pcie_rdma_csen)		ubus_pcie_rdma_addr	<=	ubus_pcie_rdma_addr +1	;

	always@(posedge ubus_clki or negedge ubus_rstn)
	if(~ubus_rstn)						ubus_rdma_data_enab	<=	0	;
	else if(ubus_ddrs_rdma_disa)		ubus_rdma_data_enab	<=	0	;
	else if(ubus_ddrs_rdma_init)		ubus_rdma_data_enab	<=	1	;
	else if(ubus_rdma_data_last)		ubus_rdma_data_enab	<=	0	;

	always@(posedge ubus_clki or negedge ubus_rstn)
	if(~ubus_rstn)						ubus_rdma_data_cnts	<=	0	;
	else if(ubus_ddrs_rdma_disa)		ubus_rdma_data_cnts	<=	0	;
	else if(ubus_ddrs_rdma_init)		ubus_rdma_data_cnts	<=	0	;
	else if(ubus_rdma_data_vlid)		ubus_rdma_data_cnts	<=	ubus_rdma_data_cnts +1	;
/**********************************************************************************************************/
/**********************************************************************************************************/
	reg		[23: 0]						pcie_rdma_data_cnts	;
	reg									pcie_axis_rdma_csen	;

	wire								pcie_axis_rdma_vlid	;
	
	always@(posedge pcie_aclk or negedge pcie_rstn)
	if(~pcie_rstn)						pcie_axis_rdma_csen	<=	0	;
	else if( pcie_axis_rdma_disa)		pcie_axis_rdma_csen	<=	0	;
	else if( pcie_axis_rdma_init)		pcie_axis_rdma_csen	<=	1	;
	else if( pcie_axis_rdma_last)		pcie_axis_rdma_csen	<=	0	;

	always@(posedge pcie_aclk or negedge  pcie_rstn)
	if(~pcie_rstn)						pcie_rdma_data_cnts	<=	0	;
	else if( pcie_axis_rdma_disa)		pcie_rdma_data_cnts	<=	0	;
	else if( pcie_axis_rdma_vlid)		pcie_rdma_data_cnts	<=	pcie_rdma_data_cnts + 1	;
//----------------------------------------------------------------------------------------------------------
	wire	[ 8: 0]						pcie_rdma_data_lsba	;
	wire	[ 8: 0]						pcie_rdma_data_nxta	;
	wire	[ 8: 0]						pcie_rdma_data_dptr	;

	wire	[23: 0]						pcie_rdma_data_inc1	;
	wire	[23: 0]						pcie_ubus_push_cnts	;
	
	assign	pcie_rdma_data_lsba	=	pcie_rdma_data_cnts[8:0]	;
	assign	pcie_rdma_data_nxta	=	pcie_rdma_data_lsba + 1		;
	assign	pcie_rdma_data_inc1	=	pcie_rdma_data_cnts + 1		;
	assign	pcie_rdma_data_dptr	=	pcie_axis_rdma_vlid	?	pcie_rdma_data_nxta	:	pcie_rdma_data_lsba	;

	assign	pcie_axis_rdma_vlid	= &{pcie_axis_rdma_csen	,	pcie_axis_rdma_drdy	,	pcie_axis_rdma_trdy	};
	assign	pcie_axis_rdma_drdy	= &{pcie_axis_rdma_csen	,	pcie_ubus_push_cnts	> 	pcie_rdma_data_cnts	};
	assign	pcie_axis_rdma_last	= &{pcie_axis_rdma_vlid	,	pcie_rdma_page_size	==	pcie_rdma_data_inc1	};
/**********************************************************************************************************/
	gens_sync_gray	#( .MSB(23) )
								u_ubus_dptr_sync_gens(
		.data_asyn					(ubus_rdma_data_cnts	),//input	[23: 0]	
		.scki						(ubus_clki				),

		.data_sync					(pcie_ubus_push_cnts	),//output	[23: 0]	
		.clki						(pcie_aclk				),//input			
		.rstn						(pcie_rstn				));//input			

	gens_sync_gray	#( .MSB(23) )
								u_pcie_dptr_sync_gens(
		.data_asyn					(pcie_rdma_data_cnts	),//input	[23: 0]	
		.scki						(pcie_aclk				),
		
		.data_sync					(ubus_pcie_pops_cnts	),//output	[23: 0]	
		.clki						(ubus_clki				),//input			
		.rstn						(ubus_rstn				));//input			


	dual_port_bram	#(	
		.ADDR_BITS	( 9 ),	.DATA_BITS	( 256 ))	
	u_idat_rdma_beat_data (
		.wport_csen					(ubus_rdma_data_vlid	),//input  				 		
		.wport_data					(ubus_pcie_rdma_data	),//input		[DATA_BITS-1:0]
		.wport_addr					(ubus_rdma_push_dptr	),//input		[ADDR_BITS-1:0]
		.wport_clki					(ubus_clki				),//input						

		.rport_addr					(pcie_rdma_data_dptr	),//input		[ADDR_BITS-1:0]
		.rport_data					(pcie_axis_rdma_data	),//output	reg	[DATA_BITS-1:0]
		.rport_clki					(pcie_aclk				));//input						
 

endmodule 
 
