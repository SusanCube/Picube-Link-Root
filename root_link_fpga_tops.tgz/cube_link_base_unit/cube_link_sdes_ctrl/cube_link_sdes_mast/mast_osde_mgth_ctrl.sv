/*----author edward------*/
module	mast_osde_mgth_ctrl(
	input		[ 3:  1]			mast_devs_osde_port	,		
	input							mast_devs_osde_enab	,
	output							mast_devs_osde_done	,

	input		[24 : 0]			mosx_devs_ddrs_base	,
	input		[24 : 0]			mosx_devs_ddrs_size	,
	
	input							link_clki			,
	input							link_rstn			,

	input							mgt1_osde_rdma_trdy	,
	output							mgt1_osde_rdma_drdy	,
	output		[255: 0]			mgt1_osde_rdma_data	,
	input							mgt1_clki			,
	input							mgt1_rstn			,

	input							mgt2_osde_rdma_trdy	,
	output							mgt2_osde_rdma_drdy	,
	output		[255: 0]			mgt2_osde_rdma_data	,
	input							mgt2_clki			,
	input							mgt2_rstn			,
	
	input							mgt3_osde_rdma_trdy	,
	output							mgt3_osde_rdma_drdy	,
	output		[255: 0]			mgt3_osde_rdma_data	,
	input							mgt3_clki			,
	input							mgt3_rstn			,

	output	reg						ubus_osde_rdma_csen	,
	output	reg	[ 24: 0]			ubus_osde_rdma_addr	,
	input							ubus_osde_rdma_trdy	,
	input		[255: 0]			ubus_osde_rdma_data	,
	input							ubus_osde_rdma_drdy	,

	input							ubus_clki			,
	input							ubus_rstn			);
/**********************************************************************************************************/
//sync enable mode signal
	reg			[ 1: 0]				ubus_rdma_enab_samp	;
	reg			[ 1: 0]				ubus_rdma_done_samp	;

	reg			[21: 0]				mast_osde_pack_numb	;

	wire							ubus_rdma_proc_disa	= ~	ubus_rdma_enab_samp[0]	;
	wire							ubus_rdma_proc_enab	=	ubus_rdma_enab_samp[0]	;
	
	wire							ubus_osde_rdma_done	;

	always@(posedge ubus_clki or negedge  ubus_rstn)
	if(~ubus_rstn)					ubus_rdma_enab_samp	<=	0	;
	else							ubus_rdma_enab_samp	<={	mast_devs_osde_enab	, ubus_rdma_enab_samp[1]	};	

	always@(posedge link_clki or negedge  link_rstn)
	if(~link_rstn)					ubus_rdma_done_samp	<=	0	;
	else							ubus_rdma_done_samp	<={	ubus_osde_rdma_done	, ubus_rdma_done_samp[1]	};	

	always@(posedge ubus_clki or negedge  ubus_rstn)
	if(~ubus_rstn)					mast_osde_pack_numb	<=	0	;
	else if(ubus_rdma_proc_disa)	mast_osde_pack_numb	<=	mosx_devs_ddrs_size[24:3]	;	
//----------------------------------------------------------------------------------------------------------
	reg								mgt1_osde_port_selx	;	
	reg								mgt2_osde_port_selx	;	
	reg								mgt3_osde_port_selx	;	

	reg		[ 1: 0]					mgt1_osde_csen_samp	;	
	reg		[ 1: 0]					mgt2_osde_csen_samp	;	
	reg		[ 1: 0]					mgt3_osde_csen_samp	;	

	always@(posedge link_clki or negedge  link_rstn)
	if(~link_rstn)					begin				
		mgt1_osde_port_selx	<=	0	;
		mgt2_osde_port_selx	<=	0	;
		mgt3_osde_port_selx	<=	0	;
	end	else						begin			
		mgt1_osde_port_selx	<= &{mast_devs_osde_enab , mast_devs_osde_port[1]	};	
		mgt2_osde_port_selx	<= &{mast_devs_osde_enab , mast_devs_osde_port[2]	};	
		mgt3_osde_port_selx	<= &{mast_devs_osde_enab , mast_devs_osde_port[3]	};	
	end
//----------------------------------------------------------------------------------------------------------
	wire	mgt1_osde_port_enab	=	mgt1_osde_csen_samp[0]	;	
	wire	mgt2_osde_port_enab	=	mgt2_osde_csen_samp[0]	;	
	wire	mgt3_osde_port_enab	=	mgt3_osde_csen_samp[0]	;	

	always@(posedge mgt1_clki or negedge  mgt1_rstn)
	if(~mgt1_rstn)					mgt1_osde_csen_samp	<=	0	;
	else							mgt1_osde_csen_samp	<={	mgt1_osde_port_selx	, mgt1_osde_csen_samp[1]	};	

	always@(posedge mgt2_clki or negedge  mgt2_rstn)
	if(~mgt2_rstn)					mgt2_osde_csen_samp	<=	0	;
	else							mgt2_osde_csen_samp	<={	mgt2_osde_port_selx	, mgt2_osde_csen_samp[1]	};	
	
	always@(posedge mgt3_clki or negedge  mgt3_rstn)
	if(~mgt3_rstn)					mgt3_osde_csen_samp	<=	0	;
	else							mgt3_osde_csen_samp	<={	mgt3_osde_port_selx	, mgt3_osde_csen_samp[1]	};	
/**********************************************************************************************************/
	reg		[2: 0]					ubus_osde_rdma_mfsm	;

	reg								ubus_osde_page_csen	;
	reg		[21: 0]					ubus_osde_pack_cnts	;
	reg		[ 2 :0]					ubus_rdma_cmnd_cnts	;
	reg		[ 2 :0]					ubus_rdma_page_cnts	;

	parameter	OSDE_MAST_UBUS_IDLE	=	4'H0	;
	parameter	OSDE_MAST_UBUS_REQS	=	4'H1	;
	parameter	OSDE_MAST_UBUS_CMND	=	4'H2	;
	parameter	OSDE_MAST_UBUS_PACK	=	4'H3	;
	parameter	OSDE_MAST_MGTH_REQS	=	4'H4	;
	parameter	OSDE_MAST_MGTH_PACK	=	4'H5	;
	parameter	OSDE_MAST_UBUS_LOOP	=	4'H6	;
	parameter	OSDE_MAST_UBUS_DONE	=	4'H7	;

	wire							ubus_rdma_cmnd_done	;
	wire							ubus_rdma_pack_done	;
	wire							ubus_rdma_proc_done	;

	wire							ubus_rdma_cmnd_vlid	;
	wire							ubus_rdma_page_vlid	;

	wire							mgth_osde_port_reqs	;
	wire							mgth_osde_pack_acks	;
	wire							mgth_osde_pack_done	;

	assign		ubus_rdma_cmnd_vlid	= &{ubus_osde_rdma_csen	,	ubus_osde_rdma_trdy	};
	assign		ubus_rdma_page_vlid	= &{ubus_osde_page_csen	,	ubus_osde_rdma_drdy	};
	assign		ubus_rdma_cmnd_done	= &{ubus_rdma_cmnd_vlid	,	ubus_rdma_cmnd_cnts };
	assign		ubus_rdma_pack_done	= &{ubus_rdma_page_vlid	,	ubus_rdma_page_cnts };
	assign		ubus_rdma_proc_done	= &{ubus_osde_pack_cnts	==	mast_osde_pack_numb };

	wire		ubus_hits_rdma_idle	=	ubus_osde_rdma_mfsm	==	OSDE_MAST_UBUS_IDLE	;
	wire		ubus_rdma_pack_reqs	=	ubus_osde_rdma_mfsm	==	OSDE_MAST_UBUS_REQS	;

	assign		mgth_osde_port_reqs	=	ubus_osde_rdma_mfsm	==	OSDE_MAST_MGTH_REQS	;
	assign		mast_devs_osde_done	=	ubus_osde_rdma_mfsm	==	OSDE_MAST_UBUS_DONE	;
//----------------------------------------------------------------------------------------------------------	
	always@(posedge ubus_clki or negedge  ubus_rstn)
	if(~ubus_rstn)					ubus_osde_rdma_csen	<=	0	;
	else if( ubus_rdma_proc_disa)	ubus_osde_rdma_csen	<=	0	;
	else if( ubus_rdma_pack_reqs)	ubus_osde_rdma_csen	<=	1	;
	else if( ubus_rdma_cmnd_done)	ubus_osde_rdma_csen	<=	0	;

	always@(posedge ubus_clki or negedge  ubus_rstn)
	if(~ubus_rstn)					ubus_osde_rdma_addr	<=	0	;
	else if( ubus_rdma_proc_disa)	ubus_osde_rdma_addr	<=	mosx_devs_ddrs_base   	;
	else if( ubus_rdma_cmnd_vlid)	ubus_osde_rdma_addr	<=	ubus_osde_rdma_addr +1	;

	always@(posedge ubus_clki or negedge  ubus_rstn)
	if(~ubus_rstn)					ubus_osde_page_csen	<=	0	;
	else if( ubus_rdma_proc_disa)	ubus_osde_page_csen	<=	0	;
	else if( ubus_rdma_pack_reqs)	ubus_osde_page_csen	<=	1	;
	else if( ubus_rdma_pack_done)	ubus_osde_page_csen	<=	0	;

	always@(posedge ubus_clki or negedge  ubus_rstn)
	if(~ubus_rstn)					ubus_rdma_cmnd_cnts	<=	0	;
	else if( ubus_rdma_proc_disa)	ubus_rdma_cmnd_cnts	<=	0	;
	else if( ubus_rdma_pack_reqs)	ubus_rdma_cmnd_cnts	<=	0 	;
	else if( ubus_rdma_cmnd_done)	ubus_rdma_cmnd_cnts	<=	0 	;
	else if( ubus_rdma_cmnd_vlid)	ubus_rdma_cmnd_cnts	<=	ubus_rdma_cmnd_cnts +1	;

	always@(posedge ubus_clki or negedge  ubus_rstn)
	if(~ubus_rstn)					ubus_rdma_page_cnts	<=	0	;
	else if( ubus_rdma_proc_disa)	ubus_rdma_page_cnts	<=	0	;
	else if( ubus_rdma_pack_reqs)	ubus_rdma_page_cnts	<=	0	;
	else if( ubus_rdma_pack_done)	ubus_rdma_page_cnts	<=	0	;
	else if( ubus_rdma_page_vlid)	ubus_rdma_page_cnts	<=	ubus_rdma_page_cnts +1	;

	always@(posedge ubus_clki or negedge  ubus_rstn)
	if(~ubus_rstn)					ubus_osde_pack_cnts	<=	0	;
	else if( ubus_rdma_proc_disa)	ubus_osde_pack_cnts	<=	0  	;
	else if( ubus_rdma_pack_done)	ubus_osde_pack_cnts	<=	ubus_osde_pack_cnts +1	;
//----------------------------------------------------------------------------------------------------------	
	always@(posedge ubus_clki or negedge  ubus_rstn)
	if(~ubus_rstn)					ubus_osde_rdma_mfsm	<=	OSDE_MAST_UBUS_IDLE	;
	else if(ubus_rdma_proc_disa)	ubus_osde_rdma_mfsm	<=	OSDE_MAST_UBUS_IDLE	;
	else begin
		case(ubus_osde_rdma_mfsm)	
			OSDE_MAST_UBUS_IDLE	:	ubus_osde_rdma_mfsm	<=	ubus_rdma_proc_enab	?	OSDE_MAST_UBUS_REQS	:	OSDE_MAST_UBUS_IDLE	;
			
			OSDE_MAST_UBUS_REQS	:	ubus_osde_rdma_mfsm	<=													OSDE_MAST_UBUS_CMND	;
			OSDE_MAST_UBUS_CMND	:	ubus_osde_rdma_mfsm	<=	ubus_rdma_cmnd_done	?	OSDE_MAST_UBUS_PACK	:	OSDE_MAST_UBUS_CMND	;
			OSDE_MAST_UBUS_PACK	:	ubus_osde_rdma_mfsm	<=	ubus_rdma_pack_done	?	OSDE_MAST_MGTH_REQS	:	OSDE_MAST_UBUS_PACK	;
			OSDE_MAST_MGTH_REQS	:	ubus_osde_rdma_mfsm	<=	mgth_osde_pack_acks	?	OSDE_MAST_MGTH_PACK	:	OSDE_MAST_MGTH_REQS	;
			OSDE_MAST_MGTH_PACK	:	ubus_osde_rdma_mfsm	<=	mgth_osde_pack_done	?	OSDE_MAST_UBUS_LOOP	:	OSDE_MAST_MGTH_PACK	;
			OSDE_MAST_UBUS_LOOP	:	ubus_osde_rdma_mfsm	<=	ubus_rdma_proc_done	?	OSDE_MAST_UBUS_DONE	:	OSDE_MAST_UBUS_REQS	;

			OSDE_MAST_UBUS_DONE	:	ubus_osde_rdma_mfsm	<=	ubus_rdma_proc_enab	?	OSDE_MAST_UBUS_DONE	:	OSDE_MAST_UBUS_IDLE	;
		endcase
	end
/**********************************************************************************************************/
	wire							mgt1_ubus_osde_acks	;	
	wire							mgt2_ubus_osde_acks	;	
	wire							mgt3_ubus_osde_acks	;	

	wire							mgt1_ubus_osde_done	;	
	wire							mgt2_ubus_osde_done	;	
	wire							mgt3_ubus_osde_done	;	

	wire							mgt1_ubus_mask_acks	;	
	wire							mgt2_ubus_mask_acks	;	
	wire							mgt3_ubus_mask_acks	;	

	wire							mgt1_ubus_mask_done	;	
	wire							mgt2_ubus_mask_done	;	
	wire							mgt3_ubus_mask_done	;	

	assign	mgt1_ubus_mask_acks	=	mgt1_osde_port_enab	?	mgt1_ubus_osde_acks	:	1'B1	;
	assign	mgt2_ubus_mask_acks	=	mgt2_osde_port_enab	?	mgt2_ubus_osde_acks	:	1'B1	;
	assign	mgt3_ubus_mask_acks	=	mgt3_osde_port_enab	?	mgt3_ubus_osde_acks	:	1'B1	;

	assign	mgt1_ubus_mask_done	=	mgt1_osde_port_enab	?	mgt1_ubus_osde_done	:	1'B1	;
	assign	mgt2_ubus_mask_done	=	mgt2_osde_port_enab	?	mgt2_ubus_osde_done	:	1'B1	;
	assign	mgt3_ubus_mask_done	=	mgt3_osde_port_enab	?	mgt3_ubus_osde_done	:	1'B1	;

	assign	mgth_osde_pack_acks	= &{mgt1_ubus_mask_acks	,	mgt2_ubus_mask_acks	,	mgt3_ubus_mask_acks};
	assign	mgth_osde_pack_done	= &{mgt1_ubus_mask_done	,	mgt2_ubus_mask_done	,	mgt3_ubus_mask_done};
//----------------------------------------------------------------------
	wire							ubus_rdma_page_wrcs	= ubus_rdma_page_vlid	;	
	wire		[255: 0]			ubus_rdma_page_data	= ubus_osde_rdma_data	;	
//----------------------------------------------------------------------
	mgth_osde_pack_ctrl			u_mgt1_osde_pack_ctrl(
		.ubus_wrcs_pack_reqs		(ubus_rdma_pack_reqs	),//input				
		.ubus_wrcs_pack_enab		(ubus_rdma_page_wrcs	),//input				
		.ubus_wrcs_pack_data		(ubus_rdma_page_data	),//input		[255:0]	
		.ubus_clki					(ubus_clki				),//input				
		.ubus_rstn					(ubus_rstn				),//input				

		.mgth_osde_port_reqs		(mgth_osde_port_reqs	),//input				
		.mgth_osde_port_enab		(mgt1_osde_port_enab	),//input				
		.mgth_osde_port_acks		(mgt1_ubus_osde_acks	),//output				
		.mgth_osde_port_done		(mgt1_ubus_osde_done	),//output	

		.mgth_osde_pack_trdy		(mgt1_osde_rdma_trdy	),//input				
		.mgth_osde_pack_drdy		(mgt1_osde_rdma_drdy	),//output				
		.mgth_osde_pack_data		(mgt1_osde_rdma_data	),//output		[255:0]	
		.mgth_clki					(mgt1_clki				),//input				
		.mgth_rstn					(mgt1_rstn				));//input				
//----------------------------------------------------------------------
	mgth_osde_pack_ctrl			u_mgt2_osde_pack_ctrl(
		.ubus_wrcs_pack_reqs		(ubus_rdma_pack_reqs	),//input				
		.ubus_wrcs_pack_enab		(ubus_rdma_page_wrcs	),//input				
		.ubus_wrcs_pack_data		(ubus_rdma_page_data	),//input		[255:0]	
		.ubus_clki					(ubus_clki				),//input				
		.ubus_rstn					(ubus_rstn				),//input				

		.mgth_osde_port_reqs		(mgth_osde_port_reqs	),//input				
		.mgth_osde_port_enab		(mgt2_osde_port_enab	),//input				
		.mgth_osde_port_acks		(mgt2_ubus_osde_acks	),//output				
		.mgth_osde_port_done		(mgt2_ubus_osde_done	),//output	

		.mgth_osde_pack_trdy		(mgt2_osde_rdma_trdy	),//input				
		.mgth_osde_pack_drdy		(mgt2_osde_rdma_drdy	),//output				
		.mgth_osde_pack_data		(mgt2_osde_rdma_data	),//output		[255:0]	
		.mgth_clki					(mgt2_clki				),//input				
		.mgth_rstn					(mgt2_rstn				));//input				
//----------------------------------------------------------------------
	mgth_osde_pack_ctrl			u_mgt3_osde_pack_ctrl(
		.ubus_wrcs_pack_reqs		(ubus_rdma_pack_reqs	),//input				
		.ubus_wrcs_pack_enab		(ubus_rdma_page_wrcs	),//input				
		.ubus_wrcs_pack_data		(ubus_rdma_page_data	),//input		[255:0]	
		.ubus_clki					(ubus_clki				),//input				
		.ubus_rstn					(ubus_rstn				),//input				

		.mgth_osde_port_reqs		(mgth_osde_port_reqs	),//input				
		.mgth_osde_port_enab		(mgt3_osde_port_enab	),//input				
		.mgth_osde_port_acks		(mgt3_ubus_osde_acks	),//output				
		.mgth_osde_port_done		(mgt3_ubus_osde_done	),//output	

		.mgth_osde_pack_trdy		(mgt3_osde_rdma_trdy	),//input				
		.mgth_osde_pack_drdy		(mgt3_osde_rdma_drdy	),//output				
		.mgth_osde_pack_data		(mgt3_osde_rdma_data	),//output		[255:0]	
		.mgth_clki					(mgt3_clki				),//input				
		.mgth_rstn					(mgt3_rstn				));//input				
	 
endmodule 
	

//	wire	ubus_hits_rdma_cmnd	=	ubus_osde_rdma_mfsm	==	OSDE_MAST_UBUS_CMND	;
//	wire	ubus_hits_rdma_pack	=	ubus_osde_rdma_mfsm	==	OSDE_MAST_UBUS_DRDY	;
//	wire	ubus_hits_mght_pack	=	ubus_osde_rdma_mfsm	==	OSDE_MAST_MGTH_DRDY	;
//	wire	ubus_hits_rdma_loop	=	ubus_osde_rdma_mfsm	==	OSDE_MAST_UBUS_LOOP	;
