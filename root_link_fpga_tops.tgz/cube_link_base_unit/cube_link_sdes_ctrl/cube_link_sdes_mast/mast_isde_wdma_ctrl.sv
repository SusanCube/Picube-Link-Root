/*----author edward------*/
module	mast_isde_wdma_ctrl(
	output		[327:0]				uila_mgth_isde_wdma	,

	input							mast_isde_wdma_drdy	,
	input		[255:0]				mast_isde_wdma_data	,
	input							mgth_clki			,
	input							mgth_rstn			,

	input		[19: 0]				mast_meta_imag_cols	,
	
	input							mast_isde_wdma_enab	,
	input							mast_isde_wdma_mode	,
	output	reg						mast_isde_wdma_done	,

	input		[24: 0]				misx_devs_ddrs_size	,
	input		[24: 0]				mism_devs_ddrs_base	,
	input		[19: 0]				mism_devs_ddrs_cols	,
	input		[24: 0]				misv_devs_ddrs_base	,
	
	input							ubus_devs_wdma_vlid	,
	output							ubus_devs_wdma_reqs	,
	output		[ 24: 0]			ubus_devs_wdma_addr	,
	output		[255: 0]			ubus_devs_wdma_data	,
	input							ubus_clki			,
	input							ubus_rstn			);
/**********************************************************************************************************/
	reg		[  1: 0]				mast_isde_mode_samp	;
	reg		[  1: 0]				mast_isde_enab_samp	;
	reg		[  1: 0]				ubus_isde_enab_samp	;
	
	wire							ubus_isde_proc_disa	= ~	ubus_isde_enab_samp[0] 	;
	wire							mast_isde_proc_disa	= ~ mast_isde_enab_samp[0] 	;
	wire							mast_isde_proc_mode	=	mast_isde_mode_samp[0]	;
	
	always@(posedge mgth_clki or negedge  mgth_rstn)
	if(~mgth_rstn)					mast_isde_enab_samp	<=	0	;
	else							mast_isde_enab_samp	<={	mast_isde_wdma_enab	, mast_isde_enab_samp[ 1 ]	};	

	always@(posedge mgth_clki or negedge  mgth_rstn)
	if(~mgth_rstn)					mast_isde_mode_samp	<=	0	;
	else							mast_isde_mode_samp	<={	mast_isde_wdma_mode	, mast_isde_mode_samp[ 1 ]	};	
//----------------------------------------------------------------------
	always@(posedge ubus_clki or negedge  ubus_rstn)
	if(~ubus_rstn)					ubus_isde_enab_samp	<=	0	;
	else							ubus_isde_enab_samp	<={	mast_isde_wdma_enab	, ubus_isde_enab_samp[ 1 ]	};	
/**********************************************************************************************************/
	reg		[24: 0]					mast_isde_wdma_addr	;
	reg		[24: 0]					mast_isde_page_cnts	;
	reg		[24: 0]					mast_isde_push_cnts	;
	
	wire							mast_isde_page_vlid	;
	wire							mism_isde_page_last	;
	wire	[  5: 0]				mast_isde_push_dptr	;
	
	assign	mast_isde_page_vlid	= &{mast_isde_wdma_drdy	, ~ mast_isde_proc_disa	};
	assign	mism_isde_page_last	= &{mast_isde_page_vlid	,	mast_isde_page_cnts + 1 ==	mism_devs_ddrs_cols	};
	assign	mast_isde_push_dptr	=	mast_isde_push_cnts[ 5: 0]	;

	always@(posedge mgth_clki or negedge  mgth_rstn)
	if(~mgth_rstn)					mast_isde_page_cnts	<=	0	;
	else if( mast_isde_proc_disa)	mast_isde_page_cnts	<=	0	;	
	else if( mism_isde_page_last)	mast_isde_page_cnts	<=	0	;	
	else if( mast_isde_page_vlid)	mast_isde_page_cnts	<=	mast_isde_page_cnts	+ 1 	;	

	always@(posedge mgth_clki or negedge  mgth_rstn)
	if(~mgth_rstn)					mast_isde_push_cnts	<=	0	;
	else if(mast_isde_proc_disa)	mast_isde_push_cnts	<=	0	;	
	else 							mast_isde_push_cnts	<=	mast_isde_push_cnts	+ 	mast_isde_page_vlid	;	
//------------------------------------------------------------------------------	
	reg		[24: 0]					mism_mtrx_rows_dist	;

	wire	mism_isde_rows_next	= &{mast_isde_wdma_mode	,	mism_isde_page_last	};

	always@(posedge mgth_clki or negedge mgth_rstn )
	if(!mgth_rstn)					mism_mtrx_rows_dist	<=	0	;
	else if(mast_isde_proc_disa)	mism_mtrx_rows_dist	<=	mast_meta_imag_cols[19: 4]	;
	else if(mism_isde_rows_next)	mism_mtrx_rows_dist	<=	mism_mtrx_rows_dist + mast_meta_imag_cols[19: 4] ;
//------------------------------------------------------------------------------	
	always@(posedge mgth_clki or negedge mgth_rstn )
	if(~mgth_rstn)					mast_isde_wdma_addr	<=	0	;
	else if(~mast_isde_wdma_mode)	begin
		if( mast_isde_proc_disa)	mast_isde_wdma_addr	<=	misv_devs_ddrs_base	;
		else						mast_isde_wdma_addr	<=	mast_isde_wdma_addr	+	mast_isde_page_vlid	;
	end else						begin
		if( mast_isde_proc_disa)	mast_isde_wdma_addr	<=	mism_devs_ddrs_base	;
		else if(mism_isde_page_last)mast_isde_wdma_addr	<=	mism_devs_ddrs_base	+	mism_mtrx_rows_dist	;
		else						mast_isde_wdma_addr	<=	mast_isde_wdma_addr	+	mast_isde_page_vlid	;
	end
/**********************************************************************************************************/
//UBUS Clock Domain
	wire	[ 24: 0]				mast_isde_push_sync	;
	reg		[ 24: 0]				ubus_isde_wdma_cnts	;

	wire							ubus_wdma_page_last	;

	wire	[  5: 0]				ubus_wdma_pops_dptr	;
	wire	[  5: 0]				ubus_wdma_cnts_lsba	;
	wire	[  5: 0]				ubus_wdma_cnts_nxta	;

	assign	ubus_wdma_page_last	= &{ubus_devs_wdma_vlid	,	ubus_isde_wdma_cnts+1==	misx_devs_ddrs_size	};
	
	assign	ubus_wdma_cnts_lsba	=	ubus_isde_wdma_cnts[5:0]	;
	assign	ubus_wdma_cnts_nxta	=	ubus_wdma_cnts_lsba +  1	;
	assign	ubus_wdma_pops_dptr	=	ubus_devs_wdma_vlid	?	ubus_wdma_cnts_nxta	:	ubus_wdma_cnts_lsba	;

	assign	ubus_devs_wdma_reqs	=&{~ubus_isde_proc_disa	,
									mast_isde_push_sync	>=	ubus_isde_wdma_cnts + 8};

	always@(posedge ubus_clki or negedge ubus_rstn )
	if(!ubus_rstn)					ubus_isde_wdma_cnts	<=	0	;	
	else if(ubus_isde_proc_disa)	ubus_isde_wdma_cnts	<=	0	;	
	else 							ubus_isde_wdma_cnts	<=	ubus_isde_wdma_cnts + ubus_devs_wdma_vlid	;	

	always@(posedge ubus_clki or negedge ubus_rstn )
	if(!ubus_rstn)					mast_isde_wdma_done	<=	0	;	
	else if(ubus_isde_proc_disa)	mast_isde_wdma_done	<=	0	;	
	else if(ubus_wdma_page_last)	mast_isde_wdma_done	<=	1	;	
/**********************************************************************************************************/
	gens_sync_gray	#( .MSB(24) )
								u_ubus_dptr_sync_gens(
		.data_asyn					(mast_isde_push_cnts	),//input	[24: 0]	
		.scki						(mgth_clki				),
					
		.data_sync					(mast_isde_push_sync	),//output	[24: 0]	
		.clki						(ubus_clki				),//input			
		.rstn						(ubus_rstn				));//input			

	dual_port_bram	#(	
		.ADDR_BITS	( 6 ),	.DATA_BITS	( 256 ))	
	u_isde_wdma_beat_data (
		.wport_csen					(mast_isde_wdma_drdy	),//input  				 		
		.wport_data					(mast_isde_wdma_data	),//input		[DATA_BITS-1:0]
		.wport_addr					(mast_isde_push_dptr	),//input		[ADDR_BITS-1:0]
		.wport_clki					(mgth_clki				),//input						

		.rport_addr					(ubus_wdma_pops_dptr	),//input		[ADDR_BITS-1:0]
		.rport_data					(ubus_devs_wdma_data	),//output	reg	[DATA_BITS-1:0]
		.rport_clki					(ubus_clki				));//input						

	dual_port_bram	#(	
		.ADDR_BITS	( 6 ),	.DATA_BITS	( 25 ))	
	u_isde_wdma_beat_addr (
		.wport_csen					(mast_isde_wdma_drdy	),//input  				 		
		.wport_data					(mast_isde_wdma_addr	),//input		[DATA_BITS-1:0]
		.wport_addr					(mast_isde_push_dptr	),//input		[ADDR_BITS-1:0]
		.wport_clki					(mgth_clki				),//input						
		
		.rport_addr					(ubus_wdma_pops_dptr	),//input		[ADDR_BITS-1:0]
		.rport_data					(ubus_devs_wdma_addr	),//output	reg	[DATA_BITS-1:0]
		.rport_clki					(ubus_clki				));//input						

assign  uila_mgth_isde_wdma= {  
							mast_isde_wdma_drdy	
						,   mism_isde_page_last  
						,   mism_devs_ddrs_cols	//bits 20
						,   misx_devs_ddrs_size	//bits 25 
						,	mast_isde_push_cnts //bits 25
                        ,   mast_isde_wdma_data	//bits 256
	        };  

endmodule 
 