/*----author edward------*/
module	mast_isde_mgth_ctrl(
	input							mast_devs_isde_enab	,
	input							mast_devs_isde_mode	,
	input		[ 3: 1]				mast_devs_isde_port	,
	output							mast_devs_isde_done	,

	input		[19: 0]				mast_meta_imag_cols	,

	input		[24: 0]				mism_dev1_ddrs_base	,
	input		[19: 0]				mism_dev1_ddrs_cols	,
	input		[24: 0]				misv_dev1_ddrs_base	,
	input		[24: 0]				misx_dev1_ddrs_size	,
	
	input		[24: 0]				misx_dev2_ddrs_size	,
	input		[24: 0]				mism_dev2_ddrs_base	,
	input		[19: 0]				mism_dev2_ddrs_cols	,
	input		[24: 0]				misv_dev2_ddrs_base	,

	input		[24: 0]				misx_dev3_ddrs_size	,
	input		[24: 0]				mism_dev3_ddrs_base	,
	input		[19: 0]				mism_dev3_ddrs_cols	,
	input		[24: 0]				misv_dev3_ddrs_base	,

	input							link_clki			,
	input							link_rstn			,
	
	input							mgt1_isde_wdma_drdy	,
	input		[255: 0]			mgt1_isde_wdma_data	,
	input							mgt1_clki			,
	input							mgt1_rstn			,

	input							mgt2_isde_wdma_drdy	,
	input		[255: 0]			mgt2_isde_wdma_data	,
	input							mgt2_clki			,
	input							mgt2_rstn			,

	input							mgt3_isde_wdma_drdy	,
	input		[255: 0]			mgt3_isde_wdma_data	,
	input							mgt3_clki			,
	input							mgt3_rstn			,

	output							ubus_isde_wdma_csen	,
	output		[ 24: 0]			ubus_isde_wdma_addr	,
	output		[255: 0]			ubus_isde_wdma_data	,
	input							ubus_isde_wdma_trdy	,
	input							ubus_isde_wdma_wrdy	,
	input							ubus_clki			,
	input							ubus_rstn			);
//----------------------------------------------------------------------	
	wire		[24: 0]				ubus_dev1_wdma_addr	;
	wire		[255:0]				ubus_dev1_wdma_data	;
	wire		[24: 0]				ubus_dev2_wdma_addr	;
	wire		[255:0]				ubus_dev2_wdma_data	;
	wire		[24: 0]				ubus_dev3_wdma_addr	;
	wire		[255:0]				ubus_dev3_wdma_data	;

	mast_isde_wdma_arbit		u_mast_isde_wdma_arbit(
		.mast_devs_isde_enab		(mast_devs_isde_enab	),//input				
		.mast_devs_isde_port		(mast_devs_isde_port	),//input		[ 3: 1]	
		.mast_devs_isde_done		(mast_devs_isde_done	),//output				
		.link_clki					(link_clki				),//input				
		.link_rstn					(link_rstn				),//input				

		.mast_dev1_wdma_enab		(mast_dev1_wdma_enab	),//output				
		.mast_dev1_wdma_done		(mast_dev1_wdma_done	),//input				
		.mast_dev1_wdma_reqs		(ubus_dev1_wdma_reqs	),//input				
		.ubus_dev1_wdma_vlid		(ubus_dev1_wdma_vlid	),//output	
		.mast_dev1_wdma_addr		(ubus_dev1_wdma_addr	),//input		[24: 0]	
		.mast_dev1_wdma_data		(ubus_dev1_wdma_data	),//input		[255:0]	
		
		.mast_dev2_wdma_enab		(mast_dev2_wdma_enab	),//output				
		.mast_dev2_wdma_done		(mast_dev2_wdma_done	),//input				
		.mast_dev2_wdma_reqs		(ubus_dev2_wdma_reqs	),//input				
		.ubus_dev2_wdma_vlid		(ubus_dev2_wdma_vlid	),//output	
		.mast_dev2_wdma_addr		(ubus_dev2_wdma_addr	),//input		[24: 0]	
		.mast_dev2_wdma_data		(ubus_dev2_wdma_data	),//input		[255:0]	
		
		.mast_dev3_wdma_enab		(mast_dev3_wdma_enab	),//output				
		.mast_dev3_wdma_done		(mast_dev3_wdma_done	),//input				
		.mast_dev3_wdma_reqs		(ubus_dev3_wdma_reqs	),//input				
		.ubus_dev3_wdma_vlid		(ubus_dev3_wdma_vlid	),//output	
		.mast_dev3_wdma_addr		(ubus_dev3_wdma_addr	),//input		[24: 0]	
		.mast_dev3_wdma_data		(ubus_dev3_wdma_data	),//input		[255:0]	
		
		.ubus_isde_wdma_csen		(ubus_isde_wdma_csen	),//output				
		.ubus_isde_wdma_addr		(ubus_isde_wdma_addr	),//output		[ 24: 0]
		.ubus_isde_wdma_data		(ubus_isde_wdma_data	),//output		[255: 0]
		.ubus_isde_wdma_trdy		(ubus_isde_wdma_trdy	),//input				
		.ubus_isde_wdma_wrdy		(ubus_isde_wdma_wrdy	),//input				
		.ubus_clki					(ubus_clki				),//input				
		.ubus_rstn					(ubus_rstn				)); //input				
	
	mast_isde_wdma_ctrl			u_mgt1_isde_dev1_wdma(
		.mast_isde_wdma_drdy		(mgt1_isde_wdma_drdy	),//input				
		.mast_isde_wdma_data		(mgt1_isde_wdma_data	),//input		[255:0]	
		.mgth_clki					(mgt1_clki				),//input				
		.mgth_rstn					(mgt1_rstn				),//input				

		.mast_meta_imag_cols		(mast_meta_imag_cols	),//input		[19: 0]	
		
		.mast_isde_wdma_mode		(mast_devs_isde_mode	),//input				
		.mast_isde_wdma_enab		(mast_dev1_wdma_enab	),//input				
		.mast_isde_wdma_done		(mast_dev1_wdma_done	),//output	reg			
		
		.misx_devs_ddrs_size		(misx_dev1_ddrs_size	),//input		[24: 0]	
		.mism_devs_ddrs_base		(mism_dev1_ddrs_base	),//input		[24: 0]	
		.mism_devs_ddrs_cols		(mism_dev1_ddrs_cols	),//input		[19: 0]	
		.misv_devs_ddrs_base		(misv_dev1_ddrs_base	),//input		[24: 0]	

		.ubus_devs_wdma_vlid		(ubus_dev1_wdma_vlid	),//input				
		.ubus_devs_wdma_reqs		(ubus_dev1_wdma_reqs	),//output				
		.ubus_devs_wdma_addr		(ubus_dev1_wdma_addr	),//output		[ 24: 0]
		.ubus_devs_wdma_data		(ubus_dev1_wdma_data	),//output		[255: 0]
		.ubus_clki					(ubus_clki				),//input				
		.ubus_rstn					(ubus_rstn				));//input				

	wire		[327:0]				uila_mgth_isde_wdma	;	

	mast_isde_wdma_ctrl			u_mgt2_isde_dev2_wdma(
		.uila_mgth_isde_wdma		(uila_mgth_isde_wdma	),

		.mast_isde_wdma_drdy		(mgt2_isde_wdma_drdy	),//input				
		.mast_isde_wdma_data		(mgt2_isde_wdma_data	),//input		[255:0]	
		.mgth_clki					(mgt2_clki				),//input				
		.mgth_rstn					(mgt2_rstn				),//input				

		.mast_meta_imag_cols		(mast_meta_imag_cols	),//input		[19: 0]	
		
		.mast_isde_wdma_mode		(mast_devs_isde_mode	),//input				
		.mast_isde_wdma_enab		(mast_dev2_wdma_enab	),//input				
		.mast_isde_wdma_done		(mast_dev2_wdma_done	),//output	reg			
		
		.misx_devs_ddrs_size		(misx_dev2_ddrs_size	),//input		[24: 0]	
		.mism_devs_ddrs_base		(mism_dev2_ddrs_base	),//input		[24: 0]	
		.mism_devs_ddrs_cols		(mism_dev2_ddrs_cols	),//input		[19: 0]	
		.misv_devs_ddrs_base		(misv_dev2_ddrs_base	),//input		[24: 0]	

		.ubus_devs_wdma_reqs		(ubus_dev2_wdma_reqs	),//output				
		.ubus_devs_wdma_vlid		(ubus_dev2_wdma_vlid	),//input				
		.ubus_devs_wdma_addr		(ubus_dev2_wdma_addr	),//output		[ 24: 0]
		.ubus_devs_wdma_data		(ubus_dev2_wdma_data	),//output		[255: 0]
		.ubus_clki					(ubus_clki				),//input				
		.ubus_rstn					(ubus_rstn				));//input				

	mast_isde_wdma_ctrl			u_mgt3_isde_dev3_wdma(
		.mast_isde_wdma_drdy		(mgt3_isde_wdma_drdy	),//input				
		.mast_isde_wdma_data		(mgt3_isde_wdma_data	),//input		[255:0]	
		.mgth_clki					(mgt3_clki				),//input				
		.mgth_rstn					(mgt3_rstn				),//input				

		.mast_meta_imag_cols		(mast_meta_imag_cols	),//input		[19: 0]	
		
		.mast_isde_wdma_mode		(mast_devs_isde_mode	),//input				
		.mast_isde_wdma_enab		(mast_dev3_wdma_enab	),//input				
		.mast_isde_wdma_done		(mast_dev3_wdma_done	),//output	reg			
		
		.misx_devs_ddrs_size		(misx_dev3_ddrs_size	),//input		[24: 0]	
		.mism_devs_ddrs_base		(mism_dev3_ddrs_base	),//input		[24: 0]	
		.mism_devs_ddrs_cols		(mism_dev3_ddrs_cols	),//input		[19: 0]	
		.misv_devs_ddrs_base		(misv_dev3_ddrs_base	),//input		[24: 0]	

		.ubus_devs_wdma_reqs		(ubus_dev3_wdma_reqs	),//output				
		.ubus_devs_wdma_vlid		(ubus_dev3_wdma_vlid	),//input				
		.ubus_devs_wdma_addr		(ubus_dev3_wdma_addr	),//output		[ 24: 0]
		.ubus_devs_wdma_data		(ubus_dev3_wdma_data	),//output		[255: 0]
		.ubus_clki					(ubus_clki				),//input				
		.ubus_rstn					(ubus_rstn				));//input				

	wire   mast_isde_wdma_drdy	=	uila_mgth_isde_wdma[327]		;
	wire   mism_isde_page_last =	uila_mgth_isde_wdma[326] 		;
	wire   mism_devs_ddrs_cols	=	uila_mgth_isde_wdma[325:306]	;//bits 20
	wire   misx_devs_ddrs_size	=	uila_mgth_isde_wdma[305:281]	;//bits 25 
	wire   mast_isde_push_cnts =	uila_mgth_isde_wdma[280:256]	;//bits 25
    wire   mast_isde_wdma_data	=	uila_mgth_isde_wdma[255:  0]	;//bits 256
/*
	ila_849	uila_tpgm_rdma_ddrs(
				.clk	(ubus_clki			)	,
				.probe0	({  
							 ubus_dev3_wdma_reqs
							,ubus_dev3_wdma_vlid
							,ubus_dev3_wdma_addr
							,ubus_dev3_wdma_data
							,ubus_dev2_wdma_reqs
							,ubus_dev2_wdma_vlid
							,ubus_dev2_wdma_addr
							,ubus_dev2_wdma_data
							,ubus_dev1_wdma_reqs
							,ubus_dev1_wdma_vlid
							,ubus_dev1_wdma_addr
							,ubus_dev1_wdma_data
						})
				);
*/
endmodule 

/******************************************************



****************************************************/
