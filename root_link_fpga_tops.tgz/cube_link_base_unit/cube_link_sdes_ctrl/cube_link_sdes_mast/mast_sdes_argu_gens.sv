//**********************************************************************************************************
module	mast_sdes_argu_gens(
	input		[ 3: 0]				ecos_omni_pile_numb	,
	input		[ 4: 0]				ecos_lead_pile_edge	,
	input		[ 4: 0]				ecos_coda_pile_edge	,

	input		[24: 0]				llmb_mast_ddrs_base	,
	input		[24: 0]				llmb_edge_imag_size	,
	input		[19: 0]				llmb_edge_imag_cols	,
//MAST ISDE DEV1-----------------------------------------
	output	reg	[24: 0]				misx_dev1_ddrs_size	,
	output	reg	[24: 0]				mism_dev1_ddrs_base	,
	output	reg	[19: 0]				mism_dev1_ddrs_cols	,
	output	reg	[24: 0]				misv_dev1_ddrs_base	,
//MAST ISDE DEV1-----------------------------------------
	output	reg	[24: 0]				misx_dev2_ddrs_size	,
	output	reg	[24: 0]				mism_dev2_ddrs_base	,
	output	reg	[19: 0]				mism_dev2_ddrs_cols	,
	output	reg	[24: 0]				misv_dev2_ddrs_base	,
//MAST ISDE DEV1-----------------------------------------
	output	reg	[24: 0]				misx_dev3_ddrs_size	,
	output	reg	[24: 0]				mism_dev3_ddrs_base	,
	output	reg	[19: 0]				mism_dev3_ddrs_cols	,
	output	reg	[24: 0]				misv_dev3_ddrs_base	,
//MAST OSDE MTRX-----------------------------------------
//	output	reg	[24: 0]				mosx_devs_ddrs_size	,
//----------------------------------------------------------------------	
	input							link_clki			,
	input							link_rstn			);
/**********************************************************************************************************/
	reg			[ 4: 0]				dev1_pile_edge_numb	;
	reg			[ 4: 0]				dev2_pile_edge_numb	;
	reg			[ 4: 0]				dev3_pile_edge_numb	;

	wire		dev1_pile_tail_true	=	ecos_omni_pile_numb	== 2	;
	wire		dev2_pile_tail_true	=	ecos_omni_pile_numb	== 3	;
	wire		dev3_pile_tail_true	=	ecos_omni_pile_numb	== 4	;
						
	always@(posedge link_clki or negedge link_rstn)
	if(~link_rstn)					dev1_pile_edge_numb	<=	0	;
	else							dev1_pile_edge_numb	<=	dev1_pile_tail_true	?	ecos_coda_pile_edge	:	ecos_lead_pile_edge	;

	always@(posedge link_clki or negedge link_rstn)
	if(~link_rstn)					dev2_pile_edge_numb	<=	0	;
	else							dev2_pile_edge_numb	<=	dev2_pile_tail_true	?	ecos_coda_pile_edge	:	ecos_lead_pile_edge	;

	always@(posedge link_clki or negedge link_rstn)
	if(~link_rstn)					dev3_pile_edge_numb	<=	0	;
	else							dev3_pile_edge_numb	<=	dev3_pile_tail_true	?	ecos_coda_pile_edge	:	ecos_lead_pile_edge	;
/**********************************************************************************************************/
	reg			[24: 0]				mism_pile_cols_bias	;

	always@(posedge link_clki or negedge link_rstn)
	if(~link_rstn)					mism_pile_cols_bias	<=	0	;
	else 							mism_pile_cols_bias	<=	ecos_lead_pile_edge * llmb_edge_imag_cols[19:4]	;

	reg			[24: 0]				misv_pile_imag_bias	;

	always@(posedge link_clki or negedge link_rstn)
	if(~link_rstn)					misv_pile_imag_bias	<=	0	;
	else 							misv_pile_imag_bias	<=	ecos_lead_pile_edge * llmb_edge_imag_size	;
/***********************************************************************************************************
	MAST_ISDES_DEV1	ARGUMENT
***********************************************************************************************************/
	always@(posedge link_clki or negedge link_rstn)
	if(~link_rstn)					mism_dev1_ddrs_base	<=	0	;
	else 							mism_dev1_ddrs_base	<=	llmb_mast_ddrs_base + mism_pile_cols_bias * 1	;

	always@(posedge link_clki or negedge link_rstn)
	if(~link_rstn)					mism_dev1_ddrs_cols	<=	0	;
	else 							mism_dev1_ddrs_cols	<=	dev1_pile_edge_numb * llmb_edge_imag_cols[19:4]	;

	always@(posedge link_clki or negedge link_rstn)
	if(~link_rstn)					misv_dev1_ddrs_base	<=	0	;
	else 							misv_dev1_ddrs_base	<=	llmb_mast_ddrs_base + misv_pile_imag_bias * 1	;

	always@(posedge link_clki or negedge link_rstn)
	if(~link_rstn)					misx_dev1_ddrs_size	<=	0	;
	else 							misx_dev1_ddrs_size	<=	dev1_pile_edge_numb * llmb_edge_imag_size		;
/***********************************************************************************************************
	MAST_ISDES_DEV2	ARGUMENT
***********************************************************************************************************/
	always@(posedge link_clki or negedge link_rstn)
	if(~link_rstn)					mism_dev2_ddrs_base	<=	0	;
	else 							mism_dev2_ddrs_base	<=	llmb_mast_ddrs_base + mism_pile_cols_bias * 2	;

	always@(posedge link_clki or negedge link_rstn)
	if(~link_rstn)					mism_dev2_ddrs_cols	<=	0	;
	else 							mism_dev2_ddrs_cols	<=	dev2_pile_edge_numb * llmb_edge_imag_cols[19:4]	;

	always@(posedge link_clki or negedge link_rstn)
	if(~link_rstn)					misv_dev2_ddrs_base	<=	0	;
	else 							misv_dev2_ddrs_base	<=	llmb_mast_ddrs_base + misv_pile_imag_bias * 2	;

	always@(posedge link_clki or negedge link_rstn)
	if(~link_rstn)					misx_dev2_ddrs_size	<=	0	;
	else 							misx_dev2_ddrs_size	<=	dev2_pile_edge_numb * llmb_edge_imag_size		;

/***********************************************************************************************************
	MAST_ISDES_DEV3	ARGUMENT
***********************************************************************************************************/
	always@(posedge link_clki or negedge link_rstn)
	if(~link_rstn)					mism_dev3_ddrs_base	<=	0	;
	else 							mism_dev3_ddrs_base	<=	llmb_mast_ddrs_base + mism_pile_cols_bias * 3	;

	always@(posedge link_clki or negedge link_rstn)
	if(~link_rstn)					mism_dev3_ddrs_cols	<=	0	;
	else 							mism_dev3_ddrs_cols	<=	dev3_pile_edge_numb * llmb_edge_imag_cols[19:4]	;

	always@(posedge link_clki or negedge link_rstn)
	if(~link_rstn)					misv_dev3_ddrs_base	<=	0	;
	else 							misv_dev3_ddrs_base	<=	llmb_mast_ddrs_base + misv_pile_imag_bias * 3	;

	always@(posedge link_clki or negedge link_rstn)
	if(~link_rstn)					misx_dev3_ddrs_size	<=	0	;
	else 							misx_dev3_ddrs_size	<=	dev3_pile_edge_numb * llmb_edge_imag_size		;
/**********************************************************************************************************/
//	always@(posedge link_clki or negedge link_rstn)
//	if(~link_rstn)					mosx_devs_ddrs_size	<=	0	;
//	else 							mosx_devs_ddrs_size	<=	ecos_meta_imag_rows * ecos_meta_imag_cols[19:4]	;
/**********************************************************************************************************/
endmodule

