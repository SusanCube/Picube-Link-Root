/*----author edward------*/
module	devs_osde_mgth_ctrl(
	input		[24: 0]				devs_osde_ddrs_base	,//add @20241229
	input		[24 :0]				devs_osde_imag_size	,//add @20241229
	
	input							devs_osde_rdma_enab	,//write enable
	output							devs_osde_rdma_done	,

	input							link_clki			,
	input							link_rstn			,

	input							mgth_osde_rdma_trdy	,
	output							mgth_osde_rdma_drdy	,
	output		[255: 0]			mgth_osde_rdma_data	,
	input							mgth_clki			,
	input							mgth_rstn			,

	output	reg						ubus_osde_rdma_csen	,
	output	reg	[ 24: 0]			ubus_osde_rdma_addr	,
	input							ubus_osde_rdma_trdy	,
	input		[255: 0]			ubus_osde_rdma_data	,
	input							ubus_osde_rdma_drdy	,

	input							ubus_clki			,
	input							ubus_rstn			);
/**********************************************************************************************************/
	reg		[ 1: 0]					ubus_rdma_enab_samp	;
	reg		[ 1: 0]					ubus_rdma_done_samp	;
	
	reg		[21: 0]					ubus_rdma_pack_size	;
	
	wire							ubus_rdma_proc_disa	= ~	ubus_rdma_enab_samp[0]	;
	wire							ubus_rdma_proc_enab	=	ubus_rdma_enab_samp[0]	;
	wire							mgth_osde_rdma_done	;

	assign	devs_osde_rdma_done	=	ubus_rdma_done_samp[0]	;	

	always@(posedge ubus_clki or negedge  ubus_rstn)
	if(~ubus_rstn)					ubus_rdma_enab_samp	<=	0	;
	else							ubus_rdma_enab_samp	<={	devs_osde_rdma_enab	, ubus_rdma_enab_samp[1]	};	

	always@(posedge link_clki or negedge  link_rstn)
	if(~link_rstn)					ubus_rdma_done_samp	<=	0	;
	else							ubus_rdma_done_samp	<={	mgth_osde_rdma_done	, ubus_rdma_done_samp[1]	};	

	always@(posedge ubus_clki or negedge  ubus_rstn)
	if(~ubus_rstn)					ubus_rdma_pack_size	<=	0	;
	else if(ubus_rdma_proc_disa)	ubus_rdma_pack_size	<=	devs_osde_imag_size[24:3]	;	
//----------------------------------------------------------------------------------------------------------
	reg		[ 1: 0]					mgth_osde_csen_samp	;	

	wire							mgth_osde_proc_enab	=	mgth_osde_csen_samp[0]	;	
	
	always@(posedge mgth_clki or negedge  mgth_rstn)
	if(~mgth_rstn)					mgth_osde_csen_samp	<=	0	;
	else							mgth_osde_csen_samp	<={	devs_osde_rdma_enab	, mgth_osde_csen_samp[1]	};	
/**********************************************************************************************************/
	reg		[3: 0]					devs_osde_ubus_mfsm	;


	reg								ubus_osde_pack_csen	;
	reg		[21: 0]					ubus_osde_pack_cnts	;
	reg		[ 2 :0]					ubus_rdma_cmnd_cnts	;
	reg		[ 3 :0]					ubus_rdma_page_cnts	;

	reg		[ 3 :0]					mgth_port_free_cnts	;

	parameter	OSDE_MAST_UBUS_IDLE	=	4'H0	;
	parameter	OSDE_MAST_UBUS_REQS	=	4'H1	;
	parameter	OSDE_MAST_UBUS_CMND	=	4'H2	;
	parameter	OSDE_MAST_UBUS_PACK	=	4'H3	;

	parameter	OSDE_MAST_MGTH_FREE	=	4'H4	;

	parameter	OSDE_MAST_MGTH_REQS	=	4'H5	;
	parameter	OSDE_MAST_MGTH_PACK	=	4'H6	;
	parameter	OSDE_MAST_UBUS_LOOP	=	4'H7	;
	parameter	OSDE_MAST_UBUS_DONE	=	4'H8	;


	wire							ubus_rdma_cmnd_done	;
	wire							ubus_rdma_pack_done	;
	wire							ubus_rdma_pack_last	;

	wire							mgth_osde_port_free	;
	wire							mgth_osde_port_fmax	;
	wire							mgth_osde_port_acks	;
	wire							mgth_osde_port_done	;

	wire							ubus_rdma_cmnd_vlid	;
	wire							ubus_rdma_page_vlid	;


	wire		ubus_hits_rdma_idle	=	devs_osde_ubus_mfsm	==	OSDE_MAST_UBUS_IDLE	;
	wire		ubus_rdma_pack_reqs	=	devs_osde_ubus_mfsm	==	OSDE_MAST_UBUS_REQS	;

	assign		ubus_rdma_cmnd_vlid	= &{ubus_osde_rdma_csen	,	ubus_osde_rdma_trdy};
	assign		ubus_rdma_page_vlid	= &{ubus_osde_pack_csen	,	ubus_osde_rdma_drdy};
	assign		ubus_rdma_cmnd_done	= &{ubus_rdma_cmnd_vlid	,	ubus_rdma_cmnd_cnts};

	wire		rdma_pack_last_page	= &	ubus_rdma_page_cnts[2:0];	
	assign		ubus_rdma_pack_done	= &{ubus_rdma_page_vlid	,	rdma_pack_last_page};
	assign		ubus_rdma_pack_last	= &{devs_osde_ubus_mfsm	==	OSDE_MAST_UBUS_LOOP	,
										ubus_osde_pack_cnts	==	ubus_rdma_pack_size};

	assign		mgth_osde_port_free	=	devs_osde_ubus_mfsm	==	OSDE_MAST_MGTH_FREE	;
	wire		mgth_osde_port_reqs	=	devs_osde_ubus_mfsm	==	OSDE_MAST_MGTH_REQS	;
	assign		mgth_osde_rdma_done	=	devs_osde_ubus_mfsm	==	OSDE_MAST_UBUS_DONE	;		
	assign		mgth_osde_port_fmax	= &	mgth_port_free_cnts	;

//----------------------------------------------------------------------------------------------------------	
	always@(posedge ubus_clki or negedge  ubus_rstn)
	if(~ubus_rstn)					devs_osde_ubus_mfsm	<=	OSDE_MAST_UBUS_IDLE	;
	else if(ubus_rdma_proc_disa)	devs_osde_ubus_mfsm	<=	OSDE_MAST_UBUS_IDLE	;
	else begin
		case(devs_osde_ubus_mfsm)	
			OSDE_MAST_UBUS_IDLE	:	devs_osde_ubus_mfsm	<=	ubus_rdma_proc_enab	?	OSDE_MAST_UBUS_REQS	:	OSDE_MAST_UBUS_IDLE	;
			OSDE_MAST_UBUS_REQS	:	devs_osde_ubus_mfsm	<=													OSDE_MAST_UBUS_CMND	;
			OSDE_MAST_UBUS_CMND	:	devs_osde_ubus_mfsm	<=	ubus_rdma_cmnd_done	?	OSDE_MAST_UBUS_PACK	:	OSDE_MAST_UBUS_CMND	;
//			OSDE_MAST_UBUS_PACK	:	devs_osde_ubus_mfsm	<=	ubus_rdma_pack_done	?	OSDE_MAST_MGTH_REQS	:	OSDE_MAST_UBUS_PACK	;
			
			OSDE_MAST_UBUS_PACK	:	devs_osde_ubus_mfsm	<=	ubus_rdma_pack_done	?	OSDE_MAST_MGTH_FREE	:	OSDE_MAST_UBUS_PACK	;
			OSDE_MAST_MGTH_FREE	:	devs_osde_ubus_mfsm	<=	mgth_osde_port_fmax	?	OSDE_MAST_MGTH_REQS	:	OSDE_MAST_MGTH_FREE	;

			OSDE_MAST_MGTH_REQS	:	devs_osde_ubus_mfsm	<=	mgth_osde_port_acks	?	OSDE_MAST_MGTH_PACK	:	OSDE_MAST_MGTH_REQS	;
			OSDE_MAST_MGTH_PACK	:	devs_osde_ubus_mfsm	<=	mgth_osde_port_done	?	OSDE_MAST_UBUS_LOOP	:	OSDE_MAST_MGTH_PACK	;
			OSDE_MAST_UBUS_LOOP	:	devs_osde_ubus_mfsm	<=	ubus_rdma_pack_last	?	OSDE_MAST_UBUS_DONE	:	OSDE_MAST_UBUS_REQS	;
			OSDE_MAST_UBUS_DONE	:	devs_osde_ubus_mfsm	<=	ubus_rdma_proc_enab	?	OSDE_MAST_UBUS_DONE	:	OSDE_MAST_UBUS_IDLE	;

			default				:	devs_osde_ubus_mfsm	<=													OSDE_MAST_UBUS_IDLE	;	
		endcase
	end
//----------------------------------------------------------------------------------------------------------	
	always@(posedge ubus_clki or negedge  ubus_rstn)
	if(~ubus_rstn)					mgth_port_free_cnts	<=	0	;
	else  if(~mgth_osde_port_free)	mgth_port_free_cnts	<=	0	;
	else							mgth_port_free_cnts	<=	mgth_port_free_cnts	+ 1;
	
	always@(posedge ubus_clki or negedge  ubus_rstn)
	if(~ubus_rstn)					ubus_osde_rdma_csen	<=	0	;
	else if( ubus_rdma_proc_disa)	ubus_osde_rdma_csen	<=	0	;
	else if( ubus_rdma_pack_reqs)	ubus_osde_rdma_csen	<=	1	;
	else if( ubus_rdma_cmnd_done)	ubus_osde_rdma_csen	<=	0	;

	always@(posedge ubus_clki or negedge  ubus_rstn)
	if(~ubus_rstn)					ubus_osde_pack_csen	<=	0	;
	else if( ubus_rdma_proc_disa)	ubus_osde_pack_csen	<=	0	;
	else if( ubus_rdma_pack_reqs)	ubus_osde_pack_csen	<=	1	;
	else if( ubus_rdma_pack_done)	ubus_osde_pack_csen	<=	0	;


	always@(posedge ubus_clki or negedge  ubus_rstn)
	if(~ubus_rstn)					ubus_osde_rdma_addr	<=	0	;
	else if( ubus_rdma_proc_disa)	ubus_osde_rdma_addr	<=	devs_osde_ddrs_base   	;
	else if( ubus_rdma_cmnd_vlid)	ubus_osde_rdma_addr	<=	ubus_osde_rdma_addr +1	;


	always@(posedge ubus_clki or negedge  ubus_rstn)
	if(~ubus_rstn)					ubus_rdma_cmnd_cnts	<=	0	;
	else if( ubus_rdma_proc_disa)	ubus_rdma_cmnd_cnts	<=	0	;
	else if( ubus_rdma_pack_reqs)	ubus_rdma_cmnd_cnts	<=	0 	;
	else if( ubus_rdma_cmnd_done)	ubus_rdma_cmnd_cnts	<=	0 	;
	else if( ubus_rdma_cmnd_vlid)	ubus_rdma_cmnd_cnts	<=	ubus_rdma_cmnd_cnts +1	;

	always@(posedge ubus_clki or negedge  ubus_rstn)
	if(~ubus_rstn)					ubus_rdma_page_cnts	<=	0	;
	else if( ubus_rdma_proc_disa)	ubus_rdma_page_cnts	<=	0	;
	else if( ubus_rdma_pack_reqs)	ubus_rdma_page_cnts	<=	0	;
	else if( ubus_rdma_pack_done)	ubus_rdma_page_cnts	<=	0	;
	else if( ubus_rdma_page_vlid)	ubus_rdma_page_cnts	<=	ubus_rdma_page_cnts +1	;

	always@(posedge ubus_clki or negedge  ubus_rstn)
	if(~ubus_rstn)					ubus_osde_pack_cnts	<=	0	;
	else if( ubus_rdma_proc_disa)	ubus_osde_pack_cnts	<=	0	;
	else if( ubus_rdma_pack_done)	ubus_osde_pack_cnts	<=	ubus_osde_pack_cnts +1	;
/**********************************************************************************************************/
	wire							ubus_rdma_page_wrcs	= ubus_rdma_page_vlid	;	
	wire		[255: 0]			ubus_rdma_page_data	= ubus_osde_rdma_data	;	
//----------------------------------------------------------------------
	mgth_osde_pack_ctrl			u_mgt1_osde_pack_ctrl(
		.ubus_wrcs_pack_reqs		(ubus_rdma_pack_reqs	),//input				
		.ubus_wrcs_pack_enab		(ubus_rdma_page_wrcs	),//input				
		.ubus_wrcs_pack_data		(ubus_rdma_page_data	),//input		[255:0]	
		.ubus_clki					(ubus_clki				),//input				
		.ubus_rstn					(ubus_rstn				),//input				

		.mgth_osde_port_reqs		(mgth_osde_port_reqs	),//input				
		.mgth_osde_port_enab		(1'B1					),//input				
		.mgth_osde_port_acks		(mgth_osde_port_acks	),//output				
		.mgth_osde_port_done		(mgth_osde_port_done	),//output	

		.mgth_osde_pack_trdy		(mgth_osde_rdma_trdy	),//input				
		.mgth_osde_pack_drdy		(mgth_osde_rdma_drdy	),//output				
		.mgth_osde_pack_data		(mgth_osde_rdma_data	),//output		[255:0]	
		.mgth_clki					(mgth_clki				),//input				
		.mgth_rstn					(mgth_rstn				));//input				
 
/*

	ila_111	uila_devs_osde_ddrs(
				.clk	(ubus_clki			)	,
				.probe0	({  ubus_osde_pack_csen	//bits +1	~	111
						,	devs_osde_rdma_done	//bits +1	~	110
						,	devs_osde_rdma_enab	//bits +1	~	109
						,	devs_osde_ubus_mfsm	//bits +4	~	108
						,	ubus_rdma_cmnd_cnts	//bits +3	~	104
						,	ubus_rdma_page_cnts	//bits +4	~	101
						,	ubus_osde_pack_cnts	//bits +22	~	97
						,	ubus_osde_rdma_addr	//bits +25	~	75
						,	devs_osde_ddrs_base	//bits +25	~	50
						,	devs_osde_imag_size	//bits +25	~	25
		    })
	);

 
*/



endmodule 




