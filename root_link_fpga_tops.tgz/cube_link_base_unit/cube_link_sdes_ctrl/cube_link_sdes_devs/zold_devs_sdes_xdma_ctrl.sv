/*----author edward------*/
module	devs_sdes_xdma_ctrl(
	input		[24 : 0]			devs_sdes_ddrs_base	,
	input		[24 : 0]			devs_osde_imag_size	,
	input							devs_osde_rdma_enab	,
	output							devs_osde_rdma_done	,

	input							link_clki			,
	input							link_rstn			,
//----------------------------------------------------------------------------------------------------------
	input							mgth_osde_rdma_trdy	,
	output							mgth_osde_rdma_drdy	,
	output		[255: 0]			mgth_osde_rdma_data	,
	input							mgth_clki			,
	input							mgth_rstn			,

	output							ubus_osde_rdma_csen	,
	output		[ 24: 0]			ubus_osde_rdma_addr	,
	input							ubus_osde_rdma_trdy	,
	input		[255: 0]			ubus_osde_rdma_data	,
	input							ubus_osde_rdma_drdy	,

	input							ubus_clki			,
	input							ubus_rstn			);
//----------------------------------------------------------------------------------------------------------
	devs_osde_mgth_ctrl			u_devs_osde_mgth_esse(
		.devs_osde_ddrs_base		(devs_sdes_ddrs_base	),//input		[24: 0]	
		.devs_osde_imag_size		(devs_osde_imag_size	),//input		[20 :0]	

		.devs_osde_rdma_done		(devs_osde_rdma_done	),//output		
		.devs_osde_rdma_enab		(devs_osde_rdma_enab	),//input					

		.link_clki					(link_clki				),//input					
		.link_rstn					(link_rstn				),//input					

		.mgth_osde_rdma_trdy		(mgth_osde_rdma_trdy	),//input					
		.mgth_osde_rdma_drdy		(mgth_osde_rdma_drdy	),//output					
		.mgth_osde_rdma_data		(mgth_osde_rdma_data	),//output		[255: 0]	
		.mgth_clki					(mgth_clki				),//input					
		.mgth_rstn					(mgth_rstn				),//input					

		.ubus_osde_rdma_csen		(ubus_osde_rdma_csen	),//output	reg				
		.ubus_osde_rdma_addr		(ubus_osde_rdma_addr	),//output	reg	[ 24: 0]	
		.ubus_osde_rdma_trdy		(ubus_osde_rdma_trdy	),//input					
		.ubus_osde_rdma_data		(ubus_osde_rdma_data	),//input		[255: 0]	
		.ubus_osde_rdma_drdy		(ubus_osde_rdma_drdy	),//input					
		.ubus_clki					(ubus_clki				),//input					
		.ubus_rstn					(ubus_rstn				));//input					

endmodule 

