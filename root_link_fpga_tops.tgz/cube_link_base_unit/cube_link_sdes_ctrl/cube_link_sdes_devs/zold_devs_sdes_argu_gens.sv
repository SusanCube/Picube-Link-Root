//**********************************************************************************************************
module	mgth_devs_sdes_argu(
	
	input		[ 3: 0]				ecos_this_pile_numb	,
	input		[ 3: 0]				ecos_omni_pile_numb	,
	
	input		[ 4: 0]				ecos_edge_pile_numb	,
	input		[ 4: 0]				ecos_edge_tail_numb	,

	input		[ 3: 0]				ecos_link_mast_addr	,
	input		[ 3: 0]				ecos_link_devs_addr	,

	input		[24: 0]				ecos_meta_imag_size	,
	input		[24: 0]				ecos_edge_imag_size	,
//DEVS OSDE MTRX-----------------------------------------
	output	reg	[24: 0]				devs_sdes_ddrs_base	,
	output	reg	[24: 0]				devs_osde_ddrs_size	,
	output	reg	[24: 0]				devs_isde_ddrs_size	,
//----------------------------------------------------------------------	
	input							link_clki			,
	input							link_rstn			);
/**********************************************************************************************************/
	reg			[ 7: 0]				devs_pile_edge_numb	;

	wire							devs_pile_tail_flag	;
	assign	devs_pile_tail_flag	=	ecos_this_pile_numb	== (ecos_omni_pile_numb	-1)	;

	always@(posedge link_clki or negedge link_rstn)
	if(~link_rstn)					devs_pile_edge_numb	<=	0	;
	else if( devs_pile_tail_flag)	devs_pile_edge_numb	<=	ecos_edge_tail_numb	;
	else							devs_pile_edge_numb	<=	ecos_edge_pile_numb	;
/**********************************************************************************************************/
	always@(posedge link_clki or negedge link_rstn)
	if(~link_rstn)					devs_sdes_ddrs_base	<=	0	;
	else							devs_sdes_ddrs_base	<=	ecos_link_devs_addr	;

	always@(posedge link_clki or negedge link_rstn)
	if(~link_rstn)					devs_isde_ddrs_size	<=	0	;
	else							devs_isde_ddrs_size	<=	ecos_meta_imag_size	;

	always@(posedge link_clki or negedge link_rstn)
	if(~link_rstn)					devs_osde_ddrs_size	<=	0	;
	else							devs_osde_ddrs_size	<=	devs_pile_edge_numb * ecos_edge_imag_size	;
/**********************************************************************************************************/
								
endmodule

