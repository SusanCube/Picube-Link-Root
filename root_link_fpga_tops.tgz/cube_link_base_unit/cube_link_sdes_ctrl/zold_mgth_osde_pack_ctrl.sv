/*----author edward------*/

module	mgth_osde_pack_ctrl(
	input							ubus_mgth_pack_reqs	,
	output							ubus_mgth_pack_acks	,
	output							ubus_mgth_pack_done	,
	input							ubus_clki			,
	input							ubus_rstn			,

	input							mgth_osde_rdma_enab	,
	output							mgth_osde_rdma_reqs	,
	output							mgth_osde_rdma_drdy	,
	input							mgth_osde_rdma_trdy	,
	input							mgth_clki			,
	input							mgth_rstn			);
/**********************************************************************************************************/
	reg		[2: 0]					mgth_osde_reqs_samp	;
	reg								mgth_osde_page_enab	;
	reg		[2: 0]					mgth_osde_page_cnts	;
	reg								mgth_osde_page_done	;
	reg		[1: 0]					mgth_rdma_acks_samp	;
	reg		[1: 0]					mgth_rdma_done_samp	;

	wire	mgth_osde_rdma_issu	=	mgth_osde_reqs_samp[1:0] == 2'B10	;
	wire	mgth_osde_rdma_last	= &{mgth_osde_rdma_drdy	,	mgth_osde_page_cnts};
	assign	mgth_osde_rdma_drdy	= &{mgth_osde_page_enab	,	mgth_osde_rdma_trdy	};	
	
	
	assign	ubus_mgth_pack_acks	=	mgth_rdma_acks_samp[0] ;	
	assign	ubus_mgth_pack_done	=	mgth_rdma_done_samp[0] ;	
//----------------------------------------------------------------------
	always@(posedge mgth_clki or negedge mgth_rstn)
	if(!mgth_rstn)					mgth_osde_reqs_samp	<=	0	;
	else if(~mgth_osde_rdma_enab)	mgth_osde_reqs_samp	<= 	0	;
	else 							mgth_osde_reqs_samp	<= {ubus_mgth_pack_reqs	,	mgth_osde_reqs_samp[2:1] };
//----------------------------------------------------------------------
	always@(posedge mgth_clki or negedge mgth_rstn)
	if(!mgth_rstn)					mgth_osde_page_enab	<=	0	;
	else if(~mgth_osde_rdma_enab)	mgth_osde_page_enab	<=	0	;
	else if( mgth_osde_rdma_issu)	mgth_osde_page_enab	<=	1	;	
	else if( mgth_osde_rdma_last)	mgth_osde_page_enab	<=	0	;	
//----------------------------------------------------------------------
	always@(posedge mgth_clki or negedge mgth_rstn)
	if(!mgth_rstn)					mgth_osde_page_cnts	<=	0	;
	else if(~mgth_osde_rdma_enab)	mgth_osde_page_cnts	<=	0	;
	else if( mgth_osde_rdma_issu)	mgth_osde_page_cnts	<=	0	;	
	else if( mgth_osde_rdma_drdy)	mgth_osde_page_cnts	<=	mgth_osde_page_cnts + 1	;	
//----------------------------------------------------------------------
	always@(posedge mgth_clki or negedge mgth_rstn)
	if(!mgth_rstn)					mgth_osde_page_done	<=	0	;
	else if(~mgth_osde_rdma_enab)	mgth_osde_page_done	<=	0	;
	else if( mgth_osde_rdma_issu)	mgth_osde_page_done	<=	0	;	
	else if( mgth_osde_rdma_last)	mgth_osde_page_done	<=	1	;	
//----------------------------------------------------------------------
	always@(posedge ubus_clki or negedge ubus_rstn)
	if(!ubus_rstn)					mgth_rdma_acks_samp	<=	0	;
	else 							mgth_rdma_acks_samp	<= {mgth_osde_page_enab	,	mgth_rdma_acks_samp[ 1 ] };
//----------------------------------------------------------------------
	always@(posedge ubus_clki or negedge ubus_rstn)
	if(!ubus_rstn)					mgth_rdma_done_samp	<=	0	;
	else 							mgth_rdma_done_samp	<= {mgth_osde_page_done	,	mgth_rdma_done_samp[ 1 ] };
/**********************************************************************************************************/

endmodule