/*----author edward------*/

module	mgth_osde_pack_ctrl(
	input							ubus_wrcs_pack_reqs	,
	input							ubus_wrcs_pack_enab	,
	input		[255:0]				ubus_wrcs_pack_data	,
	input							ubus_clki			,
	input							ubus_rstn			,

	input							mgth_osde_port_enab	,
	input							mgth_osde_port_reqs	,//ubus clock domian
	output							mgth_osde_port_acks	,//ubus clock domian
	output							mgth_osde_port_done	,//ubus clock domian
	
	input							mgth_osde_pack_trdy	,
	output							mgth_osde_pack_drdy	,
	output		[255:0]				mgth_osde_pack_data	,
	input							mgth_clki			,
	input							mgth_rstn			);
//--------------UBUS RDMA FIFO
	reg			[ 2: 0]				ubus_wrcs_pack_addr	;
	reg			[ 0: 7][255:0]		ubus_wrcs_pack_memo	;

	wire		[ 0: 7]				ubus_wrcs_pack_csid	;

	always@(posedge ubus_clki or negedge ubus_rstn)
	if(!ubus_rstn)					ubus_wrcs_pack_addr	<=	0	;
	else if(ubus_wrcs_pack_reqs)	ubus_wrcs_pack_addr	<=	0	;
	else if(ubus_wrcs_pack_enab)	ubus_wrcs_pack_addr	<=	1 +	ubus_wrcs_pack_addr	;


	for(genvar i = 0 ; i < 8 ; i++) begin	:	gens_pack_memo_wrcs
		assign	ubus_wrcs_pack_csid[i]	= &{ubus_wrcs_pack_enab	,	ubus_wrcs_pack_addr	==	i	};
	
		always@(posedge ubus_clki or negedge ubus_rstn)
		if(!ubus_rstn)					ubus_wrcs_pack_memo[i]	<=	0	;
		else if(ubus_wrcs_pack_csid[i])	ubus_wrcs_pack_memo[i]	<=	ubus_wrcs_pack_data	;	

	end
/**********************************************************************************************************/
//--------------MGTH RDMA FIFO
	reg			[ 2: 0]				mgth_osde_reqs_samp	;

	wire		mgth_osde_pack_rise	=	mgth_osde_reqs_samp[1:0] == 2'B10	;

	always@(posedge mgth_clki or negedge mgth_rstn)
	if(!mgth_rstn)					mgth_osde_reqs_samp	<=	0	;
	else if(~mgth_osde_port_enab)	mgth_osde_reqs_samp	<= 	0	;
	else 							mgth_osde_reqs_samp	<= {mgth_osde_port_reqs	,	mgth_osde_reqs_samp[2:1] };
//----------------------------------------------------------------------
	reg			[ 2: 0]				mgth_osde_pack_indx	;
	reg								mgth_osde_pack_enab	;
	reg								mgth_osde_pack_done	;
	
	wire		[ 0: 7]				mgth_rdcs_pack_csid	;

	assign		mgth_osde_pack_drdy	= &{mgth_osde_pack_enab	,	mgth_osde_pack_trdy	};
	wire		mgth_osde_pack_last	= &{mgth_osde_pack_drdy	,	mgth_osde_pack_indx	};	

	always@(posedge mgth_clki or negedge mgth_rstn)
	if(!mgth_rstn)					mgth_osde_pack_enab	<=	0	;
	else if(~mgth_osde_port_enab)	mgth_osde_pack_enab	<=	0	;
	else if( mgth_osde_pack_rise)	mgth_osde_pack_enab	<=	1	;	
	else if( mgth_osde_pack_last)	mgth_osde_pack_enab	<=	0	;	

	always@(posedge mgth_clki or negedge mgth_rstn)
	if(!mgth_rstn)					mgth_osde_pack_done	<=	0	;
	else if(~mgth_osde_pack_enab)	mgth_osde_pack_done	<=	0	;
	else if( mgth_osde_pack_rise)	mgth_osde_pack_done	<=	0	;	
	else if( mgth_osde_pack_last)	mgth_osde_pack_done	<=	1	;	

	always@(posedge mgth_clki or negedge mgth_rstn)
	if(!mgth_rstn)					mgth_osde_pack_indx	<=	0	;
	else if(~mgth_osde_port_enab)	mgth_osde_pack_indx	<=	0	;
	else if( mgth_osde_pack_rise)	mgth_osde_pack_indx	<=	0	;	
	else if( mgth_osde_pack_drdy)	mgth_osde_pack_indx	<=	1 +	mgth_osde_pack_indx ;	

	for(genvar i = 0 ; i < 8 ; i++) begin	:	gens_pack_memo_rdcs
		assign	mgth_rdcs_pack_csid[i]	= &{	mgth_osde_pack_enab	,	mgth_osde_pack_indx	==	i	};
	end
/**********************************************************************************************************/
	reg		[1: 0]					mgth_rdma_acks_samp	;
	reg		[1: 0]					mgth_rdma_done_samp	;
	
	assign		mgth_osde_port_acks	=	mgth_rdma_acks_samp[0] ;	
	assign		mgth_osde_port_done	=	mgth_rdma_done_samp[0] ;	
//----------------------------------------------------------------------
	always@(posedge ubus_clki or negedge ubus_rstn)
	if(!ubus_rstn)					mgth_rdma_acks_samp	<=	0	;
	else 							mgth_rdma_acks_samp	<= {mgth_osde_pack_enab	,	mgth_rdma_acks_samp[ 1 ] };
//----------------------------------------------------------------------
	always@(posedge ubus_clki or negedge ubus_rstn)
	if(!ubus_rstn)					mgth_rdma_done_samp	<=	0	;
	else 							mgth_rdma_done_samp	<= {mgth_osde_pack_done	,	mgth_rdma_done_samp[ 1 ] };
/**********************************************************************************************************/
	assign		mgth_osde_pack_data	=	mgth_rdcs_pack_csid[0]	?	ubus_wrcs_pack_memo[0]	:
										mgth_rdcs_pack_csid[1]	?	ubus_wrcs_pack_memo[1]	:
										mgth_rdcs_pack_csid[2]	?	ubus_wrcs_pack_memo[2]	:
										mgth_rdcs_pack_csid[3]	?	ubus_wrcs_pack_memo[3]	:
										mgth_rdcs_pack_csid[4]	?	ubus_wrcs_pack_memo[4]	:
										mgth_rdcs_pack_csid[5]	?	ubus_wrcs_pack_memo[5]	:
										mgth_rdcs_pack_csid[6]	?	ubus_wrcs_pack_memo[6]	:
										mgth_rdcs_pack_csid[7]	?	ubus_wrcs_pack_memo[7]	:	256'H0	;

endmodule