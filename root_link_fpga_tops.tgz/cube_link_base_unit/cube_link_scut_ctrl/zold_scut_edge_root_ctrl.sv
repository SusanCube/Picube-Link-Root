`include	"agile_card_vars.vh"
/*------------------------------------------------------------------------
	ODAT :: LUMP SCUT
	IDAT :: SOLO SCUT
------------------------------------------------------------------------*/
module	scut_edge_root_ctrl (
	input							cube_link_scut_enab	,
	input							cube_link_scut_type	,//ODAT : 0  1DAT: 1
	input	[ 7: 0]					cube_link_edge_enab	,
	
	input	[ 0: 7]					edge_idat_acks_lead	,
	input	[ 0: 7]					edge_idat_resp_lead	,
	input	[ 0: 7]					edge_idat_acks_wrcs	,
	input	[ 0: 7]					edge_idat_resp_wrcs	,
	input	[ 0: 7]					edge_idat_data_lead	,
	input	[ 0: 7]					edge_idat_data_wrcs	,
	input	[ 0: 7]	[31: 0]			edge_idat_data_word	,

	input							edge_odat_acks_coda	,
	input							edge_odat_resp_coda	,

	output	[ 2: 0]					scut_acks_memo_indx	,
	input	[31: 0]					scut_acks_memo_data	,
	
	output		[  7: 0]			edge_scut_root_fram	,
	output		[  7: 0]			edge_scut_root_dat3	,
	output		[  7: 0]			edge_scut_root_dat2	,
	output		[  7: 0]			edge_scut_root_dat1	,
	output		[  7: 0]			edge_scut_root_dat0	,
	
	input							cube_clki			,
	input							cube_rstn			);
/**********************************************************************************************************/
	wire							edge_solo_acks_lead	;
	wire							edge_solo_acks_wrcs	;
	wire							edge_solo_resp_lead	;
	wire							edge_solo_resp_wrcs	;
	wire							edge_solo_idat_lead	;
	wire							edge_solo_idat_wrcs	;
	wire	[31: 0]					edge_solo_idat_word	;

	assign	edge_solo_acks_lead	=	cube_link_edge_enab[0]	?	edge_idat_acks_lead[0]	:
									cube_link_edge_enab[1]	?	edge_idat_acks_lead[1]	:
									cube_link_edge_enab[2]	?	edge_idat_acks_lead[2]	:
									cube_link_edge_enab[3]	?	edge_idat_acks_lead[3]	:
									cube_link_edge_enab[4]	?	edge_idat_acks_lead[4]	:
									cube_link_edge_enab[5]	?	edge_idat_acks_lead[5]	:
									cube_link_edge_enab[6]	?	edge_idat_acks_lead[6]	:
									cube_link_edge_enab[7]	?	edge_idat_acks_lead[7]	:	1'B0	;

	assign	edge_solo_acks_wrcs	=	cube_link_edge_enab[0]	?	edge_idat_acks_wrcs[0]	:
									cube_link_edge_enab[1]	?	edge_idat_acks_wrcs[1]	:
									cube_link_edge_enab[2]	?	edge_idat_acks_wrcs[2]	:
									cube_link_edge_enab[3]	?	edge_idat_acks_wrcs[3]	:
									cube_link_edge_enab[4]	?	edge_idat_acks_wrcs[4]	:
									cube_link_edge_enab[5]	?	edge_idat_acks_wrcs[5]	:
									cube_link_edge_enab[6]	?	edge_idat_acks_wrcs[6]	:
									cube_link_edge_enab[7]	?	edge_idat_acks_wrcs[7]	:	1'B0	;

	assign	edge_solo_resp_lead	=	cube_link_edge_enab[0]	?	edge_idat_resp_lead[0]	:
									cube_link_edge_enab[1]	?	edge_idat_resp_lead[1]	:
									cube_link_edge_enab[2]	?	edge_idat_resp_lead[2]	:
									cube_link_edge_enab[3]	?	edge_idat_resp_lead[3]	:
									cube_link_edge_enab[4]	?	edge_idat_resp_lead[4]	:
									cube_link_edge_enab[5]	?	edge_idat_resp_lead[5]	:
									cube_link_edge_enab[6]	?	edge_idat_resp_lead[6]	:
									cube_link_edge_enab[7]	?	edge_idat_resp_lead[7]	:	1'B0	;

	assign	edge_solo_resp_wrcs	=	cube_link_edge_enab[0]	?	edge_idat_resp_wrcs[0]	:
									cube_link_edge_enab[1]	?	edge_idat_resp_wrcs[1]	:
									cube_link_edge_enab[2]	?	edge_idat_resp_wrcs[2]	:
									cube_link_edge_enab[3]	?	edge_idat_resp_wrcs[3]	:
									cube_link_edge_enab[4]	?	edge_idat_resp_wrcs[4]	:
									cube_link_edge_enab[5]	?	edge_idat_resp_wrcs[5]	:
									cube_link_edge_enab[6]	?	edge_idat_resp_wrcs[6]	:
									cube_link_edge_enab[7]	?	edge_idat_resp_wrcs[7]	:	1'B0	;

	assign	edge_solo_idat_lead	=	cube_link_edge_enab[0]	?	edge_idat_data_lead[0]	:
									cube_link_edge_enab[1]	?	edge_idat_data_lead[1]	:
									cube_link_edge_enab[2]	?	edge_idat_data_lead[2]	:
									cube_link_edge_enab[3]	?	edge_idat_data_lead[3]	:
									cube_link_edge_enab[4]	?	edge_idat_data_lead[4]	:
									cube_link_edge_enab[5]	?	edge_idat_data_lead[5]	:
									cube_link_edge_enab[6]	?	edge_idat_data_lead[6]	:
									cube_link_edge_enab[7]	?	edge_idat_data_lead[7]	:	1'B0	;

	assign	edge_solo_idat_wrcs	=	cube_link_edge_enab[0]	?	edge_idat_data_wrcs[0]	:
									cube_link_edge_enab[1]	?	edge_idat_data_wrcs[1]	:
									cube_link_edge_enab[2]	?	edge_idat_data_wrcs[2]	:
									cube_link_edge_enab[3]	?	edge_idat_data_wrcs[3]	:
									cube_link_edge_enab[4]	?	edge_idat_data_wrcs[4]	:
									cube_link_edge_enab[5]	?	edge_idat_data_wrcs[5]	:
									cube_link_edge_enab[6]	?	edge_idat_data_wrcs[6]	:
									cube_link_edge_enab[7]	?	edge_idat_data_wrcs[7]	:	1'B0	;

	assign	edge_solo_idat_word	=	cube_link_edge_enab[0]	?	edge_idat_data_word[0]	:
									cube_link_edge_enab[1]	?	edge_idat_data_word[1]	:
									cube_link_edge_enab[2]	?	edge_idat_data_word[2]	:
									cube_link_edge_enab[3]	?	edge_idat_data_word[3]	:
									cube_link_edge_enab[4]	?	edge_idat_data_word[4]	:
									cube_link_edge_enab[5]	?	edge_idat_data_word[5]	:
									cube_link_edge_enab[6]	?	edge_idat_data_word[6]	:
									cube_link_edge_enab[7]	?	edge_idat_data_word[7]	:	1'B0	;
/**********************************************************************************************************/
	reg								edge_lump_acks_samp	;
	reg								edge_lump_resp_samp	;
	reg		[ 3: 0]					edge_lump_acks_cnts	;
	reg		[ 3: 0]					edge_lump_resp_cnts	;

	reg								edge_lump_acks_wrcs	;
	reg								edge_lump_resp_wrcs	;
	wire							edge_lump_acks_lead	;
	wire							edge_lump_resp_lead	;
	wire							edge_lump_acks_tmax	;
	wire							edge_lump_resp_tmax	;
	
	assign	edge_lump_acks_lead	= &{edge_odat_acks_coda	, ~	edge_lump_acks_samp};
	assign	edge_lump_resp_lead	= &{edge_odat_resp_coda	, ~	edge_lump_resp_samp};
	assign	edge_lump_acks_tmax	=	edge_lump_acks_cnts	== `TPGM_LINK_ACKS_LENG	;
	assign	edge_lump_resp_tmax	=	edge_lump_resp_cnts	== `TPGM_LINK_RESP_LENG	;

	always@(posedge cube_clki or negedge cube_rstn)
	if(~cube_rstn) 					edge_lump_acks_samp	<=	0	;
	else if(~cube_link_scut_enab)	edge_lump_acks_samp	<=	0	;
	else							edge_lump_acks_samp	<=	edge_odat_acks_coda	;

	always@(posedge cube_clki or negedge cube_rstn)
	if(~cube_rstn) 					edge_lump_resp_samp	<=	0	;
	else if(~cube_link_scut_enab)	edge_lump_resp_samp	<=	0	;
	else							edge_lump_resp_samp	<=	edge_odat_resp_coda	;

	always@(posedge cube_clki or negedge cube_rstn)
	if(~cube_rstn) 					edge_lump_acks_wrcs	<=	0	;
	else if(~cube_link_scut_enab)	edge_lump_acks_wrcs	<=	0	;
	else if(edge_lump_acks_lead)	edge_lump_acks_wrcs	<=	1	;
	else if(edge_lump_acks_tmax)	edge_lump_acks_wrcs	<=	0	;

	always@(posedge cube_clki or negedge cube_rstn)
	if(~cube_rstn) 					edge_lump_resp_wrcs	<=	0	;
	else if(~cube_link_scut_enab)	edge_lump_resp_wrcs	<=	0	;
	else if(edge_lump_resp_lead)	edge_lump_resp_wrcs	<=	1	;
	else if(edge_lump_resp_tmax)	edge_lump_resp_wrcs	<=	0	;

	always@(posedge cube_clki or negedge cube_rstn)
	if(~cube_rstn) 					edge_lump_acks_cnts	<=	0	;
	else if(~cube_link_scut_enab)	edge_lump_acks_cnts	<=	0	;
	else if(edge_lump_acks_lead)	edge_lump_acks_cnts	<=	0	;
	else if(edge_lump_acks_tmax)	edge_lump_acks_cnts	<=	0	;
	else if(edge_lump_acks_wrcs)	edge_lump_acks_cnts	<=	edge_lump_acks_cnts + 1	;

	always@(posedge cube_clki or negedge cube_rstn)
	if(~cube_rstn) 					edge_lump_resp_cnts	<=	0	;
	else if(~cube_link_scut_enab)	edge_lump_resp_cnts	<=	0	;
	else if(edge_lump_resp_lead)	edge_lump_resp_cnts	<=	0	;
	else if(edge_lump_resp_tmax)	edge_lump_resp_cnts	<=	0	;
	else if(edge_lump_resp_wrcs)	edge_lump_resp_cnts	<=	edge_lump_resp_cnts + 1	;

	assign	scut_acks_memo_indx	=	edge_lump_acks_cnts[2: 0]	;
/**********************************************************************************************************/
	reg								edge_scut_root_actv	;
	reg		[31: 0]					edge_scut_root_word	;
	wire	[31: 0]					edge_scut_data_word	;

	always@(posedge cube_clki or negedge cube_rstn)
	if(~cube_rstn) 						edge_scut_root_word	<=	0		;
	else if(~cube_link_scut_enab)		edge_scut_root_word	<=	0		;
	else if(~cube_link_scut_type)	begin//ODAT SCUT
		     if(edge_lump_acks_lead)	edge_scut_root_word	<=	`CUBE_LINK_ACKS_LEAD	;
		else if(edge_lump_resp_lead)	edge_scut_root_word	<=	`CUBE_LINK_RESP_LEAD	;
		else if(edge_lump_acks_wrcs)	edge_scut_root_word	<=	scut_acks_memo_data		;
		else							edge_scut_root_word	<=	32'H0					;
	end  else						begin//IDAT SCUT
		     if(edge_solo_acks_lead)	edge_scut_root_word	<=	`CUBE_LINK_ACKS_LEAD	;
		else if(edge_solo_resp_lead)	edge_scut_root_word	<=	`CUBE_LINK_RESP_LEAD	;
		else if(edge_solo_idat_lead)	edge_scut_root_word	<=	`CUBE_LINK_DATA_LEAD	;
		else if(edge_solo_acks_wrcs)	edge_scut_root_word	<=	edge_solo_idat_word		;
		else if(edge_solo_idat_wrcs)	edge_scut_root_word	<=	edge_solo_idat_word		;
		else							edge_scut_root_word	<=	32'H0					;
	end

	always@(posedge cube_clki or negedge cube_rstn)
	if(~cube_rstn) 						edge_scut_root_actv	<=	0		;
	else if(~cube_link_scut_enab)		edge_scut_root_actv	<=	0		;
	else if(~cube_link_scut_type)	begin//ODAT SCUT
		     if(edge_lump_acks_lead)	edge_scut_root_actv	<=	1'B1	;
		else if(edge_lump_resp_lead)	edge_scut_root_actv	<=	1'B1	;
		else if(edge_lump_acks_wrcs)	edge_scut_root_actv	<=	1'B1	;
		else if(edge_lump_resp_wrcs)	edge_scut_root_actv	<=	1'B1	;
		else							edge_scut_root_actv	<=	1'B0	;
	end  else						begin//IDAT SCUT
		     if(edge_solo_acks_lead)	edge_scut_root_actv	<=	1'B1	;
		else if(edge_solo_resp_lead)	edge_scut_root_actv	<=	1'B1	;
		else if(edge_solo_idat_lead)	edge_scut_root_actv	<=	1'B1	;
		else if(edge_solo_acks_wrcs)	edge_scut_root_actv	<=	1'B1	;
		else if(edge_solo_resp_wrcs)	edge_scut_root_actv	<=	1'B1	;
		else if(edge_solo_idat_wrcs)	edge_scut_root_actv	<=	1'B1	;
		else							edge_scut_root_actv	<=	1'B0	;
	end

	assign	edge_scut_root_fram	={8{edge_scut_root_actv}}		;
	assign	edge_scut_root_dat3	=	edge_scut_root_word[31:24]	;
	assign	edge_scut_root_dat2	=	edge_scut_root_word[23:16]	;
	assign	edge_scut_root_dat1	=	edge_scut_root_word[15: 8]	;
	assign	edge_scut_root_dat0	=	edge_scut_root_word[ 7: 0]	;
/**********************************************************************************************************/								
									
endmodule