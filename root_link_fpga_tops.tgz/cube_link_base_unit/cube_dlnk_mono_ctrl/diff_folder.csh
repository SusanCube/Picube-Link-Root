#!/bin/csh

# Interactive folder difference viewer
# Function: Compare two folders, list different files, can choose to view detailed differences

# --- Input Validation ---
echo "Enter first folder path:"
set folder1 = "$<"
while (! -d "$folder1")
    echo "Error: '$folder1' is not a valid folder, please re-enter:"
    set folder1 = "$<"
end

echo "Enter second folder path:"
set folder2 = "$<"
while (! -d "$folder2")
    echo "Error: '$folder2' is not a valid folder, please re-enter:"
    set folder2 = "$<"
end

# Normalize paths (remove trailing /)
set folder1 = `echo "$folder1" | sed 's/\/$//'`
set folder2 = `echo "$folder2" | sed 's/\/$//'`

echo "\nComparing '$folder1' and '$folder2' ..."

# Get difference list
set diff_lines = `diff -rq "$folder1" "$folder2"`

if ($#diff_lines == 0) then
    echo "\n? Two folders are identical"
    exit 0
endif

# --- Main Interactive Loop ---
while (1)
    echo "\n========== Different Files List =========="
    set i = 1
    foreach line ($diff_lines)
        echo "$i) $line"
        @ i++
    end
    echo "0) Exit"
    echo "=================================="
    
    echo "\nEnter number to view detailed differences (0 to exit):"
    set choice = "$<"
    
    if ("$choice" == "0") then
        echo "Exited"
        break
    endif
    
    if ($choice < 1 || $choice > $#diff_lines) then
        echo "Error: Invalid number, please re-select"
        continue
    endif
    
    set line = "$diff_lines[$choice]"
    
    # Parse and display detailed differences
    if ("$line" =~ Files*and*differ) then
        # Extract two file paths
        set file1 = `echo "$line" | awk '{print $2}'`
        set file2 = `echo "$line" | awk '{print $4}'`
        
        echo "\nDetailed differences ($file1 vs $file2):"
        echo "----------------------------------------"
        
        # Check if colordiff is available
        if (`which colordiff` != "") then
            colordiff -u "$file1" "$file2" | less -R
        else
            diff -u "$file1" "$file2" | less
        endif
        
    else
        # Only exists in one directory
        echo "\nDetailed information:"
        echo "$line"
        echo "(File exists only in one directory, cannot compare content)"
    endif
    
    echo "\nPress Enter to return to main menu..."
    set dummy = "$<"
end