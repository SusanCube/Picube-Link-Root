//e.g 32000 cols ,16000 words ,	2000 page	,250 PACK  PACK_NUMB =	COLS_NUMB/2/8/8
//e.g 13824 cols ,6912  words ,	864  page	,108 PACK	
//e.g 8192  cols ,4096  words ,	512  page	,64  PACK	
//e.g 6656  cols ,3328  words ,	416  page	,108 PACK	
//e.g 5120  cols ,2560  words ,	 320 page	, 40 PACK  
//e.g 256   cols ,128   words ,	  16 page	,  2 PACK  

`include	"agile_card_vars.vh"

module	ubus_rdma_tile_mfsm(
	input								ubus_rdma_tile_enab	,
	output								ubus_rdma_tile_done	,
	
	output								ubus_rdma_pack_reqs	,
	output	reg	[24: 0]					ubus_rdma_pack_addr	,
	input								ubus_rdma_pack_crdy	,
	input								ubus_rdma_pack_drdy	,
		
	input								dlnk_odat_load_csen	,
	input								dlnk_odat_coda_csen	,
		
	input		[24: 0]					llmb_mast_ddrs_base	,
	input		[15: 0]					llmb_meta_imag_cols	,
	input		[14: 0]					llmb_tile_rows_numb	,
	input		[12: 0]					llmb_tile_pack_numb	,
		
	input								ubus_clki			,
	input								ubus_rstn			);
/**********************************************************************************************************/
//--------------UBUS_RDMA_TILE_MFSM
	reg		[ 3: 0]					ubus_rdma_tile_mfsm	;

	parameter	UBUS_ODAT_RDMA_IDLE	=	4'H0	;
	parameter	UBUS_ODAT_LEAD_WAIT	=	4'H1	;
	parameter	UBUS_COLS_PACK_CMND	=	4'H2	;
	parameter	UBUS_COLS_PACK_DATA	=	4'H3	;
	parameter	UBUS_PACK_ROWS_LOOP	=	4'H4	;
	parameter	UBUS_ODAT_MUTE_WAIT	=	4'H5	;
	parameter	UBUS_TILE_PACK_LOOP	=	4'H6	;
	parameter	UBUS_TILE_ROWS_LOOP	=	4'H7	;
	parameter	UBUS_ODAT_RDMA_DONE	=	4'H8	;

	wire							rdma_pack_rows_last	;
	wire							rdma_tile_pack_last	;
	wire							rdma_tile_rows_last	;
	
	always@(posedge ubus_clki or negedge ubus_rstn)
	if(!ubus_rstn)					ubus_rdma_tile_mfsm	<=	UBUS_ODAT_RDMA_IDLE	;
	else if(~ubus_rdma_tile_enab)	ubus_rdma_tile_mfsm	<=	UBUS_ODAT_RDMA_IDLE	;
	else begin
		case(ubus_rdma_tile_mfsm)
		
			UBUS_ODAT_RDMA_IDLE	:	ubus_rdma_tile_mfsm	<=													UBUS_ODAT_LEAD_WAIT	;	

			UBUS_ODAT_LEAD_WAIT	:	ubus_rdma_tile_mfsm	<=	dlnk_odat_load_csen	?	UBUS_COLS_PACK_CMND	:	UBUS_ODAT_LEAD_WAIT	;
			
			UBUS_COLS_PACK_CMND	:	ubus_rdma_tile_mfsm	<=	ubus_rdma_pack_crdy	?	UBUS_COLS_PACK_DATA	:	UBUS_COLS_PACK_CMND	;

			UBUS_COLS_PACK_DATA	:	ubus_rdma_tile_mfsm	<=	ubus_rdma_pack_drdy	?	UBUS_PACK_ROWS_LOOP	:	UBUS_COLS_PACK_DATA	;

			UBUS_PACK_ROWS_LOOP	:	ubus_rdma_tile_mfsm	<=	rdma_pack_rows_last	?	UBUS_ODAT_MUTE_WAIT	:	UBUS_COLS_PACK_CMND	;

			UBUS_ODAT_MUTE_WAIT	:	ubus_rdma_tile_mfsm	<=	dlnk_odat_coda_csen	?	UBUS_TILE_PACK_LOOP	:	UBUS_ODAT_MUTE_WAIT	;
			
			UBUS_TILE_PACK_LOOP	:	ubus_rdma_tile_mfsm	<=	rdma_tile_pack_last	?	UBUS_TILE_ROWS_LOOP	:	UBUS_ODAT_LEAD_WAIT	;

			UBUS_TILE_ROWS_LOOP	:	ubus_rdma_tile_mfsm	<=	rdma_tile_rows_last	?	UBUS_ODAT_RDMA_DONE	:	UBUS_ODAT_LEAD_WAIT	;
			
			UBUS_ODAT_RDMA_DONE	:	ubus_rdma_tile_mfsm	<=	ubus_rdma_tile_enab	?	UBUS_ODAT_RDMA_DONE	:	UBUS_ODAT_RDMA_IDLE	;

			default				:	ubus_rdma_tile_mfsm	<=													UBUS_ODAT_RDMA_IDLE	;
		endcase
	end	
/**********************************************************************************************************/
//--------------UBUS_RDMA_TILE_Misc
	wire		ubus_hits_rdma_idle	=	ubus_rdma_tile_mfsm	==	UBUS_ODAT_RDMA_IDLE	;
	wire		ubus_hits_odat_lead	=	ubus_rdma_tile_mfsm	==	UBUS_ODAT_LEAD_WAIT	;
	wire		ubus_hits_pack_cmnd	=	ubus_rdma_tile_mfsm	==	UBUS_COLS_PACK_CMND	;
	wire		ubus_hits_pack_data	=	ubus_rdma_tile_mfsm	==	UBUS_COLS_PACK_DATA	;
	wire		ubus_hits_pack_rows	=	ubus_rdma_tile_mfsm	==	UBUS_PACK_ROWS_LOOP	;
	wire		ubus_hits_odat_mute	=	ubus_rdma_tile_mfsm	==	UBUS_ODAT_MUTE_WAIT	;
	wire		ubus_hits_tile_pack	=	ubus_rdma_tile_mfsm	==	UBUS_TILE_PACK_LOOP	;
	wire		ubus_hits_tile_rows	=	ubus_rdma_tile_mfsm	==	UBUS_TILE_ROWS_LOOP	;
	assign		ubus_rdma_tile_done	=	ubus_rdma_tile_mfsm	==	UBUS_ODAT_RDMA_DONE	;

	assign		ubus_rdma_pack_reqs	=	ubus_hits_pack_cmnd	;
//----------------------------------------------------------------------	
	reg			[ 5: 0]				pack_rows_loop_indx	;//used for UBUS_PACK_ROWS_LOOP ,Range pack_rows(32)
	reg			[12: 0]				tile_pack_loop_indx	;//used for UBUS_TILE_PACK_LOOP ,Range meta_cols([19:0]) / pack_cols (128)
	reg			[14: 0]				tile_rows_loop_indx	;//used for UBUS_TILE_ROWS_LOOP ,Range meta_rows([19:0]) / tile_rows (32)

	wire		[ 5: 0]				pack_rows_indx_inc1	;
	wire		[12: 0]				tile_pack_indx_inc1	;
	wire		[14: 0]				tile_rows_indx_inc1	;

	wire							rdma_pack_rows_next	;
	wire							rdma_tile_pack_done	;
	wire							rdma_tile_rows_done	;

	assign		pack_rows_indx_inc1	=	pack_rows_loop_indx + 1	;
	assign		tile_pack_indx_inc1	=	tile_pack_loop_indx + 1	;
	assign		tile_rows_indx_inc1	=	tile_rows_loop_indx + 1	;

	assign		rdma_pack_rows_last	=	pack_rows_loop_indx	==	6'H20				;
	assign		rdma_tile_pack_last	=	tile_pack_indx_inc1	==	llmb_tile_pack_numb	;
	assign		rdma_tile_rows_last	=	tile_rows_indx_inc1	==	llmb_tile_rows_numb	;

	assign		rdma_pack_rows_next	= &{ubus_hits_pack_cmnd	,	ubus_rdma_pack_crdy	};//ubus_hits_pack_rows	;
	assign		rdma_tile_pack_done	=	ubus_hits_tile_pack	;
	assign		rdma_tile_rows_done	=	ubus_hits_tile_rows	;

	always@(posedge ubus_clki or negedge ubus_rstn)
	if(!ubus_rstn)					pack_rows_loop_indx	<=	0	;
	else if(ubus_hits_rdma_idle)	pack_rows_loop_indx	<=	0	;
	else if(ubus_hits_odat_mute)	pack_rows_loop_indx	<=	0	;
	else if(rdma_pack_rows_next)	pack_rows_loop_indx	<=	rdma_pack_rows_last	?	 6'H0	:	pack_rows_indx_inc1	;

	always@(posedge ubus_clki or negedge ubus_rstn)
	if(!ubus_rstn)					tile_pack_loop_indx	<=	0	;
	else if(ubus_hits_rdma_idle)	tile_pack_loop_indx	<=	0	;
	else if(rdma_tile_pack_done)	tile_pack_loop_indx	<=	rdma_tile_pack_last	?	13'H0	:	tile_pack_indx_inc1	;

	always@(posedge ubus_clki or negedge ubus_rstn)
	if(!ubus_rstn)					tile_rows_loop_indx	<=	0	;
	else if(ubus_hits_rdma_idle)	tile_rows_loop_indx	<=	0	;
	else if(ubus_hits_tile_rows)	tile_rows_loop_indx	<=	rdma_tile_rows_last	?	15'H0	:	tile_rows_indx_inc1	;
/**********************************************************************************************************/
//--------------UBUS_RDMA_TILE_ADDR
	wire	[19: 0]					meta_tile_rows_indx	= (	tile_rows_loop_indx * 32 )	+	pack_rows_loop_indx	;
	wire	[24: 0]					meta_tile_rows_base	= 	meta_tile_rows_indx 		*	llmb_meta_imag_cols	;
	
	wire	[24: 0]					meta_rows_pack_bias	=	tile_pack_loop_indx *  8	;
	wire	[24: 0]					meta_rows_pack_base	=	meta_rows_pack_bias			+	llmb_mast_ddrs_base	;

	reg		[24: 0]					meta_tile_rows_addr	;
	reg		[24: 0]					meta_rows_pack_addr	;

	always@(posedge ubus_clki or negedge ubus_rstn)
	if(!ubus_rstn)					meta_tile_rows_addr	<=	0	;
	else							meta_tile_rows_addr	<=	meta_tile_rows_base ;

	always@(posedge ubus_clki or negedge ubus_rstn)
	if(!ubus_rstn)					meta_rows_pack_addr	<=	0	;
	else							meta_rows_pack_addr	<=	meta_rows_pack_base	;

	always@(posedge ubus_clki or negedge ubus_rstn)
	if(!ubus_rstn)					ubus_rdma_pack_addr	<=	0	;
	else if( ubus_hits_rdma_idle)	ubus_rdma_pack_addr	<=	0	;
	else 							ubus_rdma_pack_addr	<=	meta_tile_rows_addr + meta_rows_pack_addr 	;
	



endmodule

