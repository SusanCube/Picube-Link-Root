
module	tpem_link_txdo_pmau(
	input								tune_txdo_enab	,		

	output								lvds_fclk_outp	,
	output								lvds_fclk_outn	,
	output								lvds_fram_outp	,
	output								lvds_fram_outn	,
	output								lvds_dat0_outp	,
	output								lvds_dat0_outn	,
	output								lvds_dat1_outp	,
	output								lvds_dat1_outn	,
	output								lvds_dat2_outp	,
	output								lvds_dat2_outn	,
	output								lvds_dat3_outp	,
	output								lvds_dat3_outn	,

	input	[ 7: 0]						lvds_fram_mbdi	,
	input	[ 7: 0]						lvds_dat0_mbdi	,
	input	[ 7: 0]						lvds_dat1_mbdi	,
	input	[ 7: 0]						lvds_dat2_mbdi	,
	input	[ 7: 0]						lvds_dat3_mbdi	,

	input								link_fclk		,
	input								link_strb		,
	input								link_rstn		);
/**********************************************************************************************************/
	reg		[ 1: 0]						tune_txdo_samp	;
	reg									tune_txdo_mode	;
	reg		[ 7: 0]						tune_txdo_shft	;

	always@(posedge  link_fclk or negedge link_rstn)
	if(~link_rstn)						tune_txdo_samp	<=	0	;
	else								tune_txdo_samp	<={	tune_txdo_enab	, tune_txdo_samp[1]	};

	always@(posedge  link_fclk or negedge link_rstn)
	if(~link_rstn)						tune_txdo_mode	<=	0	;
	else if(link_strb)					tune_txdo_mode	<=	tune_txdo_samp[0]	;

	always@(posedge link_fclk or negedge link_rstn)
	if(!link_rstn) 						tune_txdo_shft	<=	0		;
	else if(~tune_txdo_mode)			tune_txdo_shft	<=  0		;
	else if(link_strb)					tune_txdo_shft	<=  8'H9A	;
	else 								tune_txdo_shft	<= {tune_txdo_shft[5:0]	,tune_txdo_shft[7:6]	};
/**********************************************************************************************************/
	reg		[ 7: 0]						lvds_fram_shft	;	
	reg		[ 7: 0]						lvds_dat0_shft	;	
	reg		[ 7: 0]						lvds_dat1_shft	;	
	reg		[ 7: 0]						lvds_dat2_shft	;	
	reg		[ 7: 0]						lvds_dat3_shft	;	

	always@(posedge link_fclk or negedge link_rstn)
	if(!link_rstn) begin
		lvds_fram_shft					<=	0	;
		lvds_dat0_shft					<=	0	;
		lvds_dat1_shft					<=	0	;
		lvds_dat2_shft					<=	0	;
		lvds_dat3_shft					<=	0	;
	end else if(link_strb)	begin
		lvds_fram_shft					<=	lvds_fram_mbdi	;
		lvds_dat0_shft					<=	lvds_dat0_mbdi	;
		lvds_dat1_shft					<=	lvds_dat1_mbdi	;
		lvds_dat2_shft					<=	lvds_dat2_mbdi	;
		lvds_dat3_shft					<=	lvds_dat3_mbdi	;
	end else begin
		lvds_fram_shft					<={	lvds_fram_shft[5:0]	,2'B00	};
		lvds_dat0_shft					<={	lvds_dat0_shft[5:0]	,2'B00	};
		lvds_dat1_shft					<={	lvds_dat1_shft[5:0]	,2'B00	};
		lvds_dat2_shft					<={	lvds_dat2_shft[5:0]	,2'B00	};
		lvds_dat3_shft					<={	lvds_dat3_shft[5:0]	,2'B00	};
	end
/**********************************************************************************************************/
	wire								lvds_fram_d0	;
	wire								lvds_dat0_d0	;
	wire								lvds_dat1_d0	;
	wire								lvds_dat2_d0	;
	wire								lvds_dat3_d0	;

	wire								lvds_fram_d1	;
	wire								lvds_dat0_d1	;
	wire								lvds_dat1_d1	;
	wire								lvds_dat2_d1	;
	wire								lvds_dat3_d1	;

	assign		lvds_fram_d0	=		lvds_fram_shft[7]	| tune_txdo_shft[7]	;
	assign		lvds_fram_d1	=		lvds_fram_shft[6]	| tune_txdo_shft[6]	;

	assign		lvds_dat0_d0	=		lvds_dat0_shft[7]	| tune_txdo_shft[7]	;
	assign		lvds_dat0_d1	=		lvds_dat0_shft[6]	| tune_txdo_shft[6]	;

	assign		lvds_dat1_d0	=		lvds_dat1_shft[7]	| tune_txdo_shft[7]	;
	assign		lvds_dat1_d1	=		lvds_dat1_shft[6]	| tune_txdo_shft[6]	;

	assign		lvds_dat2_d0	=		lvds_dat2_shft[7]	| tune_txdo_shft[7]	;
	assign		lvds_dat2_d1	=		lvds_dat2_shft[6]	| tune_txdo_shft[6]	;

	assign		lvds_dat3_d0	=		lvds_dat3_shft[7]	| tune_txdo_shft[7]	;
	assign		lvds_dat3_d1	=		lvds_dat3_shft[6]	| tune_txdo_shft[6]	;
/***ODDRE1_FCLK*******************************************************************************************************/
//		.D1								(fclk_pola_c1		),	// 1-bit input: Parallel data input 1
//		.D2								(fclk_pola_c2		),	// 1-bit input: Parallel data input 2
  	ODDRE1 #(
		.IS_C_INVERTED					(1'b0				),	// Optional inversion for C
		.IS_D1_INVERTED					(1'b0				),  // Unsupported, do not use
		.IS_D2_INVERTED					(1'b0				),  // Unsupported, do not use
		.SIM_DEVICE						("ULTRASCALE"		), 	// Set the device version for simulation functionality (ULTRASCALE)
		.SRVAL							(1'b0				))	// Initializes the ODDRE1 Flip-Flops to the specified value (1'b0, 1'b1)
	ODDRE1_FCLK (	
		.Q								(lvds_fclk_txdw		),	// 1-bit output: Data output to IOB
		.D1								(1'b0				),	// 1-bit input: Parallel data input 1
		.D2								(1'b1				),	// 1-bit input: Parallel data input 2
		.C								(link_fclk			),	// 1-bit input: High-speed clock input
		.SR								(1'B0				)); // 1-bit input: Active-High Async Reset

	OBUFDS							LVDS_FCLK_OUTP	(
		.I								(lvds_fclk_txdw		),
		.O								(lvds_fclk_outp		),
		.OB								(lvds_fclk_outn		));
/***LVDS_FRAM_OUTP*******************************************************************************************************/
  	ODDRE1 #(
		.IS_C_INVERTED				(1'b0				),	// Optional inversion for C
		.IS_D1_INVERTED				(1'b0				),  // Unsupported, do not use
		.IS_D2_INVERTED				(1'b0				),  // Unsupported, do not use
		.SIM_DEVICE					("ULTRASCALE"		), 	// Set the device version for simulation functionality (ULTRASCALE)
		.SRVAL						(1'b0				))	// Initializes the ODDRE1 Flip-Flops to the specified value (1'b0, 1'b1)
	ODDRE1_FRAM (
		.Q							(lvds_fram_txdw		),// 1-bit output: Data output to IOB
		.D1							(lvds_fram_d0		),// 1-bit input: Parallel data input 1
		.D2							(lvds_fram_d1		),// 1-bit input: Parallel data input 2
		.C							(link_fclk			),// 1-bit input: High-speed clock input
		.SR							(1'B0				));  // 1-bit input: Active-High Async Reset

	OBUFDS						LVDS_FRAM_OUTP	(
		.I							(lvds_fram_txdw		),
		.O							(lvds_fram_outp		),
		.OB							(lvds_fram_outn		));
/***LVDS_DAT0_OUTP*******************************************************************************************************/
  	ODDRE1 #(
		.IS_C_INVERTED				(1'b0				),	// Optional inversion for C
		.IS_D1_INVERTED				(1'b0				),  // Unsupported, do not use
		.IS_D2_INVERTED				(1'b0				),  // Unsupported, do not use
		.SIM_DEVICE					("ULTRASCALE"		), 	// Set the device version for simulation functionality (ULTRASCALE)
		.SRVAL						(1'b0				))	// Initializes the ODDRE1 Flip-Flops to the specified value (1'b0, 1'b1)
	ODDRE1_DAT0 (
		.Q							(lvds_dat0_txdw		),// 1-bit output: Data output to IOB
		.D1							(lvds_dat0_d0		),// 1-bit input: Parallel data input 1
		.D2							(lvds_dat0_d1		),// 1-bit input: Parallel data input 2
		.C							(link_fclk			),// 1-bit input: High-speed clock input
		.SR							(1'B0				));  // 1-bit input: Active-High Async Reset

	OBUFDS						LVDS_DAT0_OUTP	(
		.I							(lvds_dat0_txdw		),
		.O							(lvds_dat0_outp		),
		.OB							(lvds_dat0_outn		));
/***LVDS_DAT1_OUTP*******************************************************************************************************/
 	ODDRE1 #(
		.IS_C_INVERTED				(1'b0				),	// Optional inversion for C
		.IS_D1_INVERTED				(1'b0				),  // Unsupported, do not use
		.IS_D2_INVERTED				(1'b0				),  // Unsupported, do not use
		.SIM_DEVICE					("ULTRASCALE"		), 	// Set the device version for simulation functionality (ULTRASCALE)
		.SRVAL						(1'b0				))	// Initializes the ODDRE1 Flip-Flops to the specified value (1'b0, 1'b1)
	ODDRE1_DAT1 (
		.Q							(lvds_dat1_txdw		),// 1-bit output: Data output to IOB
		.D1							(lvds_dat1_d0		),// 1-bit input: Parallel data input 1
		.D2							(lvds_dat1_d1		),// 1-bit input: Parallel data input 2
		.C							(link_fclk			),// 1-bit input: High-speed clock input
		.SR							(1'B0				));  // 1-bit input: Active-High Async Reset

	OBUFDS						LVDS_DAT1_OUTP	(
		.I							(lvds_dat1_txdw		),
		.O							(lvds_dat1_outp		),
		.OB							(lvds_dat1_outn		));
/***LVDS_DAT2_OUTP*******************************************************************************************************/
 	ODDRE1 #(
		.IS_C_INVERTED				(1'b0				),	// Optional inversion for C
		.IS_D1_INVERTED				(1'b0				),  // Unsupported, do not use
		.IS_D2_INVERTED				(1'b0				),  // Unsupported, do not use
		.SIM_DEVICE					("ULTRASCALE"		), 	// Set the device version for simulation functionality (ULTRASCALE)
		.SRVAL						(1'b0				))	// Initializes the ODDRE1 Flip-Flops to the specified value (1'b0, 1'b1)
	ODDRE1_DAT2 (
		.Q							(lvds_dat2_txdw		),// 1-bit output: Data output to IOB
		.D1							(lvds_dat2_d0		),// 1-bit input: Parallel data input 1
		.D2							(lvds_dat2_d1		),// 1-bit input: Parallel data input 2
		.C							(link_fclk			),// 1-bit input: High-speed clock input
		.SR							(1'B0				));  // 1-bit input: Active-High Async Reset

	OBUFDS						LVDS_DAT2_OUTP	(
		.I							(lvds_dat2_txdw		),
		.O							(lvds_dat2_outp		),
		.OB							(lvds_dat2_outn		));
/***LVDS_DAT3_OUTP*******************************************************************************************************/
 	ODDRE1 #(
		.IS_C_INVERTED				(1'b0				),	// Optional inversion for C
		.IS_D1_INVERTED				(1'b0				),  // Unsupported, do not use
		.IS_D2_INVERTED				(1'b0				),  // Unsupported, do not use
		.SIM_DEVICE					("ULTRASCALE"		), 	// Set the device version for simulation functionality (ULTRASCALE)
		.SRVAL						(1'b0				))	// Initializes the ODDRE1 Flip-Flops to the specified value (1'b0, 1'b1)
	ODDRE1_DAT3 (
		.Q							(lvds_dat3_txdw		),// 1-bit output: Data output to IOB
		.D1							(lvds_dat3_d0		),// 1-bit input: Parallel data input 1
		.D2							(lvds_dat3_d1		),// 1-bit input: Parallel data input 2
		.C							(link_fclk			),// 1-bit input: High-speed clock input
		.SR							(1'B0				));  // 1-bit input: Active-High Async Reset

	OBUFDS						LVDS_DAT3_OUTP	(
		.I							(lvds_dat3_txdw		),
		.O							(lvds_dat3_outp		),
		.OB							(lvds_dat3_outn		));

endmodule
 