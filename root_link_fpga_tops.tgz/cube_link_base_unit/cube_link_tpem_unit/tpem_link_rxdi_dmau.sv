/*		lvds_rxdi_intf
	fram_sdi---->lvds_rxdi_line		
					|----IDLY----IDDR----SHFT----lane_trim_cell---->lvds_fram_mbo0

*/

`include	"agile_card_vars.vh"

module	tpem_link_rxdi_dmau(
	input						    	link_rxdi_port_enab	,
	input						    	link_rxdi_port_init	,
	input		[11: 0]			    	link_rxdi_port_cols	,//old bit[10:0]
	
	input					    		link_rxdi_fram_lead	,
	input					    		link_rxdi_fram_body	,
	input					    		link_rxdi_fram_coda	,
	input		[7:0]		    		link_rxdi_dat0_mbdi	,
	input		[7:0]		    		link_rxdi_dat1_mbdi	,
	input		[7:0]		    		link_rxdi_dat2_mbdi	,
	input		[7:0]		    		link_rxdi_dat3_mbdi	,

	output						    	link_rxdi_acks_lead	,
	output	reg					    	link_rxdi_acks_coda	,
	output	reg					    	link_rxdi_acks_wrcs	,
	output	reg	[31: 0]			    	link_rxdi_acks_data	,

	output							    link_rxdi_resp_lead	,
	output	reg						    link_rxdi_resp_coda	,
	output	reg						    link_rxdi_resp_wrcs	,
		
	output							    link_rxdi_data_lead	,
	output	reg						    link_rxdi_data_wrcs	,
	output	reg	[31: 0]				    link_rxdi_data_word	,

	input							    link_clki			,
	input							    link_rstn			);
/**********************************************************************************************************/
	reg							    	link_rxdi_acks_flag	;
	reg							    	link_rxdi_resp_flag	;
	reg							    	link_rxdi_data_flag	;
//----------------------------------------------------------------------------------------------------------
	wire	[ 31: 0]				    link_rxdi_data_buff	;

	wire	link_acks_lead_pole	=   &{  link_rxdi_fram_lead	,	link_rxdi_data_buff	==	`CUBE_LINK_ACKS_LEAD	};
	wire	link_resp_lead_pole	=   &{  link_rxdi_fram_lead	,	link_rxdi_data_buff	==	`CUBE_LINK_RESP_LEAD	};
	wire	link_data_lead_pole	=   &{  link_rxdi_fram_lead ,   link_rxdi_data_buff	==	`CUBE_LINK_DATA_LEAD    };
    
	wire	link_acks_coda_pole	=   &{  link_rxdi_fram_coda	,	link_rxdi_acks_flag	};
	wire	link_resp_coda_pole	=   &{  link_rxdi_fram_coda	,	link_rxdi_resp_flag	};
	wire	link_data_coda_pole	=   &{  link_rxdi_fram_coda	,	link_rxdi_data_flag	};

	assign	link_rxdi_data_buff	=   {	link_rxdi_dat3_mbdi	,	
                                        link_rxdi_dat2_mbdi	,	
                                        link_rxdi_dat1_mbdi	,	
                                        link_rxdi_dat0_mbdi	};
/**********************************************************************************************************/
	always@(posedge link_clki or negedge link_rstn)	
	if(~link_rstn)					    link_rxdi_acks_flag	<=	0	;
	else if(~link_rxdi_port_enab)	    link_rxdi_acks_flag	<=	0	;
	else if( link_rxdi_port_init)	    link_rxdi_acks_flag	<=	0	;	
	else if( link_acks_lead_pole)	    link_rxdi_acks_flag	<=	1	;
	else if( link_acks_coda_pole)	    link_rxdi_acks_flag	<=	0	;
//----------------------------------------------------------------------	
	assign	link_rxdi_acks_lead	=	    link_acks_coda_pole	;	
	
	always@(posedge link_clki or negedge link_rstn)	
	if(~link_rstn)					    link_rxdi_acks_coda	<=	0	;
	else if(~link_rxdi_port_enab)	    link_rxdi_acks_coda	<=	0	;
	else if( link_rxdi_port_init)	    link_rxdi_acks_coda	<=	0	;
	else if( link_acks_coda_pole)	    link_rxdi_acks_coda	<=	1	;

	always@(posedge link_clki or negedge link_rstn)	
	if(~link_rstn)					    link_rxdi_acks_wrcs	<=	0	;
	else if(~link_rxdi_port_enab)	    link_rxdi_acks_wrcs	<=	0	;
	else if( link_rxdi_port_init)	    link_rxdi_acks_wrcs	<=	0	;
	else							    link_rxdi_acks_wrcs	<=	link_acks_coda_pole	;
	
	always@(posedge link_clki or negedge link_rstn)	
	if(~link_rstn)					    link_rxdi_acks_data	<=	0	;
	else if(~link_rxdi_port_enab)	    link_rxdi_acks_data	<=	0	;
	else if( link_rxdi_port_init)	    link_rxdi_acks_data	<=	0	;
	else if( link_rxdi_acks_flag)	    link_rxdi_acks_data	<=	link_rxdi_fram_body	?	link_rxdi_data_buff	:	link_rxdi_acks_data	;
/**********************************************************************************************************/
	always@(posedge link_clki or negedge link_rstn)	
	if(~link_rstn)					    link_rxdi_resp_flag	<=	0	;
	else if(~link_rxdi_port_enab)	    link_rxdi_resp_flag	<=	0	;
	else if( link_rxdi_port_init)	    link_rxdi_resp_flag	<=	0	;	
	else if( link_resp_lead_pole)	    link_rxdi_resp_flag	<=	1	;
	else if( link_resp_coda_pole)	    link_rxdi_resp_flag	<=	0	;
//----------------------------------------------------------------------	
	assign	link_rxdi_resp_lead	=   	link_resp_coda_pole	;//
	
	always@(posedge link_clki or negedge link_rstn)	
	if(~link_rstn)					    link_rxdi_resp_coda	<=	0	;
	else if(~link_rxdi_port_enab)	    link_rxdi_resp_coda	<=	0	;
	else if( link_rxdi_port_init)	    link_rxdi_resp_coda	<=	0	;
	else if( link_resp_coda_pole)	    link_rxdi_resp_coda	<=	1	;

	always@(posedge link_clki or negedge link_rstn)	
	if(~link_rstn)					    link_rxdi_resp_wrcs	<=	0	;
	else if(~link_rxdi_port_enab)	    link_rxdi_resp_wrcs	<=	0	;
	else if( link_rxdi_port_init)	    link_rxdi_resp_wrcs	<=	0	;
	else							    link_rxdi_resp_wrcs	<=	link_resp_coda_pole	;
/**********************************************************************************************************/
	always@(posedge link_clki or negedge link_rstn)	
	if(~link_rstn)					    link_rxdi_data_flag	<=	0	;
	else if(~link_rxdi_port_enab)	    link_rxdi_data_flag	<=	0	;
	else if( link_rxdi_port_init)	    link_rxdi_data_flag	<=	0	;	
	else if( link_data_lead_pole)	    link_rxdi_data_flag	<=	1	;
	else if( link_data_coda_pole)	    link_rxdi_data_flag	<=	0	;
//----------------------------------------------------------------------	
	reg			[9: 0]				    link_rxdi_push_addr	;
	wire							    link_rxdi_push_csen	;
	reg			[9: 0]				    link_rxdi_pops_addr	;
	reg								    link_rxdi_pops_csen	;

	reg			[1: 0]				    link_pops_lead_samp	;

	wire							    link_rxdi_pops_lead	;
	wire							    link_rxdi_pops_coda	;
	wire		[10: 0]				    link_rxdi_pops_thrs	;
	wire		[10: 0]				    link_rxdi_pops_numb	;
	wire		[31:0]				    link_rxdi_pops_data	;

	assign	link_rxdi_pops_numb	=	    link_rxdi_port_cols[11:1] 		;
	assign	link_rxdi_pops_thrs	=	    link_rxdi_port_cols[11:2] + 2	;
	assign	link_rxdi_data_lead	= 	    link_pops_lead_samp	==	2'B10	;

	assign	link_rxdi_push_csen	= &{    link_rxdi_data_flag	,	link_rxdi_fram_body	};
	assign	link_rxdi_pops_lead	= &{    link_rxdi_data_flag	,	link_rxdi_push_addr	==	link_rxdi_pops_thrs	};	
	assign	link_rxdi_pops_coda	= &{    link_rxdi_pops_csen	,	link_rxdi_pops_addr+1==	link_rxdi_pops_numb };	
	
	always@(posedge link_clki or negedge link_rstn)	
	if(~link_rstn)					    link_rxdi_push_addr	<=	0	;
	else if(~link_rxdi_port_enab)	    link_rxdi_push_addr	<=	0	;
	else if( link_rxdi_port_init)	    link_rxdi_push_addr	<=	0	;	
	else if(~link_rxdi_data_flag)	    link_rxdi_push_addr	<=	0	;	
	else							    link_rxdi_push_addr	<=	link_rxdi_push_addr + 	link_rxdi_fram_body	;	

	always@(posedge link_clki or negedge link_rstn)	
	if(~link_rstn)					    link_rxdi_pops_csen	<=	0	;
	else if(~link_rxdi_port_enab)	    link_rxdi_pops_csen	<=	0	;
	else if( link_rxdi_port_init)	    link_rxdi_pops_csen	<=	0	;	
	else if( link_rxdi_pops_lead)	    link_rxdi_pops_csen	<=	1	;	
	else if( link_rxdi_pops_coda)	    link_rxdi_pops_csen	<=	0	;	

	always@(posedge link_clki or negedge link_rstn)	
	if(~link_rstn)					    link_rxdi_pops_addr	<=	0	;
	else if(~link_rxdi_port_enab)	    link_rxdi_pops_addr	<=	0	;
	else if( link_rxdi_port_init)	    link_rxdi_pops_addr	<=	0	;	
	else if(~link_rxdi_pops_csen)	    link_rxdi_pops_addr	<=	0	;	
	else							    link_rxdi_pops_addr	<=	link_rxdi_pops_addr + 1	;	

	always@(posedge link_clki or negedge link_rstn)	
	if(~link_rstn)					    link_pops_lead_samp	<=	0	;
	else if(~link_rxdi_port_enab)	    link_pops_lead_samp	<=	0	;
	else if( link_rxdi_port_init)	    link_pops_lead_samp	<=	0	;	
	else							    link_pops_lead_samp	<={	link_rxdi_pops_lead	, 	link_pops_lead_samp[1]	};

	always@(posedge link_clki or negedge link_rstn)	
	if(~link_rstn)					    link_rxdi_data_wrcs	<=	0	;
	else if(~link_rxdi_port_enab)	    link_rxdi_data_wrcs	<=	0	;
	else if( link_rxdi_port_init)	    link_rxdi_data_wrcs	<=	0	;	
	else							    link_rxdi_data_wrcs	<=	link_rxdi_pops_csen	;
	
	dual_port_bram	#(	
		.ADDR_BITS	( 10 ),	.DATA_BITS	( 32 ))	
	u_tpem_rxdi_fifo_memo (
		.wport_csen					    (link_rxdi_push_csen	),//input  				 		
		.wport_addr					    (link_rxdi_push_addr	),//input		[ADDR_BITS-1:0]
		.wport_data					    (link_rxdi_data_buff	),//input		[DATA_BITS-1:0]
		.wport_clki					    (link_clki				),//input						

		.rport_addr					    (link_rxdi_pops_addr	),//input		[ADDR_BITS-1:0]
		.rport_data					    (link_rxdi_pops_data	),//output	reg	[DATA_BITS-1:0]
		.rport_clki					    (link_clki				));//input						


	assign	link_rxdi_data_word	=	    link_rxdi_data_wrcs	?	link_rxdi_pops_data	:	0	;

endmodule

