/*----------------------------------------------------------------------
AUTHOR	: EDWARD YANG
//	output	reg	[ 0: 7]				tpem_port_txdo_tune	,
//	input		[ 0: 7][ 7: 0]		tpem_port_rxdi_fram	,
//	input		[ 0: 7]				tpem_link_port_tune	,
----------------------------------------------------------------------*/
module	tpem_link_esse_unit(
//--------------INTERFACE-0-LVDS-PADS 
	output		[ 0: 7][ 7: 0]		tpem_port_txdo_fram	,
	output		[ 0: 7][ 7: 0]		tpem_port_txdo_dat0	,
	output		[ 0: 7][ 7: 0]		tpem_port_txdo_dat1	,
	output		[ 0: 7][ 7: 0]		tpem_port_txdo_dat2	,
	output		[ 0: 7][ 7: 0]		tpem_port_txdo_dat3	,

	input		[ 7: 0]				tpem_port_rxdi_lead	,
	input		[ 7: 0]				tpem_port_rxdi_body	,
	input		[ 7: 0]				tpem_port_rxdi_coda	,
	input		[ 0: 7][ 7: 0]		tpem_port_rxdi_dat0	,
	input		[ 0: 7][ 7: 0]		tpem_port_rxdi_dat1	,
	input		[ 0: 7][ 7: 0]		tpem_port_rxdi_dat2	,
	input		[ 0: 7][ 7: 0]		tpem_port_rxdi_dat3	,
	
	output		[ 0: 7]				tpem_scfg_prog_outp	,
	output		[ 0: 7]				tpem_scfg_cclk_outp	,
	output		[ 0: 7]				tpem_scfg_data_outp	,
	input		[ 0: 7]				tpem_scfg_init_inpp	,
	input		[ 0: 7]				tpem_scfg_done_inpp	,
//--------------FABRIC MISC CONTROL
	input							tpem_link_pile_lead	,
	output							tpem_link_port_idle	,
	input		[ 7: 0]				tpem_link_port_enab	,
	input							tpem_link_port_init	,
	
	input							tpgs_link_scut_enab	,
	output	reg						tpgs_link_scut_done	,
	output							tpem_link_acks_coda	,
	output							tpem_link_resp_coda	,

	input							tpem_link_trim_reqs	,
	input							tpem_link_icfg_reqs	,
	input							tpem_link_ocfg_reqs	,
	input							tpem_link_nnex_reqs	,
	input							tpem_link_ivct_reqs	,
	input							tpem_link_ovct_reqs	,	
	input							tpem_link_imtx_reqs	,
	input							tpem_link_omtx_reqs	,	
	input							tpem_link_aset_reqs	,
	input							tpem_link_dnld_reqs	,
	input							tpem_link_boot_reqs	,
	input							tpem_scfg_aset_reqs	,
	input							tpem_scfg_dnld_reqs	,
	input							tpem_scfg_boot_reqs	,

	output							tpem_link_trim_done	,
	output							tpem_link_icfg_done	,
	output							tpem_link_ocfg_done	,
	output							tpem_link_nnex_done	,
	output							tpem_link_ivct_done	,
	output							tpem_link_ovct_done	,	
	output							tpem_link_imtx_done	,
	output							tpem_link_omtx_done	,	
	output							tpem_link_aset_done	,
	output							tpem_link_dnld_done	,
	output							tpem_link_boot_done	,
	output							tpem_scfg_aset_done	,
	output							tpem_scfg_dnld_done	,
	output							tpem_scfg_boot_done	,
	output		[17: 0]				tpem_scfg_tpes_stat	,
//--------------DATA EXCHANGE  CONTROL	
	output		[ 3: 0]				tpem_link_cmnd_indx	,
	input		[31: 0]				tpem_link_cmnd_data	,

	output		[ 3: 0]				tpem_xdat_cmnd_indx	,
	input		[31: 0]				tpem_xdat_cmnd_data	,

	output		[ 3: 0]				tpem_scfg_cmnd_indx	,
	input		[31: 0]				tpem_scfg_cmnd_data	,

	output		[ 0: 7]				tpes_link_acks_wrcs	,
	output		[ 0: 7][31: 0]		tpes_link_acks_data	,

	output	[ 2: 0]					scut_acks_memo_indx	,
	input	[31: 0]					scut_acks_memo_data	,
//--------------ECOS and LLMB Argument
//	input		[ 3: 0]				ecos_omni_pile_numb	,
	input		[24: 0]				llmb_mast_ddrs_base	,
	input		[19: 0]				llmb_meta_imag_rows	,
	input		[19: 0]				llmb_meta_imag_cols	,
	input		[19: 0]				llmb_mtrx_imag_cols	,
	
	input		[24: 0]				llmb_edge_imag_size	,
	input		[19: 0]				llmb_edge_imag_rows	,
	input		[19: 0]				llmb_edge_imag_cols	,
	input							llmb_edge_imag_even	,
	input							llmb_edge_imag_row2	,
//--------------DDRS' USER BUS
	output							ubus_tpem_wdma_csen	,
	output		[ 24: 0]			ubus_tpem_wdma_addr	,
	output		[255: 0]			ubus_tpem_wdma_data	,
	input							ubus_tpem_wdma_trdy	,
	input							ubus_tpem_wdma_wrdy	,

	output							ubus_tpem_rdma_csen	,
	output		[ 24: 0]			ubus_tpem_rdma_addr	,
	input							ubus_tpem_rdma_trdy	,
	input		[255: 0]			ubus_tpem_rdma_data	,
	input							ubus_tpem_rdma_drdy	,

	input		[ 7: 0]				tpgs_scut_tpem_fram	,
	input		[ 7: 0]				tpgs_scut_tpem_dat0	,
	input		[ 7: 0]				tpgs_scut_tpem_dat1	,
	input		[ 7: 0]				tpgs_scut_tpem_dat2	,
	input		[ 7: 0]				tpgs_scut_tpem_dat3	,
		
	output		[ 7: 0]				tpem_scut_tpgs_fram	,
	output		[ 7: 0]				tpem_scut_tpgs_dat3	,
	output		[ 7: 0]				tpem_scut_tpgs_dat2	,
	output		[ 7: 0]				tpem_scut_tpgs_dat1	,
	output		[ 7: 0]				tpem_scut_tpgs_dat0	,

	input							tpem_clki			,
	input							tpem_rstn			,
	input							ubus_clki			,
	input							ubus_rstn			);	
/**********************************************************************************************************/
//TPEM  MISC CONTROL	
	wire							tpem_tpes_scfg_prog	;
	wire							tpem_tpes_scfg_data	;
	wire							tpem_tpes_scfg_cclk	;
	wire							tpes_scfg_tpem_init	;
	wire							tpes_scfg_tpem_done	;

	wire		[ 7: 0]				tpem_clnk_fram_mbdo	;
	wire		[ 7: 0]				tpem_clnk_dat0_mbdo	;
	wire		[ 7: 0]				tpem_clnk_dat1_mbdo	;
	wire		[ 7: 0]				tpem_clnk_dat2_mbdo	;
	wire		[ 7: 0]				tpem_clnk_dat3_mbdo	;

	wire		[ 7: 0]				tpem_dlnk_fram_mbdo	;
	wire		[ 7: 0]				tpem_dlnk_dat0_mbdo	;
	wire		[ 7: 0]				tpem_dlnk_dat1_mbdo	;
	wire		[ 7: 0]				tpem_dlnk_dat2_mbdo	;
	wire		[ 7: 0]				tpem_dlnk_dat3_mbdo	;

	wire		[ 7: 0]				tpem_link_fram_mbdo	;
	wire		[ 7: 0]				tpem_link_dat0_mbdo	;
	wire		[ 7: 0]				tpem_link_dat1_mbdo	;
	wire		[ 7: 0]				tpem_link_dat2_mbdo	;
	wire		[ 7: 0]				tpem_link_dat3_mbdo	;

	wire							tpem_idat_wdma_enab	;
	wire							tpem_idat_wdma_mode	;
	wire							tpem_idat_wdma_done	;

	wire							tpem_odat_rdma_enab	;
	wire							tpem_odat_rdma_mode	;
	wire							tpem_odat_rdma_done	;

	assign	tpem_link_fram_mbdo	=	tpem_clnk_fram_mbdo	|	tpem_dlnk_fram_mbdo	|	tpgs_scut_tpem_fram		;
	assign	tpem_link_dat0_mbdo	=	tpem_clnk_dat0_mbdo	|	tpem_dlnk_dat0_mbdo	|	tpgs_scut_tpem_dat0		;
	assign	tpem_link_dat1_mbdo	=	tpem_clnk_dat1_mbdo	|	tpem_dlnk_dat1_mbdo	|	tpgs_scut_tpem_dat1		;
	assign	tpem_link_dat2_mbdo	=	tpem_clnk_dat2_mbdo	|	tpem_dlnk_dat2_mbdo	|	tpgs_scut_tpem_dat2		;
	assign	tpem_link_dat3_mbdo	=	tpem_clnk_dat3_mbdo	|	tpem_dlnk_dat3_mbdo	|	tpgs_scut_tpem_dat3		;
//--------------Module::TPEM_LINK_MISC_CTRL
	tpem_link_misc_ctrl			u_tpem_link_misc_ctrl(
		.tpem_clnk_fram_mbdo		(tpem_clnk_fram_mbdo	),//output			
		.tpem_clnk_dat0_mbdo		(tpem_clnk_dat0_mbdo	),//output	[ 7: 0]	
		.tpem_clnk_dat1_mbdo		(tpem_clnk_dat1_mbdo	),//output	[ 7: 0]	
		.tpem_clnk_dat2_mbdo		(tpem_clnk_dat2_mbdo	),//output	[ 7: 0]	
		.tpem_clnk_dat3_mbdo		(tpem_clnk_dat3_mbdo	),//output	[ 7: 0]	
	
		.tpem_scfg_prog_outp		(tpem_tpes_scfg_prog	),//output	
		.tpem_scfg_data_outp		(tpem_tpes_scfg_data	),//output	
		.tpem_scfg_cclk_outp		(tpem_tpes_scfg_cclk	),//output	
		.tpem_scfg_init_inpp		(tpes_tpem_scfg_init	),//input	
		.tpem_scfg_done_inpp		(tpes_tpem_scfg_done	),//input	

		.tpgs_link_scut_enab		(tpgs_link_scut_enab	),//input
		.tpem_link_port_idle		(tpem_link_port_idle	),//output

		.tpem_link_icfg_done		(tpem_link_icfg_done	),//output
		.tpem_link_trim_done		(tpem_link_trim_done	),//output
		.tpem_link_ocfg_done		(tpem_link_ocfg_done	),//output
		.tpem_link_nnex_done		(tpem_link_nnex_done	),//output
		.tpem_link_ivct_done		(tpem_link_ivct_done	),//output
		.tpem_link_ovct_done		(tpem_link_ovct_done	),//output
		.tpem_link_imtx_done		(tpem_link_imtx_done	),//output
		.tpem_link_omtx_done		(tpem_link_omtx_done	),//output
		.tpem_link_aset_done		(tpem_link_aset_done	),//output
		.tpem_link_dnld_done		(tpem_link_dnld_done	),//output
		.tpem_link_boot_done		(tpem_link_boot_done	),//output
		.tpes_scfg_aset_done		(tpem_scfg_aset_done	),//output
		.tpes_scfg_dnld_done		(tpem_scfg_dnld_done	),//output
		.tpes_scfg_boot_done		(tpem_scfg_boot_done	),//output

		.tpem_link_trim_reqs		(tpem_link_trim_reqs	),//input
		.tpem_link_icfg_reqs		(tpem_link_icfg_reqs	),//input
		.tpem_link_ocfg_reqs		(tpem_link_ocfg_reqs	),//input
		.tpem_link_nnex_reqs		(tpem_link_nnex_reqs	),//input
		.tpem_link_ivct_reqs		(tpem_link_ivct_reqs	),//input
		.tpem_link_ovct_reqs		(tpem_link_ovct_reqs	),//input
		.tpem_link_imtx_reqs		(tpem_link_imtx_reqs	),//input
		.tpem_link_omtx_reqs		(tpem_link_omtx_reqs	),//input
		.tpem_link_aset_reqs		(tpem_link_aset_reqs	),//input
		.tpem_link_dnld_reqs		(tpem_link_dnld_reqs	),//input
		.tpem_link_boot_reqs		(tpem_link_boot_reqs	),//input
		.tpes_scfg_aset_reqs		(tpem_scfg_aset_reqs	),//input
		.tpes_scfg_dnld_reqs		(tpem_scfg_dnld_reqs	),//input
		.tpes_scfg_boot_reqs		(tpem_scfg_boot_reqs	),//input

		.tpem_idat_wdma_enab		(tpem_idat_wdma_enab	),//output	
		.tpem_idat_wdma_mode		(tpem_idat_wdma_mode	),//input	
		.tpem_idat_wdma_done		(tpem_idat_wdma_done	),//input	
		
		.tpem_odat_rdma_enab		(tpem_odat_rdma_enab	),//output	
		.tpem_odat_rdma_mode		(tpem_odat_rdma_mode	),//input	
		.tpem_odat_rdma_done		(tpem_odat_rdma_done	),//input	
		
		.tpem_link_cmnd_indx		(tpem_link_cmnd_indx	),//output	[ 3: 0]	
		.tpem_link_cmnd_data		(tpem_link_cmnd_data	),//input	[31: 0]	

		.tpem_xdat_cmnd_indx		(tpem_xdat_cmnd_indx	),//output	[ 3: 0]	
		.tpem_xdat_cmnd_data		(tpem_xdat_cmnd_data	),//input	[31: 0]	

		.tpem_scfg_cmnd_indx		(tpem_scfg_cmnd_indx	),//output	[ 3: 0]	
		.tpem_scfg_cmnd_data		(tpem_scfg_cmnd_data	),//input	[31: 0]	

		.tpem_link_acks_coda		(tpem_link_acks_coda	),//input	
		.tpem_link_resp_coda		(tpem_link_resp_coda	),//input	
	
		.tpem_clki					(tpem_clki				),//input
		.tpem_rstn					(tpem_rstn				));//input

//--------------WIRE DECLARE
	wire	[ 0: 7]	[ 4: 0]			tpes_link_edge_indx	;
	assign	tpes_link_edge_indx[0]=	5'H0	;
	assign	tpes_link_edge_indx[1]=	5'H2	;
	assign	tpes_link_edge_indx[2]=	5'H4	;
	assign	tpes_link_edge_indx[3]=	5'H6	;
	assign	tpes_link_edge_indx[4]=	5'H8	;
	assign	tpes_link_edge_indx[5]=	5'HA	;
	assign	tpes_link_edge_indx[6]=	5'HC	;
	assign	tpes_link_edge_indx[7]=	5'HE	;
	
	wire	[ 0: 7]					tpes_idat_wdma_reqs	;
	wire							tpes_idat_wdma_init	;
	wire							tpes_idat_wdma_pick	;
	wire	[ 3: 0]					tpes_idat_wdma_size	;

	wire	[ 0: 7]					tpes_idat_wdma_ov16	;
	wire	[ 0: 7]					tpes_idat_wdma_ov08	;
	wire	[ 0: 7]					tpes_idat_wdma_ov04	;
	wire	[ 0: 7]					tpes_idat_wdma_ov02	;
	wire	[ 0: 7]					tpes_idat_wdma_ov01	;
	

	wire	[ 0: 7]	[255: 0]		tpes_ubus_wdma_data	;
	wire	[ 0: 7]	[ 24: 0]		tpes_ubus_wdma_addr	;
	wire	[ 0: 7]					tpes_ubus_wdma_drdy	;

	wire	[ 0: 7]					tpes_link_acks_lead	;
	wire	[ 0: 7]					tpes_link_resp_lead	;
	wire	[ 0: 7]					tpes_fake_acks_lead	;
	wire	[ 0: 7]					tpes_fake_resp_lead	;

	wire	[ 0: 7]					tpes_link_acks_coda	;
	wire	[ 0: 7]					tpes_fake_acks_coda	;
	
	wire	[ 0: 7]					tpes_link_resp_coda	;
	wire	[ 0: 7]					tpes_link_resp_wrcs	;
	wire	[ 0: 7]					tpes_fake_resp_coda	;
	
	wire	[ 0: 7]					tpes_link_idat_lead	;
	wire	[ 0: 7]					tpes_link_idat_wrcs	;
	wire	[ 0: 7]	[31: 0]			tpes_link_idat_data	;
		
	wire	[ 0: 7]					tpes_scfg_init_stat	;
	wire	[ 0: 7]					tpes_scfg_done_stat	;

//	wire	[ 0: 7] 				tpes_link_wdma_done	;	
//	wire	[ 0: 7] 				tpes_fake_wdma_done	;	

	wire	[ 0: 7]					tpem_link_trim_csen	;

	wire							tpem_link_acks_lead	;
	wire							tpem_link_resp_lead	;

	wire		[ 0: 7][ 7: 0]		tpem_port_txdo_fram_w	;	
	wire		[ 0: 7][ 7: 0]		tpem_port_txdo_dat0_w	;	
	wire		[ 0: 7][ 7: 0]		tpem_port_txdo_dat1_w	;	
	wire		[ 0: 7][ 7: 0]		tpem_port_txdo_dat2_w	;	
	wire		[ 0: 7][ 7: 0]		tpem_port_txdo_dat3_w	;	
	

	assign	tpem_link_acks_lead	= &	tpes_fake_acks_lead	;	
	assign	tpem_link_resp_lead	= &	tpes_fake_resp_lead	;
	assign	tpem_link_acks_coda	= &	tpes_fake_acks_coda	;	
	assign	tpem_link_resp_coda	= &	tpes_fake_resp_coda	;

//	assign	tpgs_link_scut_done	= &{tpgs_link_scut_enab	,	tpem_link_resp_coda	};
//	assign	tpem_idat_wdma_done	= &	tpes_fake_wdma_done	;	



	always@(posedge tpem_clki or negedge tpem_rstn)
	if(~tpem_rstn)					tpgs_link_scut_done	<=	0	;
	else							tpgs_link_scut_done	<=&{tpgs_link_scut_enab	,	tpem_link_resp_coda	}	;

	assign	tpes_tpem_scfg_init	= &	tpes_scfg_init_stat	;
	assign	tpes_tpem_scfg_done	= &	tpes_scfg_done_stat	;

	assign	tpem_scfg_tpes_stat	= {	tpes_tpem_scfg_done	,		
									tpes_tpem_scfg_init	,
									tpes_scfg_done_stat	,	
									tpes_scfg_init_stat	};
//--------------INSTANCE:: 8 EDGE CHANNAL

for(genvar i = 0 ; i < 8 ; i++) begin	:	gens_tpem_link_port

	assign	tpes_fake_acks_lead[i]	=	tpem_link_port_enab[i] ? tpes_link_acks_lead[i] : 1'B1	;
	assign	tpes_fake_resp_lead[i]	=	tpem_link_port_enab[i] ? tpes_link_resp_lead[i] : 1'B1	;

	assign	tpes_fake_acks_coda[i]	=	tpem_link_port_enab[i] ? tpes_link_acks_coda[i] : 1'B1	;
	assign	tpes_fake_resp_coda[i]	=	tpem_link_port_enab[i] ? tpes_link_resp_coda[i] : 1'B1	;
	
	link_mast_scfg_port			u_tpem_scfg_port(	
		.link_fpga_port_enab		(tpem_link_port_enab[i]	),//input		
		.fpga_scfg_prog_sbdo		(tpem_scfg_prog_outp[i]	),//output	reg	
		.fpga_scfg_data_sbdo		(tpem_scfg_data_outp[i]	),//output	reg	
		.fpga_scfg_cclk_sbdo		(tpem_scfg_cclk_outp[i]	),//output	reg	
		.fpga_scfg_init_sbdi		(tpem_scfg_init_inpp[i]	),//input		
		.fpga_scfg_done_sbdi		(tpem_scfg_done_inpp[i]	),//input		
		
		.cube_scfg_prog_sbdo		(tpem_tpes_scfg_prog 	),//input		
		.cube_scfg_data_sbdo		(tpem_tpes_scfg_data 	),//input		
		.cube_scfg_cclk_sbdo		(tpem_tpes_scfg_cclk 	),//input		
		.cube_scfg_init_sbdi		(tpes_scfg_init_stat[i]	),//output	reg	
		.cube_scfg_done_sbdi		(tpes_scfg_done_stat[i]	),//output	reg	

		.link_clki					(tpem_clki				),//input
		.link_rstn					(tpem_rstn				));//input
 

	link_mast_txdo_port 		u_tpem_txdo_port(	
		.link_txdo_port_enab		(tpem_link_port_enab[i]	),//input				
		
		.link_txdo_fram_mbdi		(tpem_link_fram_mbdo	),//input	[7:0]		
		.link_txdo_dat0_mbdi		(tpem_link_dat0_mbdo	),//input	[7:0]		
		.link_txdo_dat1_mbdi		(tpem_link_dat1_mbdo	),//input	[7:0]		
		.link_txdo_dat2_mbdi		(tpem_link_dat2_mbdo	),//input	[7:0]		
		.link_txdo_dat3_mbdi		(tpem_link_dat3_mbdo	),//input	[7:0]		

		.link_txdo_fram_mbdo		(tpem_port_txdo_fram[i]	),//output	reg	[7:0]	
		.link_txdo_dat0_mbdo		(tpem_port_txdo_dat0[i]	),//output	reg	[7:0]	
		.link_txdo_dat1_mbdo		(tpem_port_txdo_dat1[i]	),//output	reg	[7:0]	
		.link_txdo_dat2_mbdo		(tpem_port_txdo_dat2[i]	),//output	reg	[7:0]	
		.link_txdo_dat3_mbdo		(tpem_port_txdo_dat3[i]	),//output	reg	[7:0]	

		.link_clki					(tpem_clki				),//input				
		.link_rstn					(tpem_rstn				));//input				

	tpem_link_rxdi_dmau			u_tpem_link_rxdi_dmau(
		.link_rxdi_port_enab		(tpem_link_port_enab[i]	),//input				
		.link_rxdi_port_init		(tpem_link_port_init	),//input				
		.link_rxdi_port_cols		(llmb_edge_imag_cols[11:0]	),//input				


		.link_rxdi_fram_lead		(tpem_port_rxdi_lead[i]	),//input	[7:0]		
		.link_rxdi_fram_body		(tpem_port_rxdi_body[i]	),//input	[7:0]		
		.link_rxdi_fram_coda		(tpem_port_rxdi_coda[i]	),//input	[7:0]		

		.link_rxdi_dat0_mbdi		(tpem_port_rxdi_dat0[i]	),//input	[7:0]		
		.link_rxdi_dat1_mbdi		(tpem_port_rxdi_dat1[i]	),//input	[7:0]		
		.link_rxdi_dat2_mbdi		(tpem_port_rxdi_dat2[i]	),//input	[7:0]		
		.link_rxdi_dat3_mbdi		(tpem_port_rxdi_dat3[i]	),//input	[7:0]		

		.link_rxdi_acks_lead		(tpes_link_acks_lead[i]	),//output	reg			
		.link_rxdi_acks_wrcs		(tpes_link_acks_wrcs[i]	),//output	reg			
		.link_rxdi_acks_coda		(tpes_link_acks_coda[i]	),//output	reg			
		.link_rxdi_acks_data		(tpes_link_acks_data[i]	),//output	reg			
		
		.link_rxdi_resp_lead		(tpes_link_resp_lead[i]	),//output	reg			
		.link_rxdi_resp_wrcs		(tpes_link_resp_wrcs[i]	),//output	reg			
		.link_rxdi_resp_coda		(tpes_link_resp_coda[i]	),//output	reg			
		
		.link_rxdi_data_lead		(tpes_link_idat_lead[i]	),//output	reg			
		.link_rxdi_data_wrcs		(tpes_link_idat_wrcs[i]	),//output	reg			
		.link_rxdi_data_word		(tpes_link_idat_data[i]	),//output	reg	[31: 0]	
		.link_clki					(tpem_clki				),//input				
		.link_rstn					(tpem_rstn				));//input				

	cube_wdma_edge_intf			u_cube_wdma_edge_intf(
		.this_tpgs_pile_lead		(tpem_link_pile_lead	),//input	[ 4: 0]	
		.this_tpgs_edge_base		(tpes_link_edge_indx[i]	),//input	[ 4: 0]	

		.llmb_hubs_ddrs_base		(llmb_mast_ddrs_base	),//input	[24 : 0]
		.llmb_hubs_imag_cols		(llmb_meta_imag_cols	),//input	[19 : 0]
		.llmb_mtrx_imag_cols		(llmb_mtrx_imag_cols	),//input	[19 : 0]

		.llmb_edge_imag_size		(llmb_edge_imag_size	),//input	[24 : 0]
		.llmb_edge_imag_cols		(llmb_edge_imag_cols	),//input	[19 : 0]
		.llmb_edge_imag_even		(llmb_edge_imag_even	),//input				
		.llmb_edge_imag_row2		(llmb_edge_imag_row2	),//input				

		.cube_edge_wdma_enab		(tpem_idat_wdma_enab	),//input	
		.cube_edge_wdma_mode		(tpem_idat_wdma_mode	),//input	
	
		.cube_edge_idat_lead		(tpes_link_idat_lead[i]	),//input				
		.cube_edge_idat_wrcs		(tpes_link_idat_wrcs[i]	),//input				
		.cube_edge_idat_data		(tpes_link_idat_data[i]	),//input	[ 31: 0]
		.link_clki					(tpem_clki				),//input	
		.link_rstn					(tpem_rstn				),//input	

		.cube_edge_wdma_init		(tpes_idat_wdma_init	),//input				
		.cube_edge_wdma_pick		(tpes_idat_wdma_pick	),//input				
		.cube_edge_wdma_reqs		(tpes_idat_wdma_reqs[i]	),//input				
		.cube_edge_wdma_size		(tpes_idat_wdma_size	),//input	[ 3: 0]	

		.cube_edge_wdma_ov08		(tpes_idat_wdma_ov08[i]	),//output					
		.cube_edge_wdma_ov04		(tpes_idat_wdma_ov04[i]	),//output					
		.cube_edge_wdma_ov02		(tpes_idat_wdma_ov02[i]	),//output		
		.cube_edge_wdma_ov01		(tpes_idat_wdma_ov01[i]	),//output		
					

		.ubus_edge_wdma_data		(tpes_ubus_wdma_data[i]	),//output	[255: 0]	
		.ubus_edge_wdma_addr		(tpes_ubus_wdma_addr[i]	),//output	[ 24: 0]	
		.ubus_edge_wdma_drdy		(tpes_ubus_wdma_drdy[i]	),//output	reg				
	
		.ubus_clki					(ubus_clki				),//input
		.ubus_rstn					(ubus_rstn				));//input
 
end//end for generate

//--------------Module::CUBE_EDGE_WDMA_CTRL	
	cube_edge_wdma_ctrl			u_tpem_edge_wdma_ctrl(
		.cube_edge_link_enab		(tpem_link_port_enab	),//input		[ 7: 0]	
		.cube_edge_imag_size		(llmb_edge_imag_size	),//input		[24: 0]	
		.cube_edge_wdma_done		(tpem_idat_wdma_done	),//output	reg			
		.cube_edge_wdma_enab		(tpem_idat_wdma_enab	),//input					
		.link_clki					(tpem_clki				),//input
		.link_rstn					(tpem_rstn				),//input

		.cube_edge_fifo_ov08		(tpes_idat_wdma_ov08	),//input	[ 0: 7]			
		.cube_edge_fifo_ov04		(tpes_idat_wdma_ov04	),//input	[ 0: 7]			
		.cube_edge_fifo_ov02		(tpes_idat_wdma_ov02	),//input	[ 0: 7]			
		.cube_edge_fifo_ov01		(tpes_idat_wdma_ov01	),//input	[ 0: 7]			
		
		.cube_edge_wdma_init		(tpes_idat_wdma_init	),//output					
		.cube_edge_wdma_pick		(tpes_idat_wdma_pick	),//output					
		.cube_edge_wdma_reqs		(tpes_idat_wdma_reqs	),//output		[ 0: 7]		
		.cube_edge_wdma_size		(tpes_idat_wdma_size	),//output	reg	[ 3: 0]		
		
		.cube_edge_wdma_data		(tpes_ubus_wdma_data	),//input	[ 0: 9][255: 0]	
		.cube_edge_wdma_addr		(tpes_ubus_wdma_addr	),//input	[ 0: 9][ 24: 0]	
		.cube_edge_wdma_drdy		(tpes_ubus_wdma_drdy	),//input	[ 0: 9]			

		.ubus_wdma_ddrs_csen		(ubus_tpem_wdma_csen	),//output					
		.ubus_wdma_ddrs_addr		(ubus_tpem_wdma_addr	),//output	[ 24: 0]		
		.ubus_wdma_ddrs_data		(ubus_tpem_wdma_data	),//output	[255: 0]		
		.ubus_wdma_ddrs_trdy		(ubus_tpem_wdma_trdy	),//input					
		.ubus_wdma_ddrs_wrdy		(ubus_tpem_wdma_wrdy	),//input					
		.ubus_clki					(ubus_clki				),//input					
		.ubus_rstn					(ubus_rstn				));//input

//--------------Module::DLNK_MONO_RDMA_CTRL	
	dlnk_mono_rdma_ctrl			u_tpem_mono_rdma_ctrl(
		.dlnk_odat_fram_mbdo		(tpem_dlnk_fram_mbdo	),//output		[ 7: 0]
		.dlnk_odat_dat3_mbdo		(tpem_dlnk_dat3_mbdo	),//output		[ 7: 0]
		.dlnk_odat_dat2_mbdo		(tpem_dlnk_dat2_mbdo	),//output		[ 7: 0]
		.dlnk_odat_dat1_mbdo		(tpem_dlnk_dat1_mbdo	),//output		[ 7: 0]
		.dlnk_odat_dat0_mbdo		(tpem_dlnk_dat0_mbdo	),//output		[ 7: 0]

		.dlnk_odat_ddrs_mode		(tpem_odat_rdma_mode	),
		.dlnk_odat_ddrs_enab		(tpem_odat_rdma_enab	),
		.dlnk_odat_ddrs_done		(tpem_odat_rdma_done	),

		.llmb_mast_ddrs_base		(llmb_mast_ddrs_base	),//input		[24: 0]		
		.llmb_meta_imag_rows		(llmb_meta_imag_rows	),//input		[19: 0]		
		.llmb_meta_imag_cols		(llmb_meta_imag_cols	),//input		[19: 0]		
		.llmb_edge_imag_rows		(llmb_edge_imag_rows	),//input		[19: 0]		
		.llmb_edge_imag_cols		(llmb_edge_imag_cols	),//input		[19: 0]		

		.link_clki					(tpem_clki				),
		.link_rstn					(tpem_rstn				),

		.ubus_dlnk_rdma_csen		(ubus_tpem_rdma_csen	),//output	reg			
		.ubus_dlnk_rdma_addr		(ubus_tpem_rdma_addr	),//output	reg	[ 24: 0]
		.ubus_dlnk_rdma_trdy		(ubus_tpem_rdma_trdy	),//input				
		.ubus_dlnk_rdma_data		(ubus_tpem_rdma_data	),//input		[255: 0]
		.ubus_dlnk_rdma_drdy		(ubus_tpem_rdma_drdy	),//input		

		.ubus_clki					(ubus_clki				),//input				
		.ubus_rstn					(ubus_rstn				));	//input				

//--------------Module::SCUT_EDGE_ROOT_CTRL	

	wire	tpgs_link_scut_type	= |{tpem_link_ivct_reqs	,tpem_link_imtx_reqs	}	;

	scut_edge_root_ctrl 		u_scut_tpes_tpgs_ctrl(
		.cube_link_scut_enab		(tpgs_link_scut_enab	),//input			
		.cube_link_scut_type		(tpgs_link_scut_type	),//input			
		.cube_link_edge_enab		(tpem_link_port_enab	),//input	[ 0: 7]			
		.cube_link_acks_coda		(tpem_link_acks_coda	),//input	[ 0: 7]			
		.cube_link_resp_coda		(tpem_link_resp_coda	),//input	[ 0: 7]			

		.edge_idat_acks_lead		(tpes_link_acks_lead	),//input	[ 0: 7]			
		.edge_idat_acks_wrcs		(tpes_link_acks_wrcs	),//input	[ 0: 7]			
		.edge_idat_resp_lead		(tpes_link_resp_lead	),//input	[ 0: 7]		
		.edge_idat_resp_wrcs		(tpes_link_resp_wrcs	),//input	[ 0: 7]		
		.edge_idat_data_lead		(tpes_link_idat_lead	),//input	[ 0: 7]			
		.edge_idat_data_wrcs		(tpes_link_idat_wrcs	),//input	[ 0: 7]			
		.edge_idat_data_word		(tpes_link_idat_data	),//input	[ 0: 7]	[31: 0]	
		
		
		.scut_acks_memo_indx		(scut_acks_memo_indx	),//output	[ 2: 0]		
		.scut_acks_memo_data		(scut_acks_memo_data	),//input	[31: 0]		

		.edge_scut_root_fram		(tpem_scut_tpgs_fram	),//output	reg	[  7: 0]	
		.edge_scut_root_dat3		(tpem_scut_tpgs_dat3	),//output		[  7: 0]	
		.edge_scut_root_dat2		(tpem_scut_tpgs_dat2	),//output		[  7: 0]	
		.edge_scut_root_dat1		(tpem_scut_tpgs_dat1	),//output		[  7: 0]	
		.edge_scut_root_dat0		(tpem_scut_tpgs_dat0	),//output		[  7: 0]	

		.cube_clki					(tpem_clki				),//input					
		.cube_rstn					(tpem_rstn				));//input					

endmodule
 /*
	cube_wdma_edge_intf			u_cube_wdma_edge_intf(

		.this_tpgs_pile_lead		(tpem_link_pile_lead	),//input	[ 4: 0]	
		.this_tpgs_edge_base		(tpes_link_edge_indx[i]	),//input	[ 4: 0]	
		.ecos_omni_pile_numb		(ecos_omni_pile_numb	),


		.llmb_mast_ddrs_base		(llmb_mast_ddrs_base	),//input	[24 : 0]
		.llmb_mast_imag_cols		(llmb_meta_imag_cols	),//input	[19 : 0]

		.llmb_edge_imag_size		(llmb_edge_imag_size	),//input	[24 : 0]
		.llmb_edge_imag_cols		(llmb_edge_imag_cols	),//input	[19 : 0]
		.llmb_edge_imag_even		(llmb_edge_imag_even	),//input				
		.llmb_edge_imag_row2		(llmb_edge_imag_row2	),//input				

		.cube_edge_wdma_enab		(tpem_idat_wdma_enab	),//input	
		.cube_edge_wdma_mode		(tpem_idat_wdma_mode	),//input	
	
		.cube_edge_idat_lead		(tpes_link_idat_lead[i]	),//input				
		.cube_edge_idat_wrcs		(tpes_link_idat_wrcs[i]	),//input				
		.cube_edge_idat_data		(tpes_link_idat_data[i]	),//input	[ 31: 0]
		.link_clki					(tpem_clki				),//input	
		.link_rstn					(tpem_rstn				),//input	

		.cube_edge_wdma_init		(tpes_idat_wdma_init	),//input				
		.cube_edge_wdma_pick		(tpes_idat_wdma_pick	),//input				
		.cube_edge_wdma_reqs		(tpes_idat_wdma_reqs[i]	),//input				
		.cube_edge_wdma_size		(tpes_idat_wdma_size	),//input	[ 3: 0]	

		.cube_edge_wdma_ov08		(tpes_idat_wdma_ov08[i]	),//output					
		.cube_edge_wdma_ov04		(tpes_idat_wdma_ov04[i]	),//output					
		.cube_edge_wdma_ov02		(tpes_idat_wdma_ov02[i]	),//output		
		.cube_edge_wdma_ov01		(tpes_idat_wdma_ov01[i]	),//output		
					

		.ubus_edge_wdma_data		(tpes_ubus_wdma_data[i]	),//output	[255: 0]	
		.ubus_edge_wdma_addr		(tpes_ubus_wdma_addr[i]	),//output	[ 24: 0]	
		.ubus_edge_wdma_drdy		(tpes_ubus_wdma_drdy[i]	),//output	reg				
	
		.ubus_clki					(ubus_clki				),//input
		.ubus_rstn					(ubus_rstn				));//input
*/
 