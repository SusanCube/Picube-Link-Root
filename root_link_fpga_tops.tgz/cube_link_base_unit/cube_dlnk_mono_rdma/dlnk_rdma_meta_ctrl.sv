//e.g 32000 cols ,16000 words ,	2000 page	,250 PACK  PACK_NUMB =	COLS_NUMB/2/8/8
//e.g 13824 cols ,6912  words ,	864  page	,108 PACK	
//e.g 8192  cols ,4096  words ,	512  page	,64  PACK	
//e.g 6656  cols ,3328  words ,	416  page	,108 PACK	
//e.g 5120  cols ,2560  words ,	 320 page	, 40 PACK  
//e.g 256   cols ,128   words ,	  16 page	,  2 PACK  

`include	"agile_card_vars.vh"
module	dlnk_rdma_meta_ctrl(
	input								dlnk_rdma_meta_mode	,//0:vect 	1:mtrx
	input								dlnk_rdma_meta_enab	,
	output								dlnk_rdma_meta_done	,

	output								dlnk_rdma_ddrs_reqs	,
	output		[24: 0]					dlnk_rdma_ddrs_addr	,			
	input								dlnk_rdma_ddrs_drdy	,
	input								dlnk_rdma_ddrs_crdy	,
	
	output								dlnk_txdo_data_reqs	,
	input								dlnk_txdo_data_lead	,
	input								dlnk_txdo_data_coda	,
	
	input		[24: 0]					llmb_meta_ddrs_base	, 
	input		[19: 0]					llmb_meta_imag_rows	, 
	input		[19: 0]					llmb_meta_imag_cols	, 
		
	input								link_sclk			,
	input								link_rstn			);
/**********************************************************************************************************************/
	wire		dlnk_rdma_rows_tail	= |	llmb_meta_imag_rows[ 4: 0]	;	
	wire		dlnk_rdma_rows_bulk	= |	llmb_meta_imag_rows[19: 5]	;	
//------------------------------------------------------------------------------
	wire								dlnk_rdma_vect_enab	,	dlnk_rdma_vect_done	;
	wire								dlnk_rdma_rect_enab	,	dlnk_rdma_rect_done	;
	wire								dlnk_rdma_tile_enab	,	dlnk_rdma_tile_done	;

	assign		dlnk_rdma_vect_enab	= &{dlnk_rdma_meta_enab	, ~	dlnk_rdma_meta_mode	}	;
	assign		dlnk_rdma_rect_enab	= &{dlnk_rdma_meta_enab	,  	dlnk_rdma_meta_mode	, ~	dlnk_rdma_rows_bulk	,	dlnk_rdma_rows_tail	};
	assign		dlnk_rdma_tile_enab	= &{dlnk_rdma_meta_enab	,  	dlnk_rdma_meta_mode	,  	dlnk_rdma_rows_bulk	, ~	dlnk_rdma_rows_tail	};

	assign		dlnk_rdma_meta_done	=	dlnk_rdma_vect_enab	?	dlnk_rdma_vect_done	:
										dlnk_rdma_rect_enab	?	dlnk_rdma_rect_done	:
										dlnk_rdma_tile_enab	?	dlnk_rdma_tile_done	:	0	;	
//------------------------------------------------------------------------------
	reg			[14: 0]					dlnk_rdma_bulk_numb	;
	reg			[ 4: 0]					dlnk_rdma_tail_numb	;
	reg			[12: 0]					dlnk_rdma_pack_numb	;

	always@(posedge link_sclk or negedge link_rstn)
	if(!link_rstn)						begin
		dlnk_rdma_bulk_numb	<=	0	;
		dlnk_rdma_tail_numb	<=	0	;
		dlnk_rdma_pack_numb	<=	0	;
	end else if(~dlnk_rdma_meta_enab)	begin
		dlnk_rdma_bulk_numb	<=	llmb_meta_imag_rows[19: 5]	;
		dlnk_rdma_tail_numb	<=	llmb_meta_imag_rows[ 4: 0]	;
		dlnk_rdma_pack_numb	<=	llmb_meta_imag_cols[19: 7]	;
	end	
//------------------------------------------------------------------------------
	wire								dlnk_rdma_vect_reqs	;
	wire								dlnk_rdma_rect_reqs	;
	wire								dlnk_rdma_tile_reqs	;

	wire		[24: 0]					dlnk_rdma_vect_addr	;
	wire		[24: 0]					dlnk_rdma_rect_addr	;
	wire		[24: 0]					dlnk_rdma_tile_addr	;

	assign		dlnk_rdma_ddrs_reqs	=	dlnk_rdma_vect_enab	?	dlnk_rdma_vect_reqs	:
										dlnk_rdma_rect_enab	?	dlnk_rdma_rect_reqs	:
										dlnk_rdma_tile_enab	?	dlnk_rdma_tile_reqs	:	0	;

	assign		dlnk_rdma_ddrs_addr	=	dlnk_rdma_vect_enab	?	dlnk_rdma_vect_addr	:
										dlnk_rdma_rect_enab	?	dlnk_rdma_rect_addr	:
										dlnk_rdma_tile_enab	?	dlnk_rdma_tile_addr	:	0	;
//------------------------------------------------------------------------------
	wire								dlnk_txdo_vect_reqs	;
	wire								dlnk_txdo_rect_reqs	;
	wire								dlnk_txdo_tile_reqs	;

	assign		dlnk_txdo_data_reqs	=	dlnk_rdma_vect_enab	?	dlnk_txdo_vect_reqs	:
										dlnk_rdma_rect_enab	?	dlnk_txdo_rect_reqs	:
										dlnk_rdma_tile_enab	?	dlnk_txdo_tile_reqs	:	0	;	
/**********************************************************************************************************************/
	
	dlnk_rdma_meta_vect				u_dlnk_rdma_meta_vect(
		.dlnk_rdma_vect_enab			(dlnk_rdma_vect_enab	),
		.dlnk_rdma_vect_done			(dlnk_rdma_vect_done	),

		.dlnk_rdma_ddrs_reqs			(dlnk_rdma_vect_reqs	),//to ubus,sync by link_sclk in ubus module
		.dlnk_rdma_ddrs_addr			(dlnk_rdma_vect_addr	),//to ubus,sync by link_sclk in ubus module
		.dlnk_rdma_ddrs_crdy			(dlnk_rdma_ddrs_crdy	),//from ubus,sync by link_sclk in ubus module
		.dlnk_rdma_ddrs_drdy			(dlnk_rdma_ddrs_drdy	),//from ubus,sync by link_sclk in ubus module

		.dlnk_rdma_txdo_reqs			(dlnk_txdo_vect_reqs	),
		.dlnk_rdma_txdo_lead			(dlnk_txdo_data_lead	),
		.dlnk_rdma_txdo_coda			(dlnk_txdo_data_coda	),

		.dlnk_rdma_ddrs_base			(llmb_meta_ddrs_base	),
		.dlnk_rdma_rows_numb			(llmb_meta_imag_rows	),
		.dlnk_rdma_page_numb			(llmb_meta_imag_cols[13:4]	),
		.link_sclk						(link_sclk				),
		.link_rstn						(link_rstn				));

	dlnk_rdma_meta_rect				u_dlnk_rdma_rect_rect(
		.dlnk_rdma_rect_enab			(dlnk_rdma_rect_enab	),//input				
		.dlnk_rdma_rect_done			(dlnk_rdma_rect_done	),//output				

		.dlnk_rdma_ddrs_reqs			(dlnk_rdma_rect_reqs	),//output				
		.dlnk_rdma_ddrs_addr			(dlnk_rdma_rect_addr	),//output	reg	[24: 0]	
		.dlnk_rdma_ddrs_crdy			(dlnk_rdma_ddrs_crdy	),//input				
		.dlnk_rdma_ddrs_drdy			(dlnk_rdma_ddrs_drdy	),//input				

		.dlnk_rdma_txdo_reqs			(dlnk_txdo_rect_reqs	),//output				
		.dlnk_rdma_txdo_lead			(dlnk_txdo_data_lead	),//input				
		.dlnk_rdma_txdo_coda			(dlnk_txdo_data_coda	),//input				

		.dlnk_rdma_ddrs_base			(llmb_meta_ddrs_base	),
		.dlnk_rdma_rows_numb			(dlnk_rdma_tail_numb	),
		.dlnk_rdma_pack_numb			(dlnk_rdma_pack_numb	),
		.link_sclk						(link_sclk				),//input				
		.link_rstn						(link_rstn				));	//input				

	dlnk_rdma_meta_tile				u_dlnk_rdma_meta_tile(
		.dlnk_rdma_tile_enab			(dlnk_rdma_tile_enab	),//input				
		.dlnk_rdma_tile_done			(dlnk_rdma_tile_done	),//output				

		.dlnk_rdma_ddrs_reqs			(dlnk_rdma_tile_reqs	),//output				
		.dlnk_rdma_ddrs_addr			(dlnk_rdma_tile_addr	),//output	reg	[24: 0]	
		.dlnk_rdma_ddrs_crdy			(dlnk_rdma_ddrs_crdy	),//input				
		.dlnk_rdma_ddrs_drdy			(dlnk_rdma_ddrs_drdy	),//input				

		.dlnk_rdma_txdo_reqs			(dlnk_txdo_tile_reqs	),//output				
		.dlnk_rdma_txdo_lead			(dlnk_txdo_data_lead	),//input				
		.dlnk_rdma_txdo_coda			(dlnk_txdo_data_coda	),//input				

		.dlnk_rdma_ddrs_base			(llmb_meta_ddrs_base	),
		.dlnk_rdma_bulk_numb			(dlnk_rdma_bulk_numb	),
		.dlnk_rdma_pack_numb			(dlnk_rdma_pack_numb	),
		.link_sclk						(link_sclk				),//input				
		.link_rstn						(link_rstn				));//input				


	 
endmodule

