
module	tpgm_link_rxdi_pmau	(
	input								tune_rxdi_enab	,
	input								tune_rxdi_envt	,
	input								tune_rxdi_load	,
	input		[ 8: 0]					tune_rxdi_taps	,
	output	reg	[ 8: 0]					tune_rxdi_vals	,
	output		[ 4: 0]					tune_rxdi_good	,

	input								tpgs_fclk_inpp	,
	input								tpgs_fclk_inpn	,
	input								tpgs_fram_inpp	,
	input								tpgs_fram_inpn	,
	input								tpgs_dat0_inpp	,
	input								tpgs_dat0_inpn	,
	input								tpgs_dat1_inpp	,
	input								tpgs_dat1_inpn	,
	input								tpgs_dat2_inpp	,
	input								tpgs_dat2_inpn	,
	input								tpgs_dat3_inpp	,
	input								tpgs_dat3_inpn	,

	output	reg	[ 7: 0]					tpgs_fram_mbdo	,
	output	reg	[ 7: 0]					tpgs_dat0_mbdo	,
	output	reg	[ 7: 0]					tpgs_dat1_mbdo	,
	output	reg	[ 7: 0]					tpgs_dat2_mbdo	,
	output	reg	[ 7: 0]					tpgs_dat3_mbdo	,

	input								dlys_cell_rst	,

	input								link_fclk		,
	input								link_sclk		,
	input								link_rstn		);
/**********************************************************************************************************/
	wire								tpgs_fram_rxdi	,	tpgs_fram_rxdd	;
	wire								tpgs_dat0_rxdi	,	tpgs_dat0_rxdd	;
	wire								tpgs_dat1_rxdi	,	tpgs_dat1_rxdd	;
	wire								tpgs_dat2_rxdi	,	tpgs_dat2_rxdd	;
	wire								tpgs_dat3_rxdi	,	tpgs_dat3_rxdd	;
	wire	[ 0: 4]						idly_dlys_dsrc	,	idly_dlys_dout	;
	
	IBUFDS							LVDS_FRAM_PAD	(
		.I                  			(tpgs_fram_inpp	),
		.IB                 			(tpgs_fram_inpn	),
		.O                  			(tpgs_fram_rxdi	));

	IBUFDS							LVDS_DAT0_PAD	(
		.I                  			(tpgs_dat0_inpp	),
		.IB                 			(tpgs_dat0_inpn	),
		.O                  			(tpgs_dat0_rxdi	));

	IBUFDS							LVDS_DAT1_PAD	(
		.I                  			(tpgs_dat1_inpp	),
		.IB                 			(tpgs_dat1_inpn	),
		.O                  			(tpgs_dat1_rxdi	));

	IBUFDS							LVDS_DAT2_PAD	(
		.I                  			(tpgs_dat2_inpp	),
		.IB                 			(tpgs_dat2_inpn	),
		.O                  			(tpgs_dat2_rxdi	));

	IBUFDS							LVDS_DAT3_PAD	(
		.I                  			(tpgs_dat3_inpp	),
		.IB                 			(tpgs_dat3_inpn	),
		.O                  			(tpgs_dat3_rxdi	));
	
	IBUFDS							LVDS_FCLK_PAD	(
		.I                  			(tpgs_fclk_inpp	),
		.IB                 			(tpgs_fclk_inpn	),
		.O                  			(tpgs_fclk_w	));

(* keep="true" *)
	BUFG							LVDS_FCLK_BUFG	(
		.I								(tpgs_fclk_w	),
		.O								(tpgs_fclk		));	

	wire								tpgs_fckp		;
	wire								tpgs_fckn		;

	assign	tpgs_fckp	=	tpgs_fclk		;
	assign	tpgs_fckn	= ~	tpgs_fclk		;

	always@(posedge link_sclk )
	if(~link_rstn)						tune_rxdi_vals	<=	0	;
	else if(tune_rxdi_load)				tune_rxdi_vals	<=	tune_rxdi_taps	;				
/**********************************************************************************************************/
	
	assign	idly_dlys_dsrc[0]	=		tpgs_fram_rxdi		;
	assign	idly_dlys_dsrc[1]	=		tpgs_dat3_rxdi		;
	assign	idly_dlys_dsrc[2]	=		tpgs_dat2_rxdi		;
	assign	idly_dlys_dsrc[3]	=		tpgs_dat1_rxdi		;
	assign	idly_dlys_dsrc[4]	=		tpgs_dat0_rxdi		;
	
	assign	tpgs_fram_rxdd		=		idly_dlys_dout[0]	;
	assign	tpgs_dat3_rxdd		=		idly_dlys_dout[1]	;
	assign	tpgs_dat2_rxdd		=		idly_dlys_dout[2]	;
	assign	tpgs_dat1_rxdd		=		idly_dlys_dout[3]	;
	assign	tpgs_dat0_rxdd		=		idly_dlys_dout[4]	;
/***TUNEIO_DLYS*******************************************************************************************************/
	wire	[ 0: 4][ 8: 0]				tune_rxdi_vout	;
	wire								tune_rxdi_reqs	;

	reg									dlys_rstb_sync	= 1'H1				;
	always@(posedge link_fclk )			dlys_rstb_sync	= dlys_cell_rst		;

	gens_asyn_edge 					gens_load_sync_edge(
		.data_edge						(tune_rxdi_reqs	),//output		
		.data_inpp						(tune_rxdi_load	),//input		
		.edge_mode						(1'B1			),//input		TRIGGER FALL EDGE
		.clki							(link_fclk		),//input		
		.rstn							(link_rstn		));//input		

	for(genvar i = 0 ; i < 5 ; i++)	begin:gens_rdxi_idly_bus
		IDELAYE3 						#(
	    	.CASCADE						("NONE"			),// Cascade setting (MASTER, NONE, SLAVE_END, SLAVE_MIDDLE)
			.DELAY_FORMAT					("TIME"		),// Units of the DELAY_VALUE (COUNT, TIME)
	    	.DELAY_SRC						("IDATAIN"		),// Delay input (DATAIN, IDATAIN)
	    	.DELAY_TYPE						("VAR_LOAD"		),// Set the type of tap delay line (FIXED, VARIABLE, VAR_LOAD)
	    	.DELAY_VALUE					( 9'H000		),// Input delay value setting
	    	.IS_CLK_INVERTED				( 1'H0			),// Optional inversion for CLK
	    	.IS_RST_INVERTED				( 1'H0			),// Optional inversion for RST
	    	.REFCLK_FREQUENCY				( 320.0			),// IDELAYCTRL clock input frequency in MHz (200.0-800.0)
	    	.SIM_DEVICE						("ULTRASCALE"	),// Set the device version for simulation functionality (ULTRASCALE)
	    	.UPDATE_MODE					("ASYNC"		))// Determines when updates to the delay will take effect (ASYNC, MANUAL, SYNC)
		u_RXDI_IDLY_CELL 				(
	    	.DATAOUT						(idly_dlys_dout[i] 	),	// 1-bit output: Delayed data output
	    	.IDATAIN						(idly_dlys_dsrc[i]	),	// 1-bit input: Data input from the IOBUF
	
			.EN_VTC							(tune_rxdi_envt		),	// 1-bit input: Keep delay constant over VT
	    	.LOAD							(tune_rxdi_reqs		),	// 1-bit input: Load DELAY_VALUE input
	    	.CNTVALUEIN						(tune_rxdi_taps		),	// 9-bit input: Counter value input
	    	
			.CNTVALUEOUT					(tune_rxdi_vout[i]	),	// 9-bit output: Counter value output
			.CASC_OUT						(  					),	// 1-bit output: Cascade delay output to ODELAY input cascade
	    	.CASC_IN						(1'B0   			),	// 1-bit input: Cascade delay input from slave ODELAY CASCADE_OUT
	    	.CASC_RETURN					(1'B0   	    	),	// 1-bit input: Cascade delay returning from slave ODELAY DATAOUT
			.DATAIN							(1'B0           	),	// 1-bit input: Data input from the logic
	    	.INC							(1'B0				),	// 1-bit input: Increment / Decrement tap delay input
	    	
			.CE								(1'B0				),	// 1-bit input: Active-High enable increment/decrement input
	    	.CLK							( link_fclk			),	//link_sclk ,	// 1-bit input: Clock inputLUE
	    	.RST							( dlys_rstb_sync	));	//1'B0 ));// 1-bit input: Asynchronous Reset to the DELAY_VA
	end
/**********************************************************************************************************/	
	wire								tpgs_fram_q0	,	tpgs_fram_q1	;
	wire								tpgs_dat0_q0	,	tpgs_dat0_q1	;
	wire								tpgs_dat1_q0	,	tpgs_dat1_q1	;
	wire								tpgs_dat2_q0	,	tpgs_dat2_q1	;
	wire								tpgs_dat3_q0	,	tpgs_dat3_q1	;

	wire	[ 1: 0]						tpgs_fram_iddr	= {	tpgs_fram_q0 , tpgs_fram_q1	};
	wire	[ 1: 0]						tpgs_dat0_iddr	= {	tpgs_dat0_q0 , tpgs_dat0_q1	};
	wire	[ 1: 0]						tpgs_dat1_iddr	= {	tpgs_dat1_q0 , tpgs_dat1_q1	};
	wire	[ 1: 0]						tpgs_dat2_iddr	= {	tpgs_dat2_q0 , tpgs_dat2_q1	};
	wire	[ 1: 0]						tpgs_dat3_iddr	= {	tpgs_dat3_q0 , tpgs_dat3_q1	};
/***IDDRE1_FRAM********************************************************************************************************/
 	IDDRE1 #(	
    	.DDR_CLK_EDGE					("SAME_EDGE_PIPELINED"), // IDDRE1 mode (OPPOSITE_EDGE, SAME_EDGE, SAME_EDGE_PIPELINED)
    	.IS_CB_INVERTED					(1'b0			), // Optional inversion for CB
    	.IS_C_INVERTED					(1'b0			)) // Optional inversion for C
    IDDRE1_FRAM_IN	(	
		.C								(tpgs_fckp		), // 1-bit input: High-speed clock
		.CB								(tpgs_fckn		), // 1-bit input: Inversion of High-speed clock C
		.R								(1'B0			), // 1-bit input: Active-High Async Reset
  		.D								(tpgs_fram_rxdd	), // 1-bit input: Serial Data Input
		.Q1								(tpgs_fram_q0	), // 1-bit output: Registered parallel output 1
		.Q2								(tpgs_fram_q1	));// 1-bit output: Registered parallel output 2
/***IDDRE1_DAT0********************************************************************************************************/
 	IDDRE1 #(	
    	.DDR_CLK_EDGE					("SAME_EDGE_PIPELINED"), // IDDRE1 mode (OPPOSITE_EDGE, SAME_EDGE, SAME_EDGE_PIPELINED)
    	.IS_CB_INVERTED					(1'b0			), // Optional inversion for CB
    	.IS_C_INVERTED					(1'b0			)) // Optional inversion for C
    IDDRE1_DAT0_IN	(		
		.C								(tpgs_fckp		), // 1-bit input: High-speed clock
		.CB								(tpgs_fckn		), // 1-bit input: Inversion of High-speed clock C
		.R								(1'B0			), // 1-bit input: Active-High Async Reset
  		.D								(tpgs_dat0_rxdd	), // 1-bit input: Serial Data Input
		.Q1								(tpgs_dat0_q0	), // 1-bit output: Registered parallel output 1
		.Q2								(tpgs_dat0_q1	));// 1-bit output: Registered parallel output 2
/***IDDRE1_DAT1********************************************************************************************************/
	IDDRE1 #(	
    	.DDR_CLK_EDGE					("SAME_EDGE_PIPELINED"), // IDDRE1 mode (OPPOSITE_EDGE, SAME_EDGE, SAME_EDGE_PIPELINED)
    	.IS_CB_INVERTED					(1'b0			), // Optional inversion for CB
    	.IS_C_INVERTED					(1'b0			)) // Optional inversion for C
    IDDRE1_DAT1_IN	(	
		.C								(tpgs_fckp		), // 1-bit input: High-speed clock
		.CB								(tpgs_fckn		), // 1-bit input: Inversion of High-speed clock C
		.R								(1'B0			), // 1-bit input: Active-High Async Reset
  		.D								(tpgs_dat1_rxdd	), // 1-bit input: Serial Data Input
		.Q1								(tpgs_dat1_q0	), // 1-bit output: Registered parallel output 1
		.Q2								(tpgs_dat1_q1	));// 1-bit output: Registered parallel output 2
/***IDDRE1_DAT2********************************************************************************************************/
	IDDRE1 #(	
    	.DDR_CLK_EDGE					("SAME_EDGE_PIPELINED"), // IDDRE1 mode (OPPOSITE_EDGE, SAME_EDGE, SAME_EDGE_PIPELINED)
    	.IS_CB_INVERTED					(1'b0			), // Optional inversion for CB
    	.IS_C_INVERTED					(1'b0			)) // Optional inversion for C
    IDDRE1_DAT2_IN	(	
		.C								(tpgs_fckp		), // 1-bit input: High-speed clock
		.CB								(tpgs_fckn		), // 1-bit input: Inversion of High-speed clock C
		.R								(1'B0			), // 1-bit input: Active-High Async Reset
  		.D								(tpgs_dat2_rxdd	), // 1-bit input: Serial Data Input
		.Q1								(tpgs_dat2_q0	), // 1-bit output: Registered parallel output 1
		.Q2								(tpgs_dat2_q1	));// 1-bit output: Registered parallel output 2
/***IDDRE1_DAT3********************************************************************************************************/
	IDDRE1 #(	
    	.DDR_CLK_EDGE					("SAME_EDGE_PIPELINED"), // IDDRE1 mode (OPPOSITE_EDGE, SAME_EDGE, SAME_EDGE_PIPELINED)
    	.IS_CB_INVERTED					(1'b0			), // Optional inversion for CB
    	.IS_C_INVERTED					(1'b0			)) // Optional inversion for C
    IDDRE1_DAT3_IN	(	
		.C								(tpgs_fckp		), // 1-bit input: High-speed clock
		.CB								(tpgs_fckn		), // 1-bit input: Inversion of High-speed clock C
		.R								(1'B0			), // 1-bit input: Active-High Async Reset
  		.D								(tpgs_dat3_rxdd	), // 1-bit input: Serial Data Input
		.Q1								(tpgs_dat3_q0	), // 1-bit output: Registered parallel output 1
		.Q2								(tpgs_dat3_q1	));// 1-bit output: Registered parallel output 2
/**********************************************************************************************************************/
	reg		[ 1: 0]						tpgs_fram_m2bo	;

	reg		[ 7: 0]						tpgs_fram_mbdi	;
	reg		[ 7: 0]						tpgs_dat0_mbdi	;
	reg		[ 7: 0]						tpgs_dat1_mbdi	;
	reg		[ 7: 0]						tpgs_dat2_mbdi	;
	reg		[ 7: 0]						tpgs_dat3_mbdi	;
//----------------------------------------------------------------------------------------------------------
	always@(posedge tpgs_fckp or negedge link_rstn)
	if(!link_rstn) 						tpgs_fram_m2bo	<=	0	;
	else 								tpgs_fram_m2bo	<=	tpgs_fram_iddr	;
//----------------------------------------------------------------------------------------------------------
	reg		[ 3: 0]						tpgs_octs_shft= 4'H8;
	reg		[ 2: 0]						tpgs_tune_samp	;

	reg									tpgs_rxdi_csen	;
	reg									tpgs_rxdi_vlid	;

	wire								tpgs_octs_wrcs	;	
	wire								tpgs_fram_rise	;
	wire								tpgs_fram_fall	;

	wire								tpgs_tune_enab	;
	assign	tpgs_tune_enab	=			tpgs_tune_samp[1:0]	==	2'B11	;

	assign	tpgs_octs_wrcs	=			tpgs_octs_shft[3]	;
	assign	tpgs_fram_rise	=     {		tpgs_tune_enab	,	tpgs_fram_iddr , tpgs_fram_m2bo }	==	5'HC	;
	assign	tpgs_fram_fall	=     {		tpgs_tune_enab	,	tpgs_fram_iddr , tpgs_fram_m2bo }	==	5'H3	;
	
	always@(posedge tpgs_fckp or negedge link_rstn)
	if(!link_rstn) 						tpgs_tune_samp	<=	0	;
	else 								tpgs_tune_samp	<= {tune_rxdi_enab ,tpgs_tune_samp[2:1] }	;

	always@(posedge tpgs_fckp or negedge link_rstn)
	if(~link_rstn)						tpgs_rxdi_csen	<=	0	;
	else if(tpgs_fram_rise)				tpgs_rxdi_csen	<=	1	;
	else if(tpgs_fram_fall)				tpgs_rxdi_csen	<=	0	;

	always@(posedge tpgs_fckp or negedge link_rstn)
	if(!link_rstn)						tpgs_rxdi_vlid	<=	0	;
	else 								tpgs_rxdi_vlid	<=	tpgs_rxdi_csen	;

	always@(posedge tpgs_fckp or negedge link_rstn)
	if(!link_rstn) 						tpgs_octs_shft	<=	4'H8	;
	else if( tpgs_fram_rise)			tpgs_octs_shft	<=	4'H1	;
	else if( tpgs_rxdi_csen)			tpgs_octs_shft	<={ tpgs_octs_shft[2:0] , tpgs_octs_shft[3]};
	else 								tpgs_octs_shft	<=	4'H0	;
//----------------------------------------------------------------------------------------------------------
	always@(posedge tpgs_fckp or negedge link_rstn)
	if(!link_rstn) begin
		tpgs_fram_mbdi	<=	0	;
		tpgs_dat0_mbdi	<=	0	;
		tpgs_dat1_mbdi	<=	0	;
		tpgs_dat2_mbdi	<=	0	;
		tpgs_dat3_mbdi	<=	0	;
	end else begin
		tpgs_fram_mbdi	<= {tpgs_fram_mbdi[5:0]	,	tpgs_fram_iddr } ;//tpgs_fram_m2bo	};
		tpgs_dat0_mbdi	<= {tpgs_dat0_mbdi[5:0]	,	tpgs_dat0_iddr } ;//tpgs_dat0_m2bo	};
		tpgs_dat1_mbdi	<= {tpgs_dat1_mbdi[5:0]	,	tpgs_dat1_iddr } ;//tpgs_dat1_m2bo	};
		tpgs_dat2_mbdi	<= {tpgs_dat2_mbdi[5:0]	,	tpgs_dat2_iddr } ;//tpgs_dat2_m2bo	};
		tpgs_dat3_mbdi	<= {tpgs_dat3_mbdi[5:0]	,	tpgs_dat3_iddr } ;//tpgs_dat3_m2bo	};
	end
//----------------------------------------------------------------------------------------------------------
	reg		[2: 0]					tpgs_push_addr	;
	
	wire							tpgs_push_csen	;
	wire							tpgs_push_init	;
	wire							tpgs_push_done	;
	wire	[39: 0]					tpgs_push_meta	;
	wire	[39: 0]					tpgs_push_data	;

	assign	tpgs_push_csen	= |{  	tpgs_octs_wrcs 	,	tpgs_push_done	};
	assign	tpgs_push_init	= &{   	tpgs_rxdi_csen	, ~	tpgs_rxdi_vlid	};
	assign	tpgs_push_done	= &{  ~	tpgs_rxdi_csen	,	tpgs_rxdi_vlid	};
	assign	tpgs_push_data	=		tpgs_octs_wrcs	?	tpgs_push_meta	:	40'H0	;

	assign	tpgs_push_meta	=   {	tpgs_fram_mbdi	,
									tpgs_dat3_mbdi	,
									tpgs_dat2_mbdi	,
									tpgs_dat1_mbdi	,
									tpgs_dat0_mbdi 	};

	always@(posedge tpgs_fckp or negedge link_rstn)
	if(!link_rstn) 					tpgs_push_addr	<=	0	;
	else if(tpgs_push_init)			tpgs_push_addr	<=	0	;
	else if(tpgs_push_csen)			tpgs_push_addr	<=	tpgs_push_addr + 1	;
//----------------------------------------------------------------------------------------------------------
	reg		[2: 0]					link_pops_addr	;
	reg		[2: 0]					link_pops_enab	;
	reg								link_pops_csen	;
	reg								link_pops_sens	;
	
	wire	[39:0]					link_pops_data	;
	wire							link_pops_init	;
	wire							link_pops_done	;
	wire							link_pops_vlid	;				

	assign	link_pops_init	=		link_pops_enab[1:0]	==	2'H2		;
	assign	link_pops_vlid	= & {	link_pops_csen 	,link_pops_sens }	;
	assign	link_pops_done	=	{ 	link_pops_vlid 	,tpgs_fram_mbdo	}	==	9'H100	;
	
	always@(posedge link_sclk or negedge link_rstn)
	if(!link_rstn) 					link_pops_enab	<=	0	;
	else 							link_pops_enab	<={ tpgs_rxdi_csen	,	link_pops_enab[2:1]	};

	always@(posedge link_sclk or negedge link_rstn)
	if(!link_rstn) 					link_pops_csen	<=	0	;
	else if(link_pops_init)			link_pops_csen	<=  1 	;
	else if(link_pops_done)			link_pops_csen	<=  0 	;		
	
	always@(posedge link_sclk or negedge link_rstn)
	if(!link_rstn) 					link_pops_sens	<=	0	;
	else 							link_pops_sens	<=  link_pops_csen 	;		
	
	always@(posedge link_sclk or negedge link_rstn)
	if(!link_rstn) 					link_pops_addr	<=	0	;
	else if(link_pops_init)			link_pops_addr	<=	0	;
	else if(link_pops_done)			link_pops_addr	<=	0	;
	else if(link_pops_csen)			link_pops_addr	<=	link_pops_addr + 1	;
//----------------------------------------------------------------------
	assign	tpgs_fram_mbdo	=		link_pops_vlid	?	link_pops_data[39:32] : 0	;
	assign	tpgs_dat3_mbdo	=		link_pops_vlid	?	link_pops_data[31:24] : 0	;
	assign	tpgs_dat2_mbdo	=		link_pops_vlid	?	link_pops_data[23:16] : 0	;
	assign	tpgs_dat1_mbdo	=		link_pops_vlid	?	link_pops_data[15: 8] : 0	;
	assign	tpgs_dat0_mbdo	=		link_pops_vlid	?	link_pops_data[ 7: 0] : 0	;
//----------------------------------------------------------------------
	dual_port_tags				u_rxdi_port_push_fifo(
		.wport_csen					(	tpgs_push_csen	),
		.wport_addr					(	tpgs_push_addr	),
		.wport_data					(	tpgs_push_data	),
		.wport_clki					(	tpgs_fckp		),

		.rport_addr					(	link_pops_addr	),
		.rport_data					(	link_pops_data	),
		.rport_clki					(	link_sclk		));
/**********************************************************************************************************/
//TUNE FLAG
	reg		[ 4: 0]					fram_patn_buff	;
	reg		[ 4: 0]					dat0_patn_buff	;
	reg		[ 4: 0]					dat1_patn_buff	;
	reg		[ 4: 0]					dat2_patn_buff	;
	reg		[ 4: 0]					dat3_patn_buff	;

	wire	fram_patn_meet	=	tpgs_fram_mbdi == 8'H9A	;//9A--10011010
	wire	dat0_patn_meet	=	tpgs_dat0_mbdi == 8'H9A	;//9A--10011010
	wire	dat1_patn_meet	=	tpgs_dat1_mbdi == 8'H9A	;//9A--10011010
	wire	dat2_patn_meet	=	tpgs_dat2_mbdi == 8'H9A	;//9A--10011010
	wire	dat3_patn_meet	=	tpgs_dat3_mbdi == 8'H9A	;//9A--10011010

	wire	fram_patn_posi	= |	fram_patn_buff	;
	wire	dat0_patn_posi	= |	dat0_patn_buff	;
	wire	dat1_patn_posi	= |	dat1_patn_buff	;
	wire	dat2_patn_posi	= |	dat2_patn_buff	;
	wire	dat3_patn_posi	= |	dat3_patn_buff	;
	
	always@(posedge tpgs_fckp or negedge link_rstn)
	if(!link_rstn) begin
		fram_patn_buff	<=	0	;
		dat0_patn_buff	<=	0	;
		dat1_patn_buff	<=	0	;
		dat2_patn_buff	<=	0	;
		dat3_patn_buff	<=	0	;
	end else if(tpgs_tune_enab)	begin
		fram_patn_buff	<={ fram_patn_buff[3:0]	,	fram_patn_meet	}	;
		dat0_patn_buff	<={ dat0_patn_buff[3:0]	,	dat0_patn_meet	}	;
		dat1_patn_buff	<={ dat1_patn_buff[3:0]	,	dat1_patn_meet	}	;
		dat2_patn_buff	<={ dat2_patn_buff[3:0]	,	dat2_patn_meet	}	;
		dat3_patn_buff	<={ dat3_patn_buff[3:0]	,	dat3_patn_meet	}	;
	end 
//----------------------------------------------------------------------------------------------------------
	reg		[ 7:0]					patn_filt_cnts	;
	wire	patn_filt_good	=	&	patn_filt_cnts[7:0]	;

	wire	patn_posi_mixs	=	&{	fram_patn_posi	,
									dat0_patn_posi	,
									dat1_patn_posi	,
									dat2_patn_posi	,
									dat3_patn_posi	};

	always@(posedge tpgs_fckp or negedge link_rstn)
	if(~link_rstn) 					patn_filt_cnts	<=	0	;
	else if(~patn_posi_mixs)		patn_filt_cnts	<=	0	;
	else if(~patn_filt_good)		patn_filt_cnts	<=	patn_filt_cnts +1	;

	reg		[ 1:0]					patn_filt_shft	;

	always@(posedge link_sclk or negedge link_rstn)
	if(!link_rstn) 					patn_filt_shft	<=	0	;
	else							patn_filt_shft	<={	patn_filt_good ,patn_filt_shft[1]	};

	assign	tune_rxdi_good	= {5{	patn_filt_shft[0]	}};

endmodule
