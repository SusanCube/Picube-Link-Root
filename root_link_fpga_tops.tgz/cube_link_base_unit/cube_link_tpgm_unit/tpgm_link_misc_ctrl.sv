/*----------------------------------------------------------------------
AUTHOR	: EDWARD YANG
----------------------------------------------------------------------*/
module	tpgm_link_misc_ctrl(
	output	[ 7: 0]					tpgm_clnk_fram_mbdo	,
	output	[ 7: 0]					tpgm_clnk_dat0_mbdo	,
	output	[ 7: 0]					tpgm_clnk_dat1_mbdo	,
	output	[ 7: 0]					tpgm_clnk_dat2_mbdo	,
	output	[ 7: 0]					tpgm_clnk_dat3_mbdo	,
	
	output	reg						tpgm_link_port_idle	,

	output							tpgm_link_trim_done	,//0
	output							tpgm_link_icfg_done	,//0
	output							tpgm_link_ocfg_done	,//1
	output							tpgm_link_nnex_done	,//2
	output							tpgm_link_ivct_done	,//3
	output							tpgm_link_ovct_done	,//4
	output							tpgm_link_imtx_done	,//5
	output							tpgm_link_omtx_done	,//6
	output							tpgm_link_rivt_done	,//7
	output							tpgm_link_rovt_done	,//8
	output 							tpgm_link_rimt_done	,//9
	output							tpgm_link_romt_done	,//10
	output							tpgm_link_risv_done	,//11
	output							tpgm_link_rosv_done	,//12
	output							tpgm_link_rism_done	,//13
	output							tpgm_link_rosm_done	,//14
	output							tpgm_link_aset_done	,//15
	output							tpgm_link_dnld_done	,//16
	output							tpgm_link_boot_done	,//17

	input							tpgm_link_trim_reqs	,//0
	input							tpgm_link_icfg_reqs	,//0
	input							tpgm_link_ocfg_reqs	,//1
	input							tpgm_link_nnex_reqs	,//2
	input							tpgm_link_ivct_reqs	,//3
	input							tpgm_link_ovct_reqs	,//4
	input							tpgm_link_imtx_reqs	,//5
	input							tpgm_link_omtx_reqs	,//6
	input							tpgm_link_rivt_reqs	,//7
	input							tpgm_link_rovt_reqs	,//8
	input 							tpgm_link_rimt_reqs	,//9
	input							tpgm_link_romt_reqs	,//10
	input							tpgm_link_risv_reqs	,//11
	input							tpgm_link_rosv_reqs	,//12
	input							tpgm_link_rism_reqs	,//13
	input							tpgm_link_rosm_reqs	,//14
	input							tpgm_link_aset_reqs	,//15
	input							tpgm_link_dnld_reqs	,//16
	input							tpgm_link_boot_reqs	,//17

	output	[ 3: 0]					tpgm_link_cmnd_indx	,
	input	[31: 0]					tpgm_link_cmnd_data	,

	output	[ 3: 0]					tpgm_link_acmd_indx	,
	input	[31: 0]					tpgm_link_acmd_data	,

	output							tpgm_odat_rdma_enab	,
	output							tpgm_odat_rdma_mode	,
	input							tpgm_odat_rdma_done	,

	output							tpgm_idat_wdma_enab	,
	output							tpgm_idat_wdma_mode	,
	input							tpgm_idat_wdma_done	,

	input							tpgm_link_acks_coda	,
	input							tpgm_link_resp_coda	,
	
	input							tpgm_sclk			,
	input							tpgm_rstn			);
/**********************************************************************/
//	wire							tpgm_link_trim_idle	;
	wire							tpgm_link_cfig_idle	;
	wire							tpgm_link_xdat_idle	;
	wire							tpgm_link_sdes_idle	;

	wire	tpgm_link_idle_stat	= &{tpgm_link_cfig_idle	,	tpgm_link_xdat_idle	,	tpgm_link_sdes_idle};

	always@(posedge tpgm_sclk or negedge tpgm_rstn)
	if(~tpgm_rstn)					tpgm_link_port_idle	<=	1'B0				;
	else							tpgm_link_port_idle	<=	tpgm_link_idle_stat	;	
/**********************************************************************/
//	wire	[ 3: 0]					tpgm_trim_cmnd_indx	;
	wire	[ 3: 0]					tpgm_cfig_cmnd_indx	;
	wire	[ 3: 0]					tpgm_xdat_cmnd_indx	;
	wire	[ 3: 0]					tpgm_sdes_cmnd_indx	;

	assign	tpgm_link_cmnd_indx	=	tpgm_cfig_cmnd_indx	|	tpgm_xdat_cmnd_indx	|	tpgm_sdes_cmnd_indx	;


	wire	[ 7: 0]					tpgm_cfig_fram_mbdo	;
	wire	[ 7: 0]					tpgm_cfig_dat0_mbdo	;
	wire	[ 7: 0]					tpgm_cfig_dat1_mbdo	;
	wire	[ 7: 0]					tpgm_cfig_dat2_mbdo	;
	wire	[ 7: 0]					tpgm_cfig_dat3_mbdo	;

	wire	[ 7: 0]					tpgm_xdat_fram_mbdo	;
	wire	[ 7: 0]					tpgm_xdat_dat0_mbdo	;
	wire	[ 7: 0]					tpgm_xdat_dat1_mbdo	;
	wire	[ 7: 0]					tpgm_xdat_dat2_mbdo	;
	wire	[ 7: 0]					tpgm_xdat_dat3_mbdo	;
	
	wire	[ 7: 0]					tpgm_sdes_fram_mbdo	;
	wire	[ 7: 0]					tpgm_sdes_dat0_mbdo	;
	wire	[ 7: 0]					tpgm_sdes_dat1_mbdo	;
	wire	[ 7: 0]					tpgm_sdes_dat2_mbdo	;
	wire	[ 7: 0]					tpgm_sdes_dat3_mbdo	;

	assign	tpgm_clnk_fram_mbdo	= 	tpgm_cfig_fram_mbdo | tpgm_xdat_fram_mbdo | tpgm_sdes_fram_mbdo	;//tpgm_trim_fram_mbdo	|
	assign	tpgm_clnk_dat0_mbdo	= 	tpgm_cfig_dat0_mbdo | tpgm_xdat_dat0_mbdo | tpgm_sdes_dat0_mbdo	;//tpgm_trim_dat0_mbdo	|
	assign	tpgm_clnk_dat1_mbdo	= 	tpgm_cfig_dat1_mbdo | tpgm_xdat_dat1_mbdo | tpgm_sdes_dat1_mbdo	;//tpgm_trim_dat1_mbdo	|
	assign	tpgm_clnk_dat2_mbdo	= 	tpgm_cfig_dat2_mbdo | tpgm_xdat_dat2_mbdo | tpgm_sdes_dat2_mbdo	;//tpgm_trim_dat2_mbdo	|
	assign	tpgm_clnk_dat3_mbdo	= 	tpgm_cfig_dat3_mbdo | tpgm_xdat_dat3_mbdo | tpgm_sdes_dat3_mbdo	;//tpgm_trim_dat3_mbdo	|
/**********************************************************************/
/*	wire			[3:0 ]			cube_link_trim_mfsm	;
	wire							cube_link_trim_coda	;

	cube_link_trim_misc #(	.LINK_MODE	("TPGM")	)	
							u_cube_link_trim_misc(
		.cube_clnk_fram_mbdo		(tpgm_trim_fram_mbdo	),//output	reg		[ 7: 0]	
		.cube_clnk_dat0_mbdo		(tpgm_trim_dat0_mbdo	),//output	reg		[ 7: 0]	
		.cube_clnk_dat1_mbdo		(tpgm_trim_dat1_mbdo	),//output	reg		[ 7: 0]	
		.cube_clnk_dat2_mbdo		(tpgm_trim_dat2_mbdo	),//output	reg		[ 7: 0]	
		.cube_clnk_dat3_mbdo		(tpgm_trim_dat3_mbdo	),//output	reg		[ 7: 0]	

		.cube_link_trim_mfsm		(tpgm_link_trim_mfsm	),//output			[3:0 ]	
		.cube_link_trim_idle		(tpgm_link_trim_idle	),//output					
		.cube_link_trim_coda		(tpgm_link_trim_coda	),//output					
		.cube_link_trim_done		(tpgm_link_trim_done	),//output					
		.cube_link_trim_reqs		(tpgm_link_trim_reqs	),//input					
		.cube_link_cmnd_indx		(tpgm_trim_cmnd_indx	),//output	reg		[ 3: 0]	
		.cube_link_cmnd_data		(tpgm_link_cmnd_data	),//input			[31: 0]	
		.link_clki					(link_clki				),//input					
		.link_rstn					(link_rstn				));	//input					
*/


	wire			[3:0 ]			cube_link_cfig_mfsm	;
	wire							cube_link_cmnd_coda	;


	cube_link_cfig_misc	#(	.LINK_MODE	("TPGM")	)	
	u_tpgm_link_cfig_misc(
		.cube_clnk_fram_mbdo		(tpgm_cfig_fram_mbdo	),//output	reg				
		.cube_clnk_dat0_mbdo		(tpgm_cfig_dat0_mbdo	),//output	reg		[ 7: 0]	
		.cube_clnk_dat1_mbdo		(tpgm_cfig_dat1_mbdo	),//output	reg		[ 7: 0]	
		.cube_clnk_dat2_mbdo		(tpgm_cfig_dat2_mbdo	),//output	reg		[ 7: 0]	
		.cube_clnk_dat3_mbdo		(tpgm_cfig_dat3_mbdo	),//output	reg		[ 7: 0]	

		.cube_link_cfig_idle		(tpgm_link_cfig_idle	),//output			
		
		.cube_link_trim_done		(tpgm_link_trim_done	),//output					
		.cube_link_icfg_done		(tpgm_link_icfg_done	),//output					
		.cube_link_ocfg_done		(tpgm_link_ocfg_done	),//output					
		.cube_link_nnex_done		(tpgm_link_nnex_done	),//output					
		.cube_link_aset_done		(tpgm_link_aset_done	),//output					
		.cube_link_dnld_done		(tpgm_link_dnld_done	),//output					
		.cube_link_boot_done		(tpgm_link_boot_done	),//output					
		.cube_link_rivt_done		(tpgm_link_rivt_done	),//output					
		.cube_link_rovt_done		(tpgm_link_rovt_done	),//output
		.cube_link_rimt_done		(tpgm_link_rimt_done	),//output					
		.cube_link_romt_done		(tpgm_link_romt_done	),//output
		
		.cube_link_trim_reqs		(tpgm_link_trim_reqs	),//input	
		.cube_link_icfg_reqs		(tpgm_link_icfg_reqs	),//input	
		.cube_link_ocfg_reqs		(tpgm_link_ocfg_reqs	),//input	
		.cube_link_nnex_reqs		(tpgm_link_nnex_reqs	),//input	
		.cube_link_aset_reqs		(tpgm_link_aset_reqs	),//input	
		.cube_link_dnld_reqs		(tpgm_link_dnld_reqs	),//input	
		.cube_link_boot_reqs		(tpgm_link_boot_reqs	),//input	
		.cube_link_rivt_reqs		(tpgm_link_rivt_reqs	),//input	
		.cube_link_rovt_reqs		(tpgm_link_rovt_reqs	),//input	
		.cube_link_rimt_reqs		(tpgm_link_rimt_reqs	),//input	
		.cube_link_romt_reqs		(tpgm_link_romt_reqs	),//input	

		.cube_link_cmnd_indx		(tpgm_cfig_cmnd_indx	),//output	reg		[ 3: 0]	
		.cube_link_cmnd_data		(tpgm_link_cmnd_data	),//input			[31: 0]	
		.cube_link_acks_coda		(tpgm_link_acks_coda	),//input					
		.cube_link_resp_coda		(tpgm_link_resp_coda	),//input					
		
		.link_clki					(tpgm_sclk				),//input		
		.link_rstn					(tpgm_rstn				));//input		
/**********************************************************************/
	cube_link_xdat_misc		#(	.LINK_MODE	("TPGM")	)	
								u_tpgm_link_xdat_misc(
		.cube_clnk_fram_mbdo		(tpgm_xdat_fram_mbdo	),//output	reg				
		.cube_clnk_dat0_mbdo		(tpgm_xdat_dat0_mbdo	),//output	reg		[ 7: 0]	
		.cube_clnk_dat1_mbdo		(tpgm_xdat_dat1_mbdo	),//output	reg		[ 7: 0]	
		.cube_clnk_dat2_mbdo		(tpgm_xdat_dat2_mbdo	),//output	reg		[ 7: 0]	
		.cube_clnk_dat3_mbdo		(tpgm_xdat_dat3_mbdo	),//output	reg		[ 7: 0]	

		.cube_link_xdat_scut		(1'b0					),//input					
		.cube_link_ivct_reqs		(tpgm_link_ivct_reqs	),//input					
		.cube_link_ovct_reqs		(tpgm_link_ovct_reqs	),//input					
		.cube_link_imtx_reqs		(tpgm_link_imtx_reqs	),//input					
		.cube_link_omtx_reqs		(tpgm_link_omtx_reqs	),//input					

		.cube_link_xdat_idle		(tpgm_link_xdat_idle	),//output					
		.cube_link_ivct_done		(tpgm_link_ivct_done	),//output					
		.cube_link_ovct_done		(tpgm_link_ovct_done	),//output					
		.cube_link_imtx_done		(tpgm_link_imtx_done	),//output					
		.cube_link_omtx_done		(tpgm_link_omtx_done	),//output					

		.link_odat_rdma_enab		(tpgm_odat_rdma_enab	),//output					
		.link_odat_rdma_mode		(tpgm_odat_rdma_mode	),//output		
		.link_odat_rdma_done		(tpgm_odat_rdma_done	),//output		
					
		.link_idat_wdma_enab		(tpgm_idat_wdma_enab	),//output					
		.link_idat_wdma_mode		(tpgm_idat_wdma_mode	),//output					
		.link_idat_wdma_done		(tpgm_idat_wdma_done	),//output					

		.cube_link_cmnd_indx		(tpgm_xdat_cmnd_indx	),//output	reg		[ 3: 0]	
		.cube_link_cmnd_data		(tpgm_link_cmnd_data	),//input			[31: 0]	
		.cube_link_acks_coda		(tpgm_link_acks_coda	),//input					
		.cube_link_resp_coda		(tpgm_link_resp_coda	),//input					

		.link_clki					(tpgm_sclk				),//input					
		.link_rstn					(tpgm_rstn				));//input						
/**********************************************************************/
	cube_link_sdes_misc			u_tpgm_link_sdes_misc(
		.cube_clnk_fram_mbdo		(tpgm_sdes_fram_mbdo	),//output	reg				
		.cube_clnk_dat3_mbdo		(tpgm_sdes_dat3_mbdo	),//output	reg		[ 7: 0]	
		.cube_clnk_dat2_mbdo		(tpgm_sdes_dat2_mbdo	),//output	reg		[ 7: 0]	
		.cube_clnk_dat1_mbdo		(tpgm_sdes_dat1_mbdo	),//output	reg		[ 7: 0]	
		.cube_clnk_dat0_mbdo		(tpgm_sdes_dat0_mbdo	),//output	reg		[ 7: 0]	
	
		.cube_link_sdes_idle		(tpgm_link_sdes_idle	),//output					
		.cube_link_risv_reqs		(tpgm_link_risv_reqs	),//input					
		.cube_link_rosv_reqs		(tpgm_link_rosv_reqs	),//input					
		.cube_link_rism_reqs		(tpgm_link_rism_reqs	),//input					
		.cube_link_rosm_reqs		(tpgm_link_rosm_reqs	),//input					
		.cube_link_risv_done		(tpgm_link_risv_done	),//output					
		.cube_link_rosv_done		(tpgm_link_rosv_done	),//output					
		.cube_link_rism_done		(tpgm_link_rism_done	),//output					
		.cube_link_rosm_done		(tpgm_link_rosm_done	),//output					

		.cube_link_acks_coda		(tpgm_link_acks_coda	),//input					
		.cube_link_resp_coda		(tpgm_link_resp_coda	),//input					

		.cube_link_cmnd_indx		(tpgm_sdes_cmnd_indx	),//output	reg		[ 3: 0]	
		.cube_link_cmnd_data		(tpgm_link_cmnd_data	),//input			[31: 0]	
		.cube_link_acmd_indx		(tpgm_link_acmd_indx	),//output	reg		[ 3: 0]	
		.cube_link_acmd_data		(tpgm_link_acmd_data	),//input			[31: 0]	

		.link_clki					(tpgm_sclk				),//input					
		.link_rstn					(tpgm_rstn				));//input					

/**********************************************************************************************************/
//ILA USAGE
	wire	[31:0]					ila_probe_signal	;
	assign	ila_probe_signal	={	cube_link_cfig_mfsm	,
									cube_link_cmnd_coda ,
									tpgm_link_acks_coda ,
									
									tpgm_link_port_idle	,
									tpgm_link_sdes_idle	,
									tpgm_link_xdat_idle	,
									tpgm_link_cfig_idle	,

									
									tpgm_link_trim_done	,
									tpgm_link_icfg_done	,
									tpgm_link_ocfg_done	,
									tpgm_link_nnex_done	,
									tpgm_link_aset_done	,
									tpgm_link_dnld_done	,
									tpgm_link_boot_done	,
									tpgm_link_rivt_done	,
									tpgm_link_rovt_done	,
									tpgm_link_rimt_done	,
									tpgm_link_romt_done	,
									tpgm_link_trim_reqs	,
									tpgm_link_icfg_reqs	,
									tpgm_link_ocfg_reqs	,
									tpgm_link_nnex_reqs	,
									tpgm_link_aset_reqs	,
									tpgm_link_dnld_reqs	,
									tpgm_link_boot_reqs	,
									tpgm_link_rivt_reqs	,
									tpgm_link_rovt_reqs	,
									tpgm_link_rimt_reqs	,
									tpgm_link_romt_reqs	 	
								};	


endmodule
/*
	cube_link_gset_misc			u_tpgm_link_gset_misc(
		.cube_link_gset_idle		(tpgm_link_gset_idle	),//output		
		.cube_link_rstn_done		(tpgm_link_rstn_done	),//output		
		.cube_link_trim_done		(tpgm_link_trim_done	),//output		
		.cube_link_rstn_reqs		(tpgm_link_rstn_reqs	),//input		
		.cube_link_trim_reqs		(tpgm_link_trim_reqs	),//input		
		.cube_link_rstn_sbdo		(tpgm_link_rstn_sbdo	),//output	reg	
		.cube_link_trim_sbdo		(tpgm_link_trim_sbdo	),//output	reg	
		.link_bclk					(tpgm_sclk				),//input		
		.link_rstn					(tpgm_rstn				));//input		
*/
