/*----------------------------------------------------------------------
AUTHOR	: EDWARD YANG
----------------------------------------------------------------------*/
module	tpgm_link_esse_unit(
	output							pile_pack_wdma_enab	,	
/******************************************************************/
	output							tpgm_link_port_idle	,
	input		[ 3: 0]				tpgm_link_port_enab	,
	input							tpgm_link_port_init	,
	output	reg	[ 3: 0]				tpgm_link_port_acks	,
	output	reg	[ 3: 0]				tpgm_link_port_resp	,

	output		[0:3][7:0]			tpgm_port_txdo_fram	,	
	output		[0:3][7:0]			tpgm_port_txdo_dat0	,	
	output		[0:3][7:0]			tpgm_port_txdo_dat1	,	
	output		[0:3][7:0]			tpgm_port_txdo_dat2	,	
	output		[0:3][7:0]			tpgm_port_txdo_dat3	,

	input		[0:3][7:0]			tpgm_port_rxdi_fram	,	
	input		[0:3][7:0]			tpgm_port_rxdi_dat0	,	
	input		[0:3][7:0]			tpgm_port_rxdi_dat1	,	
	input		[0:3][7:0]			tpgm_port_rxdi_dat2	,	
	input		[0:3][7:0]			tpgm_port_rxdi_dat3	,
/******************************************************************/
	output		[ 3: 0]				tpgm_link_cmnd_indx	,
	input		[31: 0]				tpgm_link_cmnd_data	,
	output		[ 3: 0]				tpgm_link_acmd_indx	,
	input		[31: 0]				tpgm_link_acmd_data	,

	output		[ 0: 3]				tpgs_link_acks_lead	,
	output		[ 0: 3]				tpgs_link_acks_wrcs	,
	output		[ 0: 3][31:0]		tpgs_link_acks_data	,
/***********************************************************************/
//FABRIC CONTROL
	output							tpgm_link_trim_done	,//2
	output							tpgm_link_icfg_done	,//2
	output							tpgm_link_ocfg_done	,//3
	output							tpgm_link_nnex_done	,//4
	output							tpgm_link_aset_done	,//5
	output							tpgm_link_dnld_done	,//6
	output							tpgm_link_boot_done	,//7
	output							tpgm_link_rivt_done	,//8
	output							tpgm_link_rovt_done	,//9
	output 							tpgm_link_rimt_done	,//10
	output							tpgm_link_romt_done	,//11
	output							tpgm_link_ivct_done	,//12
	output							tpgm_link_ovct_done	,//13
	output							tpgm_link_imtx_done	,//14
	output							tpgm_link_omtx_done	,//15
	output							tpgm_link_risv_done	,//16
	output							tpgm_link_rosv_done	,//17
	output							tpgm_link_rism_done	,//16
	output							tpgm_link_rosm_done	,//17

	input							tpgm_link_trim_reqs	,//2
	input							tpgm_link_icfg_reqs	,//2
	input							tpgm_link_ocfg_reqs	,//3
	input							tpgm_link_nnex_reqs	,//4
	input							tpgm_link_aset_reqs	,//5
	input							tpgm_link_dnld_reqs	,//6
	input							tpgm_link_boot_reqs	,//7
	input							tpgm_link_rivt_reqs	,//8
	input							tpgm_link_rovt_reqs	,//9
	input 							tpgm_link_rimt_reqs	,//10
	input							tpgm_link_romt_reqs	,//11
	input							tpgm_link_ivct_reqs	,//12
	input							tpgm_link_ovct_reqs	,//13
	input							tpgm_link_imtx_reqs	,//14
	input							tpgm_link_omtx_reqs	,//15
	input							tpgm_link_risv_reqs	,//16
	input							tpgm_link_rosv_reqs	,//17
	input							tpgm_link_rism_reqs	,//16
	input							tpgm_link_rosm_reqs	,//17
/***********************************************************************/
	input	[24: 0]					tpgm_xdma_ddrs_base	,
	input	[19: 0]					tpgm_xdma_meta_rows	,
	input	[19: 0]					tpgm_xdma_meta_cols	,
	input	[19: 0]					tpgm_xdma_edge_rows	,
	input	[19: 0]					tpgm_xdma_edge_cols	,
		
	output							ubus_tpgm_rdma_csen	,//output	reg			
	output		[ 24: 0]			ubus_tpgm_rdma_addr	,//output	reg	[ 27: 0]
	input							ubus_tpgm_rdma_trdy	,//input				
	input		[255: 0]			ubus_tpgm_rdma_data	,//input		[255: 0]
	input							ubus_tpgm_rdma_drdy	,//input		
	
	output							ubus_tpgm_wdma_csen	,
	output		[ 24: 0]			ubus_tpgm_wdma_addr	,
	output		[255: 0]			ubus_tpgm_wdma_data	,
	input							ubus_tpgm_wdma_trdy	,
	input							ubus_tpgm_wdma_wrdy	,
			
	input							tpgm_sclk			,
	input							tpgm_rstn			,
	input							ubus_clki			,
	input							ubus_rstn			);	
/**********************************************************************************************************/
//--TPGM LINK MISC CONTROL	
	wire							tpgm_link_acks_coda	;
	wire							tpgm_link_resp_coda	;

	wire	[ 7: 0]					tpgm_clnk_fram_mbdo	;
	wire	[ 7: 0]					tpgm_clnk_dat0_mbdo	;
	wire	[ 7: 0]					tpgm_clnk_dat1_mbdo	;
	wire	[ 7: 0]					tpgm_clnk_dat2_mbdo	;
	wire	[ 7: 0]					tpgm_clnk_dat3_mbdo	;

	wire	[ 7: 0]					tpgm_dlnk_fram_mbdo	;
	wire	[ 7: 0]					tpgm_dlnk_dat0_mbdo	;
	wire	[ 7: 0]					tpgm_dlnk_dat1_mbdo	;
	wire	[ 7: 0]					tpgm_dlnk_dat2_mbdo	;
	wire	[ 7: 0]					tpgm_dlnk_dat3_mbdo	;
	
	wire	[ 7: 0]					tpgm_link_fram_mbdw	=	tpgm_clnk_fram_mbdo	|	tpgm_dlnk_fram_mbdo	;
	wire	[ 7: 0]					tpgm_link_dat0_mbdw	=	tpgm_clnk_dat0_mbdo	|	tpgm_dlnk_dat0_mbdo	;
	wire	[ 7: 0]					tpgm_link_dat1_mbdw	=	tpgm_clnk_dat1_mbdo	|	tpgm_dlnk_dat1_mbdo	;
	wire	[ 7: 0]					tpgm_link_dat2_mbdw	=	tpgm_clnk_dat2_mbdo	|	tpgm_dlnk_dat2_mbdo	;
	wire	[ 7: 0]					tpgm_link_dat3_mbdw	=	tpgm_clnk_dat3_mbdo	|	tpgm_dlnk_dat3_mbdo	;


	tpgm_link_misc_ctrl			u_tpgm_clnk_misc_ctrl(
		.tpgm_clnk_fram_mbdo		(tpgm_clnk_fram_mbdo	),//output	[ 7: 0]	
		.tpgm_clnk_dat0_mbdo		(tpgm_clnk_dat0_mbdo	),//output	[ 7: 0]	
		.tpgm_clnk_dat1_mbdo		(tpgm_clnk_dat1_mbdo	),//output	[ 7: 0]		
		.tpgm_clnk_dat2_mbdo		(tpgm_clnk_dat2_mbdo	),//output	[ 7: 0]	
		.tpgm_clnk_dat3_mbdo		(tpgm_clnk_dat3_mbdo	),//output	[ 7: 0]	
	
		.tpgm_link_port_idle		(tpgm_link_port_idle	),//output	
		
		.tpgm_link_trim_done		(tpgm_link_trim_done	),//2//output	
		.tpgm_link_icfg_done		(tpgm_link_icfg_done	),//2//output	
		.tpgm_link_ocfg_done		(tpgm_link_ocfg_done	),//3//output	
		.tpgm_link_nnex_done		(tpgm_link_nnex_done	),//4//output	
		.tpgm_link_aset_done		(tpgm_link_aset_done	),//5//output	
		.tpgm_link_dnld_done		(tpgm_link_dnld_done	),//6//output	
		.tpgm_link_boot_done		(tpgm_link_boot_done	),//7//output	
		.tpgm_link_rivt_done		(tpgm_link_rivt_done	),//8//output	
		.tpgm_link_rovt_done		(tpgm_link_rovt_done	),//9//output	
		.tpgm_link_rimt_done		(tpgm_link_rimt_done	),//10//output 	
		.tpgm_link_romt_done		(tpgm_link_romt_done	),//11//output	
		.tpgm_link_ivct_done		(tpgm_link_ivct_done	),//12//output	
		.tpgm_link_ovct_done		(tpgm_link_ovct_done	),//13//output	
		.tpgm_link_imtx_done		(tpgm_link_imtx_done	),//14//output	
		.tpgm_link_omtx_done		(tpgm_link_omtx_done	),//15//output	
		.tpgm_link_risv_done		(tpgm_link_risv_done	),//0//output	
		.tpgm_link_rosv_done		(tpgm_link_rosv_done	),//1//output	
		.tpgm_link_rism_done		(tpgm_link_rism_done	),//16//output	
		.tpgm_link_rosm_done		(tpgm_link_rosm_done	),//17//output	

		.tpgm_link_trim_reqs		(tpgm_link_trim_reqs	),//2//input	
		.tpgm_link_icfg_reqs		(tpgm_link_icfg_reqs	),//2//input	
		.tpgm_link_ocfg_reqs		(tpgm_link_ocfg_reqs	),//3//input	
		.tpgm_link_nnex_reqs		(tpgm_link_nnex_reqs	),//4//input	
		.tpgm_link_aset_reqs		(tpgm_link_aset_reqs	),//5//input	
		.tpgm_link_dnld_reqs		(tpgm_link_dnld_reqs	),//6//input	
		.tpgm_link_boot_reqs		(tpgm_link_boot_reqs	),//7//input	
		.tpgm_link_rivt_reqs		(tpgm_link_rivt_reqs	),//8//input	
		.tpgm_link_rovt_reqs		(tpgm_link_rovt_reqs	),//9//input	
		.tpgm_link_rimt_reqs		(tpgm_link_rimt_reqs	),//10//input 	
		.tpgm_link_romt_reqs		(tpgm_link_romt_reqs	),//11//input	
		.tpgm_link_ivct_reqs		(tpgm_link_ivct_reqs	),//12//input	
		.tpgm_link_ovct_reqs		(tpgm_link_ovct_reqs	),//13//input	
		.tpgm_link_imtx_reqs		(tpgm_link_imtx_reqs	),//14//input	
		.tpgm_link_omtx_reqs		(tpgm_link_omtx_reqs	),//15//input	
		.tpgm_link_risv_reqs		(tpgm_link_risv_reqs	),//0//output	
		.tpgm_link_rosv_reqs		(tpgm_link_rosv_reqs	),//1//output	
		.tpgm_link_rism_reqs		(tpgm_link_rism_reqs	),//16//input	
		.tpgm_link_rosm_reqs		(tpgm_link_rosm_reqs	),//17//input	

		.tpgm_link_cmnd_indx		(tpgm_link_cmnd_indx	),//output	[ 3: 0]		
		.tpgm_link_cmnd_data		(tpgm_link_cmnd_data	),//input	[31: 0]		

		.tpgm_link_acmd_indx		(tpgm_link_acmd_indx	),//output	[ 3: 0]		
		.tpgm_link_acmd_data		(tpgm_link_acmd_data	),//input	[31: 0]		

		.tpgm_odat_rdma_enab		(tpgm_odat_rdma_enab	),//output				
		.tpgm_odat_rdma_mode		(tpgm_odat_rdma_mode	),//output				
		.tpgm_odat_rdma_done		(tpgm_odat_rdma_done	),//input							

		.tpgm_idat_wdma_enab		(tpgm_idat_wdma_enab	),//output				
		.tpgm_idat_wdma_mode		(tpgm_idat_wdma_mode	),//output				
		.tpgm_idat_wdma_done		(tpgm_idat_wdma_done	),//input				
		
		.tpgm_link_acks_coda		(tpgm_link_acks_coda	),//input				
		.tpgm_link_resp_coda		(tpgm_link_resp_coda	),//input				

		.tpgm_sclk					(tpgm_sclk				),//input				
		.tpgm_rstn					(tpgm_rstn				));//input	
/**********************************************************************************************************/
//--TPGM ODAT RDMA CONTROL

	dlnk_mono_rdma_ctrl			u_tpgm_dlnk_rdma_ctrl(

		.dlnk_odat_fram_mbdo		(tpgm_dlnk_fram_mbdo	),//output		[ 7: 0]
		.dlnk_odat_dat3_mbdo		(tpgm_dlnk_dat3_mbdo	),//output		[ 7: 0]
		.dlnk_odat_dat2_mbdo		(tpgm_dlnk_dat2_mbdo	),//output		[ 7: 0]
		.dlnk_odat_dat1_mbdo		(tpgm_dlnk_dat1_mbdo	),//output		[ 7: 0]
		.dlnk_odat_dat0_mbdo		(tpgm_dlnk_dat0_mbdo	),//output		[ 7: 0]

		.dlnk_odat_ddrs_mode		(tpgm_odat_rdma_mode	),
		.dlnk_odat_ddrs_enab		(tpgm_odat_rdma_enab	),
		.dlnk_odat_ddrs_done		(tpgm_odat_rdma_done	),

		.llmb_mast_ddrs_base		(tpgm_xdma_ddrs_base	),//input	[24: 0]
		.llmb_meta_imag_rows		(tpgm_xdma_meta_rows	),//input	[19: 0]
		.llmb_meta_imag_cols		(tpgm_xdma_meta_cols	),//input	[19: 0]
		.llmb_edge_imag_rows		(tpgm_xdma_edge_rows	),//input	[19: 0]
		.llmb_edge_imag_cols		(tpgm_xdma_edge_cols	),//input	[19: 0]
		
		.link_clki					(tpgm_sclk				),
		.link_rstn					(tpgm_rstn				),

		.ubus_dlnk_rdma_csen		(ubus_tpgm_rdma_csen	),//output	reg			
		.ubus_dlnk_rdma_addr		(ubus_tpgm_rdma_addr	),//output	reg	[ 27: 0]
		.ubus_dlnk_rdma_data		(ubus_tpgm_rdma_data	),//input		[255: 0]
		.ubus_dlnk_rdma_trdy		(ubus_tpgm_rdma_trdy	),//input				
		.ubus_dlnk_rdma_drdy		(ubus_tpgm_rdma_drdy	),//input				

		.ubus_clki					(ubus_clki				),//input				
		.ubus_rstn					(ubus_rstn				));	//input				
/**********************************************************************************************************/
//--TPGM LINK PORT INTERFACE	
	wire	[ 0: 3]	[ 3: 0]			ecos_pile_this_indx	;
	
	assign	ecos_pile_this_indx[0]=	4'H0	;
	assign	ecos_pile_this_indx[1]=	4'H1	;
	assign	ecos_pile_this_indx[2]=	4'H2	;
	assign	ecos_pile_this_indx[3]=	4'H3	;
	
	wire							tpgs_link_wdma_init	;
	wire							tpgs_link_wdma_updt	;
	
	wire	[ 0: 3]					tpgs_idat_wdma_done	;
	wire	[ 0: 3]					tpgs_link_wdma_reqs	;
	wire	[ 3: 0]					tpgs_link_wdma_size	;

	wire	[ 0: 3]					tpgs_link_wdma_ov16	;
	wire	[ 0: 3]					tpgs_link_wdma_ov08	;
	wire	[ 0: 3]					tpgs_link_wdma_ov04	;
	wire	[ 0: 3]					tpgs_link_wdma_ov02	;
	
	wire	[ 0: 3]	[255: 0]		tpgs_link_wdma_data	;
	wire	[ 0: 3]	[ 24: 0]		tpgs_link_wdma_addr	;
	wire	[ 0: 3]					tpgs_link_wdma_drdy	;

	wire	[ 0: 3]					tpgm_fake_acks_coda	;
	wire	[ 0: 3]					tpgm_fake_resp_coda	;
	wire	[ 0: 3]					tpgs_fake_wdma_done	;	


	wire	[ 0: 3]					tpgs_link_acks_coda	;
	wire	[ 0: 3]					tpgs_link_resp_coda	;
	wire	[ 0: 3]					tpgs_link_idat_lead	;
	wire	[ 0: 3]					tpgs_link_idat_wrcs	;
	wire	[ 0: 3]	[31: 0]			tpgs_link_idat_data	;
//	wire	[ 0: 3]					tpgm_link_trim_csen	;

	assign	tpgm_link_acks_coda	= &	tpgm_fake_acks_coda	;
	assign	tpgm_link_resp_coda	= &	tpgm_fake_resp_coda	;
	assign	tpgm_idat_wdma_done	= &	tpgs_fake_wdma_done	;

	always@(posedge tpgm_sclk or negedge tpgm_rstn )
	if(~tpgm_rstn)					tpgm_link_port_acks	<=	0	;
	else if(tpgm_link_port_init)	tpgm_link_port_acks	<=	0	;
	else							tpgm_link_port_acks	<={	tpgm_fake_acks_coda[3]	,
															tpgm_fake_acks_coda[2]	,
															tpgm_fake_acks_coda[1]	,
															tpgm_fake_acks_coda[0]	};			

	always@(posedge tpgm_sclk or negedge tpgm_rstn )
	if(~tpgm_rstn)					tpgm_link_port_resp	<=	0	;
	else if(tpgm_link_port_init)	tpgm_link_port_resp	<=	0	;
	else							tpgm_link_port_resp	<={	tpgm_fake_resp_coda[3]	,
															tpgm_fake_resp_coda[2]	,
															tpgm_fake_resp_coda[1]	,
															tpgm_fake_resp_coda[0]	};			

/**********************************************************************************************************/
(* MARK_DEBUG = "TRUE" *)	wire								tpgm_txdo_fram_csen	= &	tpgm_link_fram_mbdw	;
(* MARK_DEBUG = "TRUE" *)	wire	[31: 0]						tpgm_txdo_fram_data	={	tpgm_link_dat3_mbdw	,
																tpgm_link_dat2_mbdw	,
																tpgm_link_dat1_mbdw	,
																tpgm_link_dat0_mbdw	}	;
//----------------------------------------------------------------------------------------------------------------------
	wire								tpgm_rxdi_fram_cs00	= &	tpgm_port_rxdi_fram[0]	;
	wire								tpgm_rxdi_fram_cs01	= &	tpgm_port_rxdi_fram[1]	;
	wire								tpgm_rxdi_fram_cs02	= &	tpgm_port_rxdi_fram[2]	;
	wire								tpgm_rxdi_fram_cs03	= &	tpgm_port_rxdi_fram[3]	;

(* MARK_DEBUG = "TRUE" *)	wire		tpgm_rxdi_fram_csen =|{	tpgm_rxdi_fram_cs00	,
																tpgm_rxdi_fram_cs01	,
																tpgm_rxdi_fram_cs02	,
																tpgm_rxdi_fram_cs03	};

	wire	[31: 0]						tpgm_rxdi_fram_dat0	= {	tpgm_port_rxdi_dat3[0],tpgm_port_rxdi_dat2[0],tpgm_port_rxdi_dat1[0],tpgm_port_rxdi_dat0[0]	};
	wire	[31: 0]						tpgm_rxdi_fram_dat1	= {	tpgm_port_rxdi_dat3[1],tpgm_port_rxdi_dat2[1],tpgm_port_rxdi_dat1[1],tpgm_port_rxdi_dat0[1]	};
	wire	[31: 0]						tpgm_rxdi_fram_dat2	= {	tpgm_port_rxdi_dat3[2],tpgm_port_rxdi_dat2[2],tpgm_port_rxdi_dat1[2],tpgm_port_rxdi_dat0[2]	};
	wire	[31: 0]						tpgm_rxdi_fram_dat3	= {	tpgm_port_rxdi_dat3[3],tpgm_port_rxdi_dat2[3],tpgm_port_rxdi_dat1[3],tpgm_port_rxdi_dat0[3]	};

(* MARK_DEBUG = "TRUE" *)	wire	[31: 0]						tpgm_rxdi_fram_data	=	tpgm_rxdi_fram_cs00	?	tpgm_rxdi_fram_dat0	:
																						tpgm_rxdi_fram_cs01	?	tpgm_rxdi_fram_dat1	:
																						tpgm_rxdi_fram_cs02	?	tpgm_rxdi_fram_dat2	:
																						tpgm_rxdi_fram_cs03	?	tpgm_rxdi_fram_dat3	:	0	;

(* MARK_DEBUG = "TRUE" *)	wire	tpgm_link_ovct_quiz	;
(* MARK_DEBUG = "TRUE" *)	wire	tpgm_link_ivct_quiz	;


	xdat_patn_quiz					u_ovct_quiz_unit(
		.link_cmnd_reqs					(tpgm_link_ovct_reqs	),//input				
		.link_quiz_good					(tpgm_link_ovct_quiz	),//output				
		.link_fram_vlid					(tpgm_txdo_fram_csen	),//input	[7: 0]		
		.link_fram_data					(tpgm_txdo_fram_data	),//input	[7: 0]		
		.link_clki						(tpgm_sclk				),//input				
		.link_rstn						(tpgm_rstn				));//input				


	xdat_patn_quiz					u_ivct_quiz_unit(
		.link_cmnd_reqs					(tpgm_link_ivct_reqs	),//input				
		.link_quiz_good					(tpgm_link_ivct_quiz	),//output				
		.link_fram_vlid					(tpgm_rxdi_fram_csen	),//input		
		.link_fram_data					(tpgm_rxdi_fram_data	),//input	[31: 0]		
		.link_clki						(tpgm_sclk				),//input				
		.link_rstn						(tpgm_rstn				));//input				
/**********************************************************************************************************/
for( genvar i = 0 ; i < 4 ; i++) begin:gens_tpgm_port
	assign	tpgm_fake_acks_coda[i]			=	tpgm_link_port_enab[i]	?	tpgs_link_acks_coda[i]	:	1'B1	;
	assign	tpgm_fake_resp_coda[i]			=	tpgm_link_port_enab[i]	?	tpgs_link_resp_coda[i]	:	1'B1	;
	assign	tpgs_fake_wdma_done[i]			=	tpgm_link_port_enab[i]	?	tpgs_idat_wdma_done[i]	:	1'B1	;
	assign	tpgs_link_acks_data[i][31:0]	=	tpgs_link_idat_data[i][31:0]	;

	link_mast_txdo_port			u_tpgm_txdo_port(	
		.link_txdo_port_enab		(tpgm_link_port_enab[i]	),//input	//		.link_txdo_port_tune		(tpgm_link_port_tune	),

		.link_txdo_fram_mbdi		(tpgm_link_fram_mbdw	),//input		
		.link_txdo_dat0_mbdi		(tpgm_link_dat0_mbdw	),//input	[7:0]
		.link_txdo_dat1_mbdi		(tpgm_link_dat1_mbdw	),//input	[7:0]
		.link_txdo_dat2_mbdi		(tpgm_link_dat2_mbdw	),//input	[7:0]
		.link_txdo_dat3_mbdi		(tpgm_link_dat3_mbdw	),//input	[7:0]

		.link_txdo_fram_mbdo		(tpgm_port_txdo_fram[i][7:0]	),//output		
		.link_txdo_dat0_mbdo		(tpgm_port_txdo_dat0[i][7:0]	),//output	[7:0]
		.link_txdo_dat1_mbdo		(tpgm_port_txdo_dat1[i][7:0]	),//output	[7:0]
		.link_txdo_dat2_mbdo		(tpgm_port_txdo_dat2[i][7:0]	),//output	[7:0]
		.link_txdo_dat3_mbdo		(tpgm_port_txdo_dat3[i][7:0]	),//output	[7:0]

		.link_clki					(tpgm_sclk				),//input
		.link_rstn					(tpgm_rstn				));//input

	link_mast_rxdi_port			u_tpgm_rxdi_port(
		.link_rxdi_port_enab		(tpgm_link_port_enab[i]	),//input	
		.link_rxdi_port_init		(tpgm_link_port_init	),//input	

		.link_rxdi_fram_mbdi		(tpgm_port_rxdi_fram[i][7:0]	),//input	[7:0]
		.link_rxdi_dat0_mbdi		(tpgm_port_rxdi_dat0[i][7:0]	),//input	[7:0]
		.link_rxdi_dat1_mbdi		(tpgm_port_rxdi_dat1[i][7:0]	),//input	[7:0]
		.link_rxdi_dat2_mbdi		(tpgm_port_rxdi_dat2[i][7:0]	),//input	[7:0]
		.link_rxdi_dat3_mbdi		(tpgm_port_rxdi_dat3[i][7:0]	),//input	[7:0]
	
		.link_rxdi_acks_lead		(tpgs_link_acks_lead[i]	),//output	reg	
		.link_rxdi_acks_wrcs		(tpgs_link_acks_wrcs[i]	),//output	reg	
		.link_rxdi_acks_coda		(tpgs_link_acks_coda[i]	),//output	reg	
		
		.link_rxdi_resp_lead		(						),//output	reg	
		.link_rxdi_resp_wrcs		(						),//output	reg	
		.link_rxdi_resp_coda		(tpgs_link_resp_coda[i]	),//output	reg	

		.link_rxdi_data_lead		(tpgs_link_idat_lead[i]	),//output	reg			
		.link_rxdi_data_wrcs		(tpgs_link_idat_wrcs[i]	),//output	reg			
		.link_rxdi_data_word		(tpgs_link_idat_data[i]	),//output	reg	[31: 0]	

		.link_clki					(tpgm_sclk				),//input	
		.link_rstn					(tpgm_rstn				));//input		

	cube_pile_wdma_mono			u_tpgm_rxdi_wdma_ctrl(
		.ecos_pile_omni_numb		(4'H4					),//input		[ 3: 0]	
		.ecos_pile_this_indx		(4'H0					),//(ecos_pile_this_indx[i]	),//input		[ 3: 0]	
		
		.pile_xdat_ddrs_base		(tpgm_xdma_ddrs_base	),//input		[24 : 0]	
		.pile_xdat_rows_numb		(tpgm_xdma_edge_rows	),//input		[19 : 0]
		.pile_xdat_cols_numb		(tpgm_xdma_edge_cols	),//input		[15 : 0]
		
		.cube_pile_wdma_enab		(tpgm_idat_wdma_enab	),//input					
		.cube_pile_wdma_mode		(tpgm_idat_wdma_mode	),//input					
		.cube_pile_wdma_done		(tpgs_idat_wdma_done[i]	),//output					
		
		.cube_pile_idat_lead		(tpgs_link_idat_lead[i]	),//input				
		.cube_pile_idat_wrcs		(tpgs_link_idat_wrcs[i]	),//input				
		.cube_pile_idat_word		(tpgs_link_idat_data[i]	),//input		[ 31: 0]
		.link_clki					(tpgm_sclk				),//input	
		.link_rstn					(tpgm_rstn				),//input	

		.cube_pile_wdma_ov16		(tpgs_link_wdma_ov16[i]	),//output					
		.cube_pile_wdma_ov08		(tpgs_link_wdma_ov08[i]	),//output					
		.cube_pile_wdma_ov04		(tpgs_link_wdma_ov04[i]	),//output			
		.cube_pile_wdma_ov02		(tpgs_link_wdma_ov02[i]	),//output			

		.cube_pile_wdma_init		(tpgs_link_wdma_init	),//input	
		.cube_pile_wdma_updt		(tpgs_link_wdma_updt	),//input	
						
		.cube_pile_wdma_reqs		(tpgs_link_wdma_reqs[i]	),//input					
		.cube_pile_wdma_size		(tpgs_link_wdma_size	),//input		[ 3: 0]	

		.ubus_pile_wdma_data		(tpgs_link_wdma_data[i]	),//output		[255: 0]	
		.ubus_pile_wdma_addr		(tpgs_link_wdma_addr[i]	),//output		[ 24: 0]	
		.ubus_pile_wdma_drdy		(tpgs_link_wdma_drdy[i]	),//output	reg				

		.ubus_clki					(ubus_clki				),
		.ubus_rstn					(ubus_rstn				));	
end
//	endgenerate	
/**********************************************************************************************************/
//--TPGM IDAT WDMA CONTROL
	cube_pile_wdma_ctrl			u_cube_pile_wdma_ctrl(
		.pile_pack_wdma_enab		(pile_pack_wdma_enab	),

		.cube_pile_wdma_enab		(tpgm_idat_wdma_enab	),//input	
		.cube_pile_pack_ov16		(tpgs_link_wdma_ov16	),//input	[ 0: 3]			
		.cube_pile_pack_ov08		(tpgs_link_wdma_ov08	),//input	[ 0: 3]			
		.cube_pile_pack_ov04		(tpgs_link_wdma_ov04	),//input	[ 0: 3]			
		.cube_pile_pack_ov02		(tpgs_link_wdma_ov02	),//input	[ 0: 3]			

		.cube_pile_pack_addr		(tpgs_link_wdma_addr	),//input	[ 0: 3][ 24: 0]	
		.cube_pile_pack_data		(tpgs_link_wdma_data	),//input	[ 0: 3][255: 0]	
		.cube_pile_pack_drdy		(tpgs_link_wdma_drdy	),//input	[ 0: 3]		

		.cube_pile_push_init		(tpgs_link_wdma_init	),//output					
		.cube_pile_push_updt		(tpgs_link_wdma_updt	),//output					
		.cube_pile_push_reqs		(tpgs_link_wdma_reqs	),//output		[ 0: ]		
		.cube_pile_push_size		(tpgs_link_wdma_size	),//output	reg	[ 3: 0]		

		.link_clki					(tpgm_sclk				),//input	
		.link_rstn					(tpgm_rstn				),//input		

		.ubus_wdma_ddrs_addr		(ubus_tpgm_wdma_addr	),//output	[ 24: 0]		
		.ubus_wdma_ddrs_csen		(ubus_tpgm_wdma_csen	),//output					
		.ubus_wdma_ddrs_data		(ubus_tpgm_wdma_data	),//output	[255: 0]		
		.ubus_wdma_ddrs_trdy		(ubus_tpgm_wdma_trdy	),//input					
		.ubus_wdma_ddrs_wrdy		(ubus_tpgm_wdma_wrdy	),//input					
		.ubus_clki					(ubus_clki				),//input					
		.ubus_rstn					(ubus_rstn				));//input					

endmodule
  