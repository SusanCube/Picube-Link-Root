/*----author edward------*/
module	mgth_osde_argu_gens(
	output								sdes_link_osde_done	,	
	input								sdes_link_osde_enab	,

	input		[24: 0]					sdes_link_ddrs_size	,
	input		[24: 0]					sdes_hubs_ddrs_base	,
	input		[15: 0]					sdes_hubs_cols_dims	,
	input		[15: 0]					sdes_hubs_cols_dumy	,
	input								link_sclk			,
	input								link_rstn			,

    input								ubus_osde_mgth_done	,
	output								ubus_osde_mgth_enab	,//write enable

	output		[24: 0]					ubus_osde_ddrs_base	,
	output		[24 :0]					ubus_osde_ddrs_size	,
    output      [15: 0]                 ubus_osde_part_cols	,
    output      [15: 0]                 ubus_osde_part_dumy	,
	input								ubus_clki			,
	input								ubus_rstn			);
/**********************************************************************************************************/
	gens_sign_fast_slow #( .EXTN( 5 ))
									u_ubus_osde_done_gens(	
		.slow_sign						(sdes_link_osde_done 	),//output	
		.slow_clki						(link_sclk				),//input	
		.slow_rstn						(link_rstn				),//input	

		.fast_sign  					(ubus_osde_mgth_done	),//input
		.fast_clki						(ubus_clki				),//input
		.fast_rstn						(ubus_rstn				));//input

	gens_sign_slow_fast #( .EXTN( 2 ))	
									u_ubus_osde_enab_gens(	
		.slow_sign						(sdes_link_osde_enab 	),//input	
		.slow_clki						(link_sclk				),//input	
		.slow_rstn						(link_rstn				),//input	

		.fast_sign  					(ubus_osde_mgth_enab	),//output
		.fast_clki						(ubus_clki				),//input
		.fast_rstn						(ubus_rstn				));//input

	gens_sync_gray	#( .MSB(24) )	u_ddrs_base_sync_ubus(
		.data_asyn						(sdes_hubs_ddrs_base	),//input	[24: 0]	
		.scki							(link_sclk				),
		.data_sync						(ubus_osde_ddrs_base	),//output	[24: 0]	
		.clki							(ubus_clki				),//input			
		.rstn							(ubus_rstn				));//input			

	gens_sync_gray	#( .MSB(24) )	u_ddrs_size_sync_ubus(
		.data_asyn						(sdes_link_ddrs_size	),//input	[24: 0]	
		.scki							(link_sclk				),
		.data_sync						(ubus_osde_ddrs_size	),//output	[24: 0]	
		.clki							(ubus_clki				),//input			
		.rstn							(ubus_rstn				));//input			

	gens_sync_gray	#( .MSB(15) )	u_part_cols_sync_ubus(
		.data_asyn						(sdes_hubs_cols_dims	),//input	[15: 0]	
		.scki							(link_sclk				),
		.data_sync						(ubus_osde_part_cols	),//output	[15: 0]	
		.clki							(ubus_clki				),//input			
		.rstn							(ubus_rstn				));//input			

	gens_sync_gray	#( .MSB(15) )	u_part_dumy_sync_ubus(
		.data_asyn						(sdes_hubs_cols_dumy	),//input	[15: 0]	
		.scki							(link_sclk				),
		.data_sync						(ubus_osde_part_dumy	),//output	[15: 0]	
		.clki							(ubus_clki				),//input			
		.rstn							(ubus_rstn				));//input			


endmodule 


 