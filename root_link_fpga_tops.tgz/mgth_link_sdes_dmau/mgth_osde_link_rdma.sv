/*----author edward------*/
module	mgth_osde_link_rdma(
	input								mgth_osde_rdma_trdy	,
	output								mgth_osde_rdma_drdy	,
	output	reg	[255: 0]				mgth_osde_rdma_data	,
	input								mgth_clki			,
	input								mgth_rstn			,

    output								ubus_osde_mgth_done	,
	input								ubus_osde_mgth_enab	,//write enable

	input		[24: 0]					ubus_osde_ddrs_base	,
	input		[24 :0]					ubus_osde_ddrs_size	,
    input       [15: 0]                 ubus_osde_part_cols	,
    input       [15: 0]                 ubus_osde_part_dumy	,
    
	output								ubus_osde_rdma_csen	,
	output	reg	[ 24: 0]				ubus_osde_rdma_addr	,
	input								ubus_osde_rdma_trdy	,
	input		[255: 0]				ubus_osde_rdma_data	,
	input								ubus_osde_rdma_drdy	,
	input								ubus_clki			,
	input								ubus_rstn			);
/**********************************************************************************************************************/
	wire								mgth_osde_rdma_enab	;
	wire						    	mgth_osde_data_reqs	;
	wire						    	mgth_osde_data_last	;

	wire						    	ubus_mgth_push_vlid	;
	wire						    	ubus_mgth_osde_done	;
    wire        [ 7: 0]                 ubus_mgth_rdma_cnts	;
    reg         [ 7: 0]                 ubus_rdma_data_cnts	;

	gens_edge_fast_slow #(.EXTN( 4 ))
									u_mgth_osde_done_gens(	
		.slow_edge						(ubus_mgth_osde_done 	),//output	
		.slow_clki						(ubus_clki				),//input	
		.slow_rstn						(ubus_rstn				),//input	
		.fast_sign  					(mgth_osde_data_last	),//input
		.fast_clki						(mgth_clki				),//input
		.fast_rstn						(mgth_rstn				));//input

	gens_edge_fast_slow #(.EXTN( 4 ))
									u_mgth_osde_reqs_gens(	
		.slow_edge						(mgth_osde_data_reqs 	),//output	
		.slow_clki						(mgth_clki				),//input	
		.slow_rstn						(mgth_rstn				),//input	
		.fast_sign  					(ubus_mgth_push_vlid	),//input
		.fast_clki						(ubus_clki				),//input
		.fast_rstn						(ubus_rstn				));//input

	gens_sign_fast_slow #(.EXTN( 4 ))
									u_mgth_osde_enab_gens(	
		.slow_sign						(mgth_osde_rdma_enab 	),//output	
		.slow_clki						(mgth_clki				),//input	
		.slow_rstn						(mgth_rstn				),//input	
		.fast_sign  					(ubus_osde_mgth_enab	),//input
		.fast_clki						(ubus_clki				),//input
		.fast_rstn						(ubus_rstn				));//input

    gens_sync_gray      #(.MSB ( 7 ))	
                                    u_mgth_ubus_rdma_cnts(
		.data_asyn	                    (ubus_rdma_data_cnts    ),//input	[MSB: 0]
		.scki		                    (ubus_clki              ),//input			

		.data_sync	                    (ubus_mgth_rdma_cnts    ),//output	reg [MSB: 0]
		.clki		                    (mgth_clki              ),//input				
		.rstn		                    (mgth_rstn              ));//input				
    
/**********************************************************************************************************************/
	reg		[3: 0]					    ubus_osde_mgth_mfsm	;

    parameter   MGTH_PACK_PAGE_TRIG =   8'H01   ;//32 PAGES
    parameter   MGTH_PACK_PAGE_LENG =   8'H1F   ;//32 PAGES

	parameter	UBUS_OSDE_RDMA_IDLE	=	4'H0	;
	parameter	UBUS_OSDE_RDMA_REQS	=	4'H1	;
	parameter	USBU_OSDE_RDMA_CMND	=	4'H2	;
	parameter	USBU_OSDE_RDMA_DATA	=	4'H3	;
	parameter	UBUS_OSDE_MGTH_DATA	=	4'H4	;
	parameter	UBUS_OSDE_RDMA_DONE	=	4'H5	;
/**********************************************************************************************************/
	reg							    	ubus_rdma_cmnd_csen	;
	reg							    	ubus_rdma_data_csen	;

	reg			[ 7: 0]			    	ubus_rdma_cmnd_cnts	;
	reg			[24: 0]					ubus_rdma_ddrs_cnts	;

	wire						    	ubus_rdma_cmnd_done	;
	wire						    	ubus_rdma_ddrs_done	;

	wire		ubus_rdma_ddrs_reqs	=	ubus_osde_mgth_mfsm	==	UBUS_OSDE_RDMA_REQS	;
	wire		ubus_rdma_real_reqs	= &{ubus_rdma_ddrs_reqs	, ~	ubus_rdma_ddrs_done};	
	assign		ubus_osde_mgth_done	=	ubus_osde_mgth_mfsm	==	UBUS_OSDE_RDMA_DONE	;
	
	wire		ubus_rdma_cmnd_vlid	= &{ubus_rdma_cmnd_csen	,	ubus_osde_rdma_trdy};
	wire		ubus_rdma_data_vlid	= &{ubus_rdma_data_csen	,	ubus_osde_rdma_drdy};

	assign		ubus_rdma_cmnd_done	= &{ubus_rdma_cmnd_vlid	,	ubus_rdma_cmnd_cnts ==  MGTH_PACK_PAGE_LENG };
	assign		ubus_rdma_data_done	= &{ubus_rdma_data_vlid	,	ubus_rdma_data_cnts ==  MGTH_PACK_PAGE_LENG };
    assign      ubus_mgth_push_vlid = &{ubus_rdma_data_vlid	,	ubus_rdma_data_cnts ==  MGTH_PACK_PAGE_TRIG };  

	assign		ubus_rdma_ddrs_done	= &{ubus_rdma_ddrs_cnts	==	ubus_osde_ddrs_size};	
	assign		ubus_osde_rdma_csen	=	ubus_rdma_cmnd_vlid	;
/**********************************************************************************************************************/
	always@(posedge ubus_clki or negedge  ubus_rstn)
	if(~ubus_rstn)						ubus_osde_mgth_mfsm	<=	UBUS_OSDE_RDMA_IDLE	;
	else if(~ubus_osde_mgth_enab)		ubus_osde_mgth_mfsm	<=	UBUS_OSDE_RDMA_IDLE	;
	else begin	
		case(ubus_osde_mgth_mfsm)		
			UBUS_OSDE_RDMA_IDLE	:		ubus_osde_mgth_mfsm	<=													UBUS_OSDE_RDMA_REQS	;
			UBUS_OSDE_RDMA_REQS	:		ubus_osde_mgth_mfsm	<=	ubus_rdma_ddrs_done	?	UBUS_OSDE_RDMA_DONE	:	USBU_OSDE_RDMA_CMND	;
			USBU_OSDE_RDMA_CMND	:		ubus_osde_mgth_mfsm	<=	ubus_rdma_cmnd_done	?	USBU_OSDE_RDMA_DATA	:	USBU_OSDE_RDMA_CMND	;
			USBU_OSDE_RDMA_DATA	:		ubus_osde_mgth_mfsm	<=	ubus_rdma_data_done	?	UBUS_OSDE_MGTH_DATA	:	USBU_OSDE_RDMA_DATA	;
			UBUS_OSDE_MGTH_DATA	:		ubus_osde_mgth_mfsm	<=	ubus_mgth_osde_done	?	UBUS_OSDE_RDMA_REQS	:	UBUS_OSDE_MGTH_DATA	;
			UBUS_OSDE_RDMA_DONE	:		ubus_osde_mgth_mfsm	<=	ubus_osde_mgth_enab	?	UBUS_OSDE_RDMA_DONE	:	UBUS_OSDE_RDMA_IDLE	;

			default				:		ubus_osde_mgth_mfsm	<=													UBUS_OSDE_RDMA_IDLE	;	
		endcase
	end
//----------------------------------------------------------------------------------------------------------------------	
	always@(posedge ubus_clki or negedge  ubus_rstn)
	if(~ubus_rstn)						ubus_rdma_cmnd_csen	<=	0	;
	else if(~ubus_osde_mgth_enab)		ubus_rdma_cmnd_csen	<=	0	;
	else if( ubus_rdma_real_reqs)		ubus_rdma_cmnd_csen	<=	1	;
	else if( ubus_rdma_cmnd_done)		ubus_rdma_cmnd_csen	<=	0	;

	always@(posedge ubus_clki or negedge  ubus_rstn)
	if(~ubus_rstn)						ubus_rdma_data_csen	<=	0	;
	else if(~ubus_osde_mgth_enab)		ubus_rdma_data_csen	<=	0	;
	else if( ubus_rdma_real_reqs)		ubus_rdma_data_csen	<=	1	;
	else if( ubus_rdma_data_done)		ubus_rdma_data_csen	<=	0	;

	always@(posedge ubus_clki or negedge  ubus_rstn)
	if(~ubus_rstn)						ubus_rdma_cmnd_cnts	<=	0	;
	else if(~ubus_osde_mgth_enab)		ubus_rdma_cmnd_cnts	<=	0	;
	else if( ubus_rdma_real_reqs)		ubus_rdma_cmnd_cnts	<=	0 	;
	else if( ubus_rdma_cmnd_vlid)		ubus_rdma_cmnd_cnts	<=	ubus_rdma_cmnd_cnts +1	;

	always@(posedge ubus_clki or negedge  ubus_rstn)
	if(~ubus_rstn)						ubus_rdma_data_cnts	<=	0	;
	else if(~ubus_osde_mgth_enab)		ubus_rdma_data_cnts	<=	0	;
	else if( ubus_rdma_real_reqs)		ubus_rdma_data_cnts	<=	0	;
	else if( ubus_rdma_data_vlid)		ubus_rdma_data_cnts	<=	ubus_rdma_data_cnts +1	;

	always@(posedge ubus_clki or negedge  ubus_rstn)
	if(~ubus_rstn)						ubus_rdma_ddrs_cnts	<=	0	;
	else if(~ubus_osde_mgth_enab)		ubus_rdma_ddrs_cnts	<=	0	;
	else if( ubus_rdma_data_vlid)		ubus_rdma_ddrs_cnts	<=	ubus_rdma_ddrs_cnts +1	;
/**********************************************************************************************************************/
//zz	else if( ubus_rdma_cmnd_done)		ubus_rdma_cmnd_cnts	<=	0 	;
//--UBUS_RDMA_DDRS_ADDR & UBUS_RDMA_DDRS_DONE
	reg			[15: 0]					ubus_rdma_page_cnts	;
	
	wire		[24: 0]					ubus_addr_next_page	;		
	wire		[24: 0]					ubus_addr_next_rows	;		
	wire								ubus_rdma_rows_tail	;

	assign	ubus_addr_next_page	=		ubus_osde_rdma_addr + 	1	;
	assign	ubus_addr_next_rows	=		ubus_addr_next_page + 	ubus_osde_part_dumy	;
	assign	ubus_rdma_rows_tail	= 	&{	ubus_rdma_cmnd_vlid	,	ubus_rdma_page_cnts + 1 ==	ubus_osde_part_cols	};

	always@(posedge ubus_clki or negedge  ubus_rstn)
	if(~ubus_rstn)						ubus_rdma_page_cnts	<=	0	;
	else if(~ubus_osde_mgth_enab)		ubus_rdma_page_cnts	<=	0  	;
	else if( ubus_rdma_rows_tail)		ubus_rdma_page_cnts	<=	0	;
	else if( ubus_rdma_cmnd_vlid)		ubus_rdma_page_cnts	<=	1 + ubus_rdma_page_cnts ;

	always@(posedge ubus_clki or negedge  ubus_rstn)
	if(~ubus_rstn)						ubus_osde_rdma_addr	<=	0	;
	else if(~ubus_osde_mgth_enab)		ubus_osde_rdma_addr	<=	ubus_osde_ddrs_base ;
	else if( ubus_rdma_rows_tail)		ubus_osde_rdma_addr	<=	ubus_addr_next_rows	;		
	else if( ubus_rdma_cmnd_vlid)		ubus_osde_rdma_addr	<=	ubus_addr_next_page	;
/**********************************************************************************************************************/
	reg			[15: 0]					ubus_rdma_rows_cnts	;

	always@(posedge ubus_clki or negedge  ubus_rstn)
	if(~ubus_rstn)						ubus_rdma_rows_cnts	<=	0	;
	else if(~ubus_osde_mgth_enab)		ubus_rdma_rows_cnts	<=	0  	;
	else if( ubus_rdma_rows_tail)		ubus_rdma_rows_cnts	<=	1 + ubus_rdma_rows_cnts ;
/**********************************************************************************************************************/
	reg									mgth_osde_data_csen	;
	reg			[ 7: 0]					mgth_osde_data_cnts	;

	wire		[ 7: 0]					mgth_osde_data_inc1	;
    wire                                mgth_osde_data_vlid ;


    assign  mgth_osde_data_inc1 =       mgth_osde_data_cnts + 1	;
    assign  mgth_osde_data_vlid =		ubus_mgth_rdma_cnts >=  mgth_osde_data_inc1	;
	assign	mgth_osde_data_drdy	=	&{	mgth_osde_data_csen	,	mgth_osde_rdma_trdy	,	mgth_osde_data_vlid	};
	assign	mgth_osde_data_last	=	&{	mgth_osde_data_drdy	,	mgth_osde_data_cnts	==  MGTH_PACK_PAGE_LENG };

	always@(posedge mgth_clki or negedge  mgth_rstn)
	if(~mgth_rstn)						mgth_osde_data_csen	<=	0	;
	else if(~mgth_osde_rdma_enab)		mgth_osde_data_csen	<=	0	;
	else if( mgth_osde_data_reqs)		mgth_osde_data_csen	<=	1	;
	else if( mgth_osde_data_last)		mgth_osde_data_csen	<=	0	;

	always@(posedge mgth_clki or negedge  mgth_rstn)
	if(~mgth_rstn)						mgth_osde_data_cnts	<=	0	;
	else if(~mgth_osde_rdma_enab)		mgth_osde_data_cnts	<=	0	;
	else if( mgth_osde_data_reqs)		mgth_osde_data_cnts	<=	0	;
	else if( mgth_osde_data_last)		mgth_osde_data_cnts	<=	0	;
	else if( mgth_osde_data_drdy)		mgth_osde_data_cnts	<=	1 +	mgth_osde_data_cnts	;
/**********************************************************************************************************************/
    wire		[7: 0]					mgth_osde_data_nxta	;
	wire		[7: 0]					mgth_osde_data_dptr	;

    assign  mgth_osde_data_nxta =       mgth_osde_data_cnts + 1	;
	assign	mgth_osde_data_dptr	=		mgth_osde_data_drdy	?	mgth_osde_data_nxta :	mgth_osde_data_cnts	;	

	assign	mgth_osde_rdma_drdy	=		mgth_osde_data_drdy	;	

	dual_port_bram	#(	
		.ADDR_BITS	( 8 ),	.DATA_BITS	( 256 ))	
									u_mgth_osde_rdma_memo (
		.wport_csen						(ubus_rdma_data_vlid	),//input  				 		
		.wport_addr						(ubus_rdma_data_cnts	),//input		[ADDR_BITS-1:0]
		.wport_data						(ubus_osde_rdma_data	),//input		[DATA_BITS-1:0]
		.wport_clki						(ubus_clki				),//input						

		.rport_addr						(mgth_osde_data_dptr	),//input		[ADDR_BITS-1:0]
		.rport_data						(mgth_osde_rdma_data   	),//output	reg	[DATA_BITS-1:0]
		.rport_clki						(mgth_clki				));//input						

/**********************************************************************************************************/

endmodule 


 