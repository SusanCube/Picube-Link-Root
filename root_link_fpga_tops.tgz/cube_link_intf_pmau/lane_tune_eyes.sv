
module	lane_tune_eyes(
	input	[ 7: 0]						lane_sdes_prev	,
	input	[ 7: 0]						lane_sdes_data	,

	output	reg							lane_eyes_good	,
	input	[ 7: 0]						lane_eyes_goal	,

	input								tune_eyes_enab	,
	output								tune_eyes_done	,
	input								lane_sclk		,
	input								lane_rstn		);
/**********************************************************************************************************************/
	wire	[ 0 :7 ][ 7: 0]				sdes_data_shft	;
	
	assign	sdes_data_shft[0]	=		lane_sdes_data	;
	assign	sdes_data_shft[1]	=	{	lane_sdes_prev[ 6: 0]	,	lane_sdes_data[ 7: 7]	};
	assign	sdes_data_shft[2]	=	{	lane_sdes_prev[ 5: 0]	,	lane_sdes_data[ 7: 6]	};
	assign	sdes_data_shft[3]	=	{	lane_sdes_prev[ 4: 0]	,	lane_sdes_data[ 7: 5]	};
	assign	sdes_data_shft[4]	=	{	lane_sdes_prev[ 3: 0]	,	lane_sdes_data[ 7: 4]	};
	assign	sdes_data_shft[5]	=	{	lane_sdes_prev[ 2: 0]	,	lane_sdes_data[ 7: 3]	};
	assign	sdes_data_shft[6]	=	{	lane_sdes_prev[ 1: 0]	,	lane_sdes_data[ 7: 2]	};
	assign	sdes_data_shft[7]	=	{	lane_sdes_prev[ 0: 0]	,	lane_sdes_data[ 7: 1]	};

	assign	tune_eyes_meet		=	(	lane_eyes_goal ==	sdes_data_shft[0]	)	|	
									(	lane_eyes_goal ==	sdes_data_shft[1]	)	|	
									(	lane_eyes_goal ==	sdes_data_shft[2]	)	|	
									(	lane_eyes_goal ==	sdes_data_shft[3]	)	|	
									(	lane_eyes_goal ==	sdes_data_shft[4]	)	|	
									(	lane_eyes_goal ==	sdes_data_shft[5]	)	|	
									(	lane_eyes_goal ==	sdes_data_shft[6]	)	|	
									(	lane_eyes_goal ==	sdes_data_shft[7]	)	;
/**********************************************************************************************************************/
	reg			[ 1: 0]					tune_eyes_mfsm	;
	
	parameter	TUNE_EYES_IDLE	=		2'H0	;
	parameter	TUNE_EYES_DONE	=		2'H3	;

	parameter	TUNE_EYES_INIT	=		2'H1	;		
	parameter	TUNE_EYES_ACTV	=		2'H2	;		
	

	wire								tune_eyes_tmax	;
	wire	tune_eyes_init	=			tune_eyes_mfsm	==	TUNE_EYES_INIT	;
	wire	tune_eyes_actv	=			tune_eyes_mfsm	==	TUNE_EYES_ACTV	;
	assign	tune_eyes_done	=			tune_eyes_mfsm	==	TUNE_EYES_DONE	;	

	always@(posedge lane_sclk or negedge lane_rstn )				
	if(~lane_rstn)						tune_eyes_mfsm	<=	TUNE_EYES_IDLE	;
	else if(~tune_eyes_enab)			tune_eyes_mfsm	<=	TUNE_EYES_IDLE	;
	else begin
		case(tune_eyes_mfsm)	
			TUNE_EYES_IDLE		:		tune_eyes_mfsm	<=											TUNE_EYES_INIT	;
			TUNE_EYES_INIT		:		tune_eyes_mfsm	<=											TUNE_EYES_ACTV	;
			TUNE_EYES_ACTV		:		tune_eyes_mfsm	<=	tune_eyes_tmax	?	TUNE_EYES_DONE	:	TUNE_EYES_ACTV	;
			TUNE_EYES_DONE		:		tune_eyes_mfsm	<=											TUNE_EYES_DONE	;
			default				:		tune_eyes_mfsm	<=											TUNE_EYES_IDLE	;
		endcase
	end
/**********************************************************************************************************************/
	reg			[ 7: 0]					tune_eyes_time 	;
	reg			[ 6: 0]					tune_good_cnts	;

	assign	tune_eyes_tmax	=	&		tune_eyes_time	;
	wire	tune_eyes_pass	=	&		tune_good_cnts	;

	always@(posedge lane_sclk or negedge lane_rstn)
	if(~lane_rstn)						tune_eyes_time	<=	0	;
	else if( tune_eyes_init)			tune_eyes_time	<=	0	;
	else if(~tune_eyes_actv)			tune_eyes_time	<=	0	;
	else if(~tune_eyes_tmax)			tune_eyes_time	<=	1 +	tune_eyes_time	;	

	always@(posedge lane_sclk or negedge lane_rstn)
	if(~lane_rstn)						tune_good_cnts	<=	0	;
	else if( tune_eyes_init)			tune_good_cnts	<=	0	;
	else if(~tune_eyes_meet)			tune_good_cnts	<=	0	;
	else if(~tune_eyes_pass)			tune_good_cnts	<=	1 +	tune_good_cnts		;

	always@(posedge lane_sclk or negedge lane_rstn)
	if(~lane_rstn)						lane_eyes_good	<=	0	;
	else if( tune_eyes_init)			lane_eyes_good	<=	0	;
	else if( tune_eyes_tmax)			lane_eyes_good	<=	tune_eyes_pass	;

endmodule
 