
module	link_hubs_txdo_pmau(

	output								lane_fclk_outp	,
	output								lane_fclk_outn	,
	output								lane_fram_outp	,
	output								lane_fram_outn	,
	output								lane_dat0_outp	,
	output								lane_dat0_outn	,
	output								lane_dat1_outp	,
	output								lane_dat1_outn	,
	output								lane_dat2_outp	,
	output								lane_dat2_outn	,
	output								lane_dat3_outp	,
	output								lane_dat3_outn	,

	input								root_tune_rxdi	,

	input	[ 7: 0]						pmau_fram_txdo	,
	input	[ 7: 0]						pmau_dat3_txdo	,
	input	[ 7: 0]						pmau_dat2_txdo	,
	input	[ 7: 0]						pmau_dat1_txdo	,
	input	[ 7: 0]						pmau_dat0_txdo	,

	input	[ 7: 0]						tune_rack_fram	,
	input	[ 7: 0]						tune_rack_dat3	,
	input	[ 7: 0]						tune_rack_dat2	,
	input	[ 7: 0]						tune_rack_dat1	,
	input	[ 7: 0]						tune_rack_dat0	,

	input								link_fclk		,
	input								link_sclk		,
	input								link_rstn		);
/**********************************************************************************************************************/
	wire		root_tune_rxen	;

	link_sign_slpf					u_root_tune_rxdi_slpf(
		.mode_slpf						(root_tune_rxen	),
		.mode_sign						(root_tune_rxdi	),
		.link_sclk						(link_sclk		),
		.link_rstn						(link_rstn		));

/**********************************************************************************************************************/
	reg		[ 7: 0]						lane_fram_mbdo	;
	reg		[ 7: 0]						lane_dat0_mbdo	;
	reg		[ 7: 0]						lane_dat1_mbdo	;
	reg		[ 7: 0]						lane_dat2_mbdo	;
	reg		[ 7: 0]						lane_dat3_mbdo	;
	
	always@(posedge link_sclk or negedge link_rstn)
	if(!link_rstn) begin
		lane_fram_mbdo	<=				0				;
		lane_dat3_mbdo	<=				0				;
		lane_dat2_mbdo	<=				0				;
		lane_dat1_mbdo	<=				0				;
		lane_dat0_mbdo	<=				0				;
	end else if(root_tune_rxen)	begin
		lane_fram_mbdo	<=				8'H9A			;
		lane_dat3_mbdo	<=				8'H9A			;
		lane_dat2_mbdo	<=				8'H9A			;
		lane_dat1_mbdo	<=				8'H9A			;
		lane_dat0_mbdo	<=				8'H9A			;
	end else begin
		lane_fram_mbdo	<=				pmau_fram_txdo	|	tune_rack_fram	;
		lane_dat3_mbdo	<=				pmau_dat3_txdo	|	tune_rack_dat3	;
		lane_dat2_mbdo	<=				pmau_dat2_txdo	|	tune_rack_dat2	;
		lane_dat1_mbdo	<=				pmau_dat1_txdo	|	tune_rack_dat1	;
		lane_dat0_mbdo	<=				pmau_dat0_txdo	|	tune_rack_dat0	;
	end
//------------------------------------------------------------------------------
	wire	[ 0: 4]						lane_txdo_sbdo	;
	wire	[ 0: 4][ 7: 0]				lane_txdo_mbdo	;
	wire	[ 0: 4][ 7: 0]				lane_txdo_invt	;
	

	assign	lane_txdo_mbdo[0]	=		lane_fram_mbdo	;
	assign	lane_txdo_mbdo[1]	=		lane_dat0_mbdo	;
	assign	lane_txdo_mbdo[2]	=		lane_dat1_mbdo	;
	assign	lane_txdo_mbdo[3]	=		lane_dat2_mbdo	;
	assign	lane_txdo_mbdo[4]	=		lane_dat3_mbdo	;
			
	for(genvar i = 0 ; i < 5 ; i++)	begin:gens_rdxi_idly_bus

		gens_byte_invt				u_gens_byte_invt(
   			.byte_invt					(lane_txdo_invt[i]	),//output		[ 7: 0]	
			.byte_data					(lane_txdo_mbdo[i]	));//input		[ 7: 0]	

	 	OSERDESE3 #(
	    	.DATA_WIDTH					(8				),
			.INIT						(1'b0			),
	    	.IS_CLK_INVERTED			(1'b0			),
	    	.IS_CLKDIV_INVERTED			(1'b0			),
	    	.SIM_DEVICE					("ULTRASCALE"	)) 

		u_TXDO_SDDO_CELL (
	        .OQ							(lane_txdo_sbdo[i]	),
	        .T_OUT						(					),
	        .CLK						(link_fclk			),
	        .CLKDIV						(link_sclk			),
	        .D							(lane_txdo_invt[i]	),
	        .T							(1'b0				),
	        .RST						(~link_rstn			));
	end

	OBUFDS							LVDS_FRAM_OUTP	(
		.I								(lane_txdo_sbdo[0]	),
		.O								(lane_fram_outp		),
		.OB								(lane_fram_outn		));

	OBUFDS							LVDS_DAT0_OUTP	(
		.I								(lane_txdo_sbdo[1]	),
		.O								(lane_dat0_outp		),
		.OB								(lane_dat0_outn		));

	OBUFDS							LVDS_DAT1_OUTP	(
		.I								(lane_txdo_sbdo[2]	),
		.O								(lane_dat1_outp		),
		.OB								(lane_dat1_outn		));

	OBUFDS							LVDS_DAT2_OUTP	(
		.I								(lane_txdo_sbdo[3]	),
		.O								(lane_dat2_outp		),
		.OB								(lane_dat2_outn		));

	OBUFDS							LVDS_DAT3_OUTP	(
		.I								(lane_txdo_sbdo[4]	),
		.O								(lane_dat3_outp		),
		.OB								(lane_dat3_outn		));

	OBUFDS							LVDS_FCLK_OUTP	(
		.I								(link_fclk			),
		.O								(lane_fclk_outp		),
		.OB								(lane_fclk_outn		));

endmodule

 