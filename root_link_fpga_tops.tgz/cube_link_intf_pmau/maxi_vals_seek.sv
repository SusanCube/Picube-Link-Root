
module	maxi_vals_seek(
	output		[ 7: 0]					maxi_data	,
	input		[ 0: 4][ 7: 0]			vals_data	);
/**********************************************************************************************************************/
	wire		[ 7: 0]					maxi_0102	;
	wire		[ 7: 0]					maxi_0304	;
	wire		[ 7: 0]					maxi_1234	;

	assign	maxi_0102	= (	vals_data[0]>=	vals_data[1])	?	vals_data[0]:	vals_data[1];
	assign	maxi_0304	= (	vals_data[2]>=	vals_data[3])	?	vals_data[2]:	vals_data[3];

	assign	maxi_1234	= (	maxi_0102	>=	maxi_0304	)	?	maxi_0102	:	maxi_0304	;
	
	assign	maxi_data	= (	maxi_1234	>=	vals_data[4])	?	maxi_1234	:	vals_data[4];	
	
endmodule
 