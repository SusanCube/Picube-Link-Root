
module	link_edge_txdo_pmau(
	input								root_tune_txdo	,
	input							    host_tune_txdo_enab	,
	input		[ 8: 0]				    host_tune_txdo_taps	,
	output								host_tune_txdo_done	,
	input								host_clki		,
	input								host_rstn		,

	output								lane_fclk_outp	,
	output								lane_fclk_outn	,
	output								lane_fram_outp	,
	output								lane_fram_outn	,
	output								lane_dat0_outp	,
	output								lane_dat0_outn	,
	output								lane_dat1_outp	,
	output								lane_dat1_outn	,
	output								lane_dat2_outp	,
	output								lane_dat2_outn	,
	output								lane_dat3_outp	,
	output								lane_dat3_outn	,

	input		[ 7: 0]					pmau_fram_mbdi	,
	input		[ 7: 0]					pmau_dat3_mbdi	,
	input		[ 7: 0]					pmau_dat2_mbdi	,
	input		[ 7: 0]					pmau_dat1_mbdi	,
	input		[ 7: 0]					pmau_dat0_mbdi	,

//	input								dlys_brst		,	
	input								link_fclk		,
	input								link_sclk		,
	input								link_rstn		);
/***LANE_CLKO_TUNE*******************************************************************************************************************/

//	wire								dlys_cell_envt	;
//	wire								dlys_cell_load	;
//	wire		[ 8: 0]					dlys_cell_taps	;
//	wire		[ 8: 0]					dlys_cell_vout	;//

//	wire								tune_txdo_enab	;
//	wire								tune_txdo_done	;
//	wire		[ 8: 0]					tune_txdo_taps	;
//------------------------------------------------------------------------------
//	gens_sign_fast_slow	#( 
//		.EXTN ( 5 )	)				
//									u_gens_tune_txdo_enab(
//		.fast_sign  					(host_tune_txdo_enab	),//input	
//		.fast_clki						(host_clki		),//input	
//		.fast_rstn						(host_rstn		),//input	
//
//		.slow_sign						(tune_txdo_enab	),//output	
//		.slow_clki						(link_sclk		),//input	
//		.slow_rstn						(link_rstn		));//input	
////------------------------------------------------------------------------------
//	gens_sign_slow_fast	#( 
//		.EXTN ( 2 )	)				
//									u_gens_tune_rxdi_done(
//		.slow_sign						(tune_txdo_done	),//input	
//		.slow_clki						(link_sclk		),//input	
//		.slow_rstn						(link_rstn		),
//		
//		.fast_sign  					(host_tune_txdo_done	),//output	
//		.fast_clki						(host_clki		),//input	
//		.fast_rstn						(host_rstn		));//input	
//	
//------------------------------------------------------------------------------
//	gens_sync_gray #(	
//		.MSB ( 8 ) )				
//									u_sync_tune_dlys_taps(
//		.data_asyn						(host_tune_txdo_taps	),//input	[MSB: 0]
//		.scki							(host_clki		),//input			
//
//		.data_sync						(tune_txdo_taps	),//
//		.clki							(link_sclk		),//
//		.rstn							(link_rstn		));//
////------------------------------------------------------------------------------
//	lane_tune_dlys					u_lane_tune_txdo_dlys(
//		.dlys_cell_envt					(dlys_cell_envt		),//output	reg			
//		.dlys_cell_load					(dlys_cell_load		),//output	reg			
//		.dlys_cell_taps					(dlys_cell_taps		),//output	reg	[ 8: 0]	
//		.dlys_cell_vout					(dlys_cell_vout		),//input		[ 8: 0]	
//
//		.tune_dlys_taps					(tune_txdo_taps		),//input		[ 8: 0]	
//		.tune_dlys_enab					(tune_txdo_enab		),//input				
//		.tune_dlys_done					(tune_txdo_done		),//output				
//		.lane_sclk						(link_sclk			),//input				
//		.lane_rstn						(link_rstn			));	//input		
////------------------------------------------------------------------------------
//  	ODELAYE3 #(
//      	.CASCADE						("NONE"				),	// Cascade setting (MASTER, NONE, SLAVE_END, SLAVE_MIDDLE)
//      	.DELAY_FORMAT					("TIME"				),	// (COUNT, TIME)
//      	.DELAY_TYPE						("VAR_LOAD"			),	// Set the type of tap delay line (FIXED, VARIABLE, VAR_LOAD)
//      	.DELAY_VALUE					(9'H000				),	// Output delay tap setting
//      	.IS_CLK_INVERTED				(1'H0				),	// Optional inversion for CLK
//      	.IS_RST_INVERTED				(1'H0				),	// Optional inversion for RST
//      	.REFCLK_FREQUENCY				(320.0				),	// IDELAYCTRL clock input frequency in MHz (200.0-800.0).
//      	.SIM_DEVICE						("ULTRASCALE"		), 	// Set the device version for simulation functionality (ULTRASCALE)
//      	.UPDATE_MODE					("ASYNC"			))	// Determines when updates to the delay will take effect (ASYNC, MANUAL, SYNC)
//  	
//  	u_FCLK_ODLY_CELL (	
//  		.DATAOUT						(lane_dlys_fclk		),  // 1-bit output: Delayed data from ODATAIN input port
//  		.ODATAIN						(link_fclk			),  // 1-bit input: Data input
//  
//  		.EN_VTC							(dlys_cell_envt		),	// 1-bit input: Keep delay constant over VT
//  		.LOAD							(dlys_cell_load		),//tune_odly_reqs		),	// 1-bit input: Load DELAY_VALUE input
//  		.CNTVALUEIN						(dlys_cell_taps		),//(tune_txdo_taps		),	// 9-bit input: Counter value input
//  		.CNTVALUEOUT					(dlys_cell_vout		),//tune_txdo_vout		),//(tune_txdo_vals		),	// 9-bit output: Counter value output
//  		.CASC_IN						(1'B0				),	// 1-bit input: Cascade delay input from slave IDELAY CASCADE_OUT
//  		.CASC_OUT						(					),	// 1-bit output: Cascade delay output to IDELAY input cascade
//  		.CASC_RETURN					(1'B0				),	// 1-bit input: Cascade delay returning from slave IDELAY DATAOUT
//  		.INC							(1'H0				),  // 1-bit input: Increment/Decrement tap delay input
//  		
//  		.CE								(1'H0				),  // 1-bit input: Active-High enable increment/decrement input
//  		.CLK							( link_sclk			),  // 1-bit input: Clock input
//  		.RST							( dlys_brst			));//1'H0));	// 1-bit input: Asynchronous Reset to the DELAY_VALUE
//------------------------------------------------------------------------------
	OBUFDS							LVDS_FCLK_OUTP	(
//		.I								(lane_dlys_fclk		),
		.I								(link_fclk			),
		.O								(lane_fclk_outp		),
		.OB								(lane_fclk_outn		));			
/**********************************************************************************************************************/
	reg		[ 7: 0]						lane_fram_mbdo	;
	reg		[ 7: 0]						lane_dat3_mbdo	;
	reg		[ 7: 0]						lane_dat2_mbdo	;
	reg		[ 7: 0]						lane_dat1_mbdo	;
	reg		[ 7: 0]						lane_dat0_mbdo	;

	always@(posedge link_sclk or negedge link_rstn)
	if(!link_rstn) begin
		lane_fram_mbdo	<=				0				;
		lane_dat3_mbdo	<=				0				;
		lane_dat2_mbdo	<=				0				;
		lane_dat1_mbdo	<=				0				;
		lane_dat0_mbdo	<=				0				;
	end else if(root_tune_txdo)	begin
		lane_fram_mbdo	<=				8'H9A			;//lane_tune_patn	?		:	8'HA9	;
		lane_dat3_mbdo	<=				8'H9A			;//lane_tune_patn	?		:	8'HA9	;
		lane_dat2_mbdo	<=				8'H9A			;//lane_tune_patn	?		:	8'HA9	;
		lane_dat1_mbdo	<=				8'H9A			;//lane_tune_patn	?		:	8'HA9	;
		lane_dat0_mbdo	<=				8'H9A			;//lane_tune_patn	?		:	8'HA9	;
	end else begin
		lane_fram_mbdo	<=				pmau_fram_mbdi	;
		lane_dat3_mbdo	<=				pmau_dat3_mbdi	;
		lane_dat2_mbdo	<=				pmau_dat2_mbdi	;
		lane_dat1_mbdo	<=				pmau_dat1_mbdi	;
		lane_dat0_mbdo	<=				pmau_dat0_mbdi	;
	end
//------------------------------------------------------------------------------
	wire	[ 0: 4]						lane_txdo_sbdo	;
	wire	[ 0: 4][ 7: 0]				lane_txdo_mbdo	;
	wire	[ 0: 4][ 7: 0]				lane_txdo_invt	;


	assign	lane_txdo_mbdo[0]	=		lane_fram_mbdo	;
	assign	lane_txdo_mbdo[1]	=		lane_dat0_mbdo	;
	assign	lane_txdo_mbdo[2]	=		lane_dat1_mbdo	;
	assign	lane_txdo_mbdo[3]	=		lane_dat2_mbdo	;
	assign	lane_txdo_mbdo[4]	=		lane_dat3_mbdo	;
			
	for(genvar i = 0 ; i < 5 ; i++)	begin:gens_txdo_sbdo_bus

		gens_byte_invt				u_gens_byte_invt(
    		.byte_invt					(lane_txdo_invt[i]	),//output		[ 7: 0]	
			.byte_data					(lane_txdo_mbdo[i]	));//input		[ 7: 0]	

	 	OSERDESE3 #(
	    	.DATA_WIDTH					(8				),
			.INIT						(1'b0			),
	    	.IS_CLK_INVERTED			(1'b0			),
	    	.IS_CLKDIV_INVERTED			(1'b0			),
	    	.SIM_DEVICE					("ULTRASCALE"	)) 

		u_TXDO_SDDO_CELL (
	        .OQ							(lane_txdo_sbdo[i]	),
	        .T_OUT						(					),
	        .CLK						(link_fclk			),
	        .CLKDIV						(link_sclk			),
	        .D							(lane_txdo_invt[i]	),
	        .T							(1'b0				),
	        .RST						(~link_rstn			));
	end

	OBUFDS							LVDS_FRAM_OUTP	(
		.I								(lane_txdo_sbdo[0]	),
		.O								(lane_fram_outp		),
		.OB								(lane_fram_outn		));

	OBUFDS							LVDS_DAT0_OUTP	(
		.I								(lane_txdo_sbdo[1]	),
		.O								(lane_dat0_outp		),
		.OB								(lane_dat0_outn		));

	OBUFDS							LVDS_DAT1_OUTP	(
		.I								(lane_txdo_sbdo[2]	),
		.O								(lane_dat1_outp		),
		.OB								(lane_dat1_outn		));

	OBUFDS							LVDS_DAT2_OUTP	(
		.I								(lane_txdo_sbdo[3]	),
		.O								(lane_dat2_outp		),
		.OB								(lane_dat2_outn		));

	OBUFDS							LVDS_DAT3_OUTP	(
		.I								(lane_txdo_sbdo[4]	),
		.O								(lane_dat3_outp		),
		.OB								(lane_dat3_outn		));

/**********************************************************************************************************************/

endmodule
 