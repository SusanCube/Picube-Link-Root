
module	link_hubs_rxdi_pmau(

	input							    lane_fclk_inpp	,
	input							    lane_fclk_inpn	,
	input							    lane_fram_inpp	,
	input							    lane_fram_inpn	,
	input							    lane_dat0_inpp	,
	input							    lane_dat0_inpn	,
	input							    lane_dat1_inpp	,
	input							    lane_dat1_inpn	,
	input							    lane_dat2_inpp	,
	input							    lane_dat2_inpn	,
	input							    lane_dat3_inpp	,
	input							    lane_dat3_inpn	,

	input								root_tune_txdo	,
	
	output	reg	[ 7: 0]					pmau_fram_rxdi	,
	output	reg	[ 7: 0]					pmau_dat0_rxdi	,
	output	reg	[ 7: 0]					pmau_dat1_rxdi	,
	output	reg	[ 7: 0]					pmau_dat2_rxdi	,
	output	reg	[ 7: 0]					pmau_dat3_rxdi	,

	output		[ 7: 0]					tune_rack_fram	,
	output		[ 7: 0]					tune_rack_dat3	,
	output		[ 7: 0]					tune_rack_dat2	,
	output		[ 7: 0]					tune_rack_dat1	,
	output		[ 7: 0]					tune_rack_dat0	,

	input								link_sclk		,
	input								link_rstn		);
/***TUNE_MODE**********************************************************************************************************/
	wire								lane_fclk		;
	wire								lane_sclk		;
	wire								root_tune_txen	;

	link_sign_slpf					u_root_tune_txdo_slpf(
		.mode_slpf						(root_tune_txen	),
		.mode_sign						(root_tune_txdo	),
		.link_sclk						(link_sclk		),
		.link_rstn						(link_rstn		));
/***RXDI_CLKI**********************************************************************************************************/
	wire								lane_fclk_sbdi		;

	IBUFDS							LVDS_FCLK_PAD	(
		.I              				(lane_fclk_inpp	),
		.IB             				(lane_fclk_inpn	),
		.O              				(lane_fclk_sbdi	));

(* keep="true" *)
	BUFG							LVDS_FCLK_BUFG	(
		.I								(lane_fclk_sbdi	),
		.O								(lane_fclk		));	

(* keep="true" *)
    BUFGCE_DIV #(
        .BUFGCE_DIVIDE        			(4				),
        .IS_CE_INVERTED     			(1'B0			),
        .IS_CLR_INVERTED    			(1'B1			),
        .IS_I_INVERTED      			(1'B0			)) 
	LVDS_SCLK_BUFG (
        .O   							( lane_sclk		), 
		.I  		 					( lane_fclk_sbdi),
        .CLR 							( link_rstn		),
        .CE  							(1'b1			));
//-----------------------------------------------------------------------------
	wire								lane_fram_rxdi	;
	wire								lane_dat0_rxdi	;
	wire								lane_dat1_rxdi	;
	wire								lane_dat2_rxdi	;
	wire								lane_dat3_rxdi	;

	wire		[ 0: 4]					lane_raws_sbdi	;
	assign	lane_raws_sbdi	=	{		lane_fram_rxdi	,
										lane_dat0_rxdi	,
										lane_dat1_rxdi	,
										lane_dat2_rxdi	,
										lane_dat3_rxdi	};
//--DATYA_BUS_IBUFDS----------------------------------------------------------------------------
	IBUFDS							LVDS_FRAM_PAD	(
		.I                  			(lane_fram_inpp	),
		.IB                 			(lane_fram_inpn	),
		.O                  			(lane_fram_rxdi	));

	IBUFDS							LVDS_DAT0_PAD	(
		.I                  			(lane_dat0_inpp	),
		.IB                 			(lane_dat0_inpn	),
		.O                  			(lane_dat0_rxdi	));

	IBUFDS							LVDS_DAT1_PAD	(
		.I                  			(lane_dat1_inpp	),
		.IB                 			(lane_dat1_inpn	),
		.O                  			(lane_dat1_rxdi	));

	IBUFDS							LVDS_DAT2_PAD	(
		.I                  			(lane_dat2_inpp	),
		.IB                 			(lane_dat2_inpn	),
		.O                  			(lane_dat2_rxdi	));

	IBUFDS							LVDS_DAT3_PAD	(
		.I                  			(lane_dat3_inpp	),
		.IB                 			(lane_dat3_inpn	),
		.O                  			(lane_dat3_rxdi	));
/***DATYA_BUS_IBUFDS***************************************************************************************************/
	reg			[ 0: 4][ 7: 0]			lane_sdes_prev 	;
	wire		[ 0: 4][ 7: 0]			lane_sdes_data	;
	wire		[ 0: 4][ 7: 0]			lane_sdes_invt	;
	wire		[ 0: 4][ 7: 0]			lane_slip_data	;

	wire		[ 0: 4]					lane_slip_done	;	
	wire		[ 0: 4]					lane_slip_good	;	
//------------------------------------------------------------------------------
	for(genvar i = 0 ; i < 5 ; i++)	begin:gens_rdxi_idly_bus
	   	ISERDESE3 #(
	    	.DATA_WIDTH					(8					),// Parallel data width (4,8)
	    	.IS_CLK_B_INVERTED			(1'B1				),// Optional inversion for CLK_B
	    	.IS_CLK_INVERTED			(1'B0				),// Optional inversion for CLK
	    	.IS_RST_INVERTED			(1'B1				),// Optional inversion for RST
	    	.FIFO_ENABLE				("FALSE"			),// Enables the use of the FIFO
	    	.FIFO_SYNC_MODE				("FALSE"			),// Always set to FALSE. TRUE is reserved for later use.
	    	.SIM_DEVICE					("ULTRASCALE"		))// Set the device version for simulation functionality (ULTRASCALE)
	
	   	u_RXDI_ISDE_CELL (
	    	.FIFO_EMPTY					(					),	// 1-bit output: FIFO empty flag
	    	.INTERNAL_DIVCLK			(					),	// 1-bit output: Internally divided down clock used when FIFO is disabled (do not connect)
	    	.Q							(lane_sdes_invt[i]	),	// 8-bit registered output
	    	.D							(lane_raws_sbdi[i]	),	// 1-bit input: Serial Data Input
	    	.CLK						(lane_fclk			),	// 1-bit input: High-speed clock
	    	.CLK_B						(lane_fclk			),	// 1-bit input: Inversion of High-speed clock CLK
	    	.CLKDIV						(lane_sclk			),	// 1-bit input: Divided Clock
	    	.FIFO_RD_CLK				(1'B0				),	// 1-bit input: FIFO read clock
	    	.FIFO_RD_EN					(1'B0				),	// 1-bit input: Enables reading the FIFO when asserted
	    	.RST						(link_rstn			));	// 1-bit input: Asynchronous Reset

		gens_byte_invt				u_gens_byte_invt(
    		.byte_invt					(lane_sdes_data[i]	),//output		[ 7: 0]	
			.byte_data					(lane_sdes_invt[i]	));//input		[ 7: 0]	

		always@(posedge lane_sclk or negedge link_rstn)
		if(~link_rstn)					lane_sdes_prev[i]	<=	0	;
		else							lane_sdes_prev[i]	<=	lane_sdes_data[i]	;

		lane_tune_slip				u_lane_tune_slip(
			.lane_sdes_prev				(lane_sdes_prev[i]	),//input		[ 7: 0]	
			.lane_sdes_data				(lane_sdes_data[i]	),//input		[ 7: 0]	
			
			.lane_slip_data				(lane_slip_data[i]	),//output	reg	[ 7: 0]	
			.lane_slip_good				(lane_slip_good[i]	),//output	reg	
			.lane_slip_goal				(8'H9A				),//input		[ 7: 0]	

			.lane_slip_enab				(root_tune_txen		),//input		
			.lane_slip_done				(lane_slip_done[i]	),//output	reg	
			.lane_slip_step				(					),
		
			.lane_sclk					(lane_sclk			),//input				
			.lane_rstn					(link_rstn			));//input				

	end
/**********************************************************************************************************************/
	wire	tune_link_pass		=	&{	root_tune_txen	,	lane_slip_done	,	lane_slip_good	};	
	
	link_hubs_tune_acks				u_link_hubs_tune_acks(
		.tune_link_pass					(tune_link_pass	),//input				
		.lane_sclk						(lane_sclk		),//input				

		.tune_rack_fram					(tune_rack_fram	),//output	reg	[ 7: 0]	
		.tune_rack_dat3					(tune_rack_dat3	),//output	reg	[ 7: 0]	
		.tune_rack_dat2					(tune_rack_dat2	),//output	reg	[ 7: 0]	
		.tune_rack_dat1					(tune_rack_dat1	),//output	reg	[ 7: 0]	
		.tune_rack_dat0					(tune_rack_dat0	),//output	reg	[ 7: 0]	
		.link_sclk						(link_sclk				),//input				
		.link_rstn						(link_rstn				));//input				
/**********************************************************************************************************************/
	wire	[ 7: 0]						lane_fram_mbdi	=	lane_slip_data[0];
	wire	[ 7: 0]						lane_dat0_mbdi	=	lane_slip_data[1];
	wire	[ 7: 0]						lane_dat1_mbdi	=	lane_slip_data[2];
	wire	[ 7: 0]						lane_dat2_mbdi	=	lane_slip_data[3];
	wire	[ 7: 0]						lane_dat3_mbdi	=	lane_slip_data[4];

	reg		[ 7: 0]						lane_fram_m2di	;

	always@(posedge lane_sclk or negedge link_rstn)
	if(~link_rstn) 						lane_fram_m2di	<=	0	;
	else 								lane_fram_m2di	<=	lane_fram_mbdi	;
//------------------------------------------------------------------------------
	wire								rxdi_fram_csen	;
	wire								rxdi_fram_rise	;
	wire								rxdi_fram_fall	;
	wire								rxdi_fram_body	;
	wire	[31: 0]						rxdi_fram_data	;

	
	assign	rxdi_fram_rise	=  		{	root_tune_txen	,	lane_fram_m2di	, 	lane_fram_mbdi	}	==	17'H000FF	;
	assign	rxdi_fram_fall	=  		{	root_tune_txen	,	lane_fram_m2di	, 	lane_fram_mbdi	}	==	17'H0FF00	;
	assign	rxdi_fram_body	=  		{ 	root_tune_txen	,	lane_fram_m2di	, 	lane_fram_mbdi	}	==	17'H0FFFF	;
	assign	rxdi_fram_csen	=	|	{	rxdi_fram_rise	,	rxdi_fram_body	,	rxdi_fram_fall	}	;
		
	
	assign	rxdi_fram_data	=		{	lane_dat3_mbdi	,	
										lane_dat2_mbdi	,	
										lane_dat1_mbdi	,	
										lane_dat0_mbdi	};
//------------------------------------------------------------------------------
	reg									lane_push_csen	;
	reg			[31: 0]					lane_push_data	;
	reg			[ 1: 0]					lane_push_tags	;
	reg			[15: 0]					lane_push_addr	;
	
	wire		[15: 0]					lane_pops_dptr	;
	wire								lane_push_init	;
	wire								lane_push_clrs	;
	wire								lane_push_drdy	;
	wire								lane_push_ovfl	;

	assign	lane_push_init	=			rxdi_fram_rise	;
	assign	lane_push_ovfl	=			lane_push_addr	>=	lane_pops_dptr + 2	;	
	assign	lane_push_drdy	=	&{		lane_push_csen	,	lane_push_ovfl	   };	
	
	always@(posedge lane_sclk or negedge link_rstn)
	if(~link_rstn)	begin
		lane_push_csen	<=	0	;
		lane_push_data	<=	0	;
		lane_push_tags	<=	0	;
	end else 		begin
		lane_push_csen	<=	rxdi_fram_csen	;
		lane_push_data	<=	rxdi_fram_data	;
		lane_push_tags	<=	rxdi_fram_rise	?	2'H1	:
							rxdi_fram_fall	?	2'H3	:
							rxdi_fram_body	?	2'H2	:	2'H0	;
	end	
	
	always@(posedge lane_sclk or negedge link_rstn)
	if(~link_rstn) 						lane_push_addr	<=	0	;
	else if(lane_push_init)				lane_push_addr	<=	0	;
	else if(lane_push_csen)				lane_push_addr	<=	lane_push_addr + 1	;
	else if(lane_push_clrs)				lane_push_addr	<=	0	;
/**********************************************************************************************************************/
	reg									lane_pops_csen	;
//	reg									lane_pops_ssen	;

	reg									lane_pops_done	;
	reg			[15: 0]					lane_pops_addr	;

	wire		[15: 0]					lane_push_dptr	;
	wire								lane_pops_reqs	;
	wire		[31: 0]					lane_pops_data	;
	wire		[ 1: 0]					lane_pops_tags	;
	
	wire								lane_pops_lead	;
	wire								lane_pops_body	;
	wire								lane_pops_coda	;
	wire								lane_pops_drdy	;
//	wire								lane_pops_doen	;	

	wire								lane_pops_udfl	;

	assign	lane_pops_udfl	=			lane_push_dptr	>	lane_pops_addr	;	
	assign	lane_pops_drdy 	=	&	{	lane_pops_csen	,	lane_pops_udfl };

	assign	lane_pops_drdy 	=	&	{	lane_pops_csen	,	lane_push_dptr	>	lane_pops_addr };
	assign	lane_pops_lead	=		{	lane_pops_drdy	,	lane_pops_tags	} 	==	3'B101		;
	assign	lane_pops_body	=		{	lane_pops_drdy	,	lane_pops_tags	} 	==	3'B110		;
	assign	lane_pops_coda	=		{	lane_pops_drdy	,	lane_pops_tags	} 	==	3'B111		;
//	assign	lane_pops_doen	=	&	{	lane_pops_csen	,	lane_pops_ssen	,	lane_pops_drdy	};				

	always@(posedge link_sclk or negedge link_rstn)
	if(~link_rstn) 						lane_pops_csen	<=	0	;
	else if(lane_pops_reqs)				lane_pops_csen	<=	1	;
	else if(lane_pops_coda)				lane_pops_csen	<=	0	;

//	always@(posedge link_sclk or negedge link_rstn)
//	if(~link_rstn) 						lane_pops_ssen	<=	0	;
//	else 								lane_pops_ssen	<=	lane_pops_csen	;

	always@(posedge link_sclk or negedge link_rstn)
	if(~link_rstn) 						lane_pops_done	<=	0	;
	else if(lane_pops_reqs)				lane_pops_done	<=	0	;
	else if(lane_pops_coda)				lane_pops_done	<=	1	;

	always@(posedge link_sclk or negedge link_rstn)
	if(~link_rstn) 						lane_pops_addr	<=	0	;
	else if(lane_pops_reqs)				lane_pops_addr	<=	0	;
	else if(lane_pops_coda)				lane_pops_addr	<=	0	;	
	else if(lane_pops_drdy)				lane_pops_addr	<=	lane_pops_addr + 1	;
/**********************************************************************************************************************/
	gens_sync_gray #( .MSB (15) )	
									u_rxdi_port_push_dptr(
		.data_asyn						(lane_push_addr		),
		.scki							(lane_sclk			),
		.data_sync						(lane_push_dptr		),
		.clki							(link_sclk			),
		.rstn							(link_rstn			));

	gens_sync_gray #( .MSB (15) )	
									u_rxdi_port_pops_dptr(
		.data_asyn						(lane_pops_addr		),
		.scki							(link_sclk			),
		.data_sync						(lane_pops_dptr		),
		.clki							(lane_sclk			),
		.rstn							(link_rstn			));

	gens_edge_fast_slow	#( .EXTN (5) )	
									u_fram_pops_done_edge(
		.slow_edge						(lane_push_clrs	),//output	
		.slow_clki						(lane_sclk		),//input	
		.slow_rstn						(link_rstn		),//input	
		
		.fast_sign  					(lane_pops_done	),//input	
		.fast_clki						(link_sclk		),//input	
		.fast_rstn						(link_rstn		));//input	

	gens_edge_slow_fast				u_fram_pops_reqs_edge(
		.fast_edge						(lane_pops_reqs	),//output	
		.fast_clki						(link_sclk		),//input	
		.fast_rstn						(link_rstn		),//input	
		.slow_sign  					(lane_push_drdy	),//input	
		.slow_clki						(lane_sclk		),//input	
		.slow_rstn						(link_rstn		));//input	
	
	trip_port_tags					u_rxdi_port_push_fifo(
		.wport_csen						(lane_push_csen		),
		.wport_addr						(lane_push_addr[2:0]),
		.wport_tags						(lane_push_tags		),
		.wport_data						(lane_push_data		),
		.wport_rstn						(lane_push_init		),
		.wport_clki						(lane_sclk			),

		.rport_addr						(lane_pops_addr[2:0]),
		.rport_tags						(lane_pops_tags		),
		.rport_data						(lane_pops_data		),
		.rport_clki						(link_sclk			));
/**********************************************************************************************************************/
	always@(posedge link_sclk or negedge link_rstn)
	if(~link_rstn)						begin
		pmau_fram_rxdi		<=			0	;
		pmau_dat3_rxdi		<=			0	;
		pmau_dat2_rxdi		<=			0	;
		pmau_dat1_rxdi		<=			0	;
		pmau_dat0_rxdi		<=			0	;
	end else if(~lane_pops_drdy)		begin
		pmau_fram_rxdi		<=			0	;
		pmau_dat3_rxdi		<=			0	;
		pmau_dat2_rxdi		<=			0	;
		pmau_dat1_rxdi		<=			0	;
		pmau_dat0_rxdi		<=			0	;
	end else 							begin
		pmau_fram_rxdi		<=	{8{ ~ (	lane_pops_tags	==	2'H3)	}}	;
		pmau_dat3_rxdi		<=			lane_pops_data[31:24]	;
		pmau_dat2_rxdi		<=			lane_pops_data[23:16]	;
		pmau_dat1_rxdi		<=			lane_pops_data[15: 8]	;
		pmau_dat0_rxdi		<=			lane_pops_data[ 7: 0]	;
	end
	
endmodule
//	assign	pmau_fram_rxdi	=			lane_pops_doen	?	{8{	lane_pops_lead|lane_pops_body	}}	:8'H00	;
//	assign	pmau_dat3_rxdi	=			lane_pops_doen	?	lane_pops_data[31:24]	:	0	;
//	assign	pmau_dat2_rxdi	=			lane_pops_doen	?	lane_pops_data[23:16]	:	0	;
//	assign	pmau_dat1_rxdi	=			lane_pops_doen	?	lane_pops_data[15: 8]	:	0	;
//	assign	pmau_dat0_rxdi	=			lane_pops_doen	?	lane_pops_data[ 7: 0]	:	0	;

