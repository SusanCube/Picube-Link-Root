
module	lane_tune_dlys(
	output	reg							dlys_cell_envt	,
	output	reg							dlys_cell_load	,
	output		[ 8: 0]					dlys_cell_taps	,
	input		[ 8: 0]					dlys_cell_vout	,

	input								tune_dlys_enab	,
	input		[ 8: 0]					tune_dlys_taps	,
	output								tune_dlys_done	,
	input								lane_sclk		,
	input								lane_rstn		);
/**********************************************************************************************************************/
	reg			[ 3: 0]					tune_dlys_mfsm	;

	parameter	TUNE_DLYS_IDLE	=		4'H0	;
	parameter	TUNE_DLYS_DONE	=		4'H8	;
	parameter	TUNE_ENVT_DISA	=		4'H1	;
	parameter	TUNE_DLYS_STEP	=		4'H2	;
	parameter	TUNE_DLYS_UPDT	=		4'H3	;
	parameter	TUNE_DLYS_LOAD	=		4'H4	;
	parameter	TUNE_DLYS_VLID	=		4'H5	;
	parameter	TUNE_DLYS_LOOP	=		4'H6	;
	parameter	TUNE_ENVT_ACTV	=		4'H7	;
//------------------------------------------------------------------------------
	wire								envt_disa_tmax	;
	wire								dlys_updt_tmax	;
	wire								dlys_vlid_tmax	;
	wire								envt_actv_tmax	;
	wire								dlys_goal_meet	;
	
	always@(posedge lane_sclk or negedge lane_rstn )				
	if(~lane_rstn)						tune_dlys_mfsm	<=	TUNE_DLYS_IDLE	;
	else if(~tune_dlys_enab)			tune_dlys_mfsm	<=	TUNE_DLYS_IDLE	;
	else begin
		case(tune_dlys_mfsm)	
			TUNE_DLYS_IDLE		:		tune_dlys_mfsm	<=											TUNE_ENVT_DISA	;
			
			TUNE_ENVT_DISA		:		tune_dlys_mfsm	<=	envt_disa_tmax	?	TUNE_DLYS_STEP	:	TUNE_ENVT_DISA	;
			TUNE_DLYS_STEP		:		tune_dlys_mfsm	<=											TUNE_DLYS_UPDT	;
			TUNE_DLYS_UPDT		:		tune_dlys_mfsm	<=	dlys_updt_tmax	?	TUNE_DLYS_LOAD	:	TUNE_DLYS_UPDT	;
			TUNE_DLYS_LOAD		:		tune_dlys_mfsm	<=											TUNE_DLYS_VLID	;
			TUNE_DLYS_VLID		:		tune_dlys_mfsm	<=	dlys_vlid_tmax	?	TUNE_DLYS_LOOP	:	TUNE_DLYS_VLID	;
			TUNE_DLYS_LOOP		:		tune_dlys_mfsm	<=	dlys_goal_meet	?	TUNE_ENVT_ACTV	:	TUNE_DLYS_STEP	;
			TUNE_ENVT_ACTV		:		tune_dlys_mfsm	<=	envt_actv_tmax	?	TUNE_DLYS_DONE	:	TUNE_ENVT_ACTV	;

			TUNE_DLYS_DONE		:		tune_dlys_mfsm	<=											TUNE_DLYS_DONE	;
			default				:		tune_dlys_mfsm	<=											TUNE_DLYS_IDLE	;
		endcase
	end
/**********************************************************************************************************************/
//	wire	tune_dlys_idle	=			tune_dlys_mfsm	==	TUNE_DLYS_IDLE	;
	wire	tune_envt_disa	=			tune_dlys_mfsm	==	TUNE_ENVT_DISA	;
	wire	tune_envt_actv	=			tune_dlys_mfsm	==	TUNE_ENVT_ACTV	;
	
	wire	tune_dlys_step	=			tune_dlys_mfsm	==	TUNE_DLYS_STEP	;
	wire	tune_dlys_updt	=			tune_dlys_mfsm	==	TUNE_DLYS_UPDT	;
	wire	tune_dlys_load	=			tune_dlys_mfsm	==	TUNE_DLYS_LOAD	;
	wire	tune_dlys_vlid	=			tune_dlys_mfsm	==	TUNE_DLYS_VLID	;
	wire	tune_dlys_loop	=			tune_dlys_mfsm	==	TUNE_DLYS_LOOP	;
	assign	tune_dlys_done	=			tune_dlys_mfsm	==	TUNE_DLYS_DONE	;	
/**********************************************************************************************************************/
	reg		[ 4: 0]						tune_dlys_time	=	10'H000			;

	
	assign	envt_disa_tmax	=	&{		tune_envt_disa	,	tune_dlys_time == 	5'H18	};
	assign	envt_actv_tmax	=	&{		tune_envt_actv	,	tune_dlys_time == 	5'H18	};
	assign	dlys_updt_tmax	=	&{		tune_dlys_updt	,	tune_dlys_time == 	5'H18	};
	assign	dlys_vlid_tmax	=	&{		tune_dlys_vlid	,	tune_dlys_time == 	5'H18	};
	
	wire	tune_time_reqs	=	|{		tune_envt_disa	,	tune_dlys_updt	,	tune_dlys_vlid	,	tune_envt_actv	};									
//--------------------------------------TUNE_TIME
	always@(posedge lane_sclk or negedge lane_rstn )				
	if(~lane_rstn)						tune_dlys_time	<=	0	;
	else if(~tune_time_reqs)			tune_dlys_time	<=	0	;
	else 								tune_dlys_time	<=	tune_dlys_time + 1	;
/**********************************************************************************************************************/
	reg		[ 6: 0]						tune_dlys_cfig	;
	reg		[ 1: 0]						tune_dlys_tail	;
	reg		[ 6: 0]						tune_dlys_base	;
	reg		[ 6: 0]						tune_dlys_vals	;

	wire	[ 6: 0]						dlys_goal_next	;

	wire	dlys_goal_gecs	=			tune_dlys_cfig	>=	tune_dlys_base	;
	wire	dlys_goal_eqcs	=			tune_dlys_cfig	==	tune_dlys_base	;

	wire  	dlys_goal_inc1	=		&{	dlys_goal_gecs , ~	dlys_goal_eqcs };
	wire  	dlys_goal_dec1	=		&{~ dlys_goal_gecs , ~	dlys_goal_eqcs };

	assign	dlys_goal_meet	=			tune_dlys_cfig	==	tune_dlys_vals	;
	assign	dlys_goal_next	=			dlys_goal_inc1	?	tune_dlys_base + 1	:
										dlys_goal_dec1	?	tune_dlys_base - 1	:	tune_dlys_base	;
//--------------------------------------
	always@(posedge lane_sclk or negedge lane_rstn )				
	if(~lane_rstn)						tune_dlys_cfig	<=	0	;
	else if(tune_envt_disa)				tune_dlys_cfig	<=	tune_dlys_taps[8:2]	;
//--------------------------------------
	always@(posedge lane_sclk or negedge lane_rstn )				
	if(~lane_rstn)						tune_dlys_tail	<=	0	;
	else if(tune_envt_disa)				tune_dlys_tail	<=	tune_dlys_taps[1:0]	;
//--------------------------------------
	always@(posedge lane_sclk or negedge lane_rstn )				
	if(~lane_rstn)						tune_dlys_base	<=	0	;
	else if(envt_disa_tmax)				tune_dlys_base	<=	dlys_cell_vout[8:2]	;
	else if(tune_dlys_step)				tune_dlys_base	<= 	dlys_goal_next	;	
/**********************************************************************************************************************/
//--------------------------------------UPDT_TAPS
	always@(posedge lane_sclk or negedge lane_rstn )				
	if(~lane_rstn)						tune_dlys_vals	<=	0	;
	else if(tune_dlys_step)				tune_dlys_vals	<= 	tune_dlys_base	;
//--------------------------------------UPDT_LOAD
	always@(posedge lane_sclk or negedge lane_rstn )		
	if(~lane_rstn)						dlys_cell_load	<=	0	;
	else								dlys_cell_load	<=	tune_dlys_load	;
//--------------------------------------UPDT_ENVT
 	always@(posedge lane_sclk or negedge lane_rstn )		//ACTV/DISA_ENVT
 	if(~lane_rstn)						dlys_cell_envt	<=	1	;
 	else if(tune_envt_disa)				dlys_cell_envt	<=	0	;
 	else if(tune_envt_actv)				dlys_cell_envt	<=	1	;

	assign 	dlys_cell_taps 	=		{	tune_dlys_vals	,	tune_dlys_tail	};									


	
	
	








endmodule
 