
module	link_sign_slpf(
	output	reg							mode_slpf		,
	input								mode_sign		,
			
	input								link_sclk		,
	input								link_rstn		);
/**********************************************************************************************************************/
	reg			[5: 0]					mode_samp		;

	wire								mode_smax	= 	&		mode_samp		;			

	wire								mode_samp_lt08	=		mode_samp[5:3] == 3'H0	;
	wire		[5:0]					mode_samp_decs	=		mode_samp_lt08	?	6'H0 	:	mode_samp - 8	;
	wire		[5:0]					mode_samp_incs	=										mode_samp + 1	;

	wire		mode_samp_csen	=		mode_samp	>	6'D50	;

	always@(posedge link_sclk or negedge link_rstn)
	if(~link_rstn)						mode_samp	<=	0	;
	else if(~mode_sign)					mode_samp	<=	mode_samp_decs	;
	else if(~mode_smax)					mode_samp	<=	mode_samp_incs	;

	always@(posedge link_sclk or negedge link_rstn)
	if(~link_rstn)						mode_slpf	<=	0	;
	else								mode_slpf	<=	mode_samp_csen	;

	
	
/**********************************************************************************************************************/

endmodule
 