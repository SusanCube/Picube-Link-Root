

module axi4_lite_bridge #(
    parameter AW    =   19  ,
    parameter DW    =   31  )(
    input                               s_clki          ,
    input                               s_rstn          
    input       [AW:0]                  s_awaddr        ,
    input                               s_awvalid       ,
    output                              s_awready       ,

    input       [DW:0]                  s_wdata         ,
    input       [WS:0]                  s_wstrb         ,
    input                               s_wvalid        ,
    output                              s_wready        ,

    output      [ 1:0]                  s_bresp         ,
    output                              s_bvalid        ,
    input                               s_bready        ,

    input       [AW:0]                  s_araddr        ,
    input                               s_arvalid       ,
    output                              s_arready       ,

    output      [DW:0]                  s_rdata         ,
    output      [ 1:0]                  s_rresp         ,
    output                              s_rvalid        ,
    input                               s_rready        ,

    output      [AW:0]                  m0_awaddr       ,
	output      [ 2:0]                  m0_awprot       ,
    output                              m0_awvalid      ,
    input                               m0_awready      ,

    output      [DW:0]                  m0_wdata        ,
    output      [WS:0]                  m0_wstrb        ,
    output                              m0_wvalid       ,
    input                               m0_wready       ,

    input       [ 1:0]                  m0_bresp         ,
    input                               m0_bvalid        ,
    output                              m0_bready        ,

    output      [AW:0]                  m0_araddr        ,
    output                              m0_arvalid       ,
    input                               m0_arready       ,

    input       [DW:0]                  m0_rdata         ,
    input       [ 1:0]                  m0_rresp         ,
    input                               m0_rvalid        ,
    output                              m0_rready        ,

    output      [AW:0]                  m1_awaddr       ,
	output      [ 2:0]                  m1_awprot       ,
    output                              m1_awvalid      ,
    input                               m1_awready      ,

    output      [DW:0]                  m1_wdata        ,
    output      [WS:0]                  m1_wstrb        ,
    output                              m1_wvalid       ,
    input                               m1_wready       ,

    input       [ 1:0]                  m1_bresp         ,
    input                               m1_bvalid        ,
    output                              m1_bready        ,

    output      [AW:0]                  m1_araddr        ,
    output                              m1_arvalid       ,
    input                               m1_arready       ,

    input       [DW:0]                  m1_rdata         ,
    input       [ 1:0]                  m1_rresp         ,
    input                               m1_rvalid        ,
    output                              m1_rready        );
/***********************************************************************************************************************/
    reg                                 wsel_m0         ;
    reg                                 wsel_m1         ;
    reg                                 rsel_m0         ;
    reg                                 rsel_m1         ;

/***********************************************************************************************************************/
    assign  m0_awaddr   =               wsel_m0 ?   s_awaddr    :  20'H0    ;
    assign  m1_awaddr   =               wsel_m1 ?   s_awaddr    :  20'H0    ;
    assign  m0_awvalid  =               wsel_m0 ?   s_awvalid   :   1'H0    ;
    assign  m1_awvalid  =               wsel_m1 ?   s_awvalid   :   1'H0    ;
	assign  m0_awprot 	=               wsel_m0 ?   s_awprot   	:	3'H0    ;
    assign  m1_awprot 	=               wsel_m1 ?   s_awprot   	:	3'H0    ;

    assign  s_awread    =               wsel_m0 ?   m0_awready  :
                                        wsel_m1 ?   m1_awready  :   1'B0    ;
//------------------------------------------------------------------------------
    assign  m0_wdata    =               wsel_m0 ?   s_wdata     :   32'H0   ;
    assign  m1_wdata    =               wsel_m1 ?   s_wdata     :   32'H0   ;
    assign  m0_wstrb    =               wsel_m0 ?   s_wstrb     :    4'H0   ;
    assign  m1_wstrb    =               wsel_m1 ?   s_wstrb     :    4'H0   ;
    assign  m0_wvalid   =               wsel_m0 ?   s_wvalid    :    1'H0   ;
    assign  m1_wvalid   =               wsel_m1 ?   s_wvalid    :    1'H0   ;

    assign  s_wready    =               wsel_m0 ?   m0_wready   :
                                        wsel_m1 ?   m1_wready   :   1'B0    ;
//------------------------------------------------------------------------------
    assign  m0_bready   =               wsel_m0 ?   s_bready    :   1'b0    ;
    assign  m1_bready   =               wsel_m1 ?   s_bready    :   1'b0    ;
                                    
    assign  s_bvalid    =               wsel_m0 ?   m0_bvalid   :
                                        wsel_m1 ?   m1_bvalid   :   1'B0    ;
                              
    assign  s_bresp     =               wsel_m0 ?   m0_bresp    :
                                        wsel_m1 ?   m1_bresp    :   2'H0    ;
/***********************************************************************************************************************/
    assign  m0_araddr   =               rsel_m0 ?   s_araddr    :  20'H0    ;
    assign  m1_araddr   =               rsel_m1 ?   s_araddr    :  20'H0    ;
    assign  m0_arvalid  =               rsel_m0 ?   s_arvalid   :  20'H0    ;
    assign  m1_arvalid  =               rsel_m1 ?   s_arvalid   :  20'H0    ;

    assign  s_arready   =               rsel_m0 ?   m0_arready  :
                                        rsel_m1 ?   m1_arready  :   1'B0    ;
//------------------------------------------------------------------------------
    assign  m0_rready   =               rsel_m0 ?   s_rready    :   1'b0    ;
    assign  m1_rready   =               rsel_m1 ?   s_rready    :   1'b0    ;

    assign  s_rdata     =               rsel_m0 ?   m0_rdata    :
                                        rsel_m1 ?   m1_rdata    :  32'H0    ;

    assign  s_rresp     =               rsel_m0 ?   m0_rresp    :
                                        rsel_m1 ?   m1_rresp    :   2'H0    ;

    assign  s_rvalid    =               rsel_m0 ?   m0_rvalid   :
                                        rsel_m1 ?   m1_rvalid   :   2'H0    ;
/***********************************************************************************************************************/
    wire                                wsel_m0_reqs    ,   wsel_m1_reqs    ;
    wire                                rsel_m0_reqs    ,   rsel_m1_reqs    ;
    wire                                wsel_mx_done    ,   rsel_mx_done    ;
    
    assign  wsel_m0_reqs    =   &{  ~   s_awaddr[AW]    ,   s_awvalid   };
    assign  wsel_m1_reqs    =   &{      s_awaddr[AW]    ,   s_awvalid   };
    assign  wsel_mx_done    =   &{      s_bready        ,   s_bvalid    ,   s_bresp ==  2'H0   };
    
    assign  rsel_m0_reqs    =   &{  ~   s_araddr[AW]    ,   s_arvalid   };
    assign  rsel_m1_reqs    =   &{      s_araddr[AW]    ,   s_arvalid   };
    assign  rsel_mx_done    =   &{      s_rready        ,   s_rvalid    ,   s_rresp ==  2'H0   };

    always@(posedge a_clki or negedge a_rstn)
    if(~a_rstn)                         wsel_m0 <=  0   ;
    else if(wsel_mx_done)               wsel_m0 <=  0   ;
    else if(wsel_m0_reqs)               wsel_m0 <=  1   ;

    always@(posedge a_clki or negedge a_rstn)
    if(~a_rstn)                         wsel_m1 <=  0   ;
    else if(wsel_mx_done)               wsel_m1 <=  0   ;
    else if(wsel_m1_reqs)               wsel_m1 <=  1   ;

    always@(posedge a_clki or negedge a_rstn)
    if(~a_rstn)                         rsel_m0 <=  0   ;
    else if(rsel_mx_done)               rsel_m0 <=  0   ;
    else if(rsel_m0_reqs)               rsel_m0 <=  1   ;

    always@(posedge a_clki or negedge a_rstn)
    if(~a_rstn)                         rsel_m1 <=  0   ;
    else if(rsel_mx_done)               rsel_m1 <=  0   ;
    else if(rsel_m1_reqs)               rsel_m1 <=  1   ;

endmodule