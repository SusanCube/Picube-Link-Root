module	pcie_combo_core(
	input								s_clki 			,
	input								s_rstn			,
	
	input		[19: 0]					s_awaddr 		,
	input								s_awprot		,
	input								s_awvalid		,
	input								s_awready		,
	
	input		[31: 0]					s_wdata 		,
	input		[ 3: 0]					s_wstrb 		,
	input								s_wvalid 		,
	input								s_wready 		,
	
	output		[ 1: 0]					s_bresp 		,
	output								s_bvalid 		,
	output								s_bready 		,
	
	input		[19: 0]					s_araddr 		,
	input								s_arvalid		,
	input								s_arready		,
	
	input		[31: 0]					s_rdata 		,
	input		[ 1: 0]					s_rresp 		,
	input								s_rvalid 		,
	input								s_rready 		,
	
	output								pcie_bram_csen	,	
	output		[19: 0]					pcie_bram_addr	,	
	output		[ 3: 0]					pcie_bram_wben	,	
	output		[31: 0]					pcie_bram_wdata	,
	output								pcie_bram_rdata	,
	output								pcie_bclk		);
/**********************************************************************************************************************/
    wire		[19: 0]                 m0_awaddr 	;
	wire		[ 2: 0]					m0_awprot 	;
    wire	                            m0_awvalid	;
    wire	                            m0_awready	;
    wire		[31: 0]           	    m0_wdata  	;
    wire		[ 3: 0]           	    m0_wstrb  	;
    wire		                  	    m0_wvalid 	;
    wire		                  	    m0_wready 	;
    wire		[ 1: 0]           	    m0_bresp  	;
    wire		                  	    m0_bvalid 	;
    wire		                  	    m0_bready 	;
    wire		[19: 0]           	    m0_araddr 	;
    wire		                  	    m0_arvalid	;
    wire		                  	    m0_arready	;
    wire		[31: 0]           	    m0_rdata  	;
    wire		[ 1: 0]           	    m0_rresp  	;
    wire		                  	    m0_rvalid 	;
    wire		                  	    m0_rready 	;
 
    wire		[19: 0]            	 	m1_awaddr 	;
	wire		[ 2: 0]					m1_awprot 	;	
    wire		       					m1_awvalid	;
    wire		       					m1_awready	;
    wire		[31: 0]					m1_wdata  	;
    wire		[ 3: 0]					m1_wstrb  	;
    wire		       					m1_wvalid 	;
    wire		       					m1_wready 	;
    wire		[ 1: 0]					m1_bresp  	;
    wire		       					m1_bvalid 	;
    wire		       					m1_bready 	;
    wire		[19: 0]					m1_araddr 	;
    wire		       					m1_arvalid	;
    wire		       					m1_arready	;
    wire		[31: 0]					m1_rdata  	;
    wire		[ 1: 0]					m1_rresp  	;
    wire		       					m1_rvalid 	;
    wire		       					m1_rready 	;
/**********************************************************************************************************************/
	axi4_lite_bridge #( 
		.AW( 19 ), .DW( 31 ))		u_axi4_lite_bridge(
		.s_clki  						(s_clki					),//input             
		.s_rstn  						(s_rstn					),//input             
		.s_awaddr 						(s_awaddr				),//input       [AW:0]
		.s_awprot 						(s_awprot				),//input       [AW:0]
		.s_awvalid						(s_awvalid				),//input             
		.s_awready						(s_awready				),//output            
		.s_wdata  						(s_wdata				),//input       [DW:0]
		.s_wstrb  						(s_wstrb				),//input       [WS:0]
		.s_wvalid 						(s_wvalid				),//input             
		.s_wready 						(s_wready				),//output            
		.s_bresp  						(s_bresp				),//output      [ 1:0]
		.s_bvalid 						(s_bvalid				),//output            
		.s_bready 						(s_bready				),//input             
		.s_araddr 						(s_araddr				),//input       [AW:0]
		.s_arvalid						(s_arvalid				),//input             
		.s_arready						(s_arready				),//output            
		.s_rdata  						(s_rdata				),//output      [DW:0]
		.s_rresp  						(s_rresp				),//output      [ 1:0]
		.s_rvalid 						(s_rvalid				),//output            
		.s_rready 						(s_rready				),//input             

        .m0_awaddr   					(m0_awaddr				),//output      [AW:0]
        .m0_awvalid  					(m0_awvalid				),//output            
        .m0_awprot  					(m0_awprot				),//output            
        .m0_awready  					(m0_awready				),//input             
        .m0_wdata    					(m0_wdata				),//output      [DW:0]
        .m0_wstrb    					(m0_wstrb				),//output      [WS:0]
        .m0_wvalid   					(m0_wvalid				),//output            
        .m0_wready   					(m0_wready				),//input             
        .m0_bresp     					(m0_bresp				),//input       [ 1:0]
        .m0_bvalid    					(m0_bvalid				),//input             
        .m0_bready    					(m0_bready				),//output            
        .m0_araddr						(m0_araddr				),//output      [AW:0]
        .m0_arvalid						(m0_arvalid				),//output            
        .m0_arready						(m0_arready				),//input             
        .m0_rdata						(m0_rdata				),//input       [DW:0]
        .m0_rresp						(m0_rresp				),//input       [ 1:0]
        .m0_rvalid						(m0_rvalid				),//input             
        .m0_rready						(m0_rready				),//output

        .m1_awaddr   					(m1_awaddr				),//output      [AW:0]
        .m1_awvalid  					(m1_awvalid				),//output            
        .m1_awprot  					(m1_awprot				),//output            
        .m1_awready  					(m1_awready				),//input             
        .m1_wdata    					(m1_wdata				),//output      [DW:0]
        .m1_wstrb    					(m1_wstrb				),//output      [WS:0]
        .m1_wvalid   					(m1_wvalid				),//output            
        .m1_wready   					(m1_wready				),//input             
        .m1_bresp     					(m1_bresp				),//input       [ 1:0]
        .m1_bvalid    					(m1_bvalid				),//input             
        .m1_bready    					(m1_bready				),//output            
        .m1_araddr						(m1_araddr				),//output      [AW:0]
        .m1_arvalid						(m1_arvalid				),//output            
        .m1_arready						(m1_arready				),//input             
        .m1_rdata						(m1_rdata				),//input       [DW:0]
        .m1_rresp						(m1_rresp				),//input       [ 1:0]
        .m1_rvalid						(m1_rvalid				),//input             
        .m1_rready						(m1_rready				));//output
/**********************************************************************************************************************/
	pcie_bram_ctrl 					u_axil_bram_ctrl(
		.s_axi_awaddr 					(m0_awaddr				),//: IN STD_LOGIC_VECTOR(19 DOWNTO 0);
		.s_axi_awprot 					(m0_awprot				),//: IN STD_LOGIC_VECTOR(2 DOWNTO 0);
		.s_axi_awvalid 					(m0_awvalid				),//: IN STD_LOGIC;
		.s_axi_awready 					(m0_awready				),//: OUT STD_LOGIC;
		
		.s_axi_wdata 					(m0_wdata				),//: IN STD_LOGIC_VECTOR(31 DOWNTO 0);
		.s_axi_wstrb 					(m0_wstrb				),//: IN STD_LOGIC_VECTOR(3 DOWNTO 0);
		.s_axi_wvalid 					(m0_wvalid				),//: IN STD_LOGIC;
		.s_axi_wready 					(m0_wready				),//: OUT STD_LOGIC;
		
		.s_axi_bresp 					(m0_bresp				),//: OUT STD_LOGIC_VECTOR(1 DOWNTO 0);
		.s_axi_bvalid 					(m0_bvalid				),//: OUT STD_LOGIC;
		.s_axi_bready 					(m0_bready				),//: IN STD_LOGIC;
		
		.s_axi_araddr 					(m0_araddr				),//: IN STD_LOGIC_VECTOR(19 DOWNTO 0);
		.s_axi_arprot 					(m0_arprot				),//: IN STD_LOGIC_VECTOR(2 DOWNTO 0);
		.s_axi_arvalid 					(m0_arvalid				),//: IN STD_LOGIC;
		.s_axi_arready 					(m0_arready				),//: OUT STD_LOGIC;
		
		.s_axi_rdata 					(m0_rdata				),//: OUT STD_LOGIC_VECTOR(31 DOWNTO 0);
		.s_axi_rresp 					(m0_rresp				),//: OUT STD_LOGIC_VECTOR(1 DOWNTO 0);
		.s_axi_rvalid 					(m0_rvalid				),//: OUT STD_LOGIC;
		.s_axi_rready 					(m0_rready				),//: IN STD_LOGIC;
		
		.s_axi_aclk 					(axi4_aclk 				),//: IN STD_LOGIC;
		.s_axi_aresetn 					(axi4_rstn 				),//: IN STD_LOGIC;
		
    
		.bram_en_a 						(pcie_bram_csen			),// OUT STD_LOGIC;
		.bram_addr_a 					(pcie_bram_addr			),// OUT STD_LOGIC_VECTOR(19 DOWNTO 0);
		.bram_we_a 						(pcie_bram_wben			),// OUT STD_LOGIC_VECTOR(3 DOWNTO 0);
		.bram_wrdata_a 					(pcie_bram_wdata		),// OUT STD_LOGIC_VECTOR(31 DOWNTO 0);
		.bram_rddata_a 					(pcie_bram_rdata		),// IN STD_LOGIC_VECTOR(31 DOWNTO 0)
		.bram_rst_a 					(),//pcie_rset				),// OUT STD_LOGIC; active high
		.bram_clk_a 					(pcie_bclk				));// OUT STD_LOGIC;